import { e as encryptCredential, d as decryptCredential } from "./chunks/encryption-CqawdIkC.js";
const WALRUS_PUBLISHER = "https://publisher.walrus-testnet.walrus.space";
const WALRUS_AGGREGATOR = "https://aggregator.walrus-testnet.walrus.space";
const DEFAULT_EPOCHS = 3;
function extractBlobId(response) {
  if (response.newlyCreated) return response.newlyCreated.blobObject.blobId;
  if (response.alreadyCertified) return response.alreadyCertified.blobId;
  throw new Error("Walrus response missing blob_id");
}
async function uploadBlob(data, epochs = DEFAULT_EPOCHS) {
  const response = await fetch(
    `${WALRUS_PUBLISHER}/v1/blobs?epochs=${epochs}`,
    {
      method: "PUT",
      headers: { "Content-Type": "application/octet-stream" },
      body: data
    }
  );
  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Walrus upload failed (${response.status}): ${text}`);
  }
  const json = await response.json();
  return extractBlobId(json);
}
async function downloadBlob(blobId) {
  const response = await fetch(`${WALRUS_AGGREGATOR}/v1/blobs/${blobId}`);
  if (!response.ok) {
    throw new Error(`Walrus download failed (${response.status}): ${blobId}`);
  }
  const buffer = await response.arrayBuffer();
  return new Uint8Array(buffer);
}
async function uploadEncryptedCredential(encryptedB64) {
  const bytes = new TextEncoder().encode(encryptedB64);
  return uploadBlob(bytes);
}
async function downloadEncryptedCredential(blobId) {
  const bytes = await downloadBlob(blobId);
  return new TextDecoder().decode(bytes);
}
globalThis.window = globalThis;
const handlers = {
  INIT_VAULT: handleInitVault,
  LOGOUT: handleLogout,
  LOCK_VAULT: handleLockVault,
  GET_USER_PROFILE: handleGetUserProfile,
  SAVE_CREDENTIAL: handleSaveCredential,
  DECRYPT_CREDENTIAL: handleDecryptCredential,
  DELETE_CREDENTIAL: handleDeleteCredential,
  GET_CREDENTIALS_FOR_URL: handleGetCredentialsForUrl
};
chrome.runtime.onMessage.addListener(
  (message, _sender, sendResponse) => {
    const handler = handlers[message.type];
    if (!handler) {
      sendResponse({ success: false, error: `Unknown message type: ${message.type}` });
      return false;
    }
    handler(message.payload).then(sendResponse).catch((err) => {
      console.error(`Handler ${message.type} failed:`, err);
      sendResponse({
        success: false,
        error: err instanceof Error ? err.message : String(err)
      });
    });
    return true;
  }
);
async function handleInitVault(payload) {
  const { publicKey } = payload;
  try {
    await storeKeyShare(publicKey);
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
      if (tab.id) {
        chrome.tabs.sendMessage(tab.id, {
          type: "AUTH_UPDATE",
          payload: { publicKey }
        }).catch(() => {
        });
      }
    }
    return { success: true };
  } catch (err) {
    return { success: false, error: err instanceof Error ? err.message : String(err) };
  }
}
async function handleLogout(_payload) {
  try {
    await chrome.storage.local.remove("authState");
    return { success: true };
  } catch (err) {
    return { success: false, error: err instanceof Error ? err.message : String(err) };
  }
}
async function handleLockVault(payload) {
  const { publicKey } = payload;
  try {
    await chrome.storage.session.remove(`session_ks_${publicKey}`);
    return { success: true };
  } catch (err) {
    return { success: false, error: err instanceof Error ? err.message : String(err) };
  }
}
async function handleGetUserProfile(payload) {
  const { publicKey } = payload;
  try {
    const entries = await getLocalEntries(publicKey);
    return { success: true, data: { entries: entries.filter((e) => e.isActive) } };
  } catch (err) {
    return { success: true, data: { entries: [] } };
  }
}
async function handleSaveCredential(payload) {
  const { publicKey, label, url, username, password, notes } = payload;
  try {
    const keyShare = await getKeyShare(publicKey);
    const encryptedB64 = await encryptCredential(
      { password, notes, version: 1 },
      keyShare
    );
    let blobId = `local_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    try {
      blobId = await uploadEncryptedCredential(encryptedB64);
    } catch (walrusErr) {
      console.warn("Walrus upload failed, storing locally:", walrusErr);
      await chrome.storage.local.set({ [`blob_${blobId}`]: encryptedB64 });
    }
    const now = Math.floor(Date.now() / 1e3);
    const existing = await getLocalEntries(publicKey);
    const entry = {
      index: existing.length,
      label,
      url,
      username,
      encryptedBlobId: blobId,
      isActive: true,
      createdAt: now,
      updatedAt: now
    };
    await setLocalEntries(publicKey, [...existing, entry]);
    return { success: true, data: entry };
  } catch (err) {
    return { success: false, error: err instanceof Error ? err.message : String(err) };
  }
}
async function handleDecryptCredential(payload) {
  const { publicKey, encryptedBlobId } = payload;
  try {
    let encryptedB64;
    if (encryptedBlobId.startsWith("local_")) {
      const result = await chrome.storage.local.get(`blob_${encryptedBlobId}`);
      encryptedB64 = result[`blob_${encryptedBlobId}`];
      if (!encryptedB64) throw new Error("Local blob not found");
    } else {
      encryptedB64 = await downloadEncryptedCredential(encryptedBlobId);
    }
    const keyShare = await getKeyShare(publicKey);
    const credential = await decryptCredential(encryptedB64, keyShare);
    return { success: true, data: { password: credential.password } };
  } catch (err) {
    return { success: false, error: err instanceof Error ? err.message : String(err) };
  }
}
async function handleDeleteCredential(payload) {
  const { publicKey, entryIndex } = payload;
  try {
    const entries = await getLocalEntries(publicKey);
    await setLocalEntries(
      publicKey,
      entries.map((e) => e.index === entryIndex ? { ...e, isActive: false } : e)
    );
    return { success: true };
  } catch (err) {
    return { success: false, error: err instanceof Error ? err.message : String(err) };
  }
}
async function handleGetCredentialsForUrl(payload) {
  const { publicKey, url } = payload;
  try {
    const entries = await getLocalEntries(publicKey);
    const domain = new URL(url).hostname;
    const matches = entries.filter((e) => e.isActive && e.url.includes(domain));
    return { success: true, data: matches };
  } catch (err) {
    return { success: false, error: err instanceof Error ? err.message : String(err) };
  }
}
async function getKeyShare(publicKey) {
  const session = await chrome.storage.session.get(`session_ks_${publicKey}`);
  const sessionKs = session[`session_ks_${publicKey}`];
  if (sessionKs) return sessionKs;
  const local = await chrome.storage.local.get(`keyShare_${publicKey}`);
  const localKs = local[`keyShare_${publicKey}`];
  if (localKs) return localKs;
  throw new Error("Vault is locked — please enter your PIN");
}
async function storeKeyShare(_publicKey) {
}
async function getLocalEntries(publicKey) {
  const key = `entries_${publicKey}`;
  const result = await chrome.storage.local.get(key);
  return result[key] ?? [];
}
async function setLocalEntries(publicKey, entries) {
  await chrome.storage.local.set({ [`entries_${publicKey}`]: entries });
}
//# sourceMappingURL=background.js.map
