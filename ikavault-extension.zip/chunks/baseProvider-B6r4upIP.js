import { g as getDefaultExportFromCjs, c as commonjsGlobal } from "./_commonjsHelpers-3KnhdHPJ.js";
import { b as buffer, s as safeBufferExports } from "./index-kAnL5Ffb.js";
function _typeof(o) {
  "@babel/helpers - typeof";
  return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
    return typeof o2;
  } : function(o2) {
    return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
  }, _typeof(o);
}
function toPrimitive(t, r) {
  if ("object" != _typeof(t) || !t) return t;
  var e = t[Symbol.toPrimitive];
  if (void 0 !== e) {
    var i = e.call(t, r);
    if ("object" != _typeof(i)) return i;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return ("string" === r ? String : Number)(t);
}
function toPropertyKey(t) {
  var i = toPrimitive(t, "string");
  return "symbol" == _typeof(i) ? i : i + "";
}
function _defineProperty(e, r, t) {
  return (r = toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
    value: t,
    enumerable: true,
    configurable: true,
    writable: true
  }) : e[r] = t, e;
}
function fixProto(target, prototype) {
  var setPrototypeOf = Object.setPrototypeOf;
  setPrototypeOf ? setPrototypeOf(target, prototype) : target.__proto__ = prototype;
}
function fixStack(target, fn) {
  if (fn === void 0) {
    fn = target.constructor;
  }
  var captureStackTrace = Error.captureStackTrace;
  captureStackTrace && captureStackTrace(target, fn);
}
var __extends = /* @__PURE__ */ function() {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) {
        if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
      }
    };
    return _extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    _extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var CustomError = function(_super) {
  __extends(CustomError2, _super);
  function CustomError2(message, options) {
    var _newTarget = this.constructor;
    var _this = _super.call(this, message, options) || this;
    Object.defineProperty(_this, "name", {
      value: _newTarget.name,
      enumerable: false,
      configurable: true
    });
    fixProto(_this, _newTarget.prototype);
    fixStack(_this);
    return _this;
  }
  return CustomError2;
}(Error);
function serializeError$1(args) {
  const index = args.findIndex((arg) => arg instanceof Error);
  const msgIndex = args.findIndex((arg) => typeof arg === "string");
  const apiErrorIdx = args.findIndex((arg) => arg && typeof arg === "object" && "status" in arg && "type" in arg);
  let err;
  if (apiErrorIdx !== -1) {
    const apiError = args[apiErrorIdx];
    err = new Error(`${apiError.status} ${apiError.type.toString()} ${apiError.statusText}`);
  } else if (index !== -1) {
    err = args.splice(index, 1)[0];
  } else if (msgIndex !== -1) {
    err = new Error(args.splice(msgIndex, 1)[0]);
  } else {
    err = new Error("Unknown error");
  }
  return [err, args];
}
class Web3AuthError extends CustomError {
  constructor(code, message, cause) {
    super(message);
    _defineProperty(this, "code", void 0);
    _defineProperty(this, "message", void 0);
    _defineProperty(this, "cause", void 0);
    this.code = code;
    this.message = message || "";
    this.cause = cause;
    Object.defineProperty(this, "name", {
      value: "Web3AuthError"
    });
  }
  toJSON() {
    return {
      name: this.name,
      code: this.code,
      message: this.message,
      cause: serializeError$1([this.cause])
    };
  }
  toString() {
    return JSON.stringify(this.toJSON());
  }
}
class WalletInitializationError extends Web3AuthError {
  constructor(code, message, cause) {
    super(code, message, cause);
    Object.defineProperty(this, "name", {
      value: "WalletInitializationError"
    });
  }
  static fromCode(code, extraMessage = "", cause) {
    return new WalletInitializationError(code, `${WalletInitializationError.messages[code]}, ${extraMessage}`, cause);
  }
  // Custom methods
  static notFound(extraMessage = "", cause) {
    return WalletInitializationError.fromCode(5001, extraMessage, cause);
  }
  static notInstalled(extraMessage = "", cause) {
    return WalletInitializationError.fromCode(5002, extraMessage, cause);
  }
  static notReady(extraMessage = "", cause) {
    return WalletInitializationError.fromCode(5003, extraMessage, cause);
  }
  static windowBlocked(extraMessage = "", cause) {
    return WalletInitializationError.fromCode(5004, extraMessage, cause);
  }
  static windowClosed(extraMessage = "", cause) {
    return WalletInitializationError.fromCode(5005, extraMessage, cause);
  }
  static incompatibleChainNameSpace(extraMessage = "", cause) {
    return WalletInitializationError.fromCode(5006, extraMessage, cause);
  }
  static duplicateAdapterError(extraMessage = "", cause) {
    return WalletInitializationError.fromCode(5007, extraMessage, cause);
  }
  static invalidProviderConfigError(extraMessage = "", cause) {
    return WalletInitializationError.fromCode(5008, extraMessage, cause);
  }
  static providerNotReadyError(extraMessage = "", cause) {
    return WalletInitializationError.fromCode(5009, extraMessage, cause);
  }
  static rpcConnectionError(extraMessage = "", cause) {
    return WalletInitializationError.fromCode(5010, extraMessage, cause);
  }
  static invalidParams(extraMessage = "", cause) {
    return WalletInitializationError.fromCode(5011, extraMessage, cause);
  }
  static invalidNetwork(extraMessage = "", cause) {
    return WalletInitializationError.fromCode(5013, extraMessage, cause);
  }
}
_defineProperty(WalletInitializationError, "messages", {
  5e3: "Custom",
  5001: "Wallet is not found",
  5002: "Wallet is not installed",
  5003: "Wallet is not ready yet",
  5004: "Wallet window is blocked",
  5005: "Wallet window has been closed by the user",
  5006: "Incompatible chain namespace provided",
  5007: "Adapter has already been included",
  5008: "Invalid provider Config",
  5009: "Provider is not ready yet",
  5010: "Failed to connect with rpc url",
  5011: "Invalid params passed in",
  5013: "Invalid network provided"
});
class WalletLoginError extends Web3AuthError {
  constructor(code, message, cause) {
    super(code, message, cause);
    Object.defineProperty(this, "name", {
      value: "WalletLoginError"
    });
  }
  static fromCode(code, extraMessage = "", cause) {
    return new WalletLoginError(code, `${WalletLoginError.messages[code]}. ${extraMessage}`, cause);
  }
  static connectionError(extraMessage = "", cause) {
    return WalletLoginError.fromCode(5111, extraMessage, cause);
  }
  static disconnectionError(extraMessage = "", cause) {
    return WalletLoginError.fromCode(5112, extraMessage, cause);
  }
  static notConnectedError(extraMessage = "", cause) {
    return WalletLoginError.fromCode(5113, extraMessage, cause);
  }
  static popupClosed(extraMessage = "", cause) {
    return WalletLoginError.fromCode(5114, extraMessage, cause);
  }
  static mfaEnabled(extraMessage = "", cause) {
    return WalletLoginError.fromCode(5115, extraMessage, cause);
  }
  static chainConfigNotAdded(extraMessage = "", cause) {
    return WalletLoginError.fromCode(5116, extraMessage, cause);
  }
  static unsupportedOperation(extraMessage = "", cause) {
    return WalletLoginError.fromCode(5117, extraMessage, cause);
  }
  static coreKitKeyNotFound(extraMessage = "", cause) {
    return WalletLoginError.fromCode(5118, extraMessage, cause);
  }
  static userNotLoggedIn(extraMessage = "", cause) {
    return WalletLoginError.fromCode(5119, extraMessage, cause);
  }
}
_defineProperty(WalletLoginError, "messages", {
  5e3: "Custom",
  5111: "Failed to connect with wallet",
  5112: "Failed to disconnect from wallet",
  5113: "Wallet is not connected",
  5114: "Wallet popup has been closed by the user",
  5115: "User has already enabled mfa, please use the @web3auth/web3auth-web sdk for login with mfa",
  5116: "Chain config has not been added. Please add the chain config before calling switchChain",
  5117: "Unsupported operation",
  5118: "useCoreKitKey flag is enabled but coreKitKey is not available",
  5119: "User not logged in."
});
class WalletOperationsError extends Web3AuthError {
  constructor(code, message, cause) {
    super(code, message, cause);
    Object.defineProperty(this, "name", {
      value: "WalletOperationsError"
    });
  }
  static fromCode(code, extraMessage = "", cause) {
    return new WalletOperationsError(code, `${WalletOperationsError.messages[code]}, ${extraMessage}`, cause);
  }
  // Custom methods
  static chainIDNotAllowed(extraMessage = "", cause) {
    return WalletOperationsError.fromCode(5201, extraMessage, cause);
  }
  static operationNotAllowed(extraMessage = "", cause) {
    return WalletOperationsError.fromCode(5202, extraMessage, cause);
  }
  static chainNamespaceNotAllowed(extraMessage = "", cause) {
    return WalletOperationsError.fromCode(5203, extraMessage, cause);
  }
}
_defineProperty(WalletOperationsError, "messages", {
  5e3: "Custom",
  5201: "Provided chainId is not allowed",
  5202: "This operation is not allowed"
});
class WalletProviderError extends Web3AuthError {
  constructor(code, message, cause) {
    super(code, message, cause);
    Object.defineProperty(this, "name", {
      value: "WalletProviderError"
    });
  }
  static fromCode(code, extraMessage = "", cause) {
    return new WalletOperationsError(code, `${WalletProviderError.messages[code]}, ${extraMessage}`, cause);
  }
  // Custom methods
  static invalidRequestArgs(extraMessage = "", cause) {
    return WalletOperationsError.fromCode(5301, extraMessage, cause);
  }
  static invalidRequestMethod(extraMessage = "", cause) {
    return WalletOperationsError.fromCode(5302, extraMessage, cause);
  }
  static invalidRequestParams(extraMessage = "", cause) {
    return WalletOperationsError.fromCode(5303, extraMessage, cause);
  }
}
_defineProperty(WalletProviderError, "messages", {
  5e3: "Custom",
  5301: "Expected a single, non-array, object argument.",
  5302: "'args.method' must be a non-empty string.",
  5303: "'args.params' must be an object or array if provided."
});
const CHAIN_NAMESPACES = {
  EIP155: "eip155",
  SOLANA: "solana",
  CASPER: "casper",
  XRPL: "xrpl",
  OTHER: "other"
};
const ADAPTER_NAMESPACES = {
  MULTICHAIN: "multichain"
};
var loglevel$1 = { exports: {} };
(function(module) {
  (function(root, definition) {
    if (module.exports) {
      module.exports = definition();
    } else {
      root.log = definition();
    }
  })(commonjsGlobal, function() {
    var noop2 = function() {
    };
    var undefinedType = "undefined";
    var isIE = typeof window !== undefinedType && typeof window.navigator !== undefinedType && /Trident\/|MSIE /.test(window.navigator.userAgent);
    var logMethods = [
      "trace",
      "debug",
      "info",
      "warn",
      "error"
    ];
    var _loggersByName = {};
    var defaultLogger = null;
    function bindMethod(obj, methodName) {
      var method = obj[methodName];
      if (typeof method.bind === "function") {
        return method.bind(obj);
      } else {
        try {
          return Function.prototype.bind.call(method, obj);
        } catch (e) {
          return function() {
            return Function.prototype.apply.apply(method, [obj, arguments]);
          };
        }
      }
    }
    function traceForIE() {
      if (console.log) {
        if (console.log.apply) {
          console.log.apply(console, arguments);
        } else {
          Function.prototype.apply.apply(console.log, [console, arguments]);
        }
      }
      if (console.trace) console.trace();
    }
    function realMethod(methodName) {
      if (methodName === "debug") {
        methodName = "log";
      }
      if (typeof console === undefinedType) {
        return false;
      } else if (methodName === "trace" && isIE) {
        return traceForIE;
      } else if (console[methodName] !== void 0) {
        return bindMethod(console, methodName);
      } else if (console.log !== void 0) {
        return bindMethod(console, "log");
      } else {
        return noop2;
      }
    }
    function replaceLoggingMethods() {
      var level = this.getLevel();
      for (var i = 0; i < logMethods.length; i++) {
        var methodName = logMethods[i];
        this[methodName] = i < level ? noop2 : this.methodFactory(methodName, level, this.name);
      }
      this.log = this.debug;
      if (typeof console === undefinedType && level < this.levels.SILENT) {
        return "No console available for logging";
      }
    }
    function enableLoggingWhenConsoleArrives(methodName) {
      return function() {
        if (typeof console !== undefinedType) {
          replaceLoggingMethods.call(this);
          this[methodName].apply(this, arguments);
        }
      };
    }
    function defaultMethodFactory(methodName, _level, _loggerName) {
      return realMethod(methodName) || enableLoggingWhenConsoleArrives.apply(this, arguments);
    }
    function Logger(name, factory) {
      var self2 = this;
      var inheritedLevel;
      var defaultLevel;
      var userLevel;
      var storageKey = "loglevel";
      if (typeof name === "string") {
        storageKey += ":" + name;
      } else if (typeof name === "symbol") {
        storageKey = void 0;
      }
      function persistLevelIfPossible(levelNum) {
        var levelName = (logMethods[levelNum] || "silent").toUpperCase();
        if (typeof window === undefinedType || !storageKey) return;
        try {
          window.localStorage[storageKey] = levelName;
          return;
        } catch (ignore) {
        }
        try {
          window.document.cookie = encodeURIComponent(storageKey) + "=" + levelName + ";";
        } catch (ignore) {
        }
      }
      function getPersistedLevel() {
        var storedLevel;
        if (typeof window === undefinedType || !storageKey) return;
        try {
          storedLevel = window.localStorage[storageKey];
        } catch (ignore) {
        }
        if (typeof storedLevel === undefinedType) {
          try {
            var cookie = window.document.cookie;
            var cookieName = encodeURIComponent(storageKey);
            var location = cookie.indexOf(cookieName + "=");
            if (location !== -1) {
              storedLevel = /^([^;]+)/.exec(
                cookie.slice(location + cookieName.length + 1)
              )[1];
            }
          } catch (ignore) {
          }
        }
        if (self2.levels[storedLevel] === void 0) {
          storedLevel = void 0;
        }
        return storedLevel;
      }
      function clearPersistedLevel() {
        if (typeof window === undefinedType || !storageKey) return;
        try {
          window.localStorage.removeItem(storageKey);
        } catch (ignore) {
        }
        try {
          window.document.cookie = encodeURIComponent(storageKey) + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC";
        } catch (ignore) {
        }
      }
      function normalizeLevel(input) {
        var level = input;
        if (typeof level === "string" && self2.levels[level.toUpperCase()] !== void 0) {
          level = self2.levels[level.toUpperCase()];
        }
        if (typeof level === "number" && level >= 0 && level <= self2.levels.SILENT) {
          return level;
        } else {
          throw new TypeError("log.setLevel() called with invalid level: " + input);
        }
      }
      self2.name = name;
      self2.levels = {
        "TRACE": 0,
        "DEBUG": 1,
        "INFO": 2,
        "WARN": 3,
        "ERROR": 4,
        "SILENT": 5
      };
      self2.methodFactory = factory || defaultMethodFactory;
      self2.getLevel = function() {
        if (userLevel != null) {
          return userLevel;
        } else if (defaultLevel != null) {
          return defaultLevel;
        } else {
          return inheritedLevel;
        }
      };
      self2.setLevel = function(level, persist) {
        userLevel = normalizeLevel(level);
        if (persist !== false) {
          persistLevelIfPossible(userLevel);
        }
        return replaceLoggingMethods.call(self2);
      };
      self2.setDefaultLevel = function(level) {
        defaultLevel = normalizeLevel(level);
        if (!getPersistedLevel()) {
          self2.setLevel(level, false);
        }
      };
      self2.resetLevel = function() {
        userLevel = null;
        clearPersistedLevel();
        replaceLoggingMethods.call(self2);
      };
      self2.enableAll = function(persist) {
        self2.setLevel(self2.levels.TRACE, persist);
      };
      self2.disableAll = function(persist) {
        self2.setLevel(self2.levels.SILENT, persist);
      };
      self2.rebuild = function() {
        if (defaultLogger !== self2) {
          inheritedLevel = normalizeLevel(defaultLogger.getLevel());
        }
        replaceLoggingMethods.call(self2);
        if (defaultLogger === self2) {
          for (var childName in _loggersByName) {
            _loggersByName[childName].rebuild();
          }
        }
      };
      inheritedLevel = normalizeLevel(
        defaultLogger ? defaultLogger.getLevel() : "WARN"
      );
      var initialLevel = getPersistedLevel();
      if (initialLevel != null) {
        userLevel = normalizeLevel(initialLevel);
      }
      replaceLoggingMethods.call(self2);
    }
    defaultLogger = new Logger();
    defaultLogger.getLogger = function getLogger(name) {
      if (typeof name !== "symbol" && typeof name !== "string" || name === "") {
        throw new TypeError("You must supply a name when creating a logger.");
      }
      var logger = _loggersByName[name];
      if (!logger) {
        logger = _loggersByName[name] = new Logger(
          name,
          defaultLogger.methodFactory
        );
      }
      return logger;
    };
    var _log = typeof window !== undefinedType ? window.log : void 0;
    defaultLogger.noConflict = function() {
      if (typeof window !== undefinedType && window.log === defaultLogger) {
        window.log = _log;
      }
      return defaultLogger;
    };
    defaultLogger.getLoggers = function getLoggers() {
      return _loggersByName;
    };
    defaultLogger["default"] = defaultLogger;
    return defaultLogger;
  });
})(loglevel$1);
var loglevelExports = loglevel$1.exports;
const log = /* @__PURE__ */ getDefaultExportFromCjs(loglevelExports);
function ownKeys(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var o = Object.getOwnPropertySymbols(e);
    r && (o = o.filter(function(r2) {
      return Object.getOwnPropertyDescriptor(e, r2).enumerable;
    })), t.push.apply(t, o);
  }
  return t;
}
function _objectSpread2(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = null != arguments[r] ? arguments[r] : {};
    r % 2 ? ownKeys(Object(t), true).forEach(function(r2) {
      _defineProperty(e, r2, t[r2]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r2) {
      Object.defineProperty(e, r2, Object.getOwnPropertyDescriptor(t, r2));
    });
  }
  return e;
}
var shams;
var hasRequiredShams;
function requireShams() {
  if (hasRequiredShams) return shams;
  hasRequiredShams = 1;
  shams = function hasSymbols2() {
    if (typeof Symbol !== "function" || typeof Object.getOwnPropertySymbols !== "function") {
      return false;
    }
    if (typeof Symbol.iterator === "symbol") {
      return true;
    }
    var obj = {};
    var sym = Symbol("test");
    var symObj = Object(sym);
    if (typeof sym === "string") {
      return false;
    }
    if (Object.prototype.toString.call(sym) !== "[object Symbol]") {
      return false;
    }
    if (Object.prototype.toString.call(symObj) !== "[object Symbol]") {
      return false;
    }
    var symVal = 42;
    obj[sym] = symVal;
    for (var _ in obj) {
      return false;
    }
    if (typeof Object.keys === "function" && Object.keys(obj).length !== 0) {
      return false;
    }
    if (typeof Object.getOwnPropertyNames === "function" && Object.getOwnPropertyNames(obj).length !== 0) {
      return false;
    }
    var syms = Object.getOwnPropertySymbols(obj);
    if (syms.length !== 1 || syms[0] !== sym) {
      return false;
    }
    if (!Object.prototype.propertyIsEnumerable.call(obj, sym)) {
      return false;
    }
    if (typeof Object.getOwnPropertyDescriptor === "function") {
      var descriptor = (
        /** @type {PropertyDescriptor} */
        Object.getOwnPropertyDescriptor(obj, sym)
      );
      if (descriptor.value !== symVal || descriptor.enumerable !== true) {
        return false;
      }
    }
    return true;
  };
  return shams;
}
var esObjectAtoms = Object;
var esErrors = Error;
var _eval = EvalError;
var range = RangeError;
var ref = ReferenceError;
var syntax = SyntaxError;
var type = TypeError;
var uri = URIError;
var abs$1 = Math.abs;
var floor$1 = Math.floor;
var max$2 = Math.max;
var min$1 = Math.min;
var pow$1 = Math.pow;
var round$1 = Math.round;
var _isNaN = Number.isNaN || function isNaN2(a) {
  return a !== a;
};
var $isNaN = _isNaN;
var sign$1 = function sign(number) {
  if ($isNaN(number) || number === 0) {
    return number;
  }
  return number < 0 ? -1 : 1;
};
var gOPD$1 = Object.getOwnPropertyDescriptor;
var $gOPD$1 = gOPD$1;
if ($gOPD$1) {
  try {
    $gOPD$1([], "length");
  } catch (e) {
    $gOPD$1 = null;
  }
}
var gopd$1 = $gOPD$1;
var $defineProperty$3 = Object.defineProperty || false;
if ($defineProperty$3) {
  try {
    $defineProperty$3({}, "a", { value: 1 });
  } catch (e) {
    $defineProperty$3 = false;
  }
}
var esDefineProperty = $defineProperty$3;
var hasSymbols$1;
var hasRequiredHasSymbols;
function requireHasSymbols() {
  if (hasRequiredHasSymbols) return hasSymbols$1;
  hasRequiredHasSymbols = 1;
  var origSymbol = typeof Symbol !== "undefined" && Symbol;
  var hasSymbolSham = requireShams();
  hasSymbols$1 = function hasNativeSymbols() {
    if (typeof origSymbol !== "function") {
      return false;
    }
    if (typeof Symbol !== "function") {
      return false;
    }
    if (typeof origSymbol("foo") !== "symbol") {
      return false;
    }
    if (typeof Symbol("bar") !== "symbol") {
      return false;
    }
    return hasSymbolSham();
  };
  return hasSymbols$1;
}
var Reflect_getPrototypeOf;
var hasRequiredReflect_getPrototypeOf;
function requireReflect_getPrototypeOf() {
  if (hasRequiredReflect_getPrototypeOf) return Reflect_getPrototypeOf;
  hasRequiredReflect_getPrototypeOf = 1;
  Reflect_getPrototypeOf = typeof Reflect !== "undefined" && Reflect.getPrototypeOf || null;
  return Reflect_getPrototypeOf;
}
var Object_getPrototypeOf;
var hasRequiredObject_getPrototypeOf;
function requireObject_getPrototypeOf() {
  if (hasRequiredObject_getPrototypeOf) return Object_getPrototypeOf;
  hasRequiredObject_getPrototypeOf = 1;
  var $Object2 = esObjectAtoms;
  Object_getPrototypeOf = $Object2.getPrototypeOf || null;
  return Object_getPrototypeOf;
}
var ERROR_MESSAGE = "Function.prototype.bind called on incompatible ";
var toStr$1 = Object.prototype.toString;
var max$1 = Math.max;
var funcType = "[object Function]";
var concatty = function concatty2(a, b) {
  var arr = [];
  for (var i = 0; i < a.length; i += 1) {
    arr[i] = a[i];
  }
  for (var j = 0; j < b.length; j += 1) {
    arr[j + a.length] = b[j];
  }
  return arr;
};
var slicy = function slicy2(arrLike, offset) {
  var arr = [];
  for (var i = offset, j = 0; i < arrLike.length; i += 1, j += 1) {
    arr[j] = arrLike[i];
  }
  return arr;
};
var joiny = function(arr, joiner) {
  var str = "";
  for (var i = 0; i < arr.length; i += 1) {
    str += arr[i];
    if (i + 1 < arr.length) {
      str += joiner;
    }
  }
  return str;
};
var implementation$2 = function bind(that) {
  var target = this;
  if (typeof target !== "function" || toStr$1.apply(target) !== funcType) {
    throw new TypeError(ERROR_MESSAGE + target);
  }
  var args = slicy(arguments, 1);
  var bound;
  var binder = function() {
    if (this instanceof bound) {
      var result = target.apply(
        this,
        concatty(args, arguments)
      );
      if (Object(result) === result) {
        return result;
      }
      return this;
    }
    return target.apply(
      that,
      concatty(args, arguments)
    );
  };
  var boundLength = max$1(0, target.length - args.length);
  var boundArgs = [];
  for (var i = 0; i < boundLength; i++) {
    boundArgs[i] = "$" + i;
  }
  bound = Function("binder", "return function (" + joiny(boundArgs, ",") + "){ return binder.apply(this,arguments); }")(binder);
  if (target.prototype) {
    var Empty = function Empty2() {
    };
    Empty.prototype = target.prototype;
    bound.prototype = new Empty();
    Empty.prototype = null;
  }
  return bound;
};
var implementation$1 = implementation$2;
var functionBind = Function.prototype.bind || implementation$1;
var functionCall = Function.prototype.call;
var functionApply = Function.prototype.apply;
var reflectApply = typeof Reflect !== "undefined" && Reflect && Reflect.apply;
var bind$3 = functionBind;
var $apply$2 = functionApply;
var $call$2 = functionCall;
var $reflectApply = reflectApply;
var actualApply$1 = $reflectApply || bind$3.call($call$2, $apply$2);
var bind$2 = functionBind;
var $TypeError$3 = type;
var $call$1 = functionCall;
var $actualApply = actualApply$1;
var callBindApplyHelpers = function callBindBasic(args) {
  if (args.length < 1 || typeof args[0] !== "function") {
    throw new $TypeError$3("a function is required");
  }
  return $actualApply(bind$2, $call$1, args);
};
var get;
var hasRequiredGet;
function requireGet() {
  if (hasRequiredGet) return get;
  hasRequiredGet = 1;
  var callBind2 = callBindApplyHelpers;
  var gOPD2 = gopd$1;
  var hasProtoAccessor;
  try {
    hasProtoAccessor = /** @type {{ __proto__?: typeof Array.prototype }} */
    [].__proto__ === Array.prototype;
  } catch (e) {
    if (!e || typeof e !== "object" || !("code" in e) || e.code !== "ERR_PROTO_ACCESS") {
      throw e;
    }
  }
  var desc = !!hasProtoAccessor && gOPD2 && gOPD2(
    Object.prototype,
    /** @type {keyof typeof Object.prototype} */
    "__proto__"
  );
  var $Object2 = Object;
  var $getPrototypeOf = $Object2.getPrototypeOf;
  get = desc && typeof desc.get === "function" ? callBind2([desc.get]) : typeof $getPrototypeOf === "function" ? (
    /** @type {import('./get')} */
    function getDunder(value) {
      return $getPrototypeOf(value == null ? value : $Object2(value));
    }
  ) : false;
  return get;
}
var getProto$1;
var hasRequiredGetProto;
function requireGetProto() {
  if (hasRequiredGetProto) return getProto$1;
  hasRequiredGetProto = 1;
  var reflectGetProto = requireReflect_getPrototypeOf();
  var originalGetProto = requireObject_getPrototypeOf();
  var getDunderProto = requireGet();
  getProto$1 = reflectGetProto ? function getProto2(O) {
    return reflectGetProto(O);
  } : originalGetProto ? function getProto2(O) {
    if (!O || typeof O !== "object" && typeof O !== "function") {
      throw new TypeError("getProto: not an object");
    }
    return originalGetProto(O);
  } : getDunderProto ? function getProto2(O) {
    return getDunderProto(O);
  } : null;
  return getProto$1;
}
var hasown;
var hasRequiredHasown;
function requireHasown() {
  if (hasRequiredHasown) return hasown;
  hasRequiredHasown = 1;
  var call = Function.prototype.call;
  var $hasOwn = Object.prototype.hasOwnProperty;
  var bind3 = functionBind;
  hasown = bind3.call(call, $hasOwn);
  return hasown;
}
var undefined$1;
var $Object = esObjectAtoms;
var $Error = esErrors;
var $EvalError = _eval;
var $RangeError = range;
var $ReferenceError = ref;
var $SyntaxError$1 = syntax;
var $TypeError$2 = type;
var $URIError = uri;
var abs = abs$1;
var floor = floor$1;
var max = max$2;
var min = min$1;
var pow = pow$1;
var round = round$1;
var sign2 = sign$1;
var $Function = Function;
var getEvalledConstructor = function(expressionSyntax) {
  try {
    return $Function('"use strict"; return (' + expressionSyntax + ").constructor;")();
  } catch (e) {
  }
};
var $gOPD = gopd$1;
var $defineProperty$2 = esDefineProperty;
var throwTypeError = function() {
  throw new $TypeError$2();
};
var ThrowTypeError = $gOPD ? function() {
  try {
    arguments.callee;
    return throwTypeError;
  } catch (calleeThrows) {
    try {
      return $gOPD(arguments, "callee").get;
    } catch (gOPDthrows) {
      return throwTypeError;
    }
  }
}() : throwTypeError;
var hasSymbols = requireHasSymbols()();
var getProto = requireGetProto();
var $ObjectGPO = requireObject_getPrototypeOf();
var $ReflectGPO = requireReflect_getPrototypeOf();
var $apply$1 = functionApply;
var $call = functionCall;
var needsEval = {};
var TypedArray = typeof Uint8Array === "undefined" || !getProto ? undefined$1 : getProto(Uint8Array);
var INTRINSICS = {
  __proto__: null,
  "%AggregateError%": typeof AggregateError === "undefined" ? undefined$1 : AggregateError,
  "%Array%": Array,
  "%ArrayBuffer%": typeof ArrayBuffer === "undefined" ? undefined$1 : ArrayBuffer,
  "%ArrayIteratorPrototype%": hasSymbols && getProto ? getProto([][Symbol.iterator]()) : undefined$1,
  "%AsyncFromSyncIteratorPrototype%": undefined$1,
  "%AsyncFunction%": needsEval,
  "%AsyncGenerator%": needsEval,
  "%AsyncGeneratorFunction%": needsEval,
  "%AsyncIteratorPrototype%": needsEval,
  "%Atomics%": typeof Atomics === "undefined" ? undefined$1 : Atomics,
  "%BigInt%": typeof BigInt === "undefined" ? undefined$1 : BigInt,
  "%BigInt64Array%": typeof BigInt64Array === "undefined" ? undefined$1 : BigInt64Array,
  "%BigUint64Array%": typeof BigUint64Array === "undefined" ? undefined$1 : BigUint64Array,
  "%Boolean%": Boolean,
  "%DataView%": typeof DataView === "undefined" ? undefined$1 : DataView,
  "%Date%": Date,
  "%decodeURI%": decodeURI,
  "%decodeURIComponent%": decodeURIComponent,
  "%encodeURI%": encodeURI,
  "%encodeURIComponent%": encodeURIComponent,
  "%Error%": $Error,
  "%eval%": eval,
  // eslint-disable-line no-eval
  "%EvalError%": $EvalError,
  "%Float16Array%": typeof Float16Array === "undefined" ? undefined$1 : Float16Array,
  "%Float32Array%": typeof Float32Array === "undefined" ? undefined$1 : Float32Array,
  "%Float64Array%": typeof Float64Array === "undefined" ? undefined$1 : Float64Array,
  "%FinalizationRegistry%": typeof FinalizationRegistry === "undefined" ? undefined$1 : FinalizationRegistry,
  "%Function%": $Function,
  "%GeneratorFunction%": needsEval,
  "%Int8Array%": typeof Int8Array === "undefined" ? undefined$1 : Int8Array,
  "%Int16Array%": typeof Int16Array === "undefined" ? undefined$1 : Int16Array,
  "%Int32Array%": typeof Int32Array === "undefined" ? undefined$1 : Int32Array,
  "%isFinite%": isFinite,
  "%isNaN%": isNaN,
  "%IteratorPrototype%": hasSymbols && getProto ? getProto(getProto([][Symbol.iterator]())) : undefined$1,
  "%JSON%": typeof JSON === "object" ? JSON : undefined$1,
  "%Map%": typeof Map === "undefined" ? undefined$1 : Map,
  "%MapIteratorPrototype%": typeof Map === "undefined" || !hasSymbols || !getProto ? undefined$1 : getProto((/* @__PURE__ */ new Map())[Symbol.iterator]()),
  "%Math%": Math,
  "%Number%": Number,
  "%Object%": $Object,
  "%Object.getOwnPropertyDescriptor%": $gOPD,
  "%parseFloat%": parseFloat,
  "%parseInt%": parseInt,
  "%Promise%": typeof Promise === "undefined" ? undefined$1 : Promise,
  "%Proxy%": typeof Proxy === "undefined" ? undefined$1 : Proxy,
  "%RangeError%": $RangeError,
  "%ReferenceError%": $ReferenceError,
  "%Reflect%": typeof Reflect === "undefined" ? undefined$1 : Reflect,
  "%RegExp%": RegExp,
  "%Set%": typeof Set === "undefined" ? undefined$1 : Set,
  "%SetIteratorPrototype%": typeof Set === "undefined" || !hasSymbols || !getProto ? undefined$1 : getProto((/* @__PURE__ */ new Set())[Symbol.iterator]()),
  "%SharedArrayBuffer%": typeof SharedArrayBuffer === "undefined" ? undefined$1 : SharedArrayBuffer,
  "%String%": String,
  "%StringIteratorPrototype%": hasSymbols && getProto ? getProto(""[Symbol.iterator]()) : undefined$1,
  "%Symbol%": hasSymbols ? Symbol : undefined$1,
  "%SyntaxError%": $SyntaxError$1,
  "%ThrowTypeError%": ThrowTypeError,
  "%TypedArray%": TypedArray,
  "%TypeError%": $TypeError$2,
  "%Uint8Array%": typeof Uint8Array === "undefined" ? undefined$1 : Uint8Array,
  "%Uint8ClampedArray%": typeof Uint8ClampedArray === "undefined" ? undefined$1 : Uint8ClampedArray,
  "%Uint16Array%": typeof Uint16Array === "undefined" ? undefined$1 : Uint16Array,
  "%Uint32Array%": typeof Uint32Array === "undefined" ? undefined$1 : Uint32Array,
  "%URIError%": $URIError,
  "%WeakMap%": typeof WeakMap === "undefined" ? undefined$1 : WeakMap,
  "%WeakRef%": typeof WeakRef === "undefined" ? undefined$1 : WeakRef,
  "%WeakSet%": typeof WeakSet === "undefined" ? undefined$1 : WeakSet,
  "%Function.prototype.call%": $call,
  "%Function.prototype.apply%": $apply$1,
  "%Object.defineProperty%": $defineProperty$2,
  "%Object.getPrototypeOf%": $ObjectGPO,
  "%Math.abs%": abs,
  "%Math.floor%": floor,
  "%Math.max%": max,
  "%Math.min%": min,
  "%Math.pow%": pow,
  "%Math.round%": round,
  "%Math.sign%": sign2,
  "%Reflect.getPrototypeOf%": $ReflectGPO
};
if (getProto) {
  try {
    null.error;
  } catch (e) {
    var errorProto = getProto(getProto(e));
    INTRINSICS["%Error.prototype%"] = errorProto;
  }
}
var doEval = function doEval2(name) {
  var value;
  if (name === "%AsyncFunction%") {
    value = getEvalledConstructor("async function () {}");
  } else if (name === "%GeneratorFunction%") {
    value = getEvalledConstructor("function* () {}");
  } else if (name === "%AsyncGeneratorFunction%") {
    value = getEvalledConstructor("async function* () {}");
  } else if (name === "%AsyncGenerator%") {
    var fn = doEval2("%AsyncGeneratorFunction%");
    if (fn) {
      value = fn.prototype;
    }
  } else if (name === "%AsyncIteratorPrototype%") {
    var gen = doEval2("%AsyncGenerator%");
    if (gen && getProto) {
      value = getProto(gen.prototype);
    }
  }
  INTRINSICS[name] = value;
  return value;
};
var LEGACY_ALIASES = {
  __proto__: null,
  "%ArrayBufferPrototype%": ["ArrayBuffer", "prototype"],
  "%ArrayPrototype%": ["Array", "prototype"],
  "%ArrayProto_entries%": ["Array", "prototype", "entries"],
  "%ArrayProto_forEach%": ["Array", "prototype", "forEach"],
  "%ArrayProto_keys%": ["Array", "prototype", "keys"],
  "%ArrayProto_values%": ["Array", "prototype", "values"],
  "%AsyncFunctionPrototype%": ["AsyncFunction", "prototype"],
  "%AsyncGenerator%": ["AsyncGeneratorFunction", "prototype"],
  "%AsyncGeneratorPrototype%": ["AsyncGeneratorFunction", "prototype", "prototype"],
  "%BooleanPrototype%": ["Boolean", "prototype"],
  "%DataViewPrototype%": ["DataView", "prototype"],
  "%DatePrototype%": ["Date", "prototype"],
  "%ErrorPrototype%": ["Error", "prototype"],
  "%EvalErrorPrototype%": ["EvalError", "prototype"],
  "%Float32ArrayPrototype%": ["Float32Array", "prototype"],
  "%Float64ArrayPrototype%": ["Float64Array", "prototype"],
  "%FunctionPrototype%": ["Function", "prototype"],
  "%Generator%": ["GeneratorFunction", "prototype"],
  "%GeneratorPrototype%": ["GeneratorFunction", "prototype", "prototype"],
  "%Int8ArrayPrototype%": ["Int8Array", "prototype"],
  "%Int16ArrayPrototype%": ["Int16Array", "prototype"],
  "%Int32ArrayPrototype%": ["Int32Array", "prototype"],
  "%JSONParse%": ["JSON", "parse"],
  "%JSONStringify%": ["JSON", "stringify"],
  "%MapPrototype%": ["Map", "prototype"],
  "%NumberPrototype%": ["Number", "prototype"],
  "%ObjectPrototype%": ["Object", "prototype"],
  "%ObjProto_toString%": ["Object", "prototype", "toString"],
  "%ObjProto_valueOf%": ["Object", "prototype", "valueOf"],
  "%PromisePrototype%": ["Promise", "prototype"],
  "%PromiseProto_then%": ["Promise", "prototype", "then"],
  "%Promise_all%": ["Promise", "all"],
  "%Promise_reject%": ["Promise", "reject"],
  "%Promise_resolve%": ["Promise", "resolve"],
  "%RangeErrorPrototype%": ["RangeError", "prototype"],
  "%ReferenceErrorPrototype%": ["ReferenceError", "prototype"],
  "%RegExpPrototype%": ["RegExp", "prototype"],
  "%SetPrototype%": ["Set", "prototype"],
  "%SharedArrayBufferPrototype%": ["SharedArrayBuffer", "prototype"],
  "%StringPrototype%": ["String", "prototype"],
  "%SymbolPrototype%": ["Symbol", "prototype"],
  "%SyntaxErrorPrototype%": ["SyntaxError", "prototype"],
  "%TypedArrayPrototype%": ["TypedArray", "prototype"],
  "%TypeErrorPrototype%": ["TypeError", "prototype"],
  "%Uint8ArrayPrototype%": ["Uint8Array", "prototype"],
  "%Uint8ClampedArrayPrototype%": ["Uint8ClampedArray", "prototype"],
  "%Uint16ArrayPrototype%": ["Uint16Array", "prototype"],
  "%Uint32ArrayPrototype%": ["Uint32Array", "prototype"],
  "%URIErrorPrototype%": ["URIError", "prototype"],
  "%WeakMapPrototype%": ["WeakMap", "prototype"],
  "%WeakSetPrototype%": ["WeakSet", "prototype"]
};
var bind$1 = functionBind;
var hasOwn = requireHasown();
var $concat = bind$1.call($call, Array.prototype.concat);
var $spliceApply = bind$1.call($apply$1, Array.prototype.splice);
var $replace = bind$1.call($call, String.prototype.replace);
var $strSlice = bind$1.call($call, String.prototype.slice);
var $exec = bind$1.call($call, RegExp.prototype.exec);
var rePropName = /[^%.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|%$))/g;
var reEscapeChar = /\\(\\)?/g;
var stringToPath = function stringToPath2(string) {
  var first = $strSlice(string, 0, 1);
  var last = $strSlice(string, -1);
  if (first === "%" && last !== "%") {
    throw new $SyntaxError$1("invalid intrinsic syntax, expected closing `%`");
  } else if (last === "%" && first !== "%") {
    throw new $SyntaxError$1("invalid intrinsic syntax, expected opening `%`");
  }
  var result = [];
  $replace(string, rePropName, function(match, number, quote, subString) {
    result[result.length] = quote ? $replace(subString, reEscapeChar, "$1") : number || match;
  });
  return result;
};
var getBaseIntrinsic = function getBaseIntrinsic2(name, allowMissing) {
  var intrinsicName = name;
  var alias;
  if (hasOwn(LEGACY_ALIASES, intrinsicName)) {
    alias = LEGACY_ALIASES[intrinsicName];
    intrinsicName = "%" + alias[0] + "%";
  }
  if (hasOwn(INTRINSICS, intrinsicName)) {
    var value = INTRINSICS[intrinsicName];
    if (value === needsEval) {
      value = doEval(intrinsicName);
    }
    if (typeof value === "undefined" && !allowMissing) {
      throw new $TypeError$2("intrinsic " + name + " exists, but is not available. Please file an issue!");
    }
    return {
      alias,
      name: intrinsicName,
      value
    };
  }
  throw new $SyntaxError$1("intrinsic " + name + " does not exist!");
};
var getIntrinsic = function GetIntrinsic(name, allowMissing) {
  if (typeof name !== "string" || name.length === 0) {
    throw new $TypeError$2("intrinsic name must be a non-empty string");
  }
  if (arguments.length > 1 && typeof allowMissing !== "boolean") {
    throw new $TypeError$2('"allowMissing" argument must be a boolean');
  }
  if ($exec(/^%?[^%]*%?$/, name) === null) {
    throw new $SyntaxError$1("`%` may not be present anywhere but at the beginning and end of the intrinsic name");
  }
  var parts = stringToPath(name);
  var intrinsicBaseName = parts.length > 0 ? parts[0] : "";
  var intrinsic = getBaseIntrinsic("%" + intrinsicBaseName + "%", allowMissing);
  var intrinsicRealName = intrinsic.name;
  var value = intrinsic.value;
  var skipFurtherCaching = false;
  var alias = intrinsic.alias;
  if (alias) {
    intrinsicBaseName = alias[0];
    $spliceApply(parts, $concat([0, 1], alias));
  }
  for (var i = 1, isOwn = true; i < parts.length; i += 1) {
    var part = parts[i];
    var first = $strSlice(part, 0, 1);
    var last = $strSlice(part, -1);
    if ((first === '"' || first === "'" || first === "`" || (last === '"' || last === "'" || last === "`")) && first !== last) {
      throw new $SyntaxError$1("property names with quotes must have matching quotes");
    }
    if (part === "constructor" || !isOwn) {
      skipFurtherCaching = true;
    }
    intrinsicBaseName += "." + part;
    intrinsicRealName = "%" + intrinsicBaseName + "%";
    if (hasOwn(INTRINSICS, intrinsicRealName)) {
      value = INTRINSICS[intrinsicRealName];
    } else if (value != null) {
      if (!(part in value)) {
        if (!allowMissing) {
          throw new $TypeError$2("base intrinsic for " + name + " exists, but the property is not available.");
        }
        return void 0;
      }
      if ($gOPD && i + 1 >= parts.length) {
        var desc = $gOPD(value, part);
        isOwn = !!desc;
        if (isOwn && "get" in desc && !("originalValue" in desc.get)) {
          value = desc.get;
        } else {
          value = value[part];
        }
      } else {
        isOwn = hasOwn(value, part);
        value = value[part];
      }
      if (isOwn && !skipFurtherCaching) {
        INTRINSICS[intrinsicRealName] = value;
      }
    }
  }
  return value;
};
var GetIntrinsic$1 = getIntrinsic;
var callBindBasic2 = callBindApplyHelpers;
var $indexOf$1 = callBindBasic2([GetIntrinsic$1("%String.prototype.indexOf%")]);
var callBound$1 = function callBoundIntrinsic(name, allowMissing) {
  var intrinsic = (
    /** @type {(this: unknown, ...args: unknown[]) => unknown} */
    GetIntrinsic$1(name, !!allowMissing)
  );
  if (typeof intrinsic === "function" && $indexOf$1(name, ".prototype.") > -1) {
    return callBindBasic2(
      /** @type {const} */
      [intrinsic]
    );
  }
  return intrinsic;
};
var callBind$1 = { exports: {} };
var $defineProperty$1 = esDefineProperty;
var $SyntaxError = syntax;
var $TypeError$1 = type;
var gopd = gopd$1;
var defineDataProperty = function defineDataProperty2(obj, property, value) {
  if (!obj || typeof obj !== "object" && typeof obj !== "function") {
    throw new $TypeError$1("`obj` must be an object or a function`");
  }
  if (typeof property !== "string" && typeof property !== "symbol") {
    throw new $TypeError$1("`property` must be a string or a symbol`");
  }
  if (arguments.length > 3 && typeof arguments[3] !== "boolean" && arguments[3] !== null) {
    throw new $TypeError$1("`nonEnumerable`, if provided, must be a boolean or null");
  }
  if (arguments.length > 4 && typeof arguments[4] !== "boolean" && arguments[4] !== null) {
    throw new $TypeError$1("`nonWritable`, if provided, must be a boolean or null");
  }
  if (arguments.length > 5 && typeof arguments[5] !== "boolean" && arguments[5] !== null) {
    throw new $TypeError$1("`nonConfigurable`, if provided, must be a boolean or null");
  }
  if (arguments.length > 6 && typeof arguments[6] !== "boolean") {
    throw new $TypeError$1("`loose`, if provided, must be a boolean");
  }
  var nonEnumerable = arguments.length > 3 ? arguments[3] : null;
  var nonWritable = arguments.length > 4 ? arguments[4] : null;
  var nonConfigurable = arguments.length > 5 ? arguments[5] : null;
  var loose = arguments.length > 6 ? arguments[6] : false;
  var desc = !!gopd && gopd(obj, property);
  if ($defineProperty$1) {
    $defineProperty$1(obj, property, {
      configurable: nonConfigurable === null && desc ? desc.configurable : !nonConfigurable,
      enumerable: nonEnumerable === null && desc ? desc.enumerable : !nonEnumerable,
      value,
      writable: nonWritable === null && desc ? desc.writable : !nonWritable
    });
  } else if (loose || !nonEnumerable && !nonWritable && !nonConfigurable) {
    obj[property] = value;
  } else {
    throw new $SyntaxError("This environment does not support defining a property as non-configurable, non-writable, or non-enumerable.");
  }
};
var $defineProperty = esDefineProperty;
var hasPropertyDescriptors = function hasPropertyDescriptors2() {
  return !!$defineProperty;
};
hasPropertyDescriptors.hasArrayLengthDefineBug = function hasArrayLengthDefineBug() {
  if (!$defineProperty) {
    return null;
  }
  try {
    return $defineProperty([], "length", { value: 1 }).length !== 1;
  } catch (e) {
    return true;
  }
};
var hasPropertyDescriptors_1 = hasPropertyDescriptors;
var GetIntrinsic2 = getIntrinsic;
var define = defineDataProperty;
var hasDescriptors = hasPropertyDescriptors_1();
var gOPD = gopd$1;
var $TypeError = type;
var $floor = GetIntrinsic2("%Math.floor%");
var setFunctionLength = function setFunctionLength2(fn, length) {
  if (typeof fn !== "function") {
    throw new $TypeError("`fn` is not a function");
  }
  if (typeof length !== "number" || length < 0 || length > 4294967295 || $floor(length) !== length) {
    throw new $TypeError("`length` must be a positive 32-bit integer");
  }
  var loose = arguments.length > 2 && !!arguments[2];
  var functionLengthIsConfigurable = true;
  var functionLengthIsWritable = true;
  if ("length" in fn && gOPD) {
    var desc = gOPD(fn, "length");
    if (desc && !desc.configurable) {
      functionLengthIsConfigurable = false;
    }
    if (desc && !desc.writable) {
      functionLengthIsWritable = false;
    }
  }
  if (functionLengthIsConfigurable || functionLengthIsWritable || !loose) {
    if (hasDescriptors) {
      define(
        /** @type {Parameters<define>[0]} */
        fn,
        "length",
        length,
        true,
        true
      );
    } else {
      define(
        /** @type {Parameters<define>[0]} */
        fn,
        "length",
        length
      );
    }
  }
  return fn;
};
var bind2 = functionBind;
var $apply = functionApply;
var actualApply = actualApply$1;
var applyBind = function applyBind2() {
  return actualApply(bind2, $apply, arguments);
};
(function(module) {
  var setFunctionLength$1 = setFunctionLength;
  var $defineProperty2 = esDefineProperty;
  var callBindBasic3 = callBindApplyHelpers;
  var applyBind$1 = applyBind;
  module.exports = function callBind2(originalFunction) {
    var func = callBindBasic3(arguments);
    var adjustedLength = originalFunction.length - (arguments.length - 1);
    return setFunctionLength$1(
      func,
      1 + (adjustedLength > 0 ? adjustedLength : 0),
      true
    );
  };
  if ($defineProperty2) {
    $defineProperty2(module.exports, "apply", { value: applyBind$1 });
  } else {
    module.exports.apply = applyBind$1;
  }
})(callBind$1);
var callBindExports = callBind$1.exports;
var toStr = Object.prototype.toString;
var isArguments = function isArguments2(value) {
  var str = toStr.call(value);
  var isArgs2 = str === "[object Arguments]";
  if (!isArgs2) {
    isArgs2 = str !== "[object Array]" && value !== null && typeof value === "object" && typeof value.length === "number" && value.length >= 0 && toStr.call(value.callee) === "[object Function]";
  }
  return isArgs2;
};
var implementation;
var hasRequiredImplementation;
function requireImplementation() {
  if (hasRequiredImplementation) return implementation;
  hasRequiredImplementation = 1;
  var keysShim2;
  if (!Object.keys) {
    var has = Object.prototype.hasOwnProperty;
    var toStr2 = Object.prototype.toString;
    var isArgs2 = isArguments;
    var isEnumerable = Object.prototype.propertyIsEnumerable;
    var hasDontEnumBug = !isEnumerable.call({ toString: null }, "toString");
    var hasProtoEnumBug = isEnumerable.call(function() {
    }, "prototype");
    var dontEnums = [
      "toString",
      "toLocaleString",
      "valueOf",
      "hasOwnProperty",
      "isPrototypeOf",
      "propertyIsEnumerable",
      "constructor"
    ];
    var equalsConstructorPrototype = function(o) {
      var ctor = o.constructor;
      return ctor && ctor.prototype === o;
    };
    var excludedKeys = {
      $applicationCache: true,
      $console: true,
      $external: true,
      $frame: true,
      $frameElement: true,
      $frames: true,
      $innerHeight: true,
      $innerWidth: true,
      $onmozfullscreenchange: true,
      $onmozfullscreenerror: true,
      $outerHeight: true,
      $outerWidth: true,
      $pageXOffset: true,
      $pageYOffset: true,
      $parent: true,
      $scrollLeft: true,
      $scrollTop: true,
      $scrollX: true,
      $scrollY: true,
      $self: true,
      $webkitIndexedDB: true,
      $webkitStorageInfo: true,
      $window: true
    };
    var hasAutomationEqualityBug = function() {
      if (typeof window === "undefined") {
        return false;
      }
      for (var k in window) {
        try {
          if (!excludedKeys["$" + k] && has.call(window, k) && window[k] !== null && typeof window[k] === "object") {
            try {
              equalsConstructorPrototype(window[k]);
            } catch (e) {
              return true;
            }
          }
        } catch (e) {
          return true;
        }
      }
      return false;
    }();
    var equalsConstructorPrototypeIfNotBuggy = function(o) {
      if (typeof window === "undefined" || !hasAutomationEqualityBug) {
        return equalsConstructorPrototype(o);
      }
      try {
        return equalsConstructorPrototype(o);
      } catch (e) {
        return false;
      }
    };
    keysShim2 = function keys2(object) {
      var isObject2 = object !== null && typeof object === "object";
      var isFunction = toStr2.call(object) === "[object Function]";
      var isArguments3 = isArgs2(object);
      var isString = isObject2 && toStr2.call(object) === "[object String]";
      var theKeys = [];
      if (!isObject2 && !isFunction && !isArguments3) {
        throw new TypeError("Object.keys called on a non-object");
      }
      var skipProto = hasProtoEnumBug && isFunction;
      if (isString && object.length > 0 && !has.call(object, 0)) {
        for (var i = 0; i < object.length; ++i) {
          theKeys.push(String(i));
        }
      }
      if (isArguments3 && object.length > 0) {
        for (var j = 0; j < object.length; ++j) {
          theKeys.push(String(j));
        }
      } else {
        for (var name in object) {
          if (!(skipProto && name === "prototype") && has.call(object, name)) {
            theKeys.push(String(name));
          }
        }
      }
      if (hasDontEnumBug) {
        var skipConstructor = equalsConstructorPrototypeIfNotBuggy(object);
        for (var k = 0; k < dontEnums.length; ++k) {
          if (!(skipConstructor && dontEnums[k] === "constructor") && has.call(object, dontEnums[k])) {
            theKeys.push(dontEnums[k]);
          }
        }
      }
      return theKeys;
    };
  }
  implementation = keysShim2;
  return implementation;
}
var slice = Array.prototype.slice;
var isArgs = isArguments;
var origKeys = Object.keys;
var keysShim = origKeys ? function keys(o) {
  return origKeys(o);
} : requireImplementation();
var originalKeys = Object.keys;
keysShim.shim = function shimObjectKeys() {
  if (Object.keys) {
    var keysWorksWithArguments = function() {
      var args = Object.keys(arguments);
      return args && args.length === arguments.length;
    }(1, 2);
    if (!keysWorksWithArguments) {
      Object.keys = function keys2(object) {
        if (isArgs(object)) {
          return originalKeys(slice.call(object));
        }
        return originalKeys(object);
      };
    }
  } else {
    Object.keys = keysShim;
  }
  return Object.keys || keysShim;
};
var objectKeys$1 = keysShim;
const loglevel = log.getLogger("auth");
loglevel.setLevel("error");
var jsonify = {};
var parse;
var hasRequiredParse;
function requireParse() {
  if (hasRequiredParse) return parse;
  hasRequiredParse = 1;
  var at;
  var ch;
  var escapee = {
    '"': '"',
    "\\": "\\",
    "/": "/",
    b: "\b",
    f: "\f",
    n: "\n",
    r: "\r",
    t: "	"
  };
  var text;
  function error(m) {
    throw {
      name: "SyntaxError",
      message: m,
      at,
      text
    };
  }
  function next(c) {
    if (c && c !== ch) {
      error("Expected '" + c + "' instead of '" + ch + "'");
    }
    ch = text.charAt(at);
    at += 1;
    return ch;
  }
  function number() {
    var num;
    var str = "";
    if (ch === "-") {
      str = "-";
      next("-");
    }
    while (ch >= "0" && ch <= "9") {
      str += ch;
      next();
    }
    if (ch === ".") {
      str += ".";
      while (next() && ch >= "0" && ch <= "9") {
        str += ch;
      }
    }
    if (ch === "e" || ch === "E") {
      str += ch;
      next();
      if (ch === "-" || ch === "+") {
        str += ch;
        next();
      }
      while (ch >= "0" && ch <= "9") {
        str += ch;
        next();
      }
    }
    num = Number(str);
    if (!isFinite(num)) {
      error("Bad number");
    }
    return num;
  }
  function string() {
    var hex;
    var i;
    var str = "";
    var uffff;
    if (ch === '"') {
      while (next()) {
        if (ch === '"') {
          next();
          return str;
        } else if (ch === "\\") {
          next();
          if (ch === "u") {
            uffff = 0;
            for (i = 0; i < 4; i += 1) {
              hex = parseInt(next(), 16);
              if (!isFinite(hex)) {
                break;
              }
              uffff = uffff * 16 + hex;
            }
            str += String.fromCharCode(uffff);
          } else if (typeof escapee[ch] === "string") {
            str += escapee[ch];
          } else {
            break;
          }
        } else {
          str += ch;
        }
      }
    }
    error("Bad string");
  }
  function white() {
    while (ch && ch <= " ") {
      next();
    }
  }
  function word() {
    switch (ch) {
      case "t":
        next("t");
        next("r");
        next("u");
        next("e");
        return true;
      case "f":
        next("f");
        next("a");
        next("l");
        next("s");
        next("e");
        return false;
      case "n":
        next("n");
        next("u");
        next("l");
        next("l");
        return null;
      default:
        error("Unexpected '" + ch + "'");
    }
  }
  function array() {
    var arr = [];
    if (ch === "[") {
      next("[");
      white();
      if (ch === "]") {
        next("]");
        return arr;
      }
      while (ch) {
        arr.push(value());
        white();
        if (ch === "]") {
          next("]");
          return arr;
        }
        next(",");
        white();
      }
    }
    error("Bad array");
  }
  function object() {
    var key;
    var obj = {};
    if (ch === "{") {
      next("{");
      white();
      if (ch === "}") {
        next("}");
        return obj;
      }
      while (ch) {
        key = string();
        white();
        next(":");
        if (Object.prototype.hasOwnProperty.call(obj, key)) {
          error('Duplicate key "' + key + '"');
        }
        obj[key] = value();
        white();
        if (ch === "}") {
          next("}");
          return obj;
        }
        next(",");
        white();
      }
    }
    error("Bad object");
  }
  function value() {
    white();
    switch (ch) {
      case "{":
        return object();
      case "[":
        return array();
      case '"':
        return string();
      case "-":
        return number();
      default:
        return ch >= "0" && ch <= "9" ? number() : word();
    }
  }
  parse = function(source, reviver) {
    var result;
    text = source;
    at = 0;
    ch = " ";
    result = value();
    white();
    if (ch) {
      error("Syntax error");
    }
    return typeof reviver === "function" ? function walk(holder, key) {
      var k;
      var v;
      var val = holder[key];
      if (val && typeof val === "object") {
        for (k in value) {
          if (Object.prototype.hasOwnProperty.call(val, k)) {
            v = walk(val, k);
            if (typeof v === "undefined") {
              delete val[k];
            } else {
              val[k] = v;
            }
          }
        }
      }
      return reviver.call(holder, key, val);
    }({ "": result }, "") : result;
  };
  return parse;
}
var stringify$1;
var hasRequiredStringify;
function requireStringify() {
  if (hasRequiredStringify) return stringify$1;
  hasRequiredStringify = 1;
  var escapable = /[\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;
  var gap;
  var indent;
  var meta = {
    // table of character substitutions
    "\b": "\\b",
    "	": "\\t",
    "\n": "\\n",
    "\f": "\\f",
    "\r": "\\r",
    '"': '\\"',
    "\\": "\\\\"
  };
  var rep;
  function quote(string) {
    escapable.lastIndex = 0;
    return escapable.test(string) ? '"' + string.replace(escapable, function(a) {
      var c = meta[a];
      return typeof c === "string" ? c : "\\u" + ("0000" + a.charCodeAt(0).toString(16)).slice(-4);
    }) + '"' : '"' + string + '"';
  }
  function str(key, holder) {
    var i;
    var k;
    var v;
    var length;
    var mind = gap;
    var partial;
    var value = holder[key];
    if (value && typeof value === "object" && typeof value.toJSON === "function") {
      value = value.toJSON(key);
    }
    if (typeof rep === "function") {
      value = rep.call(holder, key, value);
    }
    switch (typeof value) {
      case "string":
        return quote(value);
      case "number":
        return isFinite(value) ? String(value) : "null";
      case "boolean":
      case "null":
        return String(value);
      case "object":
        if (!value) {
          return "null";
        }
        gap += indent;
        partial = [];
        if (Object.prototype.toString.apply(value) === "[object Array]") {
          length = value.length;
          for (i = 0; i < length; i += 1) {
            partial[i] = str(i, value) || "null";
          }
          v = partial.length === 0 ? "[]" : gap ? "[\n" + gap + partial.join(",\n" + gap) + "\n" + mind + "]" : "[" + partial.join(",") + "]";
          gap = mind;
          return v;
        }
        if (rep && typeof rep === "object") {
          length = rep.length;
          for (i = 0; i < length; i += 1) {
            k = rep[i];
            if (typeof k === "string") {
              v = str(k, value);
              if (v) {
                partial.push(quote(k) + (gap ? ": " : ":") + v);
              }
            }
          }
        } else {
          for (k in value) {
            if (Object.prototype.hasOwnProperty.call(value, k)) {
              v = str(k, value);
              if (v) {
                partial.push(quote(k) + (gap ? ": " : ":") + v);
              }
            }
          }
        }
        v = partial.length === 0 ? "{}" : gap ? "{\n" + gap + partial.join(",\n" + gap) + "\n" + mind + "}" : "{" + partial.join(",") + "}";
        gap = mind;
        return v;
    }
  }
  stringify$1 = function(value, replacer, space) {
    var i;
    gap = "";
    indent = "";
    if (typeof space === "number") {
      for (i = 0; i < space; i += 1) {
        indent += " ";
      }
    } else if (typeof space === "string") {
      indent = space;
    }
    rep = replacer;
    if (replacer && typeof replacer !== "function" && (typeof replacer !== "object" || typeof replacer.length !== "number")) {
      throw new Error("JSON.stringify");
    }
    return str("", { "": value });
  };
  return stringify$1;
}
var hasRequiredJsonify;
function requireJsonify() {
  if (hasRequiredJsonify) return jsonify;
  hasRequiredJsonify = 1;
  jsonify.parse = requireParse();
  jsonify.stringify = requireStringify();
  return jsonify;
}
var toString = {}.toString;
var isarray = Array.isArray || function(arr) {
  return toString.call(arr) == "[object Array]";
};
var jsonStringify = (typeof JSON !== "undefined" ? JSON : requireJsonify()).stringify;
var isArray = isarray;
var objectKeys = objectKeys$1;
var callBind = callBindExports;
var callBound = callBound$1;
var $join = callBound("Array.prototype.join");
var $indexOf = callBound("Array.prototype.indexOf");
var $splice = callBound("Array.prototype.splice");
var $sort = callBound("Array.prototype.sort");
var strRepeat = function repeat(n, char) {
  var str = "";
  for (var i = 0; i < n; i += 1) {
    str += char;
  }
  return str;
};
var defaultReplacer = function(_parent, _key, value) {
  return value;
};
var jsonStableStringify = function stableStringify(obj) {
  var opts = arguments.length > 1 ? arguments[1] : void 0;
  var space = opts && opts.space || "";
  if (typeof space === "number") {
    space = strRepeat(space, " ");
  }
  var cycles = !!opts && typeof opts.cycles === "boolean" && opts.cycles;
  var replacer = opts && opts.replacer ? callBind(opts.replacer) : defaultReplacer;
  if (opts && typeof opts.collapseEmpty !== "undefined" && typeof opts.collapseEmpty !== "boolean") {
    throw new TypeError("`collapseEmpty` must be a boolean, if provided");
  }
  var collapseEmpty = !!opts && opts.collapseEmpty;
  var cmpOpt = typeof opts === "function" ? opts : opts && opts.cmp;
  var cmp = cmpOpt && function(node) {
    var get2 = (
      /** @type {NonNullable<typeof cmpOpt>} */
      cmpOpt.length > 2 && /** @type {import('.').Getter['get']} */
      function get3(k) {
        return node[k];
      }
    );
    return function(a, b) {
      return (
        /** @type {NonNullable<typeof cmpOpt>} */
        cmpOpt(
          { key: a, value: node[a] },
          { key: b, value: node[b] },
          // @ts-expect-error TS doesn't understand the optimization used here
          get2 ? (
            /** @type {import('.').Getter} */
            { __proto__: null, get: get2 }
          ) : void 0
        )
      );
    };
  };
  var seen = [];
  return (
    /** @type {(parent: import('.').Node, key: string | number, node: unknown, level: number) => string | undefined} */
    function stringify2(parent, key, node, level) {
      var indent = space ? "\n" + strRepeat(level, space) : "";
      var colonSeparator = space ? ": " : ":";
      if (node && /** @type {{ toJSON?: unknown }} */
      node.toJSON && typeof /** @type {{ toJSON?: unknown }} */
      node.toJSON === "function") {
        node = /** @type {{ toJSON: Function }} */
        node.toJSON();
      }
      node = replacer(parent, key, node);
      if (node === void 0) {
        return;
      }
      if (typeof node !== "object" || node === null) {
        return jsonStringify(node);
      }
      var groupOutput = function(out2, brackets) {
        return collapseEmpty && out2.length === 0 ? brackets : (brackets === "[]" ? "[" : "{") + $join(out2, ",") + indent + (brackets === "[]" ? "]" : "}");
      };
      if (isArray(node)) {
        var out = [];
        for (var i = 0; i < node.length; i++) {
          var item = stringify2(node, i, node[i], level + 1) || jsonStringify(null);
          out[out.length] = indent + space + item;
        }
        return groupOutput(out, "[]");
      }
      if ($indexOf(seen, node) !== -1) {
        if (cycles) {
          return jsonStringify("__cycle__");
        }
        throw new TypeError("Converting circular structure to JSON");
      } else {
        seen[seen.length] = /** @type {import('.').NonArrayNode} */
        node;
      }
      var keys2 = $sort(objectKeys(node), cmp && cmp(
        /** @type {import('.').NonArrayNode} */
        node
      ));
      var out = [];
      for (var i = 0; i < keys2.length; i++) {
        var key = keys2[i];
        var value = stringify2(
          /** @type {import('.').Node} */
          node,
          key,
          /** @type {import('.').NonArrayNode} */
          node[key],
          level + 1
        );
        if (!value) {
          continue;
        }
        var keyValue = jsonStringify(key) + colonSeparator + value;
        out[out.length] = indent + space + keyValue;
      }
      $splice(seen, $indexOf(seen, node), 1);
      return groupOutput(out, "{}");
    }({ "": obj }, "", obj, 0)
  );
};
const stringify = /* @__PURE__ */ getDefaultExportFromCjs(jsonStableStringify);
var events = { exports: {} };
var R = typeof Reflect === "object" ? Reflect : null;
var ReflectApply = R && typeof R.apply === "function" ? R.apply : function ReflectApply2(target, receiver, args) {
  return Function.prototype.apply.call(target, receiver, args);
};
var ReflectOwnKeys;
if (R && typeof R.ownKeys === "function") {
  ReflectOwnKeys = R.ownKeys;
} else if (Object.getOwnPropertySymbols) {
  ReflectOwnKeys = function ReflectOwnKeys2(target) {
    return Object.getOwnPropertyNames(target).concat(Object.getOwnPropertySymbols(target));
  };
} else {
  ReflectOwnKeys = function ReflectOwnKeys2(target) {
    return Object.getOwnPropertyNames(target);
  };
}
function ProcessEmitWarning(warning) {
  if (console && console.warn) console.warn(warning);
}
var NumberIsNaN$2 = Number.isNaN || function NumberIsNaN(value) {
  return value !== value;
};
function EventEmitter() {
  EventEmitter.init.call(this);
}
events.exports = EventEmitter;
events.exports.once = once$2;
EventEmitter.EventEmitter = EventEmitter;
EventEmitter.prototype._events = void 0;
EventEmitter.prototype._eventsCount = 0;
EventEmitter.prototype._maxListeners = void 0;
var defaultMaxListeners = 10;
function checkListener(listener) {
  if (typeof listener !== "function") {
    throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof listener);
  }
}
Object.defineProperty(EventEmitter, "defaultMaxListeners", {
  enumerable: true,
  get: function() {
    return defaultMaxListeners;
  },
  set: function(arg) {
    if (typeof arg !== "number" || arg < 0 || NumberIsNaN$2(arg)) {
      throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + arg + ".");
    }
    defaultMaxListeners = arg;
  }
});
EventEmitter.init = function() {
  if (this._events === void 0 || this._events === Object.getPrototypeOf(this)._events) {
    this._events = /* @__PURE__ */ Object.create(null);
    this._eventsCount = 0;
  }
  this._maxListeners = this._maxListeners || void 0;
};
EventEmitter.prototype.setMaxListeners = function setMaxListeners(n) {
  if (typeof n !== "number" || n < 0 || NumberIsNaN$2(n)) {
    throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + n + ".");
  }
  this._maxListeners = n;
  return this;
};
function _getMaxListeners(that) {
  if (that._maxListeners === void 0)
    return EventEmitter.defaultMaxListeners;
  return that._maxListeners;
}
EventEmitter.prototype.getMaxListeners = function getMaxListeners() {
  return _getMaxListeners(this);
};
EventEmitter.prototype.emit = function emit(type2) {
  var args = [];
  for (var i = 1; i < arguments.length; i++) args.push(arguments[i]);
  var doError = type2 === "error";
  var events2 = this._events;
  if (events2 !== void 0)
    doError = doError && events2.error === void 0;
  else if (!doError)
    return false;
  if (doError) {
    var er;
    if (args.length > 0)
      er = args[0];
    if (er instanceof Error) {
      throw er;
    }
    var err = new Error("Unhandled error." + (er ? " (" + er.message + ")" : ""));
    err.context = er;
    throw err;
  }
  var handler = events2[type2];
  if (handler === void 0)
    return false;
  if (typeof handler === "function") {
    ReflectApply(handler, this, args);
  } else {
    var len = handler.length;
    var listeners2 = arrayClone$1(handler, len);
    for (var i = 0; i < len; ++i)
      ReflectApply(listeners2[i], this, args);
  }
  return true;
};
function _addListener(target, type2, listener, prepend) {
  var m;
  var events2;
  var existing;
  checkListener(listener);
  events2 = target._events;
  if (events2 === void 0) {
    events2 = target._events = /* @__PURE__ */ Object.create(null);
    target._eventsCount = 0;
  } else {
    if (events2.newListener !== void 0) {
      target.emit(
        "newListener",
        type2,
        listener.listener ? listener.listener : listener
      );
      events2 = target._events;
    }
    existing = events2[type2];
  }
  if (existing === void 0) {
    existing = events2[type2] = listener;
    ++target._eventsCount;
  } else {
    if (typeof existing === "function") {
      existing = events2[type2] = prepend ? [listener, existing] : [existing, listener];
    } else if (prepend) {
      existing.unshift(listener);
    } else {
      existing.push(listener);
    }
    m = _getMaxListeners(target);
    if (m > 0 && existing.length > m && !existing.warned) {
      existing.warned = true;
      var w = new Error("Possible EventEmitter memory leak detected. " + existing.length + " " + String(type2) + " listeners added. Use emitter.setMaxListeners() to increase limit");
      w.name = "MaxListenersExceededWarning";
      w.emitter = target;
      w.type = type2;
      w.count = existing.length;
      ProcessEmitWarning(w);
    }
  }
  return target;
}
EventEmitter.prototype.addListener = function addListener(type2, listener) {
  return _addListener(this, type2, listener, false);
};
EventEmitter.prototype.on = EventEmitter.prototype.addListener;
EventEmitter.prototype.prependListener = function prependListener(type2, listener) {
  return _addListener(this, type2, listener, true);
};
function onceWrapper() {
  if (!this.fired) {
    this.target.removeListener(this.type, this.wrapFn);
    this.fired = true;
    if (arguments.length === 0)
      return this.listener.call(this.target);
    return this.listener.apply(this.target, arguments);
  }
}
function _onceWrap(target, type2, listener) {
  var state2 = { fired: false, wrapFn: void 0, target, type: type2, listener };
  var wrapped = onceWrapper.bind(state2);
  wrapped.listener = listener;
  state2.wrapFn = wrapped;
  return wrapped;
}
EventEmitter.prototype.once = function once(type2, listener) {
  checkListener(listener);
  this.on(type2, _onceWrap(this, type2, listener));
  return this;
};
EventEmitter.prototype.prependOnceListener = function prependOnceListener(type2, listener) {
  checkListener(listener);
  this.prependListener(type2, _onceWrap(this, type2, listener));
  return this;
};
EventEmitter.prototype.removeListener = function removeListener(type2, listener) {
  var list, events2, position, i, originalListener;
  checkListener(listener);
  events2 = this._events;
  if (events2 === void 0)
    return this;
  list = events2[type2];
  if (list === void 0)
    return this;
  if (list === listener || list.listener === listener) {
    if (--this._eventsCount === 0)
      this._events = /* @__PURE__ */ Object.create(null);
    else {
      delete events2[type2];
      if (events2.removeListener)
        this.emit("removeListener", type2, list.listener || listener);
    }
  } else if (typeof list !== "function") {
    position = -1;
    for (i = list.length - 1; i >= 0; i--) {
      if (list[i] === listener || list[i].listener === listener) {
        originalListener = list[i].listener;
        position = i;
        break;
      }
    }
    if (position < 0)
      return this;
    if (position === 0)
      list.shift();
    else {
      spliceOne(list, position);
    }
    if (list.length === 1)
      events2[type2] = list[0];
    if (events2.removeListener !== void 0)
      this.emit("removeListener", type2, originalListener || listener);
  }
  return this;
};
EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
EventEmitter.prototype.removeAllListeners = function removeAllListeners(type2) {
  var listeners2, events2, i;
  events2 = this._events;
  if (events2 === void 0)
    return this;
  if (events2.removeListener === void 0) {
    if (arguments.length === 0) {
      this._events = /* @__PURE__ */ Object.create(null);
      this._eventsCount = 0;
    } else if (events2[type2] !== void 0) {
      if (--this._eventsCount === 0)
        this._events = /* @__PURE__ */ Object.create(null);
      else
        delete events2[type2];
    }
    return this;
  }
  if (arguments.length === 0) {
    var keys2 = Object.keys(events2);
    var key;
    for (i = 0; i < keys2.length; ++i) {
      key = keys2[i];
      if (key === "removeListener") continue;
      this.removeAllListeners(key);
    }
    this.removeAllListeners("removeListener");
    this._events = /* @__PURE__ */ Object.create(null);
    this._eventsCount = 0;
    return this;
  }
  listeners2 = events2[type2];
  if (typeof listeners2 === "function") {
    this.removeListener(type2, listeners2);
  } else if (listeners2 !== void 0) {
    for (i = listeners2.length - 1; i >= 0; i--) {
      this.removeListener(type2, listeners2[i]);
    }
  }
  return this;
};
function _listeners(target, type2, unwrap) {
  var events2 = target._events;
  if (events2 === void 0)
    return [];
  var evlistener = events2[type2];
  if (evlistener === void 0)
    return [];
  if (typeof evlistener === "function")
    return unwrap ? [evlistener.listener || evlistener] : [evlistener];
  return unwrap ? unwrapListeners(evlistener) : arrayClone$1(evlistener, evlistener.length);
}
EventEmitter.prototype.listeners = function listeners(type2) {
  return _listeners(this, type2, true);
};
EventEmitter.prototype.rawListeners = function rawListeners(type2) {
  return _listeners(this, type2, false);
};
EventEmitter.listenerCount = function(emitter, type2) {
  if (typeof emitter.listenerCount === "function") {
    return emitter.listenerCount(type2);
  } else {
    return listenerCount.call(emitter, type2);
  }
};
EventEmitter.prototype.listenerCount = listenerCount;
function listenerCount(type2) {
  var events2 = this._events;
  if (events2 !== void 0) {
    var evlistener = events2[type2];
    if (typeof evlistener === "function") {
      return 1;
    } else if (evlistener !== void 0) {
      return evlistener.length;
    }
  }
  return 0;
}
EventEmitter.prototype.eventNames = function eventNames() {
  return this._eventsCount > 0 ? ReflectOwnKeys(this._events) : [];
};
function arrayClone$1(arr, n) {
  var copy = new Array(n);
  for (var i = 0; i < n; ++i)
    copy[i] = arr[i];
  return copy;
}
function spliceOne(list, index) {
  for (; index + 1 < list.length; index++)
    list[index] = list[index + 1];
  list.pop();
}
function unwrapListeners(arr) {
  var ret = new Array(arr.length);
  for (var i = 0; i < ret.length; ++i) {
    ret[i] = arr[i].listener || arr[i];
  }
  return ret;
}
function once$2(emitter, name) {
  return new Promise(function(resolve, reject) {
    function errorListener(err) {
      emitter.removeListener(name, resolver);
      reject(err);
    }
    function resolver() {
      if (typeof emitter.removeListener === "function") {
        emitter.removeListener("error", errorListener);
      }
      resolve([].slice.call(arguments));
    }
    eventTargetAgnosticAddListener(emitter, name, resolver, { once: true });
    if (name !== "error") {
      addErrorHandlerIfEventEmitter(emitter, errorListener, { once: true });
    }
  });
}
function addErrorHandlerIfEventEmitter(emitter, handler, flags) {
  if (typeof emitter.on === "function") {
    eventTargetAgnosticAddListener(emitter, "error", handler, flags);
  }
}
function eventTargetAgnosticAddListener(emitter, name, listener, flags) {
  if (typeof emitter.on === "function") {
    if (flags.once) {
      emitter.once(name, listener);
    } else {
      emitter.on(name, listener);
    }
  } else if (typeof emitter.addEventListener === "function") {
    emitter.addEventListener(name, function wrapListener(arg) {
      if (flags.once) {
        emitter.removeEventListener(name, wrapListener);
      }
      listener(arg);
    });
  } else {
    throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type ' + typeof emitter);
  }
}
var eventsExports = events.exports;
var browser$2 = { exports: {} };
var stream = { exports: {} };
let AggregateError$2 = class AggregateError2 extends Error {
  constructor(errors2) {
    if (!Array.isArray(errors2)) {
      throw new TypeError(`Expected input to be an Array, got ${typeof errors2}`);
    }
    let message = "";
    for (let i = 0; i < errors2.length; i++) {
      message += `    ${errors2[i].stack}
`;
    }
    super(message);
    this.name = "AggregateError";
    this.errors = errors2;
  }
};
var primordials = {
  AggregateError: AggregateError$2,
  ArrayIsArray(self2) {
    return Array.isArray(self2);
  },
  ArrayPrototypeIncludes(self2, el) {
    return self2.includes(el);
  },
  ArrayPrototypeIndexOf(self2, el) {
    return self2.indexOf(el);
  },
  ArrayPrototypeJoin(self2, sep) {
    return self2.join(sep);
  },
  ArrayPrototypeMap(self2, fn) {
    return self2.map(fn);
  },
  ArrayPrototypePop(self2, el) {
    return self2.pop(el);
  },
  ArrayPrototypePush(self2, el) {
    return self2.push(el);
  },
  ArrayPrototypeSlice(self2, start, end) {
    return self2.slice(start, end);
  },
  Error,
  FunctionPrototypeCall(fn, thisArgs, ...args) {
    return fn.call(thisArgs, ...args);
  },
  FunctionPrototypeSymbolHasInstance(self2, instance) {
    return Function.prototype[Symbol.hasInstance].call(self2, instance);
  },
  MathFloor: Math.floor,
  Number,
  NumberIsInteger: Number.isInteger,
  NumberIsNaN: Number.isNaN,
  NumberMAX_SAFE_INTEGER: Number.MAX_SAFE_INTEGER,
  NumberMIN_SAFE_INTEGER: Number.MIN_SAFE_INTEGER,
  NumberParseInt: Number.parseInt,
  ObjectDefineProperties(self2, props) {
    return Object.defineProperties(self2, props);
  },
  ObjectDefineProperty(self2, name, prop) {
    return Object.defineProperty(self2, name, prop);
  },
  ObjectGetOwnPropertyDescriptor(self2, name) {
    return Object.getOwnPropertyDescriptor(self2, name);
  },
  ObjectKeys(obj) {
    return Object.keys(obj);
  },
  ObjectSetPrototypeOf(target, proto) {
    return Object.setPrototypeOf(target, proto);
  },
  Promise,
  PromisePrototypeCatch(self2, fn) {
    return self2.catch(fn);
  },
  PromisePrototypeThen(self2, thenFn, catchFn) {
    return self2.then(thenFn, catchFn);
  },
  PromiseReject(err) {
    return Promise.reject(err);
  },
  PromiseResolve(val) {
    return Promise.resolve(val);
  },
  ReflectApply: Reflect.apply,
  RegExpPrototypeTest(self2, value) {
    return self2.test(value);
  },
  SafeSet: Set,
  String,
  StringPrototypeSlice(self2, start, end) {
    return self2.slice(start, end);
  },
  StringPrototypeToLowerCase(self2) {
    return self2.toLowerCase();
  },
  StringPrototypeToUpperCase(self2) {
    return self2.toUpperCase();
  },
  StringPrototypeTrim(self2) {
    return self2.trim();
  },
  Symbol,
  SymbolFor: Symbol.for,
  SymbolAsyncIterator: Symbol.asyncIterator,
  SymbolHasInstance: Symbol.hasInstance,
  SymbolIterator: Symbol.iterator,
  SymbolDispose: Symbol.dispose || Symbol("Symbol.dispose"),
  SymbolAsyncDispose: Symbol.asyncDispose || Symbol("Symbol.asyncDispose"),
  TypedArrayPrototypeSet(self2, buf, len) {
    return self2.set(buf, len);
  },
  Boolean,
  Uint8Array
};
var util = { exports: {} };
var inspect$2 = {
  format(format2, ...args) {
    return format2.replace(/%([sdifj])/g, function(...[_unused, type2]) {
      const replacement = args.shift();
      if (type2 === "f") {
        return replacement.toFixed(6);
      } else if (type2 === "j") {
        return JSON.stringify(replacement);
      } else if (type2 === "s" && typeof replacement === "object") {
        const ctor = replacement.constructor !== Object ? replacement.constructor.name : "";
        return `${ctor} {}`.trim();
      } else {
        return replacement.toString();
      }
    });
  },
  inspect(value) {
    switch (typeof value) {
      case "string":
        if (value.includes("'")) {
          if (!value.includes('"')) {
            return `"${value}"`;
          } else if (!value.includes("`") && !value.includes("${")) {
            return `\`${value}\``;
          }
        }
        return `'${value}'`;
      case "number":
        if (isNaN(value)) {
          return "NaN";
        } else if (Object.is(value, -0)) {
          return String(value);
        }
        return value;
      case "bigint":
        return `${String(value)}n`;
      case "boolean":
      case "undefined":
        return String(value);
      case "object":
        return "{}";
    }
  }
};
const { format, inspect: inspect$1 } = inspect$2;
const { AggregateError: CustomAggregateError } = primordials;
const AggregateError$1 = globalThis.AggregateError || CustomAggregateError;
const kIsNodeError = Symbol("kIsNodeError");
const kTypes = [
  "string",
  "function",
  "number",
  "object",
  // Accept 'Function' and 'Object' as alternative to the lower cased version.
  "Function",
  "Object",
  "boolean",
  "bigint",
  "symbol"
];
const classRegExp = /^([A-Z][a-z0-9]*)+$/;
const nodeInternalPrefix = "__node_internal_";
const codes$1 = {};
function assert(value, message) {
  if (!value) {
    throw new codes$1.ERR_INTERNAL_ASSERTION(message);
  }
}
function addNumericalSeparator(val) {
  let res = "";
  let i = val.length;
  const start = val[0] === "-" ? 1 : 0;
  for (; i >= start + 4; i -= 3) {
    res = `_${val.slice(i - 3, i)}${res}`;
  }
  return `${val.slice(0, i)}${res}`;
}
function getMessage(key, msg, args) {
  if (typeof msg === "function") {
    assert(
      msg.length <= args.length,
      // Default options do not count.
      `Code: ${key}; The provided arguments length (${args.length}) does not match the required ones (${msg.length}).`
    );
    return msg(...args);
  }
  const expectedLength = (msg.match(/%[dfijoOs]/g) || []).length;
  assert(
    expectedLength === args.length,
    `Code: ${key}; The provided arguments length (${args.length}) does not match the required ones (${expectedLength}).`
  );
  if (args.length === 0) {
    return msg;
  }
  return format(msg, ...args);
}
function E(code, message, Base) {
  if (!Base) {
    Base = Error;
  }
  class NodeError extends Base {
    constructor(...args) {
      super(getMessage(code, message, args));
    }
    toString() {
      return `${this.name} [${code}]: ${this.message}`;
    }
  }
  Object.defineProperties(NodeError.prototype, {
    name: {
      value: Base.name,
      writable: true,
      enumerable: false,
      configurable: true
    },
    toString: {
      value() {
        return `${this.name} [${code}]: ${this.message}`;
      },
      writable: true,
      enumerable: false,
      configurable: true
    }
  });
  NodeError.prototype.code = code;
  NodeError.prototype[kIsNodeError] = true;
  codes$1[code] = NodeError;
}
function hideStackFrames$1(fn) {
  const hidden = nodeInternalPrefix + fn.name;
  Object.defineProperty(fn, "name", {
    value: hidden
  });
  return fn;
}
function aggregateTwoErrors$2(innerError, outerError) {
  if (innerError && outerError && innerError !== outerError) {
    if (Array.isArray(outerError.errors)) {
      outerError.errors.push(innerError);
      return outerError;
    }
    const err = new AggregateError$1([outerError, innerError], outerError.message);
    err.code = outerError.code;
    return err;
  }
  return innerError || outerError;
}
let AbortError$5 = class AbortError extends Error {
  constructor(message = "The operation was aborted", options = void 0) {
    if (options !== void 0 && typeof options !== "object") {
      throw new codes$1.ERR_INVALID_ARG_TYPE("options", "Object", options);
    }
    super(message, options);
    this.code = "ABORT_ERR";
    this.name = "AbortError";
  }
};
E("ERR_ASSERTION", "%s", Error);
E(
  "ERR_INVALID_ARG_TYPE",
  (name, expected, actual) => {
    assert(typeof name === "string", "'name' must be a string");
    if (!Array.isArray(expected)) {
      expected = [expected];
    }
    let msg = "The ";
    if (name.endsWith(" argument")) {
      msg += `${name} `;
    } else {
      msg += `"${name}" ${name.includes(".") ? "property" : "argument"} `;
    }
    msg += "must be ";
    const types = [];
    const instances = [];
    const other = [];
    for (const value of expected) {
      assert(typeof value === "string", "All expected entries have to be of type string");
      if (kTypes.includes(value)) {
        types.push(value.toLowerCase());
      } else if (classRegExp.test(value)) {
        instances.push(value);
      } else {
        assert(value !== "object", 'The value "object" should be written as "Object"');
        other.push(value);
      }
    }
    if (instances.length > 0) {
      const pos = types.indexOf("object");
      if (pos !== -1) {
        types.splice(types, pos, 1);
        instances.push("Object");
      }
    }
    if (types.length > 0) {
      switch (types.length) {
        case 1:
          msg += `of type ${types[0]}`;
          break;
        case 2:
          msg += `one of type ${types[0]} or ${types[1]}`;
          break;
        default: {
          const last = types.pop();
          msg += `one of type ${types.join(", ")}, or ${last}`;
        }
      }
      if (instances.length > 0 || other.length > 0) {
        msg += " or ";
      }
    }
    if (instances.length > 0) {
      switch (instances.length) {
        case 1:
          msg += `an instance of ${instances[0]}`;
          break;
        case 2:
          msg += `an instance of ${instances[0]} or ${instances[1]}`;
          break;
        default: {
          const last = instances.pop();
          msg += `an instance of ${instances.join(", ")}, or ${last}`;
        }
      }
      if (other.length > 0) {
        msg += " or ";
      }
    }
    switch (other.length) {
      case 0:
        break;
      case 1:
        if (other[0].toLowerCase() !== other[0]) {
          msg += "an ";
        }
        msg += `${other[0]}`;
        break;
      case 2:
        msg += `one of ${other[0]} or ${other[1]}`;
        break;
      default: {
        const last = other.pop();
        msg += `one of ${other.join(", ")}, or ${last}`;
      }
    }
    if (actual == null) {
      msg += `. Received ${actual}`;
    } else if (typeof actual === "function" && actual.name) {
      msg += `. Received function ${actual.name}`;
    } else if (typeof actual === "object") {
      var _actual$constructor;
      if ((_actual$constructor = actual.constructor) !== null && _actual$constructor !== void 0 && _actual$constructor.name) {
        msg += `. Received an instance of ${actual.constructor.name}`;
      } else {
        const inspected = inspect$1(actual, {
          depth: -1
        });
        msg += `. Received ${inspected}`;
      }
    } else {
      let inspected = inspect$1(actual, {
        colors: false
      });
      if (inspected.length > 25) {
        inspected = `${inspected.slice(0, 25)}...`;
      }
      msg += `. Received type ${typeof actual} (${inspected})`;
    }
    return msg;
  },
  TypeError
);
E(
  "ERR_INVALID_ARG_VALUE",
  (name, value, reason = "is invalid") => {
    let inspected = inspect$1(value);
    if (inspected.length > 128) {
      inspected = inspected.slice(0, 128) + "...";
    }
    const type2 = name.includes(".") ? "property" : "argument";
    return `The ${type2} '${name}' ${reason}. Received ${inspected}`;
  },
  TypeError
);
E(
  "ERR_INVALID_RETURN_VALUE",
  (input, name, value) => {
    var _value$constructor;
    const type2 = value !== null && value !== void 0 && (_value$constructor = value.constructor) !== null && _value$constructor !== void 0 && _value$constructor.name ? `instance of ${value.constructor.name}` : `type ${typeof value}`;
    return `Expected ${input} to be returned from the "${name}" function but got ${type2}.`;
  },
  TypeError
);
E(
  "ERR_MISSING_ARGS",
  (...args) => {
    assert(args.length > 0, "At least one arg needs to be specified");
    let msg;
    const len = args.length;
    args = (Array.isArray(args) ? args : [args]).map((a) => `"${a}"`).join(" or ");
    switch (len) {
      case 1:
        msg += `The ${args[0]} argument`;
        break;
      case 2:
        msg += `The ${args[0]} and ${args[1]} arguments`;
        break;
      default:
        {
          const last = args.pop();
          msg += `The ${args.join(", ")}, and ${last} arguments`;
        }
        break;
    }
    return `${msg} must be specified`;
  },
  TypeError
);
E(
  "ERR_OUT_OF_RANGE",
  (str, range2, input) => {
    assert(range2, 'Missing "range" argument');
    let received;
    if (Number.isInteger(input) && Math.abs(input) > 2 ** 32) {
      received = addNumericalSeparator(String(input));
    } else if (typeof input === "bigint") {
      received = String(input);
      const limit = BigInt(2) ** BigInt(32);
      if (input > limit || input < -limit) {
        received = addNumericalSeparator(received);
      }
      received += "n";
    } else {
      received = inspect$1(input);
    }
    return `The value of "${str}" is out of range. It must be ${range2}. Received ${received}`;
  },
  RangeError
);
E("ERR_MULTIPLE_CALLBACK", "Callback called multiple times", Error);
E("ERR_METHOD_NOT_IMPLEMENTED", "The %s method is not implemented", Error);
E("ERR_STREAM_ALREADY_FINISHED", "Cannot call %s after a stream was finished", Error);
E("ERR_STREAM_CANNOT_PIPE", "Cannot pipe, not readable", Error);
E("ERR_STREAM_DESTROYED", "Cannot call %s after a stream was destroyed", Error);
E("ERR_STREAM_NULL_VALUES", "May not write null values to stream", TypeError);
E("ERR_STREAM_PREMATURE_CLOSE", "Premature close", Error);
E("ERR_STREAM_PUSH_AFTER_EOF", "stream.push() after EOF", Error);
E("ERR_STREAM_UNSHIFT_AFTER_END_EVENT", "stream.unshift() after end event", Error);
E("ERR_STREAM_WRITE_AFTER_END", "write after end", Error);
E("ERR_UNKNOWN_ENCODING", "Unknown encoding: %s", TypeError);
var errors = {
  AbortError: AbortError$5,
  aggregateTwoErrors: hideStackFrames$1(aggregateTwoErrors$2),
  hideStackFrames: hideStackFrames$1,
  codes: codes$1
};
var browser$1 = { exports: {} };
var hasRequiredBrowser;
function requireBrowser() {
  if (hasRequiredBrowser) return browser$1.exports;
  hasRequiredBrowser = 1;
  const { AbortController: AbortController2, AbortSignal } = typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : (
    /* otherwise */
    void 0
  );
  browser$1.exports = AbortController2;
  browser$1.exports.AbortSignal = AbortSignal;
  browser$1.exports.default = AbortController2;
  return browser$1.exports;
}
(function(module) {
  const bufferModule = buffer;
  const { format: format2, inspect: inspect2 } = inspect$2;
  const {
    codes: { ERR_INVALID_ARG_TYPE: ERR_INVALID_ARG_TYPE2 }
  } = errors;
  const { kResistStopPropagation: kResistStopPropagation2, AggregateError: AggregateError3, SymbolDispose: SymbolDispose2 } = primordials;
  const AbortSignal = globalThis.AbortSignal || requireBrowser().AbortSignal;
  const AbortController2 = globalThis.AbortController || requireBrowser().AbortController;
  const AsyncFunction = Object.getPrototypeOf(async function() {
  }).constructor;
  const Blob = globalThis.Blob || bufferModule.Blob;
  const isBlob = typeof Blob !== "undefined" ? function isBlob2(b) {
    return b instanceof Blob;
  } : function isBlob3(b) {
    return false;
  };
  const validateAbortSignal2 = (signal, name) => {
    if (signal !== void 0 && (signal === null || typeof signal !== "object" || !("aborted" in signal))) {
      throw new ERR_INVALID_ARG_TYPE2(name, "AbortSignal", signal);
    }
  };
  const validateFunction2 = (value, name) => {
    if (typeof value !== "function") {
      throw new ERR_INVALID_ARG_TYPE2(name, "Function", value);
    }
  };
  module.exports = {
    AggregateError: AggregateError3,
    kEmptyObject: Object.freeze({}),
    once(callback) {
      let called = false;
      return function(...args) {
        if (called) {
          return;
        }
        called = true;
        callback.apply(this, args);
      };
    },
    createDeferredPromise: function() {
      let resolve;
      let reject;
      const promise = new Promise((res, rej) => {
        resolve = res;
        reject = rej;
      });
      return {
        promise,
        resolve,
        reject
      };
    },
    promisify(fn) {
      return new Promise((resolve, reject) => {
        fn((err, ...args) => {
          if (err) {
            return reject(err);
          }
          return resolve(...args);
        });
      });
    },
    debuglog() {
      return function() {
      };
    },
    format: format2,
    inspect: inspect2,
    types: {
      isAsyncFunction(fn) {
        return fn instanceof AsyncFunction;
      },
      isArrayBufferView(arr) {
        return ArrayBuffer.isView(arr);
      }
    },
    isBlob,
    deprecate(fn, message) {
      return fn;
    },
    addAbortListener: eventsExports.addAbortListener || function addAbortListener2(signal, listener) {
      if (signal === void 0) {
        throw new ERR_INVALID_ARG_TYPE2("signal", "AbortSignal", signal);
      }
      validateAbortSignal2(signal, "signal");
      validateFunction2(listener, "listener");
      let removeEventListener;
      if (signal.aborted) {
        queueMicrotask(() => listener());
      } else {
        signal.addEventListener("abort", listener, {
          __proto__: null,
          once: true,
          [kResistStopPropagation2]: true
        });
        removeEventListener = () => {
          signal.removeEventListener("abort", listener);
        };
      }
      return {
        __proto__: null,
        [SymbolDispose2]() {
          var _removeEventListener;
          (_removeEventListener = removeEventListener) === null || _removeEventListener === void 0 ? void 0 : _removeEventListener();
        }
      };
    },
    AbortSignalAny: AbortSignal.any || function AbortSignalAny(signals) {
      if (signals.length === 1) {
        return signals[0];
      }
      const ac = new AbortController2();
      const abort = () => ac.abort();
      signals.forEach((signal) => {
        validateAbortSignal2(signal, "signals");
        signal.addEventListener("abort", abort, {
          once: true
        });
      });
      ac.signal.addEventListener(
        "abort",
        () => {
          signals.forEach((signal) => signal.removeEventListener("abort", abort));
        },
        {
          once: true
        }
      );
      return ac.signal;
    }
  };
  module.exports.promisify.custom = Symbol.for("nodejs.util.promisify.custom");
})(util);
var utilExports = util.exports;
var operators = {};
const {
  ArrayIsArray: ArrayIsArray$2,
  ArrayPrototypeIncludes,
  ArrayPrototypeJoin,
  ArrayPrototypeMap,
  NumberIsInteger: NumberIsInteger$1,
  NumberIsNaN: NumberIsNaN$1,
  NumberMAX_SAFE_INTEGER,
  NumberMIN_SAFE_INTEGER,
  NumberParseInt,
  ObjectPrototypeHasOwnProperty,
  RegExpPrototypeExec,
  String: String$1,
  StringPrototypeToUpperCase,
  StringPrototypeTrim
} = primordials;
const {
  hideStackFrames,
  codes: { ERR_SOCKET_BAD_PORT, ERR_INVALID_ARG_TYPE: ERR_INVALID_ARG_TYPE$4, ERR_INVALID_ARG_VALUE: ERR_INVALID_ARG_VALUE$3, ERR_OUT_OF_RANGE: ERR_OUT_OF_RANGE$1, ERR_UNKNOWN_SIGNAL }
} = errors;
const { normalizeEncoding: normalizeEncoding$1 } = utilExports;
const { isAsyncFunction, isArrayBufferView } = utilExports.types;
const validateInteger$2 = hideStackFrames((value, name, min2 = NumberMIN_SAFE_INTEGER, max2 = NumberMAX_SAFE_INTEGER) => {
  if (typeof value !== "number") throw new ERR_INVALID_ARG_TYPE$4(name, "number", value);
  if (!NumberIsInteger$1(value)) throw new ERR_OUT_OF_RANGE$1(name, "an integer", value);
  if (value < min2 || value > max2) throw new ERR_OUT_OF_RANGE$1(name, `>= ${min2} && <= ${max2}`, value);
});
hideStackFrames((value, name, min2 = -2147483648, max2 = 2147483647) => {
  if (typeof value !== "number") {
    throw new ERR_INVALID_ARG_TYPE$4(name, "number", value);
  }
  if (!NumberIsInteger$1(value)) {
    throw new ERR_OUT_OF_RANGE$1(name, "an integer", value);
  }
  if (value < min2 || value > max2) {
    throw new ERR_OUT_OF_RANGE$1(name, `>= ${min2} && <= ${max2}`, value);
  }
});
hideStackFrames((value, name, positive = false) => {
  if (typeof value !== "number") {
    throw new ERR_INVALID_ARG_TYPE$4(name, "number", value);
  }
  if (!NumberIsInteger$1(value)) {
    throw new ERR_OUT_OF_RANGE$1(name, "an integer", value);
  }
  const min2 = positive ? 1 : 0;
  const max2 = 4294967295;
  if (value < min2 || value > max2) {
    throw new ERR_OUT_OF_RANGE$1(name, `>= ${min2} && <= ${max2}`, value);
  }
});
hideStackFrames((value, name, oneOf) => {
  if (!ArrayPrototypeIncludes(oneOf, value)) {
    const allowed = ArrayPrototypeJoin(
      ArrayPrototypeMap(oneOf, (v) => typeof v === "string" ? `'${v}'` : String$1(v)),
      ", "
    );
    const reason = "must be one of: " + allowed;
    throw new ERR_INVALID_ARG_VALUE$3(name, value, reason);
  }
});
function validateBoolean$1(value, name) {
  if (typeof value !== "boolean") throw new ERR_INVALID_ARG_TYPE$4(name, "boolean", value);
}
function getOwnPropertyValueOrDefault(options, key, defaultValue) {
  return options == null || !ObjectPrototypeHasOwnProperty(options, key) ? defaultValue : options[key];
}
const validateObject$2 = hideStackFrames((value, name, options = null) => {
  const allowArray = getOwnPropertyValueOrDefault(options, "allowArray", false);
  const allowFunction = getOwnPropertyValueOrDefault(options, "allowFunction", false);
  const nullable = getOwnPropertyValueOrDefault(options, "nullable", false);
  if (!nullable && value === null || !allowArray && ArrayIsArray$2(value) || typeof value !== "object" && (!allowFunction || typeof value !== "function")) {
    throw new ERR_INVALID_ARG_TYPE$4(name, "Object", value);
  }
});
hideStackFrames((value, name) => {
  if (value != null && typeof value !== "object" && typeof value !== "function") {
    throw new ERR_INVALID_ARG_TYPE$4(name, "a dictionary", value);
  }
});
hideStackFrames((value, name, minLength = 0) => {
  if (!ArrayIsArray$2(value)) {
    throw new ERR_INVALID_ARG_TYPE$4(name, "Array", value);
  }
  if (value.length < minLength) {
    const reason = `must be longer than ${minLength}`;
    throw new ERR_INVALID_ARG_VALUE$3(name, value, reason);
  }
});
hideStackFrames((buffer2, name = "buffer") => {
  if (!isArrayBufferView(buffer2)) {
    throw new ERR_INVALID_ARG_TYPE$4(name, ["Buffer", "TypedArray", "DataView"], buffer2);
  }
});
const validateAbortSignal$3 = hideStackFrames((signal, name) => {
  if (signal !== void 0 && (signal === null || typeof signal !== "object" || !("aborted" in signal))) {
    throw new ERR_INVALID_ARG_TYPE$4(name, "AbortSignal", signal);
  }
});
const validateFunction$2 = hideStackFrames((value, name) => {
  if (typeof value !== "function") throw new ERR_INVALID_ARG_TYPE$4(name, "Function", value);
});
hideStackFrames((value, name) => {
  if (typeof value !== "function" || isAsyncFunction(value)) throw new ERR_INVALID_ARG_TYPE$4(name, "Function", value);
});
hideStackFrames((value, name) => {
  if (value !== void 0) throw new ERR_INVALID_ARG_TYPE$4(name, "undefined", value);
});
var validators = {
  validateBoolean: validateBoolean$1,
  validateFunction: validateFunction$2,
  validateInteger: validateInteger$2,
  validateObject: validateObject$2,
  validateAbortSignal: validateAbortSignal$3
};
var endOfStream = { exports: {} };
var browser = { exports: {} };
var process$4 = browser.exports = {};
var cachedSetTimeout;
var cachedClearTimeout;
function defaultSetTimout() {
  throw new Error("setTimeout has not been defined");
}
function defaultClearTimeout() {
  throw new Error("clearTimeout has not been defined");
}
(function() {
  try {
    if (typeof setTimeout === "function") {
      cachedSetTimeout = setTimeout;
    } else {
      cachedSetTimeout = defaultSetTimout;
    }
  } catch (e) {
    cachedSetTimeout = defaultSetTimout;
  }
  try {
    if (typeof clearTimeout === "function") {
      cachedClearTimeout = clearTimeout;
    } else {
      cachedClearTimeout = defaultClearTimeout;
    }
  } catch (e) {
    cachedClearTimeout = defaultClearTimeout;
  }
})();
function runTimeout(fun) {
  if (cachedSetTimeout === setTimeout) {
    return setTimeout(fun, 0);
  }
  if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
    cachedSetTimeout = setTimeout;
    return setTimeout(fun, 0);
  }
  try {
    return cachedSetTimeout(fun, 0);
  } catch (e) {
    try {
      return cachedSetTimeout.call(null, fun, 0);
    } catch (e2) {
      return cachedSetTimeout.call(this, fun, 0);
    }
  }
}
function runClearTimeout(marker) {
  if (cachedClearTimeout === clearTimeout) {
    return clearTimeout(marker);
  }
  if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
    cachedClearTimeout = clearTimeout;
    return clearTimeout(marker);
  }
  try {
    return cachedClearTimeout(marker);
  } catch (e) {
    try {
      return cachedClearTimeout.call(null, marker);
    } catch (e2) {
      return cachedClearTimeout.call(this, marker);
    }
  }
}
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;
function cleanUpNextTick() {
  if (!draining || !currentQueue) {
    return;
  }
  draining = false;
  if (currentQueue.length) {
    queue = currentQueue.concat(queue);
  } else {
    queueIndex = -1;
  }
  if (queue.length) {
    drainQueue();
  }
}
function drainQueue() {
  if (draining) {
    return;
  }
  var timeout2 = runTimeout(cleanUpNextTick);
  draining = true;
  var len = queue.length;
  while (len) {
    currentQueue = queue;
    queue = [];
    while (++queueIndex < len) {
      if (currentQueue) {
        currentQueue[queueIndex].run();
      }
    }
    queueIndex = -1;
    len = queue.length;
  }
  currentQueue = null;
  draining = false;
  runClearTimeout(timeout2);
}
process$4.nextTick = function(fun) {
  var args = new Array(arguments.length - 1);
  if (arguments.length > 1) {
    for (var i = 1; i < arguments.length; i++) {
      args[i - 1] = arguments[i];
    }
  }
  queue.push(new Item(fun, args));
  if (queue.length === 1 && !draining) {
    runTimeout(drainQueue);
  }
};
function Item(fun, array) {
  this.fun = fun;
  this.array = array;
}
Item.prototype.run = function() {
  this.fun.apply(null, this.array);
};
process$4.title = "browser";
process$4.browser = true;
process$4.env = {};
process$4.argv = [];
process$4.version = "";
process$4.versions = {};
function noop() {
}
process$4.on = noop;
process$4.addListener = noop;
process$4.once = noop;
process$4.off = noop;
process$4.removeListener = noop;
process$4.removeAllListeners = noop;
process$4.emit = noop;
process$4.prependListener = noop;
process$4.prependOnceListener = noop;
process$4.listeners = function(name) {
  return [];
};
process$4.binding = function(name) {
  throw new Error("process.binding is not supported");
};
process$4.cwd = function() {
  return "/";
};
process$4.chdir = function(dir) {
  throw new Error("process.chdir is not supported");
};
process$4.umask = function() {
  return 0;
};
var browserExports = browser.exports;
const { SymbolAsyncIterator: SymbolAsyncIterator$2, SymbolIterator: SymbolIterator$2, SymbolFor } = primordials;
const kIsDestroyed$1 = SymbolFor("nodejs.stream.destroyed");
const kIsErrored = SymbolFor("nodejs.stream.errored");
const kIsReadable = SymbolFor("nodejs.stream.readable");
const kIsWritable = SymbolFor("nodejs.stream.writable");
const kIsDisturbed = SymbolFor("nodejs.stream.disturbed");
const kIsClosedPromise$1 = SymbolFor("nodejs.webstream.isClosedPromise");
const kControllerErrorFunction = SymbolFor("nodejs.webstream.controllerErrorFunction");
function isReadableNodeStream$2(obj, strict = false) {
  var _obj$_readableState;
  return !!(obj && typeof obj.pipe === "function" && typeof obj.on === "function" && (!strict || typeof obj.pause === "function" && typeof obj.resume === "function") && (!obj._writableState || ((_obj$_readableState = obj._readableState) === null || _obj$_readableState === void 0 ? void 0 : _obj$_readableState.readable) !== false) && // Duplex
  (!obj._writableState || obj._readableState));
}
function isWritableNodeStream$1(obj) {
  var _obj$_writableState;
  return !!(obj && typeof obj.write === "function" && typeof obj.on === "function" && (!obj._readableState || ((_obj$_writableState = obj._writableState) === null || _obj$_writableState === void 0 ? void 0 : _obj$_writableState.writable) !== false));
}
function isDuplexNodeStream(obj) {
  return !!(obj && typeof obj.pipe === "function" && obj._readableState && typeof obj.on === "function" && typeof obj.write === "function");
}
function isNodeStream$4(obj) {
  return obj && (obj._readableState || obj._writableState || typeof obj.write === "function" && typeof obj.on === "function" || typeof obj.pipe === "function" && typeof obj.on === "function");
}
function isReadableStream$3(obj) {
  return !!(obj && !isNodeStream$4(obj) && typeof obj.pipeThrough === "function" && typeof obj.getReader === "function" && typeof obj.cancel === "function");
}
function isWritableStream$2(obj) {
  return !!(obj && !isNodeStream$4(obj) && typeof obj.getWriter === "function" && typeof obj.abort === "function");
}
function isTransformStream$2(obj) {
  return !!(obj && !isNodeStream$4(obj) && typeof obj.readable === "object" && typeof obj.writable === "object");
}
function isWebStream$2(obj) {
  return isReadableStream$3(obj) || isWritableStream$2(obj) || isTransformStream$2(obj);
}
function isIterable$1(obj, isAsync) {
  if (obj == null) return false;
  if (isAsync === true) return typeof obj[SymbolAsyncIterator$2] === "function";
  if (isAsync === false) return typeof obj[SymbolIterator$2] === "function";
  return typeof obj[SymbolAsyncIterator$2] === "function" || typeof obj[SymbolIterator$2] === "function";
}
function isDestroyed$1(stream2) {
  if (!isNodeStream$4(stream2)) return null;
  const wState = stream2._writableState;
  const rState = stream2._readableState;
  const state2 = wState || rState;
  return !!(stream2.destroyed || stream2[kIsDestroyed$1] || state2 !== null && state2 !== void 0 && state2.destroyed);
}
function isWritableEnded(stream2) {
  if (!isWritableNodeStream$1(stream2)) return null;
  if (stream2.writableEnded === true) return true;
  const wState = stream2._writableState;
  if (wState !== null && wState !== void 0 && wState.errored) return false;
  if (typeof (wState === null || wState === void 0 ? void 0 : wState.ended) !== "boolean") return null;
  return wState.ended;
}
function isWritableFinished$1(stream2, strict) {
  if (!isWritableNodeStream$1(stream2)) return null;
  if (stream2.writableFinished === true) return true;
  const wState = stream2._writableState;
  if (wState !== null && wState !== void 0 && wState.errored) return false;
  if (typeof (wState === null || wState === void 0 ? void 0 : wState.finished) !== "boolean") return null;
  return !!(wState.finished || strict === false && wState.ended === true && wState.length === 0);
}
function isReadableFinished$2(stream2, strict) {
  if (!isReadableNodeStream$2(stream2)) return null;
  const rState = stream2._readableState;
  if (rState !== null && rState !== void 0 && rState.errored) return false;
  if (typeof (rState === null || rState === void 0 ? void 0 : rState.endEmitted) !== "boolean") return null;
  return !!(rState.endEmitted || strict === false && rState.ended === true && rState.length === 0);
}
function isReadable$3(stream2) {
  if (stream2 && stream2[kIsReadable] != null) return stream2[kIsReadable];
  if (typeof (stream2 === null || stream2 === void 0 ? void 0 : stream2.readable) !== "boolean") return null;
  if (isDestroyed$1(stream2)) return false;
  return isReadableNodeStream$2(stream2) && stream2.readable && !isReadableFinished$2(stream2);
}
function isWritable$3(stream2) {
  if (stream2 && stream2[kIsWritable] != null) return stream2[kIsWritable];
  if (typeof (stream2 === null || stream2 === void 0 ? void 0 : stream2.writable) !== "boolean") return null;
  if (isDestroyed$1(stream2)) return false;
  return isWritableNodeStream$1(stream2) && stream2.writable && !isWritableEnded(stream2);
}
function isFinished$1(stream2, opts) {
  if (!isNodeStream$4(stream2)) {
    return null;
  }
  if (isDestroyed$1(stream2)) {
    return true;
  }
  if ((opts === null || opts === void 0 ? void 0 : opts.readable) !== false && isReadable$3(stream2)) {
    return false;
  }
  if ((opts === null || opts === void 0 ? void 0 : opts.writable) !== false && isWritable$3(stream2)) {
    return false;
  }
  return true;
}
function isWritableErrored$1(stream2) {
  var _stream$_writableStat, _stream$_writableStat2;
  if (!isNodeStream$4(stream2)) {
    return null;
  }
  if (stream2.writableErrored) {
    return stream2.writableErrored;
  }
  return (_stream$_writableStat = (_stream$_writableStat2 = stream2._writableState) === null || _stream$_writableStat2 === void 0 ? void 0 : _stream$_writableStat2.errored) !== null && _stream$_writableStat !== void 0 ? _stream$_writableStat : null;
}
function isReadableErrored$1(stream2) {
  var _stream$_readableStat, _stream$_readableStat2;
  if (!isNodeStream$4(stream2)) {
    return null;
  }
  if (stream2.readableErrored) {
    return stream2.readableErrored;
  }
  return (_stream$_readableStat = (_stream$_readableStat2 = stream2._readableState) === null || _stream$_readableStat2 === void 0 ? void 0 : _stream$_readableStat2.errored) !== null && _stream$_readableStat !== void 0 ? _stream$_readableStat : null;
}
function isClosed$1(stream2) {
  if (!isNodeStream$4(stream2)) {
    return null;
  }
  if (typeof stream2.closed === "boolean") {
    return stream2.closed;
  }
  const wState = stream2._writableState;
  const rState = stream2._readableState;
  if (typeof (wState === null || wState === void 0 ? void 0 : wState.closed) === "boolean" || typeof (rState === null || rState === void 0 ? void 0 : rState.closed) === "boolean") {
    return (wState === null || wState === void 0 ? void 0 : wState.closed) || (rState === null || rState === void 0 ? void 0 : rState.closed);
  }
  if (typeof stream2._closed === "boolean" && isOutgoingMessage(stream2)) {
    return stream2._closed;
  }
  return null;
}
function isOutgoingMessage(stream2) {
  return typeof stream2._closed === "boolean" && typeof stream2._defaultKeepAlive === "boolean" && typeof stream2._removedConnection === "boolean" && typeof stream2._removedContLen === "boolean";
}
function isServerResponse(stream2) {
  return typeof stream2._sent100 === "boolean" && isOutgoingMessage(stream2);
}
function isServerRequest$1(stream2) {
  var _stream$req;
  return typeof stream2._consuming === "boolean" && typeof stream2._dumped === "boolean" && ((_stream$req = stream2.req) === null || _stream$req === void 0 ? void 0 : _stream$req.upgradeOrConnect) === void 0;
}
function willEmitClose(stream2) {
  if (!isNodeStream$4(stream2)) return null;
  const wState = stream2._writableState;
  const rState = stream2._readableState;
  const state2 = wState || rState;
  return !state2 && isServerResponse(stream2) || !!(state2 && state2.autoDestroy && state2.emitClose && state2.closed === false);
}
function isDisturbed(stream2) {
  var _stream$kIsDisturbed;
  return !!(stream2 && ((_stream$kIsDisturbed = stream2[kIsDisturbed]) !== null && _stream$kIsDisturbed !== void 0 ? _stream$kIsDisturbed : stream2.readableDidRead || stream2.readableAborted));
}
function isErrored(stream2) {
  var _ref, _ref2, _ref3, _ref4, _ref5, _stream$kIsErrored, _stream$_readableStat3, _stream$_writableStat3, _stream$_readableStat4, _stream$_writableStat4;
  return !!(stream2 && ((_ref = (_ref2 = (_ref3 = (_ref4 = (_ref5 = (_stream$kIsErrored = stream2[kIsErrored]) !== null && _stream$kIsErrored !== void 0 ? _stream$kIsErrored : stream2.readableErrored) !== null && _ref5 !== void 0 ? _ref5 : stream2.writableErrored) !== null && _ref4 !== void 0 ? _ref4 : (_stream$_readableStat3 = stream2._readableState) === null || _stream$_readableStat3 === void 0 ? void 0 : _stream$_readableStat3.errorEmitted) !== null && _ref3 !== void 0 ? _ref3 : (_stream$_writableStat3 = stream2._writableState) === null || _stream$_writableStat3 === void 0 ? void 0 : _stream$_writableStat3.errorEmitted) !== null && _ref2 !== void 0 ? _ref2 : (_stream$_readableStat4 = stream2._readableState) === null || _stream$_readableStat4 === void 0 ? void 0 : _stream$_readableStat4.errored) !== null && _ref !== void 0 ? _ref : (_stream$_writableStat4 = stream2._writableState) === null || _stream$_writableStat4 === void 0 ? void 0 : _stream$_writableStat4.errored));
}
var utils = {
  isDestroyed: isDestroyed$1,
  kIsDestroyed: kIsDestroyed$1,
  isDisturbed,
  isErrored,
  isReadable: isReadable$3,
  kIsClosedPromise: kIsClosedPromise$1,
  kControllerErrorFunction,
  isClosed: isClosed$1,
  isDuplexNodeStream,
  isFinished: isFinished$1,
  isIterable: isIterable$1,
  isReadableNodeStream: isReadableNodeStream$2,
  isReadableStream: isReadableStream$3,
  isReadableFinished: isReadableFinished$2,
  isReadableErrored: isReadableErrored$1,
  isNodeStream: isNodeStream$4,
  isWebStream: isWebStream$2,
  isWritable: isWritable$3,
  isWritableNodeStream: isWritableNodeStream$1,
  isWritableStream: isWritableStream$2,
  isWritableFinished: isWritableFinished$1,
  isWritableErrored: isWritableErrored$1,
  isServerRequest: isServerRequest$1,
  willEmitClose,
  isTransformStream: isTransformStream$2
};
const process$3 = browserExports;
const { AbortError: AbortError$4, codes } = errors;
const { ERR_INVALID_ARG_TYPE: ERR_INVALID_ARG_TYPE$3, ERR_STREAM_PREMATURE_CLOSE: ERR_STREAM_PREMATURE_CLOSE$1 } = codes;
const { kEmptyObject, once: once$1 } = utilExports;
const { validateAbortSignal: validateAbortSignal$2, validateFunction: validateFunction$1, validateObject: validateObject$1, validateBoolean } = validators;
const { Promise: Promise$3, PromisePrototypeThen: PromisePrototypeThen$2, SymbolDispose: SymbolDispose$1 } = primordials;
const {
  isClosed,
  isReadable: isReadable$2,
  isReadableNodeStream: isReadableNodeStream$1,
  isReadableStream: isReadableStream$2,
  isReadableFinished: isReadableFinished$1,
  isReadableErrored,
  isWritable: isWritable$2,
  isWritableNodeStream,
  isWritableStream: isWritableStream$1,
  isWritableFinished,
  isWritableErrored,
  isNodeStream: isNodeStream$3,
  willEmitClose: _willEmitClose,
  kIsClosedPromise
} = utils;
let addAbortListener$1;
function isRequest$1(stream2) {
  return stream2.setHeader && typeof stream2.abort === "function";
}
const nop = () => {
};
function eos$2(stream2, options, callback) {
  var _options$readable, _options$writable;
  if (arguments.length === 2) {
    callback = options;
    options = kEmptyObject;
  } else if (options == null) {
    options = kEmptyObject;
  } else {
    validateObject$1(options, "options");
  }
  validateFunction$1(callback, "callback");
  validateAbortSignal$2(options.signal, "options.signal");
  callback = once$1(callback);
  if (isReadableStream$2(stream2) || isWritableStream$1(stream2)) {
    return eosWeb(stream2, options, callback);
  }
  if (!isNodeStream$3(stream2)) {
    throw new ERR_INVALID_ARG_TYPE$3("stream", ["ReadableStream", "WritableStream", "Stream"], stream2);
  }
  const readable2 = (_options$readable = options.readable) !== null && _options$readable !== void 0 ? _options$readable : isReadableNodeStream$1(stream2);
  const writable2 = (_options$writable = options.writable) !== null && _options$writable !== void 0 ? _options$writable : isWritableNodeStream(stream2);
  const wState = stream2._writableState;
  const rState = stream2._readableState;
  const onlegacyfinish = () => {
    if (!stream2.writable) {
      onfinish();
    }
  };
  let willEmitClose2 = _willEmitClose(stream2) && isReadableNodeStream$1(stream2) === readable2 && isWritableNodeStream(stream2) === writable2;
  let writableFinished = isWritableFinished(stream2, false);
  const onfinish = () => {
    writableFinished = true;
    if (stream2.destroyed) {
      willEmitClose2 = false;
    }
    if (willEmitClose2 && (!stream2.readable || readable2)) {
      return;
    }
    if (!readable2 || readableFinished) {
      callback.call(stream2);
    }
  };
  let readableFinished = isReadableFinished$1(stream2, false);
  const onend = () => {
    readableFinished = true;
    if (stream2.destroyed) {
      willEmitClose2 = false;
    }
    if (willEmitClose2 && (!stream2.writable || writable2)) {
      return;
    }
    if (!writable2 || writableFinished) {
      callback.call(stream2);
    }
  };
  const onerror = (err) => {
    callback.call(stream2, err);
  };
  let closed = isClosed(stream2);
  const onclose = () => {
    closed = true;
    const errored = isWritableErrored(stream2) || isReadableErrored(stream2);
    if (errored && typeof errored !== "boolean") {
      return callback.call(stream2, errored);
    }
    if (readable2 && !readableFinished && isReadableNodeStream$1(stream2, true)) {
      if (!isReadableFinished$1(stream2, false)) return callback.call(stream2, new ERR_STREAM_PREMATURE_CLOSE$1());
    }
    if (writable2 && !writableFinished) {
      if (!isWritableFinished(stream2, false)) return callback.call(stream2, new ERR_STREAM_PREMATURE_CLOSE$1());
    }
    callback.call(stream2);
  };
  const onclosed = () => {
    closed = true;
    const errored = isWritableErrored(stream2) || isReadableErrored(stream2);
    if (errored && typeof errored !== "boolean") {
      return callback.call(stream2, errored);
    }
    callback.call(stream2);
  };
  const onrequest = () => {
    stream2.req.on("finish", onfinish);
  };
  if (isRequest$1(stream2)) {
    stream2.on("complete", onfinish);
    if (!willEmitClose2) {
      stream2.on("abort", onclose);
    }
    if (stream2.req) {
      onrequest();
    } else {
      stream2.on("request", onrequest);
    }
  } else if (writable2 && !wState) {
    stream2.on("end", onlegacyfinish);
    stream2.on("close", onlegacyfinish);
  }
  if (!willEmitClose2 && typeof stream2.aborted === "boolean") {
    stream2.on("aborted", onclose);
  }
  stream2.on("end", onend);
  stream2.on("finish", onfinish);
  if (options.error !== false) {
    stream2.on("error", onerror);
  }
  stream2.on("close", onclose);
  if (closed) {
    process$3.nextTick(onclose);
  } else if (wState !== null && wState !== void 0 && wState.errorEmitted || rState !== null && rState !== void 0 && rState.errorEmitted) {
    if (!willEmitClose2) {
      process$3.nextTick(onclosed);
    }
  } else if (!readable2 && (!willEmitClose2 || isReadable$2(stream2)) && (writableFinished || isWritable$2(stream2) === false)) {
    process$3.nextTick(onclosed);
  } else if (!writable2 && (!willEmitClose2 || isWritable$2(stream2)) && (readableFinished || isReadable$2(stream2) === false)) {
    process$3.nextTick(onclosed);
  } else if (rState && stream2.req && stream2.aborted) {
    process$3.nextTick(onclosed);
  }
  const cleanup = () => {
    callback = nop;
    stream2.removeListener("aborted", onclose);
    stream2.removeListener("complete", onfinish);
    stream2.removeListener("abort", onclose);
    stream2.removeListener("request", onrequest);
    if (stream2.req) stream2.req.removeListener("finish", onfinish);
    stream2.removeListener("end", onlegacyfinish);
    stream2.removeListener("close", onlegacyfinish);
    stream2.removeListener("finish", onfinish);
    stream2.removeListener("end", onend);
    stream2.removeListener("error", onerror);
    stream2.removeListener("close", onclose);
  };
  if (options.signal && !closed) {
    const abort = () => {
      const endCallback = callback;
      cleanup();
      endCallback.call(
        stream2,
        new AbortError$4(void 0, {
          cause: options.signal.reason
        })
      );
    };
    if (options.signal.aborted) {
      process$3.nextTick(abort);
    } else {
      addAbortListener$1 = addAbortListener$1 || utilExports.addAbortListener;
      const disposable = addAbortListener$1(options.signal, abort);
      const originalCallback = callback;
      callback = once$1((...args) => {
        disposable[SymbolDispose$1]();
        originalCallback.apply(stream2, args);
      });
    }
  }
  return cleanup;
}
function eosWeb(stream2, options, callback) {
  let isAborted = false;
  let abort = nop;
  if (options.signal) {
    abort = () => {
      isAborted = true;
      callback.call(
        stream2,
        new AbortError$4(void 0, {
          cause: options.signal.reason
        })
      );
    };
    if (options.signal.aborted) {
      process$3.nextTick(abort);
    } else {
      addAbortListener$1 = addAbortListener$1 || utilExports.addAbortListener;
      const disposable = addAbortListener$1(options.signal, abort);
      const originalCallback = callback;
      callback = once$1((...args) => {
        disposable[SymbolDispose$1]();
        originalCallback.apply(stream2, args);
      });
    }
  }
  const resolverFn = (...args) => {
    if (!isAborted) {
      process$3.nextTick(() => callback.apply(stream2, args));
    }
  };
  PromisePrototypeThen$2(stream2[kIsClosedPromise].promise, resolverFn, resolverFn);
  return nop;
}
function finished$1(stream2, opts) {
  var _opts;
  let autoCleanup = false;
  if (opts === null) {
    opts = kEmptyObject;
  }
  if ((_opts = opts) !== null && _opts !== void 0 && _opts.cleanup) {
    validateBoolean(opts.cleanup, "cleanup");
    autoCleanup = opts.cleanup;
  }
  return new Promise$3((resolve, reject) => {
    const cleanup = eos$2(stream2, opts, (err) => {
      if (autoCleanup) {
        cleanup();
      }
      if (err) {
        reject(err);
      } else {
        resolve();
      }
    });
  });
}
endOfStream.exports = eos$2;
endOfStream.exports.finished = finished$1;
var endOfStreamExports = endOfStream.exports;
const process$2 = browserExports;
const {
  aggregateTwoErrors: aggregateTwoErrors$1,
  codes: { ERR_MULTIPLE_CALLBACK },
  AbortError: AbortError$3
} = errors;
const { Symbol: Symbol$3 } = primordials;
const { kIsDestroyed, isDestroyed, isFinished, isServerRequest } = utils;
const kDestroy = Symbol$3("kDestroy");
const kConstruct = Symbol$3("kConstruct");
function checkError(err, w, r) {
  if (err) {
    err.stack;
    if (w && !w.errored) {
      w.errored = err;
    }
    if (r && !r.errored) {
      r.errored = err;
    }
  }
}
function destroy(err, cb) {
  const r = this._readableState;
  const w = this._writableState;
  const s = w || r;
  if (w !== null && w !== void 0 && w.destroyed || r !== null && r !== void 0 && r.destroyed) {
    if (typeof cb === "function") {
      cb();
    }
    return this;
  }
  checkError(err, w, r);
  if (w) {
    w.destroyed = true;
  }
  if (r) {
    r.destroyed = true;
  }
  if (!s.constructed) {
    this.once(kDestroy, function(er) {
      _destroy(this, aggregateTwoErrors$1(er, err), cb);
    });
  } else {
    _destroy(this, err, cb);
  }
  return this;
}
function _destroy(self2, err, cb) {
  let called = false;
  function onDestroy(err2) {
    if (called) {
      return;
    }
    called = true;
    const r = self2._readableState;
    const w = self2._writableState;
    checkError(err2, w, r);
    if (w) {
      w.closed = true;
    }
    if (r) {
      r.closed = true;
    }
    if (typeof cb === "function") {
      cb(err2);
    }
    if (err2) {
      process$2.nextTick(emitErrorCloseNT, self2, err2);
    } else {
      process$2.nextTick(emitCloseNT, self2);
    }
  }
  try {
    self2._destroy(err || null, onDestroy);
  } catch (err2) {
    onDestroy(err2);
  }
}
function emitErrorCloseNT(self2, err) {
  emitErrorNT(self2, err);
  emitCloseNT(self2);
}
function emitCloseNT(self2) {
  const r = self2._readableState;
  const w = self2._writableState;
  if (w) {
    w.closeEmitted = true;
  }
  if (r) {
    r.closeEmitted = true;
  }
  if (w !== null && w !== void 0 && w.emitClose || r !== null && r !== void 0 && r.emitClose) {
    self2.emit("close");
  }
}
function emitErrorNT(self2, err) {
  const r = self2._readableState;
  const w = self2._writableState;
  if (w !== null && w !== void 0 && w.errorEmitted || r !== null && r !== void 0 && r.errorEmitted) {
    return;
  }
  if (w) {
    w.errorEmitted = true;
  }
  if (r) {
    r.errorEmitted = true;
  }
  self2.emit("error", err);
}
function undestroy() {
  const r = this._readableState;
  const w = this._writableState;
  if (r) {
    r.constructed = true;
    r.closed = false;
    r.closeEmitted = false;
    r.destroyed = false;
    r.errored = null;
    r.errorEmitted = false;
    r.reading = false;
    r.ended = r.readable === false;
    r.endEmitted = r.readable === false;
  }
  if (w) {
    w.constructed = true;
    w.destroyed = false;
    w.closed = false;
    w.closeEmitted = false;
    w.errored = null;
    w.errorEmitted = false;
    w.finalCalled = false;
    w.prefinished = false;
    w.ended = w.writable === false;
    w.ending = w.writable === false;
    w.finished = w.writable === false;
  }
}
function errorOrDestroy(stream2, err, sync) {
  const r = stream2._readableState;
  const w = stream2._writableState;
  if (w !== null && w !== void 0 && w.destroyed || r !== null && r !== void 0 && r.destroyed) {
    return this;
  }
  if (r !== null && r !== void 0 && r.autoDestroy || w !== null && w !== void 0 && w.autoDestroy)
    stream2.destroy(err);
  else if (err) {
    err.stack;
    if (w && !w.errored) {
      w.errored = err;
    }
    if (r && !r.errored) {
      r.errored = err;
    }
    if (sync) {
      process$2.nextTick(emitErrorNT, stream2, err);
    } else {
      emitErrorNT(stream2, err);
    }
  }
}
function construct(stream2, cb) {
  if (typeof stream2._construct !== "function") {
    return;
  }
  const r = stream2._readableState;
  const w = stream2._writableState;
  if (r) {
    r.constructed = false;
  }
  if (w) {
    w.constructed = false;
  }
  stream2.once(kConstruct, cb);
  if (stream2.listenerCount(kConstruct) > 1) {
    return;
  }
  process$2.nextTick(constructNT, stream2);
}
function constructNT(stream2) {
  let called = false;
  function onConstruct(err) {
    if (called) {
      errorOrDestroy(stream2, err !== null && err !== void 0 ? err : new ERR_MULTIPLE_CALLBACK());
      return;
    }
    called = true;
    const r = stream2._readableState;
    const w = stream2._writableState;
    const s = w || r;
    if (r) {
      r.constructed = true;
    }
    if (w) {
      w.constructed = true;
    }
    if (s.destroyed) {
      stream2.emit(kDestroy, err);
    } else if (err) {
      errorOrDestroy(stream2, err, true);
    } else {
      process$2.nextTick(emitConstructNT, stream2);
    }
  }
  try {
    stream2._construct((err) => {
      process$2.nextTick(onConstruct, err);
    });
  } catch (err) {
    process$2.nextTick(onConstruct, err);
  }
}
function emitConstructNT(stream2) {
  stream2.emit(kConstruct);
}
function isRequest(stream2) {
  return (stream2 === null || stream2 === void 0 ? void 0 : stream2.setHeader) && typeof stream2.abort === "function";
}
function emitCloseLegacy(stream2) {
  stream2.emit("close");
}
function emitErrorCloseLegacy(stream2, err) {
  stream2.emit("error", err);
  process$2.nextTick(emitCloseLegacy, stream2);
}
function destroyer$2(stream2, err) {
  if (!stream2 || isDestroyed(stream2)) {
    return;
  }
  if (!err && !isFinished(stream2)) {
    err = new AbortError$3();
  }
  if (isServerRequest(stream2)) {
    stream2.socket = null;
    stream2.destroy(err);
  } else if (isRequest(stream2)) {
    stream2.abort();
  } else if (isRequest(stream2.req)) {
    stream2.req.abort();
  } else if (typeof stream2.destroy === "function") {
    stream2.destroy(err);
  } else if (typeof stream2.close === "function") {
    stream2.close();
  } else if (err) {
    process$2.nextTick(emitErrorCloseLegacy, stream2, err);
  } else {
    process$2.nextTick(emitCloseLegacy, stream2);
  }
  if (!stream2.destroyed) {
    stream2[kIsDestroyed] = true;
  }
}
var destroy_1 = {
  construct,
  destroyer: destroyer$2,
  destroy,
  undestroy,
  errorOrDestroy
};
const { ArrayIsArray: ArrayIsArray$1, ObjectSetPrototypeOf: ObjectSetPrototypeOf$2 } = primordials;
const { EventEmitter: EE } = eventsExports;
function Stream(opts) {
  EE.call(this, opts);
}
ObjectSetPrototypeOf$2(Stream.prototype, EE.prototype);
ObjectSetPrototypeOf$2(Stream, EE);
Stream.prototype.pipe = function(dest, options) {
  const source = this;
  function ondata(chunk) {
    if (dest.writable && dest.write(chunk) === false && source.pause) {
      source.pause();
    }
  }
  source.on("data", ondata);
  function ondrain() {
    if (source.readable && source.resume) {
      source.resume();
    }
  }
  dest.on("drain", ondrain);
  if (!dest._isStdio && (!options || options.end !== false)) {
    source.on("end", onend);
    source.on("close", onclose);
  }
  let didOnEnd = false;
  function onend() {
    if (didOnEnd) return;
    didOnEnd = true;
    dest.end();
  }
  function onclose() {
    if (didOnEnd) return;
    didOnEnd = true;
    if (typeof dest.destroy === "function") dest.destroy();
  }
  function onerror(er) {
    cleanup();
    if (EE.listenerCount(this, "error") === 0) {
      this.emit("error", er);
    }
  }
  prependListener2(source, "error", onerror);
  prependListener2(dest, "error", onerror);
  function cleanup() {
    source.removeListener("data", ondata);
    dest.removeListener("drain", ondrain);
    source.removeListener("end", onend);
    source.removeListener("close", onclose);
    source.removeListener("error", onerror);
    dest.removeListener("error", onerror);
    source.removeListener("end", cleanup);
    source.removeListener("close", cleanup);
    dest.removeListener("close", cleanup);
  }
  source.on("end", cleanup);
  source.on("close", cleanup);
  dest.on("close", cleanup);
  dest.emit("pipe", source);
  return dest;
};
function prependListener2(emitter, event, fn) {
  if (typeof emitter.prependListener === "function") return emitter.prependListener(event, fn);
  if (!emitter._events || !emitter._events[event]) emitter.on(event, fn);
  else if (ArrayIsArray$1(emitter._events[event])) emitter._events[event].unshift(fn);
  else emitter._events[event] = [fn, emitter._events[event]];
}
var legacy = {
  Stream,
  prependListener: prependListener2
};
var addAbortSignal = { exports: {} };
(function(module) {
  const { SymbolDispose: SymbolDispose2 } = primordials;
  const { AbortError: AbortError3, codes: codes2 } = errors;
  const { isNodeStream: isNodeStream2, isWebStream: isWebStream2, kControllerErrorFunction: kControllerErrorFunction2 } = utils;
  const eos2 = endOfStreamExports;
  const { ERR_INVALID_ARG_TYPE: ERR_INVALID_ARG_TYPE2 } = codes2;
  let addAbortListener2;
  const validateAbortSignal2 = (signal, name) => {
    if (typeof signal !== "object" || !("aborted" in signal)) {
      throw new ERR_INVALID_ARG_TYPE2(name, "AbortSignal", signal);
    }
  };
  module.exports.addAbortSignal = function addAbortSignal2(signal, stream2) {
    validateAbortSignal2(signal, "signal");
    if (!isNodeStream2(stream2) && !isWebStream2(stream2)) {
      throw new ERR_INVALID_ARG_TYPE2("stream", ["ReadableStream", "WritableStream", "Stream"], stream2);
    }
    return module.exports.addAbortSignalNoValidate(signal, stream2);
  };
  module.exports.addAbortSignalNoValidate = function(signal, stream2) {
    if (typeof signal !== "object" || !("aborted" in signal)) {
      return stream2;
    }
    const onAbort = isNodeStream2(stream2) ? () => {
      stream2.destroy(
        new AbortError3(void 0, {
          cause: signal.reason
        })
      );
    } : () => {
      stream2[kControllerErrorFunction2](
        new AbortError3(void 0, {
          cause: signal.reason
        })
      );
    };
    if (signal.aborted) {
      onAbort();
    } else {
      addAbortListener2 = addAbortListener2 || utilExports.addAbortListener;
      const disposable = addAbortListener2(signal, onAbort);
      eos2(stream2, disposable[SymbolDispose2]);
    }
    return stream2;
  };
})(addAbortSignal);
var addAbortSignalExports = addAbortSignal.exports;
const { StringPrototypeSlice, SymbolIterator: SymbolIterator$1, TypedArrayPrototypeSet, Uint8Array: Uint8Array$1 } = primordials;
const { Buffer: Buffer$2 } = buffer;
const { inspect } = utilExports;
var buffer_list = class BufferList {
  constructor() {
    this.head = null;
    this.tail = null;
    this.length = 0;
  }
  push(v) {
    const entry = {
      data: v,
      next: null
    };
    if (this.length > 0) this.tail.next = entry;
    else this.head = entry;
    this.tail = entry;
    ++this.length;
  }
  unshift(v) {
    const entry = {
      data: v,
      next: this.head
    };
    if (this.length === 0) this.tail = entry;
    this.head = entry;
    ++this.length;
  }
  shift() {
    if (this.length === 0) return;
    const ret = this.head.data;
    if (this.length === 1) this.head = this.tail = null;
    else this.head = this.head.next;
    --this.length;
    return ret;
  }
  clear() {
    this.head = this.tail = null;
    this.length = 0;
  }
  join(s) {
    if (this.length === 0) return "";
    let p = this.head;
    let ret = "" + p.data;
    while ((p = p.next) !== null) ret += s + p.data;
    return ret;
  }
  concat(n) {
    if (this.length === 0) return Buffer$2.alloc(0);
    const ret = Buffer$2.allocUnsafe(n >>> 0);
    let p = this.head;
    let i = 0;
    while (p) {
      TypedArrayPrototypeSet(ret, p.data, i);
      i += p.data.length;
      p = p.next;
    }
    return ret;
  }
  // Consumes a specified amount of bytes or characters from the buffered data.
  consume(n, hasStrings) {
    const data = this.head.data;
    if (n < data.length) {
      const slice2 = data.slice(0, n);
      this.head.data = data.slice(n);
      return slice2;
    }
    if (n === data.length) {
      return this.shift();
    }
    return hasStrings ? this._getString(n) : this._getBuffer(n);
  }
  first() {
    return this.head.data;
  }
  *[SymbolIterator$1]() {
    for (let p = this.head; p; p = p.next) {
      yield p.data;
    }
  }
  // Consumes a specified amount of characters from the buffered data.
  _getString(n) {
    let ret = "";
    let p = this.head;
    let c = 0;
    do {
      const str = p.data;
      if (n > str.length) {
        ret += str;
        n -= str.length;
      } else {
        if (n === str.length) {
          ret += str;
          ++c;
          if (p.next) this.head = p.next;
          else this.head = this.tail = null;
        } else {
          ret += StringPrototypeSlice(str, 0, n);
          this.head = p;
          p.data = StringPrototypeSlice(str, n);
        }
        break;
      }
      ++c;
    } while ((p = p.next) !== null);
    this.length -= c;
    return ret;
  }
  // Consumes a specified amount of bytes from the buffered data.
  _getBuffer(n) {
    const ret = Buffer$2.allocUnsafe(n);
    const retLen = n;
    let p = this.head;
    let c = 0;
    do {
      const buf = p.data;
      if (n > buf.length) {
        TypedArrayPrototypeSet(ret, buf, retLen - n);
        n -= buf.length;
      } else {
        if (n === buf.length) {
          TypedArrayPrototypeSet(ret, buf, retLen - n);
          ++c;
          if (p.next) this.head = p.next;
          else this.head = this.tail = null;
        } else {
          TypedArrayPrototypeSet(ret, new Uint8Array$1(buf.buffer, buf.byteOffset, n), retLen - n);
          this.head = p;
          p.data = buf.slice(n);
        }
        break;
      }
      ++c;
    } while ((p = p.next) !== null);
    this.length -= c;
    return ret;
  }
  // Make sure the linked list only shows the minimal necessary information.
  [Symbol.for("nodejs.util.inspect.custom")](_, options) {
    return inspect(this, {
      ...options,
      // Only inspect one level.
      depth: 0,
      // It should not recurse.
      customInspect: false
    });
  }
};
const { MathFloor: MathFloor$1, NumberIsInteger } = primordials;
const { validateInteger: validateInteger$1 } = validators;
const { ERR_INVALID_ARG_VALUE: ERR_INVALID_ARG_VALUE$2 } = errors.codes;
let defaultHighWaterMarkBytes = 16 * 1024;
let defaultHighWaterMarkObjectMode = 16;
function highWaterMarkFrom(options, isDuplex, duplexKey) {
  return options.highWaterMark != null ? options.highWaterMark : isDuplex ? options[duplexKey] : null;
}
function getDefaultHighWaterMark(objectMode) {
  return objectMode ? defaultHighWaterMarkObjectMode : defaultHighWaterMarkBytes;
}
function setDefaultHighWaterMark(objectMode, value) {
  validateInteger$1(value, "value", 0);
  if (objectMode) {
    defaultHighWaterMarkObjectMode = value;
  } else {
    defaultHighWaterMarkBytes = value;
  }
}
function getHighWaterMark$1(state2, options, duplexKey, isDuplex) {
  const hwm = highWaterMarkFrom(options, isDuplex, duplexKey);
  if (hwm != null) {
    if (!NumberIsInteger(hwm) || hwm < 0) {
      const name = isDuplex ? `options.${duplexKey}` : "options.highWaterMark";
      throw new ERR_INVALID_ARG_VALUE$2(name, hwm);
    }
    return MathFloor$1(hwm);
  }
  return getDefaultHighWaterMark(state2.objectMode);
}
var state = {
  getHighWaterMark: getHighWaterMark$1,
  getDefaultHighWaterMark,
  setDefaultHighWaterMark
};
var string_decoder = {};
var Buffer$1 = safeBufferExports.Buffer;
var isEncoding = Buffer$1.isEncoding || function(encoding) {
  encoding = "" + encoding;
  switch (encoding && encoding.toLowerCase()) {
    case "hex":
    case "utf8":
    case "utf-8":
    case "ascii":
    case "binary":
    case "base64":
    case "ucs2":
    case "ucs-2":
    case "utf16le":
    case "utf-16le":
    case "raw":
      return true;
    default:
      return false;
  }
};
function _normalizeEncoding(enc) {
  if (!enc) return "utf8";
  var retried;
  while (true) {
    switch (enc) {
      case "utf8":
      case "utf-8":
        return "utf8";
      case "ucs2":
      case "ucs-2":
      case "utf16le":
      case "utf-16le":
        return "utf16le";
      case "latin1":
      case "binary":
        return "latin1";
      case "base64":
      case "ascii":
      case "hex":
        return enc;
      default:
        if (retried) return;
        enc = ("" + enc).toLowerCase();
        retried = true;
    }
  }
}
function normalizeEncoding(enc) {
  var nenc = _normalizeEncoding(enc);
  if (typeof nenc !== "string" && (Buffer$1.isEncoding === isEncoding || !isEncoding(enc))) throw new Error("Unknown encoding: " + enc);
  return nenc || enc;
}
string_decoder.StringDecoder = StringDecoder;
function StringDecoder(encoding) {
  this.encoding = normalizeEncoding(encoding);
  var nb;
  switch (this.encoding) {
    case "utf16le":
      this.text = utf16Text;
      this.end = utf16End;
      nb = 4;
      break;
    case "utf8":
      this.fillLast = utf8FillLast;
      nb = 4;
      break;
    case "base64":
      this.text = base64Text;
      this.end = base64End;
      nb = 3;
      break;
    default:
      this.write = simpleWrite;
      this.end = simpleEnd;
      return;
  }
  this.lastNeed = 0;
  this.lastTotal = 0;
  this.lastChar = Buffer$1.allocUnsafe(nb);
}
StringDecoder.prototype.write = function(buf) {
  if (buf.length === 0) return "";
  var r;
  var i;
  if (this.lastNeed) {
    r = this.fillLast(buf);
    if (r === void 0) return "";
    i = this.lastNeed;
    this.lastNeed = 0;
  } else {
    i = 0;
  }
  if (i < buf.length) return r ? r + this.text(buf, i) : this.text(buf, i);
  return r || "";
};
StringDecoder.prototype.end = utf8End;
StringDecoder.prototype.text = utf8Text;
StringDecoder.prototype.fillLast = function(buf) {
  if (this.lastNeed <= buf.length) {
    buf.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, this.lastNeed);
    return this.lastChar.toString(this.encoding, 0, this.lastTotal);
  }
  buf.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, buf.length);
  this.lastNeed -= buf.length;
};
function utf8CheckByte(byte) {
  if (byte <= 127) return 0;
  else if (byte >> 5 === 6) return 2;
  else if (byte >> 4 === 14) return 3;
  else if (byte >> 3 === 30) return 4;
  return byte >> 6 === 2 ? -1 : -2;
}
function utf8CheckIncomplete(self2, buf, i) {
  var j = buf.length - 1;
  if (j < i) return 0;
  var nb = utf8CheckByte(buf[j]);
  if (nb >= 0) {
    if (nb > 0) self2.lastNeed = nb - 1;
    return nb;
  }
  if (--j < i || nb === -2) return 0;
  nb = utf8CheckByte(buf[j]);
  if (nb >= 0) {
    if (nb > 0) self2.lastNeed = nb - 2;
    return nb;
  }
  if (--j < i || nb === -2) return 0;
  nb = utf8CheckByte(buf[j]);
  if (nb >= 0) {
    if (nb > 0) {
      if (nb === 2) nb = 0;
      else self2.lastNeed = nb - 3;
    }
    return nb;
  }
  return 0;
}
function utf8CheckExtraBytes(self2, buf, p) {
  if ((buf[0] & 192) !== 128) {
    self2.lastNeed = 0;
    return "�";
  }
  if (self2.lastNeed > 1 && buf.length > 1) {
    if ((buf[1] & 192) !== 128) {
      self2.lastNeed = 1;
      return "�";
    }
    if (self2.lastNeed > 2 && buf.length > 2) {
      if ((buf[2] & 192) !== 128) {
        self2.lastNeed = 2;
        return "�";
      }
    }
  }
}
function utf8FillLast(buf) {
  var p = this.lastTotal - this.lastNeed;
  var r = utf8CheckExtraBytes(this, buf);
  if (r !== void 0) return r;
  if (this.lastNeed <= buf.length) {
    buf.copy(this.lastChar, p, 0, this.lastNeed);
    return this.lastChar.toString(this.encoding, 0, this.lastTotal);
  }
  buf.copy(this.lastChar, p, 0, buf.length);
  this.lastNeed -= buf.length;
}
function utf8Text(buf, i) {
  var total = utf8CheckIncomplete(this, buf, i);
  if (!this.lastNeed) return buf.toString("utf8", i);
  this.lastTotal = total;
  var end = buf.length - (total - this.lastNeed);
  buf.copy(this.lastChar, 0, end);
  return buf.toString("utf8", i, end);
}
function utf8End(buf) {
  var r = buf && buf.length ? this.write(buf) : "";
  if (this.lastNeed) return r + "�";
  return r;
}
function utf16Text(buf, i) {
  if ((buf.length - i) % 2 === 0) {
    var r = buf.toString("utf16le", i);
    if (r) {
      var c = r.charCodeAt(r.length - 1);
      if (c >= 55296 && c <= 56319) {
        this.lastNeed = 2;
        this.lastTotal = 4;
        this.lastChar[0] = buf[buf.length - 2];
        this.lastChar[1] = buf[buf.length - 1];
        return r.slice(0, -1);
      }
    }
    return r;
  }
  this.lastNeed = 1;
  this.lastTotal = 2;
  this.lastChar[0] = buf[buf.length - 1];
  return buf.toString("utf16le", i, buf.length - 1);
}
function utf16End(buf) {
  var r = buf && buf.length ? this.write(buf) : "";
  if (this.lastNeed) {
    var end = this.lastTotal - this.lastNeed;
    return r + this.lastChar.toString("utf16le", 0, end);
  }
  return r;
}
function base64Text(buf, i) {
  var n = (buf.length - i) % 3;
  if (n === 0) return buf.toString("base64", i);
  this.lastNeed = 3 - n;
  this.lastTotal = 3;
  if (n === 1) {
    this.lastChar[0] = buf[buf.length - 1];
  } else {
    this.lastChar[0] = buf[buf.length - 2];
    this.lastChar[1] = buf[buf.length - 1];
  }
  return buf.toString("base64", i, buf.length - n);
}
function base64End(buf) {
  var r = buf && buf.length ? this.write(buf) : "";
  if (this.lastNeed) return r + this.lastChar.toString("base64", 0, 3 - this.lastNeed);
  return r;
}
function simpleWrite(buf) {
  return buf.toString(this.encoding);
}
function simpleEnd(buf) {
  return buf && buf.length ? this.write(buf) : "";
}
const process$1 = browserExports;
const { PromisePrototypeThen: PromisePrototypeThen$1, SymbolAsyncIterator: SymbolAsyncIterator$1, SymbolIterator } = primordials;
const { Buffer } = buffer;
const { ERR_INVALID_ARG_TYPE: ERR_INVALID_ARG_TYPE$2, ERR_STREAM_NULL_VALUES } = errors.codes;
function from(Readable2, iterable, opts) {
  let iterator;
  if (typeof iterable === "string" || iterable instanceof Buffer) {
    return new Readable2({
      objectMode: true,
      ...opts,
      read() {
        this.push(iterable);
        this.push(null);
      }
    });
  }
  let isAsync;
  if (iterable && iterable[SymbolAsyncIterator$1]) {
    isAsync = true;
    iterator = iterable[SymbolAsyncIterator$1]();
  } else if (iterable && iterable[SymbolIterator]) {
    isAsync = false;
    iterator = iterable[SymbolIterator]();
  } else {
    throw new ERR_INVALID_ARG_TYPE$2("iterable", ["Iterable"], iterable);
  }
  const readable2 = new Readable2({
    objectMode: true,
    highWaterMark: 1,
    // TODO(ronag): What options should be allowed?
    ...opts
  });
  let reading = false;
  readable2._read = function() {
    if (!reading) {
      reading = true;
      next();
    }
  };
  readable2._destroy = function(error, cb) {
    PromisePrototypeThen$1(
      close(error),
      () => process$1.nextTick(cb, error),
      // nextTick is here in case cb throws
      (e) => process$1.nextTick(cb, e || error)
    );
  };
  async function close(error) {
    const hadError = error !== void 0 && error !== null;
    const hasThrow = typeof iterator.throw === "function";
    if (hadError && hasThrow) {
      const { value, done } = await iterator.throw(error);
      await value;
      if (done) {
        return;
      }
    }
    if (typeof iterator.return === "function") {
      const { value } = await iterator.return();
      await value;
    }
  }
  async function next() {
    for (; ; ) {
      try {
        const { value, done } = isAsync ? await iterator.next() : iterator.next();
        if (done) {
          readable2.push(null);
        } else {
          const res = value && typeof value.then === "function" ? await value : value;
          if (res === null) {
            reading = false;
            throw new ERR_STREAM_NULL_VALUES();
          } else if (readable2.push(res)) {
            continue;
          } else {
            reading = false;
          }
        }
      } catch (err) {
        readable2.destroy(err);
      }
      break;
    }
  }
  return readable2;
}
var from_1 = from;
var readable;
var hasRequiredReadable;
function requireReadable() {
  if (hasRequiredReadable) return readable;
  hasRequiredReadable = 1;
  const process2 = browserExports;
  const {
    ArrayPrototypeIndexOf,
    NumberIsInteger: NumberIsInteger2,
    NumberIsNaN: NumberIsNaN3,
    NumberParseInt: NumberParseInt2,
    ObjectDefineProperties,
    ObjectKeys,
    ObjectSetPrototypeOf: ObjectSetPrototypeOf2,
    Promise: Promise2,
    SafeSet,
    SymbolAsyncDispose,
    SymbolAsyncIterator: SymbolAsyncIterator2,
    Symbol: Symbol2
  } = primordials;
  readable = Readable2;
  Readable2.ReadableState = ReadableState;
  const { EventEmitter: EE2 } = eventsExports;
  const { Stream: Stream2, prependListener: prependListener3 } = legacy;
  const { Buffer: Buffer2 } = buffer;
  const { addAbortSignal: addAbortSignal2 } = addAbortSignalExports;
  const eos2 = endOfStreamExports;
  let debug = utilExports.debuglog("stream", (fn) => {
    debug = fn;
  });
  const BufferList2 = buffer_list;
  const destroyImpl2 = destroy_1;
  const { getHighWaterMark: getHighWaterMark2, getDefaultHighWaterMark: getDefaultHighWaterMark2 } = state;
  const {
    aggregateTwoErrors: aggregateTwoErrors2,
    codes: {
      ERR_INVALID_ARG_TYPE: ERR_INVALID_ARG_TYPE2,
      ERR_METHOD_NOT_IMPLEMENTED: ERR_METHOD_NOT_IMPLEMENTED2,
      ERR_OUT_OF_RANGE: ERR_OUT_OF_RANGE2,
      ERR_STREAM_PUSH_AFTER_EOF,
      ERR_STREAM_UNSHIFT_AFTER_END_EVENT
    },
    AbortError: AbortError3
  } = errors;
  const { validateObject: validateObject2 } = validators;
  const kPaused = Symbol2("kPaused");
  const { StringDecoder: StringDecoder2 } = string_decoder;
  const from2 = from_1;
  ObjectSetPrototypeOf2(Readable2.prototype, Stream2.prototype);
  ObjectSetPrototypeOf2(Readable2, Stream2);
  const nop2 = () => {
  };
  const { errorOrDestroy: errorOrDestroy2 } = destroyImpl2;
  const kObjectMode = 1 << 0;
  const kEnded = 1 << 1;
  const kEndEmitted = 1 << 2;
  const kReading = 1 << 3;
  const kConstructed = 1 << 4;
  const kSync = 1 << 5;
  const kNeedReadable = 1 << 6;
  const kEmittedReadable = 1 << 7;
  const kReadableListening = 1 << 8;
  const kResumeScheduled = 1 << 9;
  const kErrorEmitted = 1 << 10;
  const kEmitClose = 1 << 11;
  const kAutoDestroy = 1 << 12;
  const kDestroyed = 1 << 13;
  const kClosed = 1 << 14;
  const kCloseEmitted = 1 << 15;
  const kMultiAwaitDrain = 1 << 16;
  const kReadingMore = 1 << 17;
  const kDataEmitted = 1 << 18;
  function makeBitMapDescriptor(bit) {
    return {
      enumerable: false,
      get() {
        return (this.state & bit) !== 0;
      },
      set(value) {
        if (value) this.state |= bit;
        else this.state &= ~bit;
      }
    };
  }
  ObjectDefineProperties(ReadableState.prototype, {
    objectMode: makeBitMapDescriptor(kObjectMode),
    ended: makeBitMapDescriptor(kEnded),
    endEmitted: makeBitMapDescriptor(kEndEmitted),
    reading: makeBitMapDescriptor(kReading),
    // Stream is still being constructed and cannot be
    // destroyed until construction finished or failed.
    // Async construction is opt in, therefore we start as
    // constructed.
    constructed: makeBitMapDescriptor(kConstructed),
    // A flag to be able to tell if the event 'readable'/'data' is emitted
    // immediately, or on a later tick.  We set this to true at first, because
    // any actions that shouldn't happen until "later" should generally also
    // not happen before the first read call.
    sync: makeBitMapDescriptor(kSync),
    // Whenever we return null, then we set a flag to say
    // that we're awaiting a 'readable' event emission.
    needReadable: makeBitMapDescriptor(kNeedReadable),
    emittedReadable: makeBitMapDescriptor(kEmittedReadable),
    readableListening: makeBitMapDescriptor(kReadableListening),
    resumeScheduled: makeBitMapDescriptor(kResumeScheduled),
    // True if the error was already emitted and should not be thrown again.
    errorEmitted: makeBitMapDescriptor(kErrorEmitted),
    emitClose: makeBitMapDescriptor(kEmitClose),
    autoDestroy: makeBitMapDescriptor(kAutoDestroy),
    // Has it been destroyed.
    destroyed: makeBitMapDescriptor(kDestroyed),
    // Indicates whether the stream has finished destroying.
    closed: makeBitMapDescriptor(kClosed),
    // True if close has been emitted or would have been emitted
    // depending on emitClose.
    closeEmitted: makeBitMapDescriptor(kCloseEmitted),
    multiAwaitDrain: makeBitMapDescriptor(kMultiAwaitDrain),
    // If true, a maybeReadMore has been scheduled.
    readingMore: makeBitMapDescriptor(kReadingMore),
    dataEmitted: makeBitMapDescriptor(kDataEmitted)
  });
  function ReadableState(options, stream2, isDuplex) {
    if (typeof isDuplex !== "boolean") isDuplex = stream2 instanceof requireDuplex();
    this.state = kEmitClose | kAutoDestroy | kConstructed | kSync;
    if (options && options.objectMode) this.state |= kObjectMode;
    if (isDuplex && options && options.readableObjectMode) this.state |= kObjectMode;
    this.highWaterMark = options ? getHighWaterMark2(this, options, "readableHighWaterMark", isDuplex) : getDefaultHighWaterMark2(false);
    this.buffer = new BufferList2();
    this.length = 0;
    this.pipes = [];
    this.flowing = null;
    this[kPaused] = null;
    if (options && options.emitClose === false) this.state &= ~kEmitClose;
    if (options && options.autoDestroy === false) this.state &= ~kAutoDestroy;
    this.errored = null;
    this.defaultEncoding = options && options.defaultEncoding || "utf8";
    this.awaitDrainWriters = null;
    this.decoder = null;
    this.encoding = null;
    if (options && options.encoding) {
      this.decoder = new StringDecoder2(options.encoding);
      this.encoding = options.encoding;
    }
  }
  function Readable2(options) {
    if (!(this instanceof Readable2)) return new Readable2(options);
    const isDuplex = this instanceof requireDuplex();
    this._readableState = new ReadableState(options, this, isDuplex);
    if (options) {
      if (typeof options.read === "function") this._read = options.read;
      if (typeof options.destroy === "function") this._destroy = options.destroy;
      if (typeof options.construct === "function") this._construct = options.construct;
      if (options.signal && !isDuplex) addAbortSignal2(options.signal, this);
    }
    Stream2.call(this, options);
    destroyImpl2.construct(this, () => {
      if (this._readableState.needReadable) {
        maybeReadMore(this, this._readableState);
      }
    });
  }
  Readable2.prototype.destroy = destroyImpl2.destroy;
  Readable2.prototype._undestroy = destroyImpl2.undestroy;
  Readable2.prototype._destroy = function(err, cb) {
    cb(err);
  };
  Readable2.prototype[EE2.captureRejectionSymbol] = function(err) {
    this.destroy(err);
  };
  Readable2.prototype[SymbolAsyncDispose] = function() {
    let error;
    if (!this.destroyed) {
      error = this.readableEnded ? null : new AbortError3();
      this.destroy(error);
    }
    return new Promise2((resolve, reject) => eos2(this, (err) => err && err !== error ? reject(err) : resolve(null)));
  };
  Readable2.prototype.push = function(chunk, encoding) {
    return readableAddChunk(this, chunk, encoding, false);
  };
  Readable2.prototype.unshift = function(chunk, encoding) {
    return readableAddChunk(this, chunk, encoding, true);
  };
  function readableAddChunk(stream2, chunk, encoding, addToFront) {
    debug("readableAddChunk", chunk);
    const state2 = stream2._readableState;
    let err;
    if ((state2.state & kObjectMode) === 0) {
      if (typeof chunk === "string") {
        encoding = encoding || state2.defaultEncoding;
        if (state2.encoding !== encoding) {
          if (addToFront && state2.encoding) {
            chunk = Buffer2.from(chunk, encoding).toString(state2.encoding);
          } else {
            chunk = Buffer2.from(chunk, encoding);
            encoding = "";
          }
        }
      } else if (chunk instanceof Buffer2) {
        encoding = "";
      } else if (Stream2._isUint8Array(chunk)) {
        chunk = Stream2._uint8ArrayToBuffer(chunk);
        encoding = "";
      } else if (chunk != null) {
        err = new ERR_INVALID_ARG_TYPE2("chunk", ["string", "Buffer", "Uint8Array"], chunk);
      }
    }
    if (err) {
      errorOrDestroy2(stream2, err);
    } else if (chunk === null) {
      state2.state &= ~kReading;
      onEofChunk(stream2, state2);
    } else if ((state2.state & kObjectMode) !== 0 || chunk && chunk.length > 0) {
      if (addToFront) {
        if ((state2.state & kEndEmitted) !== 0) errorOrDestroy2(stream2, new ERR_STREAM_UNSHIFT_AFTER_END_EVENT());
        else if (state2.destroyed || state2.errored) return false;
        else addChunk(stream2, state2, chunk, true);
      } else if (state2.ended) {
        errorOrDestroy2(stream2, new ERR_STREAM_PUSH_AFTER_EOF());
      } else if (state2.destroyed || state2.errored) {
        return false;
      } else {
        state2.state &= ~kReading;
        if (state2.decoder && !encoding) {
          chunk = state2.decoder.write(chunk);
          if (state2.objectMode || chunk.length !== 0) addChunk(stream2, state2, chunk, false);
          else maybeReadMore(stream2, state2);
        } else {
          addChunk(stream2, state2, chunk, false);
        }
      }
    } else if (!addToFront) {
      state2.state &= ~kReading;
      maybeReadMore(stream2, state2);
    }
    return !state2.ended && (state2.length < state2.highWaterMark || state2.length === 0);
  }
  function addChunk(stream2, state2, chunk, addToFront) {
    if (state2.flowing && state2.length === 0 && !state2.sync && stream2.listenerCount("data") > 0) {
      if ((state2.state & kMultiAwaitDrain) !== 0) {
        state2.awaitDrainWriters.clear();
      } else {
        state2.awaitDrainWriters = null;
      }
      state2.dataEmitted = true;
      stream2.emit("data", chunk);
    } else {
      state2.length += state2.objectMode ? 1 : chunk.length;
      if (addToFront) state2.buffer.unshift(chunk);
      else state2.buffer.push(chunk);
      if ((state2.state & kNeedReadable) !== 0) emitReadable(stream2);
    }
    maybeReadMore(stream2, state2);
  }
  Readable2.prototype.isPaused = function() {
    const state2 = this._readableState;
    return state2[kPaused] === true || state2.flowing === false;
  };
  Readable2.prototype.setEncoding = function(enc) {
    const decoder = new StringDecoder2(enc);
    this._readableState.decoder = decoder;
    this._readableState.encoding = this._readableState.decoder.encoding;
    const buffer2 = this._readableState.buffer;
    let content = "";
    for (const data of buffer2) {
      content += decoder.write(data);
    }
    buffer2.clear();
    if (content !== "") buffer2.push(content);
    this._readableState.length = content.length;
    return this;
  };
  const MAX_HWM = 1073741824;
  function computeNewHighWaterMark(n) {
    if (n > MAX_HWM) {
      throw new ERR_OUT_OF_RANGE2("size", "<= 1GiB", n);
    } else {
      n--;
      n |= n >>> 1;
      n |= n >>> 2;
      n |= n >>> 4;
      n |= n >>> 8;
      n |= n >>> 16;
      n++;
    }
    return n;
  }
  function howMuchToRead(n, state2) {
    if (n <= 0 || state2.length === 0 && state2.ended) return 0;
    if ((state2.state & kObjectMode) !== 0) return 1;
    if (NumberIsNaN3(n)) {
      if (state2.flowing && state2.length) return state2.buffer.first().length;
      return state2.length;
    }
    if (n <= state2.length) return n;
    return state2.ended ? state2.length : 0;
  }
  Readable2.prototype.read = function(n) {
    debug("read", n);
    if (n === void 0) {
      n = NaN;
    } else if (!NumberIsInteger2(n)) {
      n = NumberParseInt2(n, 10);
    }
    const state2 = this._readableState;
    const nOrig = n;
    if (n > state2.highWaterMark) state2.highWaterMark = computeNewHighWaterMark(n);
    if (n !== 0) state2.state &= ~kEmittedReadable;
    if (n === 0 && state2.needReadable && ((state2.highWaterMark !== 0 ? state2.length >= state2.highWaterMark : state2.length > 0) || state2.ended)) {
      debug("read: emitReadable", state2.length, state2.ended);
      if (state2.length === 0 && state2.ended) endReadable(this);
      else emitReadable(this);
      return null;
    }
    n = howMuchToRead(n, state2);
    if (n === 0 && state2.ended) {
      if (state2.length === 0) endReadable(this);
      return null;
    }
    let doRead = (state2.state & kNeedReadable) !== 0;
    debug("need readable", doRead);
    if (state2.length === 0 || state2.length - n < state2.highWaterMark) {
      doRead = true;
      debug("length less than watermark", doRead);
    }
    if (state2.ended || state2.reading || state2.destroyed || state2.errored || !state2.constructed) {
      doRead = false;
      debug("reading, ended or constructing", doRead);
    } else if (doRead) {
      debug("do read");
      state2.state |= kReading | kSync;
      if (state2.length === 0) state2.state |= kNeedReadable;
      try {
        this._read(state2.highWaterMark);
      } catch (err) {
        errorOrDestroy2(this, err);
      }
      state2.state &= ~kSync;
      if (!state2.reading) n = howMuchToRead(nOrig, state2);
    }
    let ret;
    if (n > 0) ret = fromList(n, state2);
    else ret = null;
    if (ret === null) {
      state2.needReadable = state2.length <= state2.highWaterMark;
      n = 0;
    } else {
      state2.length -= n;
      if (state2.multiAwaitDrain) {
        state2.awaitDrainWriters.clear();
      } else {
        state2.awaitDrainWriters = null;
      }
    }
    if (state2.length === 0) {
      if (!state2.ended) state2.needReadable = true;
      if (nOrig !== n && state2.ended) endReadable(this);
    }
    if (ret !== null && !state2.errorEmitted && !state2.closeEmitted) {
      state2.dataEmitted = true;
      this.emit("data", ret);
    }
    return ret;
  };
  function onEofChunk(stream2, state2) {
    debug("onEofChunk");
    if (state2.ended) return;
    if (state2.decoder) {
      const chunk = state2.decoder.end();
      if (chunk && chunk.length) {
        state2.buffer.push(chunk);
        state2.length += state2.objectMode ? 1 : chunk.length;
      }
    }
    state2.ended = true;
    if (state2.sync) {
      emitReadable(stream2);
    } else {
      state2.needReadable = false;
      state2.emittedReadable = true;
      emitReadable_(stream2);
    }
  }
  function emitReadable(stream2) {
    const state2 = stream2._readableState;
    debug("emitReadable", state2.needReadable, state2.emittedReadable);
    state2.needReadable = false;
    if (!state2.emittedReadable) {
      debug("emitReadable", state2.flowing);
      state2.emittedReadable = true;
      process2.nextTick(emitReadable_, stream2);
    }
  }
  function emitReadable_(stream2) {
    const state2 = stream2._readableState;
    debug("emitReadable_", state2.destroyed, state2.length, state2.ended);
    if (!state2.destroyed && !state2.errored && (state2.length || state2.ended)) {
      stream2.emit("readable");
      state2.emittedReadable = false;
    }
    state2.needReadable = !state2.flowing && !state2.ended && state2.length <= state2.highWaterMark;
    flow(stream2);
  }
  function maybeReadMore(stream2, state2) {
    if (!state2.readingMore && state2.constructed) {
      state2.readingMore = true;
      process2.nextTick(maybeReadMore_, stream2, state2);
    }
  }
  function maybeReadMore_(stream2, state2) {
    while (!state2.reading && !state2.ended && (state2.length < state2.highWaterMark || state2.flowing && state2.length === 0)) {
      const len = state2.length;
      debug("maybeReadMore read 0");
      stream2.read(0);
      if (len === state2.length)
        break;
    }
    state2.readingMore = false;
  }
  Readable2.prototype._read = function(n) {
    throw new ERR_METHOD_NOT_IMPLEMENTED2("_read()");
  };
  Readable2.prototype.pipe = function(dest, pipeOpts) {
    const src = this;
    const state2 = this._readableState;
    if (state2.pipes.length === 1) {
      if (!state2.multiAwaitDrain) {
        state2.multiAwaitDrain = true;
        state2.awaitDrainWriters = new SafeSet(state2.awaitDrainWriters ? [state2.awaitDrainWriters] : []);
      }
    }
    state2.pipes.push(dest);
    debug("pipe count=%d opts=%j", state2.pipes.length, pipeOpts);
    const doEnd = (!pipeOpts || pipeOpts.end !== false) && dest !== process2.stdout && dest !== process2.stderr;
    const endFn = doEnd ? onend : unpipe;
    if (state2.endEmitted) process2.nextTick(endFn);
    else src.once("end", endFn);
    dest.on("unpipe", onunpipe);
    function onunpipe(readable2, unpipeInfo) {
      debug("onunpipe");
      if (readable2 === src) {
        if (unpipeInfo && unpipeInfo.hasUnpiped === false) {
          unpipeInfo.hasUnpiped = true;
          cleanup();
        }
      }
    }
    function onend() {
      debug("onend");
      dest.end();
    }
    let ondrain;
    let cleanedUp = false;
    function cleanup() {
      debug("cleanup");
      dest.removeListener("close", onclose);
      dest.removeListener("finish", onfinish);
      if (ondrain) {
        dest.removeListener("drain", ondrain);
      }
      dest.removeListener("error", onerror);
      dest.removeListener("unpipe", onunpipe);
      src.removeListener("end", onend);
      src.removeListener("end", unpipe);
      src.removeListener("data", ondata);
      cleanedUp = true;
      if (ondrain && state2.awaitDrainWriters && (!dest._writableState || dest._writableState.needDrain)) ondrain();
    }
    function pause() {
      if (!cleanedUp) {
        if (state2.pipes.length === 1 && state2.pipes[0] === dest) {
          debug("false write response, pause", 0);
          state2.awaitDrainWriters = dest;
          state2.multiAwaitDrain = false;
        } else if (state2.pipes.length > 1 && state2.pipes.includes(dest)) {
          debug("false write response, pause", state2.awaitDrainWriters.size);
          state2.awaitDrainWriters.add(dest);
        }
        src.pause();
      }
      if (!ondrain) {
        ondrain = pipeOnDrain(src, dest);
        dest.on("drain", ondrain);
      }
    }
    src.on("data", ondata);
    function ondata(chunk) {
      debug("ondata");
      const ret = dest.write(chunk);
      debug("dest.write", ret);
      if (ret === false) {
        pause();
      }
    }
    function onerror(er) {
      debug("onerror", er);
      unpipe();
      dest.removeListener("error", onerror);
      if (dest.listenerCount("error") === 0) {
        const s = dest._writableState || dest._readableState;
        if (s && !s.errorEmitted) {
          errorOrDestroy2(dest, er);
        } else {
          dest.emit("error", er);
        }
      }
    }
    prependListener3(dest, "error", onerror);
    function onclose() {
      dest.removeListener("finish", onfinish);
      unpipe();
    }
    dest.once("close", onclose);
    function onfinish() {
      debug("onfinish");
      dest.removeListener("close", onclose);
      unpipe();
    }
    dest.once("finish", onfinish);
    function unpipe() {
      debug("unpipe");
      src.unpipe(dest);
    }
    dest.emit("pipe", src);
    if (dest.writableNeedDrain === true) {
      pause();
    } else if (!state2.flowing) {
      debug("pipe resume");
      src.resume();
    }
    return dest;
  };
  function pipeOnDrain(src, dest) {
    return function pipeOnDrainFunctionResult() {
      const state2 = src._readableState;
      if (state2.awaitDrainWriters === dest) {
        debug("pipeOnDrain", 1);
        state2.awaitDrainWriters = null;
      } else if (state2.multiAwaitDrain) {
        debug("pipeOnDrain", state2.awaitDrainWriters.size);
        state2.awaitDrainWriters.delete(dest);
      }
      if ((!state2.awaitDrainWriters || state2.awaitDrainWriters.size === 0) && src.listenerCount("data")) {
        src.resume();
      }
    };
  }
  Readable2.prototype.unpipe = function(dest) {
    const state2 = this._readableState;
    const unpipeInfo = {
      hasUnpiped: false
    };
    if (state2.pipes.length === 0) return this;
    if (!dest) {
      const dests = state2.pipes;
      state2.pipes = [];
      this.pause();
      for (let i = 0; i < dests.length; i++)
        dests[i].emit("unpipe", this, {
          hasUnpiped: false
        });
      return this;
    }
    const index = ArrayPrototypeIndexOf(state2.pipes, dest);
    if (index === -1) return this;
    state2.pipes.splice(index, 1);
    if (state2.pipes.length === 0) this.pause();
    dest.emit("unpipe", this, unpipeInfo);
    return this;
  };
  Readable2.prototype.on = function(ev, fn) {
    const res = Stream2.prototype.on.call(this, ev, fn);
    const state2 = this._readableState;
    if (ev === "data") {
      state2.readableListening = this.listenerCount("readable") > 0;
      if (state2.flowing !== false) this.resume();
    } else if (ev === "readable") {
      if (!state2.endEmitted && !state2.readableListening) {
        state2.readableListening = state2.needReadable = true;
        state2.flowing = false;
        state2.emittedReadable = false;
        debug("on readable", state2.length, state2.reading);
        if (state2.length) {
          emitReadable(this);
        } else if (!state2.reading) {
          process2.nextTick(nReadingNextTick, this);
        }
      }
    }
    return res;
  };
  Readable2.prototype.addListener = Readable2.prototype.on;
  Readable2.prototype.removeListener = function(ev, fn) {
    const res = Stream2.prototype.removeListener.call(this, ev, fn);
    if (ev === "readable") {
      process2.nextTick(updateReadableListening, this);
    }
    return res;
  };
  Readable2.prototype.off = Readable2.prototype.removeListener;
  Readable2.prototype.removeAllListeners = function(ev) {
    const res = Stream2.prototype.removeAllListeners.apply(this, arguments);
    if (ev === "readable" || ev === void 0) {
      process2.nextTick(updateReadableListening, this);
    }
    return res;
  };
  function updateReadableListening(self2) {
    const state2 = self2._readableState;
    state2.readableListening = self2.listenerCount("readable") > 0;
    if (state2.resumeScheduled && state2[kPaused] === false) {
      state2.flowing = true;
    } else if (self2.listenerCount("data") > 0) {
      self2.resume();
    } else if (!state2.readableListening) {
      state2.flowing = null;
    }
  }
  function nReadingNextTick(self2) {
    debug("readable nexttick read 0");
    self2.read(0);
  }
  Readable2.prototype.resume = function() {
    const state2 = this._readableState;
    if (!state2.flowing) {
      debug("resume");
      state2.flowing = !state2.readableListening;
      resume(this, state2);
    }
    state2[kPaused] = false;
    return this;
  };
  function resume(stream2, state2) {
    if (!state2.resumeScheduled) {
      state2.resumeScheduled = true;
      process2.nextTick(resume_, stream2, state2);
    }
  }
  function resume_(stream2, state2) {
    debug("resume", state2.reading);
    if (!state2.reading) {
      stream2.read(0);
    }
    state2.resumeScheduled = false;
    stream2.emit("resume");
    flow(stream2);
    if (state2.flowing && !state2.reading) stream2.read(0);
  }
  Readable2.prototype.pause = function() {
    debug("call pause flowing=%j", this._readableState.flowing);
    if (this._readableState.flowing !== false) {
      debug("pause");
      this._readableState.flowing = false;
      this.emit("pause");
    }
    this._readableState[kPaused] = true;
    return this;
  };
  function flow(stream2) {
    const state2 = stream2._readableState;
    debug("flow", state2.flowing);
    while (state2.flowing && stream2.read() !== null) ;
  }
  Readable2.prototype.wrap = function(stream2) {
    let paused = false;
    stream2.on("data", (chunk) => {
      if (!this.push(chunk) && stream2.pause) {
        paused = true;
        stream2.pause();
      }
    });
    stream2.on("end", () => {
      this.push(null);
    });
    stream2.on("error", (err) => {
      errorOrDestroy2(this, err);
    });
    stream2.on("close", () => {
      this.destroy();
    });
    stream2.on("destroy", () => {
      this.destroy();
    });
    this._read = () => {
      if (paused && stream2.resume) {
        paused = false;
        stream2.resume();
      }
    };
    const streamKeys = ObjectKeys(stream2);
    for (let j = 1; j < streamKeys.length; j++) {
      const i = streamKeys[j];
      if (this[i] === void 0 && typeof stream2[i] === "function") {
        this[i] = stream2[i].bind(stream2);
      }
    }
    return this;
  };
  Readable2.prototype[SymbolAsyncIterator2] = function() {
    return streamToAsyncIterator(this);
  };
  Readable2.prototype.iterator = function(options) {
    if (options !== void 0) {
      validateObject2(options, "options");
    }
    return streamToAsyncIterator(this, options);
  };
  function streamToAsyncIterator(stream2, options) {
    if (typeof stream2.read !== "function") {
      stream2 = Readable2.wrap(stream2, {
        objectMode: true
      });
    }
    const iter = createAsyncIterator(stream2, options);
    iter.stream = stream2;
    return iter;
  }
  async function* createAsyncIterator(stream2, options) {
    let callback = nop2;
    function next(resolve) {
      if (this === stream2) {
        callback();
        callback = nop2;
      } else {
        callback = resolve;
      }
    }
    stream2.on("readable", next);
    let error;
    const cleanup = eos2(
      stream2,
      {
        writable: false
      },
      (err) => {
        error = err ? aggregateTwoErrors2(error, err) : null;
        callback();
        callback = nop2;
      }
    );
    try {
      while (true) {
        const chunk = stream2.destroyed ? null : stream2.read();
        if (chunk !== null) {
          yield chunk;
        } else if (error) {
          throw error;
        } else if (error === null) {
          return;
        } else {
          await new Promise2(next);
        }
      }
    } catch (err) {
      error = aggregateTwoErrors2(error, err);
      throw error;
    } finally {
      if ((error || (options === null || options === void 0 ? void 0 : options.destroyOnReturn) !== false) && (error === void 0 || stream2._readableState.autoDestroy)) {
        destroyImpl2.destroyer(stream2, null);
      } else {
        stream2.off("readable", next);
        cleanup();
      }
    }
  }
  ObjectDefineProperties(Readable2.prototype, {
    readable: {
      __proto__: null,
      get() {
        const r = this._readableState;
        return !!r && r.readable !== false && !r.destroyed && !r.errorEmitted && !r.endEmitted;
      },
      set(val) {
        if (this._readableState) {
          this._readableState.readable = !!val;
        }
      }
    },
    readableDidRead: {
      __proto__: null,
      enumerable: false,
      get: function() {
        return this._readableState.dataEmitted;
      }
    },
    readableAborted: {
      __proto__: null,
      enumerable: false,
      get: function() {
        return !!(this._readableState.readable !== false && (this._readableState.destroyed || this._readableState.errored) && !this._readableState.endEmitted);
      }
    },
    readableHighWaterMark: {
      __proto__: null,
      enumerable: false,
      get: function() {
        return this._readableState.highWaterMark;
      }
    },
    readableBuffer: {
      __proto__: null,
      enumerable: false,
      get: function() {
        return this._readableState && this._readableState.buffer;
      }
    },
    readableFlowing: {
      __proto__: null,
      enumerable: false,
      get: function() {
        return this._readableState.flowing;
      },
      set: function(state2) {
        if (this._readableState) {
          this._readableState.flowing = state2;
        }
      }
    },
    readableLength: {
      __proto__: null,
      enumerable: false,
      get() {
        return this._readableState.length;
      }
    },
    readableObjectMode: {
      __proto__: null,
      enumerable: false,
      get() {
        return this._readableState ? this._readableState.objectMode : false;
      }
    },
    readableEncoding: {
      __proto__: null,
      enumerable: false,
      get() {
        return this._readableState ? this._readableState.encoding : null;
      }
    },
    errored: {
      __proto__: null,
      enumerable: false,
      get() {
        return this._readableState ? this._readableState.errored : null;
      }
    },
    closed: {
      __proto__: null,
      get() {
        return this._readableState ? this._readableState.closed : false;
      }
    },
    destroyed: {
      __proto__: null,
      enumerable: false,
      get() {
        return this._readableState ? this._readableState.destroyed : false;
      },
      set(value) {
        if (!this._readableState) {
          return;
        }
        this._readableState.destroyed = value;
      }
    },
    readableEnded: {
      __proto__: null,
      enumerable: false,
      get() {
        return this._readableState ? this._readableState.endEmitted : false;
      }
    }
  });
  ObjectDefineProperties(ReadableState.prototype, {
    // Legacy getter for `pipesCount`.
    pipesCount: {
      __proto__: null,
      get() {
        return this.pipes.length;
      }
    },
    // Legacy property for `paused`.
    paused: {
      __proto__: null,
      get() {
        return this[kPaused] !== false;
      },
      set(value) {
        this[kPaused] = !!value;
      }
    }
  });
  Readable2._fromList = fromList;
  function fromList(n, state2) {
    if (state2.length === 0) return null;
    let ret;
    if (state2.objectMode) ret = state2.buffer.shift();
    else if (!n || n >= state2.length) {
      if (state2.decoder) ret = state2.buffer.join("");
      else if (state2.buffer.length === 1) ret = state2.buffer.first();
      else ret = state2.buffer.concat(state2.length);
      state2.buffer.clear();
    } else {
      ret = state2.buffer.consume(n, state2.decoder);
    }
    return ret;
  }
  function endReadable(stream2) {
    const state2 = stream2._readableState;
    debug("endReadable", state2.endEmitted);
    if (!state2.endEmitted) {
      state2.ended = true;
      process2.nextTick(endReadableNT, state2, stream2);
    }
  }
  function endReadableNT(state2, stream2) {
    debug("endReadableNT", state2.endEmitted, state2.length);
    if (!state2.errored && !state2.closeEmitted && !state2.endEmitted && state2.length === 0) {
      state2.endEmitted = true;
      stream2.emit("end");
      if (stream2.writable && stream2.allowHalfOpen === false) {
        process2.nextTick(endWritableNT, stream2);
      } else if (state2.autoDestroy) {
        const wState = stream2._writableState;
        const autoDestroy = !wState || wState.autoDestroy && // We don't expect the writable to ever 'finish'
        // if writable is explicitly set to false.
        (wState.finished || wState.writable === false);
        if (autoDestroy) {
          stream2.destroy();
        }
      }
    }
  }
  function endWritableNT(stream2) {
    const writable2 = stream2.writable && !stream2.writableEnded && !stream2.destroyed;
    if (writable2) {
      stream2.end();
    }
  }
  Readable2.from = function(iterable, opts) {
    return from2(Readable2, iterable, opts);
  };
  let webStreamsAdapters;
  function lazyWebStreams() {
    if (webStreamsAdapters === void 0) webStreamsAdapters = {};
    return webStreamsAdapters;
  }
  Readable2.fromWeb = function(readableStream, options) {
    return lazyWebStreams().newStreamReadableFromReadableStream(readableStream, options);
  };
  Readable2.toWeb = function(streamReadable, options) {
    return lazyWebStreams().newReadableStreamFromStreamReadable(streamReadable, options);
  };
  Readable2.wrap = function(src, options) {
    var _ref, _src$readableObjectMo;
    return new Readable2({
      objectMode: (_ref = (_src$readableObjectMo = src.readableObjectMode) !== null && _src$readableObjectMo !== void 0 ? _src$readableObjectMo : src.objectMode) !== null && _ref !== void 0 ? _ref : true,
      ...options,
      destroy(err, callback) {
        destroyImpl2.destroyer(src, err);
        callback(err);
      }
    }).wrap(src);
  };
  return readable;
}
var writable;
var hasRequiredWritable;
function requireWritable() {
  if (hasRequiredWritable) return writable;
  hasRequiredWritable = 1;
  const process2 = browserExports;
  const {
    ArrayPrototypeSlice,
    Error: Error2,
    FunctionPrototypeSymbolHasInstance,
    ObjectDefineProperty,
    ObjectDefineProperties,
    ObjectSetPrototypeOf: ObjectSetPrototypeOf2,
    StringPrototypeToLowerCase,
    Symbol: Symbol2,
    SymbolHasInstance
  } = primordials;
  writable = Writable;
  Writable.WritableState = WritableState;
  const { EventEmitter: EE2 } = eventsExports;
  const Stream2 = legacy.Stream;
  const { Buffer: Buffer2 } = buffer;
  const destroyImpl2 = destroy_1;
  const { addAbortSignal: addAbortSignal2 } = addAbortSignalExports;
  const { getHighWaterMark: getHighWaterMark2, getDefaultHighWaterMark: getDefaultHighWaterMark2 } = state;
  const {
    ERR_INVALID_ARG_TYPE: ERR_INVALID_ARG_TYPE2,
    ERR_METHOD_NOT_IMPLEMENTED: ERR_METHOD_NOT_IMPLEMENTED2,
    ERR_MULTIPLE_CALLBACK: ERR_MULTIPLE_CALLBACK2,
    ERR_STREAM_CANNOT_PIPE,
    ERR_STREAM_DESTROYED: ERR_STREAM_DESTROYED2,
    ERR_STREAM_ALREADY_FINISHED,
    ERR_STREAM_NULL_VALUES: ERR_STREAM_NULL_VALUES2,
    ERR_STREAM_WRITE_AFTER_END,
    ERR_UNKNOWN_ENCODING
  } = errors.codes;
  const { errorOrDestroy: errorOrDestroy2 } = destroyImpl2;
  ObjectSetPrototypeOf2(Writable.prototype, Stream2.prototype);
  ObjectSetPrototypeOf2(Writable, Stream2);
  function nop2() {
  }
  const kOnFinished = Symbol2("kOnFinished");
  function WritableState(options, stream2, isDuplex) {
    if (typeof isDuplex !== "boolean") isDuplex = stream2 instanceof requireDuplex();
    this.objectMode = !!(options && options.objectMode);
    if (isDuplex) this.objectMode = this.objectMode || !!(options && options.writableObjectMode);
    this.highWaterMark = options ? getHighWaterMark2(this, options, "writableHighWaterMark", isDuplex) : getDefaultHighWaterMark2(false);
    this.finalCalled = false;
    this.needDrain = false;
    this.ending = false;
    this.ended = false;
    this.finished = false;
    this.destroyed = false;
    const noDecode = !!(options && options.decodeStrings === false);
    this.decodeStrings = !noDecode;
    this.defaultEncoding = options && options.defaultEncoding || "utf8";
    this.length = 0;
    this.writing = false;
    this.corked = 0;
    this.sync = true;
    this.bufferProcessing = false;
    this.onwrite = onwrite.bind(void 0, stream2);
    this.writecb = null;
    this.writelen = 0;
    this.afterWriteTickInfo = null;
    resetBuffer(this);
    this.pendingcb = 0;
    this.constructed = true;
    this.prefinished = false;
    this.errorEmitted = false;
    this.emitClose = !options || options.emitClose !== false;
    this.autoDestroy = !options || options.autoDestroy !== false;
    this.errored = null;
    this.closed = false;
    this.closeEmitted = false;
    this[kOnFinished] = [];
  }
  function resetBuffer(state2) {
    state2.buffered = [];
    state2.bufferedIndex = 0;
    state2.allBuffers = true;
    state2.allNoop = true;
  }
  WritableState.prototype.getBuffer = function getBuffer() {
    return ArrayPrototypeSlice(this.buffered, this.bufferedIndex);
  };
  ObjectDefineProperty(WritableState.prototype, "bufferedRequestCount", {
    __proto__: null,
    get() {
      return this.buffered.length - this.bufferedIndex;
    }
  });
  function Writable(options) {
    const isDuplex = this instanceof requireDuplex();
    if (!isDuplex && !FunctionPrototypeSymbolHasInstance(Writable, this)) return new Writable(options);
    this._writableState = new WritableState(options, this, isDuplex);
    if (options) {
      if (typeof options.write === "function") this._write = options.write;
      if (typeof options.writev === "function") this._writev = options.writev;
      if (typeof options.destroy === "function") this._destroy = options.destroy;
      if (typeof options.final === "function") this._final = options.final;
      if (typeof options.construct === "function") this._construct = options.construct;
      if (options.signal) addAbortSignal2(options.signal, this);
    }
    Stream2.call(this, options);
    destroyImpl2.construct(this, () => {
      const state2 = this._writableState;
      if (!state2.writing) {
        clearBuffer(this, state2);
      }
      finishMaybe(this, state2);
    });
  }
  ObjectDefineProperty(Writable, SymbolHasInstance, {
    __proto__: null,
    value: function(object) {
      if (FunctionPrototypeSymbolHasInstance(this, object)) return true;
      if (this !== Writable) return false;
      return object && object._writableState instanceof WritableState;
    }
  });
  Writable.prototype.pipe = function() {
    errorOrDestroy2(this, new ERR_STREAM_CANNOT_PIPE());
  };
  function _write(stream2, chunk, encoding, cb) {
    const state2 = stream2._writableState;
    if (typeof encoding === "function") {
      cb = encoding;
      encoding = state2.defaultEncoding;
    } else {
      if (!encoding) encoding = state2.defaultEncoding;
      else if (encoding !== "buffer" && !Buffer2.isEncoding(encoding)) throw new ERR_UNKNOWN_ENCODING(encoding);
      if (typeof cb !== "function") cb = nop2;
    }
    if (chunk === null) {
      throw new ERR_STREAM_NULL_VALUES2();
    } else if (!state2.objectMode) {
      if (typeof chunk === "string") {
        if (state2.decodeStrings !== false) {
          chunk = Buffer2.from(chunk, encoding);
          encoding = "buffer";
        }
      } else if (chunk instanceof Buffer2) {
        encoding = "buffer";
      } else if (Stream2._isUint8Array(chunk)) {
        chunk = Stream2._uint8ArrayToBuffer(chunk);
        encoding = "buffer";
      } else {
        throw new ERR_INVALID_ARG_TYPE2("chunk", ["string", "Buffer", "Uint8Array"], chunk);
      }
    }
    let err;
    if (state2.ending) {
      err = new ERR_STREAM_WRITE_AFTER_END();
    } else if (state2.destroyed) {
      err = new ERR_STREAM_DESTROYED2("write");
    }
    if (err) {
      process2.nextTick(cb, err);
      errorOrDestroy2(stream2, err, true);
      return err;
    }
    state2.pendingcb++;
    return writeOrBuffer(stream2, state2, chunk, encoding, cb);
  }
  Writable.prototype.write = function(chunk, encoding, cb) {
    return _write(this, chunk, encoding, cb) === true;
  };
  Writable.prototype.cork = function() {
    this._writableState.corked++;
  };
  Writable.prototype.uncork = function() {
    const state2 = this._writableState;
    if (state2.corked) {
      state2.corked--;
      if (!state2.writing) clearBuffer(this, state2);
    }
  };
  Writable.prototype.setDefaultEncoding = function setDefaultEncoding(encoding) {
    if (typeof encoding === "string") encoding = StringPrototypeToLowerCase(encoding);
    if (!Buffer2.isEncoding(encoding)) throw new ERR_UNKNOWN_ENCODING(encoding);
    this._writableState.defaultEncoding = encoding;
    return this;
  };
  function writeOrBuffer(stream2, state2, chunk, encoding, callback) {
    const len = state2.objectMode ? 1 : chunk.length;
    state2.length += len;
    const ret = state2.length < state2.highWaterMark;
    if (!ret) state2.needDrain = true;
    if (state2.writing || state2.corked || state2.errored || !state2.constructed) {
      state2.buffered.push({
        chunk,
        encoding,
        callback
      });
      if (state2.allBuffers && encoding !== "buffer") {
        state2.allBuffers = false;
      }
      if (state2.allNoop && callback !== nop2) {
        state2.allNoop = false;
      }
    } else {
      state2.writelen = len;
      state2.writecb = callback;
      state2.writing = true;
      state2.sync = true;
      stream2._write(chunk, encoding, state2.onwrite);
      state2.sync = false;
    }
    return ret && !state2.errored && !state2.destroyed;
  }
  function doWrite(stream2, state2, writev, len, chunk, encoding, cb) {
    state2.writelen = len;
    state2.writecb = cb;
    state2.writing = true;
    state2.sync = true;
    if (state2.destroyed) state2.onwrite(new ERR_STREAM_DESTROYED2("write"));
    else if (writev) stream2._writev(chunk, state2.onwrite);
    else stream2._write(chunk, encoding, state2.onwrite);
    state2.sync = false;
  }
  function onwriteError(stream2, state2, er, cb) {
    --state2.pendingcb;
    cb(er);
    errorBuffer(state2);
    errorOrDestroy2(stream2, er);
  }
  function onwrite(stream2, er) {
    const state2 = stream2._writableState;
    const sync = state2.sync;
    const cb = state2.writecb;
    if (typeof cb !== "function") {
      errorOrDestroy2(stream2, new ERR_MULTIPLE_CALLBACK2());
      return;
    }
    state2.writing = false;
    state2.writecb = null;
    state2.length -= state2.writelen;
    state2.writelen = 0;
    if (er) {
      er.stack;
      if (!state2.errored) {
        state2.errored = er;
      }
      if (stream2._readableState && !stream2._readableState.errored) {
        stream2._readableState.errored = er;
      }
      if (sync) {
        process2.nextTick(onwriteError, stream2, state2, er, cb);
      } else {
        onwriteError(stream2, state2, er, cb);
      }
    } else {
      if (state2.buffered.length > state2.bufferedIndex) {
        clearBuffer(stream2, state2);
      }
      if (sync) {
        if (state2.afterWriteTickInfo !== null && state2.afterWriteTickInfo.cb === cb) {
          state2.afterWriteTickInfo.count++;
        } else {
          state2.afterWriteTickInfo = {
            count: 1,
            cb,
            stream: stream2,
            state: state2
          };
          process2.nextTick(afterWriteTick, state2.afterWriteTickInfo);
        }
      } else {
        afterWrite(stream2, state2, 1, cb);
      }
    }
  }
  function afterWriteTick({ stream: stream2, state: state2, count, cb }) {
    state2.afterWriteTickInfo = null;
    return afterWrite(stream2, state2, count, cb);
  }
  function afterWrite(stream2, state2, count, cb) {
    const needDrain = !state2.ending && !stream2.destroyed && state2.length === 0 && state2.needDrain;
    if (needDrain) {
      state2.needDrain = false;
      stream2.emit("drain");
    }
    while (count-- > 0) {
      state2.pendingcb--;
      cb();
    }
    if (state2.destroyed) {
      errorBuffer(state2);
    }
    finishMaybe(stream2, state2);
  }
  function errorBuffer(state2) {
    if (state2.writing) {
      return;
    }
    for (let n = state2.bufferedIndex; n < state2.buffered.length; ++n) {
      var _state$errored;
      const { chunk, callback } = state2.buffered[n];
      const len = state2.objectMode ? 1 : chunk.length;
      state2.length -= len;
      callback(
        (_state$errored = state2.errored) !== null && _state$errored !== void 0 ? _state$errored : new ERR_STREAM_DESTROYED2("write")
      );
    }
    const onfinishCallbacks = state2[kOnFinished].splice(0);
    for (let i = 0; i < onfinishCallbacks.length; i++) {
      var _state$errored2;
      onfinishCallbacks[i](
        (_state$errored2 = state2.errored) !== null && _state$errored2 !== void 0 ? _state$errored2 : new ERR_STREAM_DESTROYED2("end")
      );
    }
    resetBuffer(state2);
  }
  function clearBuffer(stream2, state2) {
    if (state2.corked || state2.bufferProcessing || state2.destroyed || !state2.constructed) {
      return;
    }
    const { buffered, bufferedIndex, objectMode } = state2;
    const bufferedLength = buffered.length - bufferedIndex;
    if (!bufferedLength) {
      return;
    }
    let i = bufferedIndex;
    state2.bufferProcessing = true;
    if (bufferedLength > 1 && stream2._writev) {
      state2.pendingcb -= bufferedLength - 1;
      const callback = state2.allNoop ? nop2 : (err) => {
        for (let n = i; n < buffered.length; ++n) {
          buffered[n].callback(err);
        }
      };
      const chunks = state2.allNoop && i === 0 ? buffered : ArrayPrototypeSlice(buffered, i);
      chunks.allBuffers = state2.allBuffers;
      doWrite(stream2, state2, true, state2.length, chunks, "", callback);
      resetBuffer(state2);
    } else {
      do {
        const { chunk, encoding, callback } = buffered[i];
        buffered[i++] = null;
        const len = objectMode ? 1 : chunk.length;
        doWrite(stream2, state2, false, len, chunk, encoding, callback);
      } while (i < buffered.length && !state2.writing);
      if (i === buffered.length) {
        resetBuffer(state2);
      } else if (i > 256) {
        buffered.splice(0, i);
        state2.bufferedIndex = 0;
      } else {
        state2.bufferedIndex = i;
      }
    }
    state2.bufferProcessing = false;
  }
  Writable.prototype._write = function(chunk, encoding, cb) {
    if (this._writev) {
      this._writev(
        [
          {
            chunk,
            encoding
          }
        ],
        cb
      );
    } else {
      throw new ERR_METHOD_NOT_IMPLEMENTED2("_write()");
    }
  };
  Writable.prototype._writev = null;
  Writable.prototype.end = function(chunk, encoding, cb) {
    const state2 = this._writableState;
    if (typeof chunk === "function") {
      cb = chunk;
      chunk = null;
      encoding = null;
    } else if (typeof encoding === "function") {
      cb = encoding;
      encoding = null;
    }
    let err;
    if (chunk !== null && chunk !== void 0) {
      const ret = _write(this, chunk, encoding);
      if (ret instanceof Error2) {
        err = ret;
      }
    }
    if (state2.corked) {
      state2.corked = 1;
      this.uncork();
    }
    if (err) ;
    else if (!state2.errored && !state2.ending) {
      state2.ending = true;
      finishMaybe(this, state2, true);
      state2.ended = true;
    } else if (state2.finished) {
      err = new ERR_STREAM_ALREADY_FINISHED("end");
    } else if (state2.destroyed) {
      err = new ERR_STREAM_DESTROYED2("end");
    }
    if (typeof cb === "function") {
      if (err || state2.finished) {
        process2.nextTick(cb, err);
      } else {
        state2[kOnFinished].push(cb);
      }
    }
    return this;
  };
  function needFinish(state2) {
    return state2.ending && !state2.destroyed && state2.constructed && state2.length === 0 && !state2.errored && state2.buffered.length === 0 && !state2.finished && !state2.writing && !state2.errorEmitted && !state2.closeEmitted;
  }
  function callFinal(stream2, state2) {
    let called = false;
    function onFinish(err) {
      if (called) {
        errorOrDestroy2(stream2, err !== null && err !== void 0 ? err : ERR_MULTIPLE_CALLBACK2());
        return;
      }
      called = true;
      state2.pendingcb--;
      if (err) {
        const onfinishCallbacks = state2[kOnFinished].splice(0);
        for (let i = 0; i < onfinishCallbacks.length; i++) {
          onfinishCallbacks[i](err);
        }
        errorOrDestroy2(stream2, err, state2.sync);
      } else if (needFinish(state2)) {
        state2.prefinished = true;
        stream2.emit("prefinish");
        state2.pendingcb++;
        process2.nextTick(finish, stream2, state2);
      }
    }
    state2.sync = true;
    state2.pendingcb++;
    try {
      stream2._final(onFinish);
    } catch (err) {
      onFinish(err);
    }
    state2.sync = false;
  }
  function prefinish2(stream2, state2) {
    if (!state2.prefinished && !state2.finalCalled) {
      if (typeof stream2._final === "function" && !state2.destroyed) {
        state2.finalCalled = true;
        callFinal(stream2, state2);
      } else {
        state2.prefinished = true;
        stream2.emit("prefinish");
      }
    }
  }
  function finishMaybe(stream2, state2, sync) {
    if (needFinish(state2)) {
      prefinish2(stream2, state2);
      if (state2.pendingcb === 0) {
        if (sync) {
          state2.pendingcb++;
          process2.nextTick(
            (stream22, state22) => {
              if (needFinish(state22)) {
                finish(stream22, state22);
              } else {
                state22.pendingcb--;
              }
            },
            stream2,
            state2
          );
        } else if (needFinish(state2)) {
          state2.pendingcb++;
          finish(stream2, state2);
        }
      }
    }
  }
  function finish(stream2, state2) {
    state2.pendingcb--;
    state2.finished = true;
    const onfinishCallbacks = state2[kOnFinished].splice(0);
    for (let i = 0; i < onfinishCallbacks.length; i++) {
      onfinishCallbacks[i]();
    }
    stream2.emit("finish");
    if (state2.autoDestroy) {
      const rState = stream2._readableState;
      const autoDestroy = !rState || rState.autoDestroy && // We don't expect the readable to ever 'end'
      // if readable is explicitly set to false.
      (rState.endEmitted || rState.readable === false);
      if (autoDestroy) {
        stream2.destroy();
      }
    }
  }
  ObjectDefineProperties(Writable.prototype, {
    closed: {
      __proto__: null,
      get() {
        return this._writableState ? this._writableState.closed : false;
      }
    },
    destroyed: {
      __proto__: null,
      get() {
        return this._writableState ? this._writableState.destroyed : false;
      },
      set(value) {
        if (this._writableState) {
          this._writableState.destroyed = value;
        }
      }
    },
    writable: {
      __proto__: null,
      get() {
        const w = this._writableState;
        return !!w && w.writable !== false && !w.destroyed && !w.errored && !w.ending && !w.ended;
      },
      set(val) {
        if (this._writableState) {
          this._writableState.writable = !!val;
        }
      }
    },
    writableFinished: {
      __proto__: null,
      get() {
        return this._writableState ? this._writableState.finished : false;
      }
    },
    writableObjectMode: {
      __proto__: null,
      get() {
        return this._writableState ? this._writableState.objectMode : false;
      }
    },
    writableBuffer: {
      __proto__: null,
      get() {
        return this._writableState && this._writableState.getBuffer();
      }
    },
    writableEnded: {
      __proto__: null,
      get() {
        return this._writableState ? this._writableState.ending : false;
      }
    },
    writableNeedDrain: {
      __proto__: null,
      get() {
        const wState = this._writableState;
        if (!wState) return false;
        return !wState.destroyed && !wState.ending && wState.needDrain;
      }
    },
    writableHighWaterMark: {
      __proto__: null,
      get() {
        return this._writableState && this._writableState.highWaterMark;
      }
    },
    writableCorked: {
      __proto__: null,
      get() {
        return this._writableState ? this._writableState.corked : 0;
      }
    },
    writableLength: {
      __proto__: null,
      get() {
        return this._writableState && this._writableState.length;
      }
    },
    errored: {
      __proto__: null,
      enumerable: false,
      get() {
        return this._writableState ? this._writableState.errored : null;
      }
    },
    writableAborted: {
      __proto__: null,
      enumerable: false,
      get: function() {
        return !!(this._writableState.writable !== false && (this._writableState.destroyed || this._writableState.errored) && !this._writableState.finished);
      }
    }
  });
  const destroy2 = destroyImpl2.destroy;
  Writable.prototype.destroy = function(err, cb) {
    const state2 = this._writableState;
    if (!state2.destroyed && (state2.bufferedIndex < state2.buffered.length || state2[kOnFinished].length)) {
      process2.nextTick(errorBuffer, state2);
    }
    destroy2.call(this, err, cb);
    return this;
  };
  Writable.prototype._undestroy = destroyImpl2.undestroy;
  Writable.prototype._destroy = function(err, cb) {
    cb(err);
  };
  Writable.prototype[EE2.captureRejectionSymbol] = function(err) {
    this.destroy(err);
  };
  let webStreamsAdapters;
  function lazyWebStreams() {
    if (webStreamsAdapters === void 0) webStreamsAdapters = {};
    return webStreamsAdapters;
  }
  Writable.fromWeb = function(writableStream, options) {
    return lazyWebStreams().newStreamWritableFromWritableStream(writableStream, options);
  };
  Writable.toWeb = function(streamWritable) {
    return lazyWebStreams().newWritableStreamFromStreamWritable(streamWritable);
  };
  return writable;
}
var duplexify;
var hasRequiredDuplexify;
function requireDuplexify() {
  if (hasRequiredDuplexify) return duplexify;
  hasRequiredDuplexify = 1;
  const process2 = browserExports;
  const bufferModule = buffer;
  const {
    isReadable: isReadable2,
    isWritable: isWritable2,
    isIterable: isIterable2,
    isNodeStream: isNodeStream2,
    isReadableNodeStream: isReadableNodeStream2,
    isWritableNodeStream: isWritableNodeStream2,
    isDuplexNodeStream: isDuplexNodeStream2,
    isReadableStream: isReadableStream2,
    isWritableStream: isWritableStream2
  } = utils;
  const eos2 = endOfStreamExports;
  const {
    AbortError: AbortError3,
    codes: { ERR_INVALID_ARG_TYPE: ERR_INVALID_ARG_TYPE2, ERR_INVALID_RETURN_VALUE: ERR_INVALID_RETURN_VALUE2 }
  } = errors;
  const { destroyer: destroyer2 } = destroy_1;
  const Duplex2 = requireDuplex();
  const Readable2 = requireReadable();
  const Writable = requireWritable();
  const { createDeferredPromise } = utilExports;
  const from2 = from_1;
  const Blob = globalThis.Blob || bufferModule.Blob;
  const isBlob = typeof Blob !== "undefined" ? function isBlob2(b) {
    return b instanceof Blob;
  } : function isBlob3(b) {
    return false;
  };
  const AbortController2 = globalThis.AbortController || requireBrowser().AbortController;
  const { FunctionPrototypeCall } = primordials;
  class Duplexify extends Duplex2 {
    constructor(options) {
      super(options);
      if ((options === null || options === void 0 ? void 0 : options.readable) === false) {
        this._readableState.readable = false;
        this._readableState.ended = true;
        this._readableState.endEmitted = true;
      }
      if ((options === null || options === void 0 ? void 0 : options.writable) === false) {
        this._writableState.writable = false;
        this._writableState.ending = true;
        this._writableState.ended = true;
        this._writableState.finished = true;
      }
    }
  }
  duplexify = function duplexify2(body, name) {
    if (isDuplexNodeStream2(body)) {
      return body;
    }
    if (isReadableNodeStream2(body)) {
      return _duplexify({
        readable: body
      });
    }
    if (isWritableNodeStream2(body)) {
      return _duplexify({
        writable: body
      });
    }
    if (isNodeStream2(body)) {
      return _duplexify({
        writable: false,
        readable: false
      });
    }
    if (isReadableStream2(body)) {
      return _duplexify({
        readable: Readable2.fromWeb(body)
      });
    }
    if (isWritableStream2(body)) {
      return _duplexify({
        writable: Writable.fromWeb(body)
      });
    }
    if (typeof body === "function") {
      const { value, write, final: final2, destroy: destroy2 } = fromAsyncGen(body);
      if (isIterable2(value)) {
        return from2(Duplexify, value, {
          // TODO (ronag): highWaterMark?
          objectMode: true,
          write,
          final: final2,
          destroy: destroy2
        });
      }
      const then2 = value === null || value === void 0 ? void 0 : value.then;
      if (typeof then2 === "function") {
        let d;
        const promise = FunctionPrototypeCall(
          then2,
          value,
          (val) => {
            if (val != null) {
              throw new ERR_INVALID_RETURN_VALUE2("nully", "body", val);
            }
          },
          (err) => {
            destroyer2(d, err);
          }
        );
        return d = new Duplexify({
          // TODO (ronag): highWaterMark?
          objectMode: true,
          readable: false,
          write,
          final(cb) {
            final2(async () => {
              try {
                await promise;
                process2.nextTick(cb, null);
              } catch (err) {
                process2.nextTick(cb, err);
              }
            });
          },
          destroy: destroy2
        });
      }
      throw new ERR_INVALID_RETURN_VALUE2("Iterable, AsyncIterable or AsyncFunction", name, value);
    }
    if (isBlob(body)) {
      return duplexify2(body.arrayBuffer());
    }
    if (isIterable2(body)) {
      return from2(Duplexify, body, {
        // TODO (ronag): highWaterMark?
        objectMode: true,
        writable: false
      });
    }
    if (isReadableStream2(body === null || body === void 0 ? void 0 : body.readable) && isWritableStream2(body === null || body === void 0 ? void 0 : body.writable)) {
      return Duplexify.fromWeb(body);
    }
    if (typeof (body === null || body === void 0 ? void 0 : body.writable) === "object" || typeof (body === null || body === void 0 ? void 0 : body.readable) === "object") {
      const readable2 = body !== null && body !== void 0 && body.readable ? isReadableNodeStream2(body === null || body === void 0 ? void 0 : body.readable) ? body === null || body === void 0 ? void 0 : body.readable : duplexify2(body.readable) : void 0;
      const writable2 = body !== null && body !== void 0 && body.writable ? isWritableNodeStream2(body === null || body === void 0 ? void 0 : body.writable) ? body === null || body === void 0 ? void 0 : body.writable : duplexify2(body.writable) : void 0;
      return _duplexify({
        readable: readable2,
        writable: writable2
      });
    }
    const then = body === null || body === void 0 ? void 0 : body.then;
    if (typeof then === "function") {
      let d;
      FunctionPrototypeCall(
        then,
        body,
        (val) => {
          if (val != null) {
            d.push(val);
          }
          d.push(null);
        },
        (err) => {
          destroyer2(d, err);
        }
      );
      return d = new Duplexify({
        objectMode: true,
        writable: false,
        read() {
        }
      });
    }
    throw new ERR_INVALID_ARG_TYPE2(
      name,
      [
        "Blob",
        "ReadableStream",
        "WritableStream",
        "Stream",
        "Iterable",
        "AsyncIterable",
        "Function",
        "{ readable, writable } pair",
        "Promise"
      ],
      body
    );
  };
  function fromAsyncGen(fn) {
    let { promise, resolve } = createDeferredPromise();
    const ac = new AbortController2();
    const signal = ac.signal;
    const value = fn(
      async function* () {
        while (true) {
          const _promise = promise;
          promise = null;
          const { chunk, done, cb } = await _promise;
          process2.nextTick(cb);
          if (done) return;
          if (signal.aborted)
            throw new AbortError3(void 0, {
              cause: signal.reason
            });
          ({ promise, resolve } = createDeferredPromise());
          yield chunk;
        }
      }(),
      {
        signal
      }
    );
    return {
      value,
      write(chunk, encoding, cb) {
        const _resolve = resolve;
        resolve = null;
        _resolve({
          chunk,
          done: false,
          cb
        });
      },
      final(cb) {
        const _resolve = resolve;
        resolve = null;
        _resolve({
          done: true,
          cb
        });
      },
      destroy(err, cb) {
        ac.abort();
        cb(err);
      }
    };
  }
  function _duplexify(pair) {
    const r = pair.readable && typeof pair.readable.read !== "function" ? Readable2.wrap(pair.readable) : pair.readable;
    const w = pair.writable;
    let readable2 = !!isReadable2(r);
    let writable2 = !!isWritable2(w);
    let ondrain;
    let onfinish;
    let onreadable;
    let onclose;
    let d;
    function onfinished(err) {
      const cb = onclose;
      onclose = null;
      if (cb) {
        cb(err);
      } else if (err) {
        d.destroy(err);
      }
    }
    d = new Duplexify({
      // TODO (ronag): highWaterMark?
      readableObjectMode: !!(r !== null && r !== void 0 && r.readableObjectMode),
      writableObjectMode: !!(w !== null && w !== void 0 && w.writableObjectMode),
      readable: readable2,
      writable: writable2
    });
    if (writable2) {
      eos2(w, (err) => {
        writable2 = false;
        if (err) {
          destroyer2(r, err);
        }
        onfinished(err);
      });
      d._write = function(chunk, encoding, callback) {
        if (w.write(chunk, encoding)) {
          callback();
        } else {
          ondrain = callback;
        }
      };
      d._final = function(callback) {
        w.end();
        onfinish = callback;
      };
      w.on("drain", function() {
        if (ondrain) {
          const cb = ondrain;
          ondrain = null;
          cb();
        }
      });
      w.on("finish", function() {
        if (onfinish) {
          const cb = onfinish;
          onfinish = null;
          cb();
        }
      });
    }
    if (readable2) {
      eos2(r, (err) => {
        readable2 = false;
        if (err) {
          destroyer2(r, err);
        }
        onfinished(err);
      });
      r.on("readable", function() {
        if (onreadable) {
          const cb = onreadable;
          onreadable = null;
          cb();
        }
      });
      r.on("end", function() {
        d.push(null);
      });
      d._read = function() {
        while (true) {
          const buf = r.read();
          if (buf === null) {
            onreadable = d._read;
            return;
          }
          if (!d.push(buf)) {
            return;
          }
        }
      };
    }
    d._destroy = function(err, callback) {
      if (!err && onclose !== null) {
        err = new AbortError3();
      }
      onreadable = null;
      ondrain = null;
      onfinish = null;
      if (onclose === null) {
        callback(err);
      } else {
        onclose = callback;
        destroyer2(w, err);
        destroyer2(r, err);
      }
    };
    return d;
  }
  return duplexify;
}
var duplex;
var hasRequiredDuplex;
function requireDuplex() {
  if (hasRequiredDuplex) return duplex;
  hasRequiredDuplex = 1;
  const {
    ObjectDefineProperties,
    ObjectGetOwnPropertyDescriptor,
    ObjectKeys,
    ObjectSetPrototypeOf: ObjectSetPrototypeOf2
  } = primordials;
  duplex = Duplex2;
  const Readable2 = requireReadable();
  const Writable = requireWritable();
  ObjectSetPrototypeOf2(Duplex2.prototype, Readable2.prototype);
  ObjectSetPrototypeOf2(Duplex2, Readable2);
  {
    const keys2 = ObjectKeys(Writable.prototype);
    for (let i = 0; i < keys2.length; i++) {
      const method = keys2[i];
      if (!Duplex2.prototype[method]) Duplex2.prototype[method] = Writable.prototype[method];
    }
  }
  function Duplex2(options) {
    if (!(this instanceof Duplex2)) return new Duplex2(options);
    Readable2.call(this, options);
    Writable.call(this, options);
    if (options) {
      this.allowHalfOpen = options.allowHalfOpen !== false;
      if (options.readable === false) {
        this._readableState.readable = false;
        this._readableState.ended = true;
        this._readableState.endEmitted = true;
      }
      if (options.writable === false) {
        this._writableState.writable = false;
        this._writableState.ending = true;
        this._writableState.ended = true;
        this._writableState.finished = true;
      }
    } else {
      this.allowHalfOpen = true;
    }
  }
  ObjectDefineProperties(Duplex2.prototype, {
    writable: {
      __proto__: null,
      ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writable")
    },
    writableHighWaterMark: {
      __proto__: null,
      ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableHighWaterMark")
    },
    writableObjectMode: {
      __proto__: null,
      ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableObjectMode")
    },
    writableBuffer: {
      __proto__: null,
      ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableBuffer")
    },
    writableLength: {
      __proto__: null,
      ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableLength")
    },
    writableFinished: {
      __proto__: null,
      ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableFinished")
    },
    writableCorked: {
      __proto__: null,
      ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableCorked")
    },
    writableEnded: {
      __proto__: null,
      ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableEnded")
    },
    writableNeedDrain: {
      __proto__: null,
      ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableNeedDrain")
    },
    destroyed: {
      __proto__: null,
      get() {
        if (this._readableState === void 0 || this._writableState === void 0) {
          return false;
        }
        return this._readableState.destroyed && this._writableState.destroyed;
      },
      set(value) {
        if (this._readableState && this._writableState) {
          this._readableState.destroyed = value;
          this._writableState.destroyed = value;
        }
      }
    }
  });
  let webStreamsAdapters;
  function lazyWebStreams() {
    if (webStreamsAdapters === void 0) webStreamsAdapters = {};
    return webStreamsAdapters;
  }
  Duplex2.fromWeb = function(pair, options) {
    return lazyWebStreams().newStreamDuplexFromReadableWritablePair(pair, options);
  };
  Duplex2.toWeb = function(duplex2) {
    return lazyWebStreams().newReadableWritablePairFromDuplex(duplex2);
  };
  let duplexify2;
  Duplex2.from = function(body) {
    if (!duplexify2) {
      duplexify2 = requireDuplexify();
    }
    return duplexify2(body, "body");
  };
  return duplex;
}
const { ObjectSetPrototypeOf: ObjectSetPrototypeOf$1, Symbol: Symbol$2 } = primordials;
var transform = Transform$1;
const { ERR_METHOD_NOT_IMPLEMENTED } = errors.codes;
const Duplex$2 = requireDuplex();
const { getHighWaterMark } = state;
ObjectSetPrototypeOf$1(Transform$1.prototype, Duplex$2.prototype);
ObjectSetPrototypeOf$1(Transform$1, Duplex$2);
const kCallback = Symbol$2("kCallback");
function Transform$1(options) {
  if (!(this instanceof Transform$1)) return new Transform$1(options);
  const readableHighWaterMark = options ? getHighWaterMark(this, options, "readableHighWaterMark", true) : null;
  if (readableHighWaterMark === 0) {
    options = {
      ...options,
      highWaterMark: null,
      readableHighWaterMark,
      // TODO (ronag): 0 is not optimal since we have
      // a "bug" where we check needDrain before calling _write and not after.
      // Refs: https://github.com/nodejs/node/pull/32887
      // Refs: https://github.com/nodejs/node/pull/35941
      writableHighWaterMark: options.writableHighWaterMark || 0
    };
  }
  Duplex$2.call(this, options);
  this._readableState.sync = false;
  this[kCallback] = null;
  if (options) {
    if (typeof options.transform === "function") this._transform = options.transform;
    if (typeof options.flush === "function") this._flush = options.flush;
  }
  this.on("prefinish", prefinish);
}
function final(cb) {
  if (typeof this._flush === "function" && !this.destroyed) {
    this._flush((er, data) => {
      if (er) {
        if (cb) {
          cb(er);
        } else {
          this.destroy(er);
        }
        return;
      }
      if (data != null) {
        this.push(data);
      }
      this.push(null);
      if (cb) {
        cb();
      }
    });
  } else {
    this.push(null);
    if (cb) {
      cb();
    }
  }
}
function prefinish() {
  if (this._final !== final) {
    final.call(this);
  }
}
Transform$1.prototype._final = final;
Transform$1.prototype._transform = function(chunk, encoding, callback) {
  throw new ERR_METHOD_NOT_IMPLEMENTED("_transform()");
};
Transform$1.prototype._write = function(chunk, encoding, callback) {
  const rState = this._readableState;
  const wState = this._writableState;
  const length = rState.length;
  this._transform(chunk, encoding, (err, val) => {
    if (err) {
      callback(err);
      return;
    }
    if (val != null) {
      this.push(val);
    }
    if (wState.ended || // Backwards compat.
    length === rState.length || // Backwards compat.
    rState.length < rState.highWaterMark) {
      callback();
    } else {
      this[kCallback] = callback;
    }
  });
};
Transform$1.prototype._read = function() {
  if (this[kCallback]) {
    const callback = this[kCallback];
    this[kCallback] = null;
    callback();
  }
};
const { ObjectSetPrototypeOf } = primordials;
var passthrough = PassThrough$1;
const Transform = transform;
ObjectSetPrototypeOf(PassThrough$1.prototype, Transform.prototype);
ObjectSetPrototypeOf(PassThrough$1, Transform);
function PassThrough$1(options) {
  if (!(this instanceof PassThrough$1)) return new PassThrough$1(options);
  Transform.call(this, options);
}
PassThrough$1.prototype._transform = function(chunk, encoding, cb) {
  cb(null, chunk);
};
const process = browserExports;
const { ArrayIsArray, Promise: Promise$2, SymbolAsyncIterator, SymbolDispose } = primordials;
const eos$1 = endOfStreamExports;
const { once: once2 } = utilExports;
const destroyImpl = destroy_1;
const Duplex$1 = requireDuplex();
const {
  aggregateTwoErrors,
  codes: {
    ERR_INVALID_ARG_TYPE: ERR_INVALID_ARG_TYPE$1,
    ERR_INVALID_RETURN_VALUE,
    ERR_MISSING_ARGS: ERR_MISSING_ARGS$2,
    ERR_STREAM_DESTROYED,
    ERR_STREAM_PREMATURE_CLOSE
  },
  AbortError: AbortError$2
} = errors;
const { validateFunction, validateAbortSignal: validateAbortSignal$1 } = validators;
const {
  isIterable,
  isReadable: isReadable$1,
  isReadableNodeStream,
  isNodeStream: isNodeStream$2,
  isTransformStream: isTransformStream$1,
  isWebStream: isWebStream$1,
  isReadableStream: isReadableStream$1,
  isReadableFinished
} = utils;
const AbortController$1 = globalThis.AbortController || requireBrowser().AbortController;
let PassThrough;
let Readable;
let addAbortListener;
function destroyer$1(stream2, reading, writing) {
  let finished2 = false;
  stream2.on("close", () => {
    finished2 = true;
  });
  const cleanup = eos$1(
    stream2,
    {
      readable: reading,
      writable: writing
    },
    (err) => {
      finished2 = !err;
    }
  );
  return {
    destroy: (err) => {
      if (finished2) return;
      finished2 = true;
      destroyImpl.destroyer(stream2, err || new ERR_STREAM_DESTROYED("pipe"));
    },
    cleanup
  };
}
function popCallback(streams) {
  validateFunction(streams[streams.length - 1], "streams[stream.length - 1]");
  return streams.pop();
}
function makeAsyncIterable(val) {
  if (isIterable(val)) {
    return val;
  } else if (isReadableNodeStream(val)) {
    return fromReadable(val);
  }
  throw new ERR_INVALID_ARG_TYPE$1("val", ["Readable", "Iterable", "AsyncIterable"], val);
}
async function* fromReadable(val) {
  if (!Readable) {
    Readable = requireReadable();
  }
  yield* Readable.prototype[SymbolAsyncIterator].call(val);
}
async function pumpToNode(iterable, writable2, finish, { end }) {
  let error;
  let onresolve = null;
  const resume = (err) => {
    if (err) {
      error = err;
    }
    if (onresolve) {
      const callback = onresolve;
      onresolve = null;
      callback();
    }
  };
  const wait = () => new Promise$2((resolve, reject) => {
    if (error) {
      reject(error);
    } else {
      onresolve = () => {
        if (error) {
          reject(error);
        } else {
          resolve();
        }
      };
    }
  });
  writable2.on("drain", resume);
  const cleanup = eos$1(
    writable2,
    {
      readable: false
    },
    resume
  );
  try {
    if (writable2.writableNeedDrain) {
      await wait();
    }
    for await (const chunk of iterable) {
      if (!writable2.write(chunk)) {
        await wait();
      }
    }
    if (end) {
      writable2.end();
      await wait();
    }
    finish();
  } catch (err) {
    finish(error !== err ? aggregateTwoErrors(error, err) : err);
  } finally {
    cleanup();
    writable2.off("drain", resume);
  }
}
async function pumpToWeb(readable2, writable2, finish, { end }) {
  if (isTransformStream$1(writable2)) {
    writable2 = writable2.writable;
  }
  const writer = writable2.getWriter();
  try {
    for await (const chunk of readable2) {
      await writer.ready;
      writer.write(chunk).catch(() => {
      });
    }
    await writer.ready;
    if (end) {
      await writer.close();
    }
    finish();
  } catch (err) {
    try {
      await writer.abort(err);
      finish(err);
    } catch (err2) {
      finish(err2);
    }
  }
}
function pipeline$1(...streams) {
  return pipelineImpl(streams, once2(popCallback(streams)));
}
function pipelineImpl(streams, callback, opts) {
  if (streams.length === 1 && ArrayIsArray(streams[0])) {
    streams = streams[0];
  }
  if (streams.length < 2) {
    throw new ERR_MISSING_ARGS$2("streams");
  }
  const ac = new AbortController$1();
  const signal = ac.signal;
  const outerSignal = opts === null || opts === void 0 ? void 0 : opts.signal;
  const lastStreamCleanup = [];
  validateAbortSignal$1(outerSignal, "options.signal");
  function abort() {
    finishImpl(new AbortError$2());
  }
  addAbortListener = addAbortListener || utilExports.addAbortListener;
  let disposable;
  if (outerSignal) {
    disposable = addAbortListener(outerSignal, abort);
  }
  let error;
  let value;
  const destroys = [];
  let finishCount = 0;
  function finish(err) {
    finishImpl(err, --finishCount === 0);
  }
  function finishImpl(err, final2) {
    var _disposable;
    if (err && (!error || error.code === "ERR_STREAM_PREMATURE_CLOSE")) {
      error = err;
    }
    if (!error && !final2) {
      return;
    }
    while (destroys.length) {
      destroys.shift()(error);
    }
    (_disposable = disposable) === null || _disposable === void 0 ? void 0 : _disposable[SymbolDispose]();
    ac.abort();
    if (final2) {
      if (!error) {
        lastStreamCleanup.forEach((fn) => fn());
      }
      process.nextTick(callback, error, value);
    }
  }
  let ret;
  for (let i = 0; i < streams.length; i++) {
    const stream2 = streams[i];
    const reading = i < streams.length - 1;
    const writing = i > 0;
    const end = reading || (opts === null || opts === void 0 ? void 0 : opts.end) !== false;
    const isLastStream = i === streams.length - 1;
    if (isNodeStream$2(stream2)) {
      let onError2 = function(err) {
        if (err && err.name !== "AbortError" && err.code !== "ERR_STREAM_PREMATURE_CLOSE") {
          finish(err);
        }
      };
      if (end) {
        const { destroy: destroy2, cleanup } = destroyer$1(stream2, reading, writing);
        destroys.push(destroy2);
        if (isReadable$1(stream2) && isLastStream) {
          lastStreamCleanup.push(cleanup);
        }
      }
      stream2.on("error", onError2);
      if (isReadable$1(stream2) && isLastStream) {
        lastStreamCleanup.push(() => {
          stream2.removeListener("error", onError2);
        });
      }
    }
    if (i === 0) {
      if (typeof stream2 === "function") {
        ret = stream2({
          signal
        });
        if (!isIterable(ret)) {
          throw new ERR_INVALID_RETURN_VALUE("Iterable, AsyncIterable or Stream", "source", ret);
        }
      } else if (isIterable(stream2) || isReadableNodeStream(stream2) || isTransformStream$1(stream2)) {
        ret = stream2;
      } else {
        ret = Duplex$1.from(stream2);
      }
    } else if (typeof stream2 === "function") {
      if (isTransformStream$1(ret)) {
        var _ret;
        ret = makeAsyncIterable((_ret = ret) === null || _ret === void 0 ? void 0 : _ret.readable);
      } else {
        ret = makeAsyncIterable(ret);
      }
      ret = stream2(ret, {
        signal
      });
      if (reading) {
        if (!isIterable(ret, true)) {
          throw new ERR_INVALID_RETURN_VALUE("AsyncIterable", `transform[${i - 1}]`, ret);
        }
      } else {
        var _ret2;
        if (!PassThrough) {
          PassThrough = passthrough;
        }
        const pt = new PassThrough({
          objectMode: true
        });
        const then = (_ret2 = ret) === null || _ret2 === void 0 ? void 0 : _ret2.then;
        if (typeof then === "function") {
          finishCount++;
          then.call(
            ret,
            (val) => {
              value = val;
              if (val != null) {
                pt.write(val);
              }
              if (end) {
                pt.end();
              }
              process.nextTick(finish);
            },
            (err) => {
              pt.destroy(err);
              process.nextTick(finish, err);
            }
          );
        } else if (isIterable(ret, true)) {
          finishCount++;
          pumpToNode(ret, pt, finish, {
            end
          });
        } else if (isReadableStream$1(ret) || isTransformStream$1(ret)) {
          const toRead = ret.readable || ret;
          finishCount++;
          pumpToNode(toRead, pt, finish, {
            end
          });
        } else {
          throw new ERR_INVALID_RETURN_VALUE("AsyncIterable or Promise", "destination", ret);
        }
        ret = pt;
        const { destroy: destroy2, cleanup } = destroyer$1(ret, false, true);
        destroys.push(destroy2);
        if (isLastStream) {
          lastStreamCleanup.push(cleanup);
        }
      }
    } else if (isNodeStream$2(stream2)) {
      if (isReadableNodeStream(ret)) {
        finishCount += 2;
        const cleanup = pipe(ret, stream2, finish, {
          end
        });
        if (isReadable$1(stream2) && isLastStream) {
          lastStreamCleanup.push(cleanup);
        }
      } else if (isTransformStream$1(ret) || isReadableStream$1(ret)) {
        const toRead = ret.readable || ret;
        finishCount++;
        pumpToNode(toRead, stream2, finish, {
          end
        });
      } else if (isIterable(ret)) {
        finishCount++;
        pumpToNode(ret, stream2, finish, {
          end
        });
      } else {
        throw new ERR_INVALID_ARG_TYPE$1(
          "val",
          ["Readable", "Iterable", "AsyncIterable", "ReadableStream", "TransformStream"],
          ret
        );
      }
      ret = stream2;
    } else if (isWebStream$1(stream2)) {
      if (isReadableNodeStream(ret)) {
        finishCount++;
        pumpToWeb(makeAsyncIterable(ret), stream2, finish, {
          end
        });
      } else if (isReadableStream$1(ret) || isIterable(ret)) {
        finishCount++;
        pumpToWeb(ret, stream2, finish, {
          end
        });
      } else if (isTransformStream$1(ret)) {
        finishCount++;
        pumpToWeb(ret.readable, stream2, finish, {
          end
        });
      } else {
        throw new ERR_INVALID_ARG_TYPE$1(
          "val",
          ["Readable", "Iterable", "AsyncIterable", "ReadableStream", "TransformStream"],
          ret
        );
      }
      ret = stream2;
    } else {
      ret = Duplex$1.from(stream2);
    }
  }
  if (signal !== null && signal !== void 0 && signal.aborted || outerSignal !== null && outerSignal !== void 0 && outerSignal.aborted) {
    process.nextTick(abort);
  }
  return ret;
}
function pipe(src, dst, finish, { end }) {
  let ended = false;
  dst.on("close", () => {
    if (!ended) {
      finish(new ERR_STREAM_PREMATURE_CLOSE());
    }
  });
  src.pipe(dst, {
    end: false
  });
  if (end) {
    let endFn2 = function() {
      ended = true;
      dst.end();
    };
    if (isReadableFinished(src)) {
      process.nextTick(endFn2);
    } else {
      src.once("end", endFn2);
    }
  } else {
    finish();
  }
  eos$1(
    src,
    {
      readable: true,
      writable: false
    },
    (err) => {
      const rState = src._readableState;
      if (err && err.code === "ERR_STREAM_PREMATURE_CLOSE" && rState && rState.ended && !rState.errored && !rState.errorEmitted) {
        src.once("end", finish).once("error", finish);
      } else {
        finish(err);
      }
    }
  );
  return eos$1(
    dst,
    {
      readable: false,
      writable: true
    },
    finish
  );
}
var pipeline_1 = {
  pipelineImpl,
  pipeline: pipeline$1
};
const { pipeline } = pipeline_1;
const Duplex = requireDuplex();
const { destroyer } = destroy_1;
const {
  isNodeStream: isNodeStream$1,
  isReadable,
  isWritable: isWritable$1,
  isWebStream,
  isTransformStream,
  isWritableStream,
  isReadableStream
} = utils;
const {
  AbortError: AbortError$1,
  codes: { ERR_INVALID_ARG_VALUE: ERR_INVALID_ARG_VALUE$1, ERR_MISSING_ARGS: ERR_MISSING_ARGS$1 }
} = errors;
const eos = endOfStreamExports;
var compose$1 = function compose(...streams) {
  if (streams.length === 0) {
    throw new ERR_MISSING_ARGS$1("streams");
  }
  if (streams.length === 1) {
    return Duplex.from(streams[0]);
  }
  const orgStreams = [...streams];
  if (typeof streams[0] === "function") {
    streams[0] = Duplex.from(streams[0]);
  }
  if (typeof streams[streams.length - 1] === "function") {
    const idx = streams.length - 1;
    streams[idx] = Duplex.from(streams[idx]);
  }
  for (let n = 0; n < streams.length; ++n) {
    if (!isNodeStream$1(streams[n]) && !isWebStream(streams[n])) {
      continue;
    }
    if (n < streams.length - 1 && !(isReadable(streams[n]) || isReadableStream(streams[n]) || isTransformStream(streams[n]))) {
      throw new ERR_INVALID_ARG_VALUE$1(`streams[${n}]`, orgStreams[n], "must be readable");
    }
    if (n > 0 && !(isWritable$1(streams[n]) || isWritableStream(streams[n]) || isTransformStream(streams[n]))) {
      throw new ERR_INVALID_ARG_VALUE$1(`streams[${n}]`, orgStreams[n], "must be writable");
    }
  }
  let ondrain;
  let onfinish;
  let onreadable;
  let onclose;
  let d;
  function onfinished(err) {
    const cb = onclose;
    onclose = null;
    if (cb) {
      cb(err);
    } else if (err) {
      d.destroy(err);
    } else if (!readable2 && !writable2) {
      d.destroy();
    }
  }
  const head = streams[0];
  const tail = pipeline(streams, onfinished);
  const writable2 = !!(isWritable$1(head) || isWritableStream(head) || isTransformStream(head));
  const readable2 = !!(isReadable(tail) || isReadableStream(tail) || isTransformStream(tail));
  d = new Duplex({
    // TODO (ronag): highWaterMark?
    writableObjectMode: !!(head !== null && head !== void 0 && head.writableObjectMode),
    readableObjectMode: !!(tail !== null && tail !== void 0 && tail.readableObjectMode),
    writable: writable2,
    readable: readable2
  });
  if (writable2) {
    if (isNodeStream$1(head)) {
      d._write = function(chunk, encoding, callback) {
        if (head.write(chunk, encoding)) {
          callback();
        } else {
          ondrain = callback;
        }
      };
      d._final = function(callback) {
        head.end();
        onfinish = callback;
      };
      head.on("drain", function() {
        if (ondrain) {
          const cb = ondrain;
          ondrain = null;
          cb();
        }
      });
    } else if (isWebStream(head)) {
      const writable3 = isTransformStream(head) ? head.writable : head;
      const writer = writable3.getWriter();
      d._write = async function(chunk, encoding, callback) {
        try {
          await writer.ready;
          writer.write(chunk).catch(() => {
          });
          callback();
        } catch (err) {
          callback(err);
        }
      };
      d._final = async function(callback) {
        try {
          await writer.ready;
          writer.close().catch(() => {
          });
          onfinish = callback;
        } catch (err) {
          callback(err);
        }
      };
    }
    const toRead = isTransformStream(tail) ? tail.readable : tail;
    eos(toRead, () => {
      if (onfinish) {
        const cb = onfinish;
        onfinish = null;
        cb();
      }
    });
  }
  if (readable2) {
    if (isNodeStream$1(tail)) {
      tail.on("readable", function() {
        if (onreadable) {
          const cb = onreadable;
          onreadable = null;
          cb();
        }
      });
      tail.on("end", function() {
        d.push(null);
      });
      d._read = function() {
        while (true) {
          const buf = tail.read();
          if (buf === null) {
            onreadable = d._read;
            return;
          }
          if (!d.push(buf)) {
            return;
          }
        }
      };
    } else if (isWebStream(tail)) {
      const readable3 = isTransformStream(tail) ? tail.readable : tail;
      const reader = readable3.getReader();
      d._read = async function() {
        while (true) {
          try {
            const { value, done } = await reader.read();
            if (!d.push(value)) {
              return;
            }
            if (done) {
              d.push(null);
              return;
            }
          } catch {
            return;
          }
        }
      };
    }
  }
  d._destroy = function(err, callback) {
    if (!err && onclose !== null) {
      err = new AbortError$1();
    }
    onreadable = null;
    ondrain = null;
    onfinish = null;
    if (onclose === null) {
      callback(err);
    } else {
      onclose = callback;
      if (isNodeStream$1(tail)) {
        destroyer(tail, err);
      }
    }
  };
  return d;
};
const AbortController = globalThis.AbortController || requireBrowser().AbortController;
const {
  codes: { ERR_INVALID_ARG_VALUE, ERR_INVALID_ARG_TYPE, ERR_MISSING_ARGS, ERR_OUT_OF_RANGE },
  AbortError: AbortError2
} = errors;
const { validateAbortSignal, validateInteger, validateObject } = validators;
const kWeakHandler = primordials.Symbol("kWeak");
const kResistStopPropagation = primordials.Symbol("kResistStopPropagation");
const { finished } = endOfStreamExports;
const staticCompose = compose$1;
const { addAbortSignalNoValidate } = addAbortSignalExports;
const { isWritable, isNodeStream } = utils;
const { deprecate } = utilExports;
const {
  ArrayPrototypePush,
  Boolean: Boolean$1,
  MathFloor,
  Number: Number$1,
  NumberIsNaN: NumberIsNaN2,
  Promise: Promise$1,
  PromiseReject,
  PromiseResolve,
  PromisePrototypeThen,
  Symbol: Symbol$1
} = primordials;
const kEmpty = Symbol$1("kEmpty");
const kEof = Symbol$1("kEof");
function compose2(stream2, options) {
  if (options != null) {
    validateObject(options, "options");
  }
  if ((options === null || options === void 0 ? void 0 : options.signal) != null) {
    validateAbortSignal(options.signal, "options.signal");
  }
  if (isNodeStream(stream2) && !isWritable(stream2)) {
    throw new ERR_INVALID_ARG_VALUE("stream", stream2, "must be writable");
  }
  const composedStream = staticCompose(this, stream2);
  if (options !== null && options !== void 0 && options.signal) {
    addAbortSignalNoValidate(options.signal, composedStream);
  }
  return composedStream;
}
function map(fn, options) {
  if (typeof fn !== "function") {
    throw new ERR_INVALID_ARG_TYPE("fn", ["Function", "AsyncFunction"], fn);
  }
  if (options != null) {
    validateObject(options, "options");
  }
  if ((options === null || options === void 0 ? void 0 : options.signal) != null) {
    validateAbortSignal(options.signal, "options.signal");
  }
  let concurrency = 1;
  if ((options === null || options === void 0 ? void 0 : options.concurrency) != null) {
    concurrency = MathFloor(options.concurrency);
  }
  let highWaterMark = concurrency - 1;
  if ((options === null || options === void 0 ? void 0 : options.highWaterMark) != null) {
    highWaterMark = MathFloor(options.highWaterMark);
  }
  validateInteger(concurrency, "options.concurrency", 1);
  validateInteger(highWaterMark, "options.highWaterMark", 0);
  highWaterMark += concurrency;
  return (async function* map2() {
    const signal = utilExports.AbortSignalAny(
      [options === null || options === void 0 ? void 0 : options.signal].filter(Boolean$1)
    );
    const stream2 = this;
    const queue2 = [];
    const signalOpt = {
      signal
    };
    let next;
    let resume;
    let done = false;
    let cnt = 0;
    function onCatch() {
      done = true;
      afterItemProcessed();
    }
    function afterItemProcessed() {
      cnt -= 1;
      maybeResume();
    }
    function maybeResume() {
      if (resume && !done && cnt < concurrency && queue2.length < highWaterMark) {
        resume();
        resume = null;
      }
    }
    async function pump() {
      try {
        for await (let val of stream2) {
          if (done) {
            return;
          }
          if (signal.aborted) {
            throw new AbortError2();
          }
          try {
            val = fn(val, signalOpt);
            if (val === kEmpty) {
              continue;
            }
            val = PromiseResolve(val);
          } catch (err) {
            val = PromiseReject(err);
          }
          cnt += 1;
          PromisePrototypeThen(val, afterItemProcessed, onCatch);
          queue2.push(val);
          if (next) {
            next();
            next = null;
          }
          if (!done && (queue2.length >= highWaterMark || cnt >= concurrency)) {
            await new Promise$1((resolve) => {
              resume = resolve;
            });
          }
        }
        queue2.push(kEof);
      } catch (err) {
        const val = PromiseReject(err);
        PromisePrototypeThen(val, afterItemProcessed, onCatch);
        queue2.push(val);
      } finally {
        done = true;
        if (next) {
          next();
          next = null;
        }
      }
    }
    pump();
    try {
      while (true) {
        while (queue2.length > 0) {
          const val = await queue2[0];
          if (val === kEof) {
            return;
          }
          if (signal.aborted) {
            throw new AbortError2();
          }
          if (val !== kEmpty) {
            yield val;
          }
          queue2.shift();
          maybeResume();
        }
        await new Promise$1((resolve) => {
          next = resolve;
        });
      }
    } finally {
      done = true;
      if (resume) {
        resume();
        resume = null;
      }
    }
  }).call(this);
}
function asIndexedPairs(options = void 0) {
  if (options != null) {
    validateObject(options, "options");
  }
  if ((options === null || options === void 0 ? void 0 : options.signal) != null) {
    validateAbortSignal(options.signal, "options.signal");
  }
  return (async function* asIndexedPairs2() {
    let index = 0;
    for await (const val of this) {
      var _options$signal;
      if (options !== null && options !== void 0 && (_options$signal = options.signal) !== null && _options$signal !== void 0 && _options$signal.aborted) {
        throw new AbortError2({
          cause: options.signal.reason
        });
      }
      yield [index++, val];
    }
  }).call(this);
}
async function some(fn, options = void 0) {
  for await (const unused of filter.call(this, fn, options)) {
    return true;
  }
  return false;
}
async function every(fn, options = void 0) {
  if (typeof fn !== "function") {
    throw new ERR_INVALID_ARG_TYPE("fn", ["Function", "AsyncFunction"], fn);
  }
  return !await some.call(
    this,
    async (...args) => {
      return !await fn(...args);
    },
    options
  );
}
async function find(fn, options) {
  for await (const result of filter.call(this, fn, options)) {
    return result;
  }
  return void 0;
}
async function forEach(fn, options) {
  if (typeof fn !== "function") {
    throw new ERR_INVALID_ARG_TYPE("fn", ["Function", "AsyncFunction"], fn);
  }
  async function forEachFn(value, options2) {
    await fn(value, options2);
    return kEmpty;
  }
  for await (const unused of map.call(this, forEachFn, options)) ;
}
function filter(fn, options) {
  if (typeof fn !== "function") {
    throw new ERR_INVALID_ARG_TYPE("fn", ["Function", "AsyncFunction"], fn);
  }
  async function filterFn(value, options2) {
    if (await fn(value, options2)) {
      return value;
    }
    return kEmpty;
  }
  return map.call(this, filterFn, options);
}
class ReduceAwareErrMissingArgs extends ERR_MISSING_ARGS {
  constructor() {
    super("reduce");
    this.message = "Reduce of an empty stream requires an initial value";
  }
}
async function reduce(reducer, initialValue, options) {
  var _options$signal2;
  if (typeof reducer !== "function") {
    throw new ERR_INVALID_ARG_TYPE("reducer", ["Function", "AsyncFunction"], reducer);
  }
  if (options != null) {
    validateObject(options, "options");
  }
  if ((options === null || options === void 0 ? void 0 : options.signal) != null) {
    validateAbortSignal(options.signal, "options.signal");
  }
  let hasInitialValue = arguments.length > 1;
  if (options !== null && options !== void 0 && (_options$signal2 = options.signal) !== null && _options$signal2 !== void 0 && _options$signal2.aborted) {
    const err = new AbortError2(void 0, {
      cause: options.signal.reason
    });
    this.once("error", () => {
    });
    await finished(this.destroy(err));
    throw err;
  }
  const ac = new AbortController();
  const signal = ac.signal;
  if (options !== null && options !== void 0 && options.signal) {
    const opts = {
      once: true,
      [kWeakHandler]: this,
      [kResistStopPropagation]: true
    };
    options.signal.addEventListener("abort", () => ac.abort(), opts);
  }
  let gotAnyItemFromStream = false;
  try {
    for await (const value of this) {
      var _options$signal3;
      gotAnyItemFromStream = true;
      if (options !== null && options !== void 0 && (_options$signal3 = options.signal) !== null && _options$signal3 !== void 0 && _options$signal3.aborted) {
        throw new AbortError2();
      }
      if (!hasInitialValue) {
        initialValue = value;
        hasInitialValue = true;
      } else {
        initialValue = await reducer(initialValue, value, {
          signal
        });
      }
    }
    if (!gotAnyItemFromStream && !hasInitialValue) {
      throw new ReduceAwareErrMissingArgs();
    }
  } finally {
    ac.abort();
  }
  return initialValue;
}
async function toArray(options) {
  if (options != null) {
    validateObject(options, "options");
  }
  if ((options === null || options === void 0 ? void 0 : options.signal) != null) {
    validateAbortSignal(options.signal, "options.signal");
  }
  const result = [];
  for await (const val of this) {
    var _options$signal4;
    if (options !== null && options !== void 0 && (_options$signal4 = options.signal) !== null && _options$signal4 !== void 0 && _options$signal4.aborted) {
      throw new AbortError2(void 0, {
        cause: options.signal.reason
      });
    }
    ArrayPrototypePush(result, val);
  }
  return result;
}
function flatMap(fn, options) {
  const values = map.call(this, fn, options);
  return (async function* flatMap2() {
    for await (const val of values) {
      yield* val;
    }
  }).call(this);
}
function toIntegerOrInfinity(number) {
  number = Number$1(number);
  if (NumberIsNaN2(number)) {
    return 0;
  }
  if (number < 0) {
    throw new ERR_OUT_OF_RANGE("number", ">= 0", number);
  }
  return number;
}
function drop(number, options = void 0) {
  if (options != null) {
    validateObject(options, "options");
  }
  if ((options === null || options === void 0 ? void 0 : options.signal) != null) {
    validateAbortSignal(options.signal, "options.signal");
  }
  number = toIntegerOrInfinity(number);
  return (async function* drop2() {
    var _options$signal5;
    if (options !== null && options !== void 0 && (_options$signal5 = options.signal) !== null && _options$signal5 !== void 0 && _options$signal5.aborted) {
      throw new AbortError2();
    }
    for await (const val of this) {
      var _options$signal6;
      if (options !== null && options !== void 0 && (_options$signal6 = options.signal) !== null && _options$signal6 !== void 0 && _options$signal6.aborted) {
        throw new AbortError2();
      }
      if (number-- <= 0) {
        yield val;
      }
    }
  }).call(this);
}
function take(number, options = void 0) {
  if (options != null) {
    validateObject(options, "options");
  }
  if ((options === null || options === void 0 ? void 0 : options.signal) != null) {
    validateAbortSignal(options.signal, "options.signal");
  }
  number = toIntegerOrInfinity(number);
  return (async function* take2() {
    var _options$signal7;
    if (options !== null && options !== void 0 && (_options$signal7 = options.signal) !== null && _options$signal7 !== void 0 && _options$signal7.aborted) {
      throw new AbortError2();
    }
    for await (const val of this) {
      var _options$signal8;
      if (options !== null && options !== void 0 && (_options$signal8 = options.signal) !== null && _options$signal8 !== void 0 && _options$signal8.aborted) {
        throw new AbortError2();
      }
      if (number-- > 0) {
        yield val;
      }
      if (number <= 0) {
        return;
      }
    }
  }).call(this);
}
operators.streamReturningOperators = {
  asIndexedPairs: deprecate(asIndexedPairs, "readable.asIndexedPairs will be removed in a future version."),
  drop,
  filter,
  flatMap,
  map,
  take,
  compose: compose2
};
operators.promiseReturningOperators = {
  every,
  forEach,
  reduce,
  toArray,
  some,
  find
};
var promises;
var hasRequiredPromises;
function requirePromises() {
  if (hasRequiredPromises) return promises;
  hasRequiredPromises = 1;
  const { ArrayPrototypePop, Promise: Promise2 } = primordials;
  const { isIterable: isIterable2, isNodeStream: isNodeStream2, isWebStream: isWebStream2 } = utils;
  const { pipelineImpl: pl } = pipeline_1;
  const { finished: finished2 } = endOfStreamExports;
  requireStream();
  function pipeline2(...streams) {
    return new Promise2((resolve, reject) => {
      let signal;
      let end;
      const lastArg = streams[streams.length - 1];
      if (lastArg && typeof lastArg === "object" && !isNodeStream2(lastArg) && !isIterable2(lastArg) && !isWebStream2(lastArg)) {
        const options = ArrayPrototypePop(streams);
        signal = options.signal;
        end = options.end;
      }
      pl(
        streams,
        (err, value) => {
          if (err) {
            reject(err);
          } else {
            resolve(value);
          }
        },
        {
          signal,
          end
        }
      );
    });
  }
  promises = {
    finished: finished2,
    pipeline: pipeline2
  };
  return promises;
}
var hasRequiredStream;
function requireStream() {
  if (hasRequiredStream) return stream.exports;
  hasRequiredStream = 1;
  const { Buffer: Buffer2 } = buffer;
  const { ObjectDefineProperty, ObjectKeys, ReflectApply: ReflectApply3 } = primordials;
  const {
    promisify: { custom: customPromisify }
  } = utilExports;
  const { streamReturningOperators, promiseReturningOperators } = operators;
  const {
    codes: { ERR_ILLEGAL_CONSTRUCTOR }
  } = errors;
  const compose3 = compose$1;
  const { setDefaultHighWaterMark: setDefaultHighWaterMark2, getDefaultHighWaterMark: getDefaultHighWaterMark2 } = state;
  const { pipeline: pipeline2 } = pipeline_1;
  const { destroyer: destroyer2 } = destroy_1;
  const eos2 = endOfStreamExports;
  const promises2 = requirePromises();
  const utils$1 = utils;
  const Stream2 = stream.exports = legacy.Stream;
  Stream2.isDestroyed = utils$1.isDestroyed;
  Stream2.isDisturbed = utils$1.isDisturbed;
  Stream2.isErrored = utils$1.isErrored;
  Stream2.isReadable = utils$1.isReadable;
  Stream2.isWritable = utils$1.isWritable;
  Stream2.Readable = requireReadable();
  for (const key of ObjectKeys(streamReturningOperators)) {
    let fn = function(...args) {
      if (new.target) {
        throw ERR_ILLEGAL_CONSTRUCTOR();
      }
      return Stream2.Readable.from(ReflectApply3(op, this, args));
    };
    const op = streamReturningOperators[key];
    ObjectDefineProperty(fn, "name", {
      __proto__: null,
      value: op.name
    });
    ObjectDefineProperty(fn, "length", {
      __proto__: null,
      value: op.length
    });
    ObjectDefineProperty(Stream2.Readable.prototype, key, {
      __proto__: null,
      value: fn,
      enumerable: false,
      configurable: true,
      writable: true
    });
  }
  for (const key of ObjectKeys(promiseReturningOperators)) {
    let fn = function(...args) {
      if (new.target) {
        throw ERR_ILLEGAL_CONSTRUCTOR();
      }
      return ReflectApply3(op, this, args);
    };
    const op = promiseReturningOperators[key];
    ObjectDefineProperty(fn, "name", {
      __proto__: null,
      value: op.name
    });
    ObjectDefineProperty(fn, "length", {
      __proto__: null,
      value: op.length
    });
    ObjectDefineProperty(Stream2.Readable.prototype, key, {
      __proto__: null,
      value: fn,
      enumerable: false,
      configurable: true,
      writable: true
    });
  }
  Stream2.Writable = requireWritable();
  Stream2.Duplex = requireDuplex();
  Stream2.Transform = transform;
  Stream2.PassThrough = passthrough;
  Stream2.pipeline = pipeline2;
  const { addAbortSignal: addAbortSignal2 } = addAbortSignalExports;
  Stream2.addAbortSignal = addAbortSignal2;
  Stream2.finished = eos2;
  Stream2.destroy = destroyer2;
  Stream2.compose = compose3;
  Stream2.setDefaultHighWaterMark = setDefaultHighWaterMark2;
  Stream2.getDefaultHighWaterMark = getDefaultHighWaterMark2;
  ObjectDefineProperty(Stream2, "promises", {
    __proto__: null,
    configurable: true,
    enumerable: true,
    get() {
      return promises2;
    }
  });
  ObjectDefineProperty(pipeline2, customPromisify, {
    __proto__: null,
    enumerable: true,
    get() {
      return promises2.pipeline;
    }
  });
  ObjectDefineProperty(eos2, customPromisify, {
    __proto__: null,
    enumerable: true,
    get() {
      return promises2.finished;
    }
  });
  Stream2.Stream = Stream2;
  Stream2._isUint8Array = function isUint8Array(value) {
    return value instanceof Uint8Array;
  };
  Stream2._uint8ArrayToBuffer = function _uint8ArrayToBuffer(chunk) {
    return Buffer2.from(chunk.buffer, chunk.byteOffset, chunk.byteLength);
  };
  return stream.exports;
}
(function(module) {
  const CustomStream = requireStream();
  const promises2 = requirePromises();
  const originalDestroy = CustomStream.Readable.destroy;
  module.exports = CustomStream.Readable;
  module.exports._uint8ArrayToBuffer = CustomStream._uint8ArrayToBuffer;
  module.exports._isUint8Array = CustomStream._isUint8Array;
  module.exports.isDisturbed = CustomStream.isDisturbed;
  module.exports.isErrored = CustomStream.isErrored;
  module.exports.isReadable = CustomStream.isReadable;
  module.exports.Readable = CustomStream.Readable;
  module.exports.Writable = CustomStream.Writable;
  module.exports.Duplex = CustomStream.Duplex;
  module.exports.Transform = CustomStream.Transform;
  module.exports.PassThrough = CustomStream.PassThrough;
  module.exports.addAbortSignal = CustomStream.addAbortSignal;
  module.exports.finished = CustomStream.finished;
  module.exports.destroy = CustomStream.destroy;
  module.exports.destroy = originalDestroy;
  module.exports.pipeline = CustomStream.pipeline;
  module.exports.compose = CustomStream.compose;
  Object.defineProperty(CustomStream, "promises", {
    configurable: true,
    enumerable: true,
    get() {
      return promises2;
    }
  });
  module.exports.Stream = CustomStream.Stream;
  module.exports.default = module.exports;
})(browser$2);
function safeApply(handler, context, args) {
  try {
    Reflect.apply(handler, context, args);
  } catch (err) {
    setTimeout(() => {
      throw err;
    });
  }
}
function arrayClone(arr) {
  const n = arr.length;
  const copy = new Array(n);
  for (let i = 0; i < n; i += 1) {
    copy[i] = arr[i];
  }
  return copy;
}
class SafeEventEmitter extends eventsExports.EventEmitter {
  emit(type2, ...args) {
    let doError = type2 === "error";
    const events2 = this._events;
    if (events2 !== void 0) {
      doError = doError && events2.error === void 0;
    } else if (!doError) {
      return false;
    }
    if (doError) {
      let er;
      if (args.length > 0) {
        [er] = args;
      }
      if (er instanceof Error) {
        throw er;
      }
      const err = new Error(`Unhandled error.${er ? ` (${er.message})` : ""}`);
      err.context = er;
      throw err;
    }
    const handler = events2[type2];
    if (handler === void 0) {
      return false;
    }
    if (typeof handler === "function") {
      safeApply(handler, this, args);
    } else {
      const len = handler.length;
      const listeners2 = arrayClone(handler);
      for (let i = 0; i < len; i += 1) {
        safeApply(listeners2[i], this, args);
      }
    }
    return true;
  }
}
class SerializableError extends Error {
  constructor({
    code,
    message,
    data
  }) {
    if (!Number.isInteger(code)) {
      throw new Error("code must be an integer");
    }
    if (!message || typeof message !== "string") {
      throw new Error("message must be string");
    }
    super(message);
    _defineProperty(this, "code", void 0);
    _defineProperty(this, "data", void 0);
    this.code = code;
    if (data !== void 0) {
      this.data = data;
    }
  }
  toString() {
    return stringify({
      code: this.code,
      message: this.message,
      data: this.data,
      stack: this.stack
    });
  }
}
const errorCodes = {
  rpc: {
    invalidInput: -32e3,
    resourceNotFound: -32001,
    resourceUnavailable: -32002,
    transactionRejected: -32003,
    methodNotSupported: -32004,
    limitExceeded: -32005,
    parse: -32700,
    invalidRequest: -32600,
    methodNotFound: -32601,
    invalidParams: -32602,
    internal: -32603
  },
  provider: {
    userRejectedRequest: 4001,
    unauthorized: 4100,
    unsupportedMethod: 4200,
    disconnected: 4900,
    chainDisconnected: 4901
  }
};
const errorValues = {
  "-32700": {
    standard: "JSON RPC 2.0",
    message: "Invalid JSON was received by the server. An error occurred on the server while parsing the JSON text."
  },
  "-32600": {
    standard: "JSON RPC 2.0",
    message: "The JSON sent is not a valid Request object."
  },
  "-32601": {
    standard: "JSON RPC 2.0",
    message: "The method does not exist / is not available."
  },
  "-32602": {
    standard: "JSON RPC 2.0",
    message: "Invalid method parameter(s)."
  },
  "-32603": {
    standard: "JSON RPC 2.0",
    message: "Internal JSON-RPC error."
  },
  "-32000": {
    standard: "EIP-1474",
    message: "Invalid input."
  },
  "-32001": {
    standard: "EIP-1474",
    message: "Resource not found."
  },
  "-32002": {
    standard: "EIP-1474",
    message: "Resource unavailable."
  },
  "-32003": {
    standard: "EIP-1474",
    message: "Transaction rejected."
  },
  "-32004": {
    standard: "EIP-1474",
    message: "Method not supported."
  },
  "-32005": {
    standard: "EIP-1474",
    message: "Request limit exceeded."
  },
  "4001": {
    standard: "EIP-1193",
    message: "User rejected the request."
  },
  "4100": {
    standard: "EIP-1193",
    message: "The requested account and/or method has not been authorized by the user."
  },
  "4200": {
    standard: "EIP-1193",
    message: "The requested method is not supported by this Ethereum provider."
  },
  "4900": {
    standard: "EIP-1193",
    message: "The provider is disconnected from all chains."
  },
  "4901": {
    standard: "EIP-1193",
    message: "The provider is disconnected from the specified chain."
  }
};
const FALLBACK_ERROR_CODE = errorCodes.rpc.internal;
const FALLBACK_MESSAGE = "Unspecified error message. This is a bug, please report it.";
const JSON_RPC_SERVER_ERROR_MESSAGE = "Unspecified server error.";
function isValidCode(code) {
  return Number.isInteger(code);
}
function isValidString(value) {
  return typeof value === "string" && value.length > 0;
}
function isObject(value) {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}
function isPlainObject(value) {
  if (typeof value !== "object" || value === null) {
    return false;
  }
  try {
    let proto = value;
    while (Object.getPrototypeOf(proto) !== null) {
      proto = Object.getPrototypeOf(proto);
    }
    return Object.getPrototypeOf(value) === proto;
  } catch (_) {
    return false;
  }
}
function isJsonRpcServerError(code) {
  return code >= -32099 && code <= -32e3;
}
function isJsonRpcError(value) {
  const castValue = value;
  if (!castValue) return false;
  if (!isValidCode(castValue.code) || !isValidString(castValue.message)) return false;
  if (castValue.stack && !isValidString(castValue.stack)) return false;
  return true;
}
function getMessageFromCode(code, fallbackMessage = FALLBACK_MESSAGE) {
  if (isValidCode(code)) {
    const codeString = code.toString();
    if (Object.hasOwn(errorValues, codeString)) {
      return errorValues[codeString].message;
    }
    if (isJsonRpcServerError(code)) {
      return JSON_RPC_SERVER_ERROR_MESSAGE;
    }
  }
  return fallbackMessage;
}
const FALLBACK_ERROR = {
  code: FALLBACK_ERROR_CODE,
  message: getMessageFromCode(FALLBACK_ERROR_CODE)
};
function isValidJson(str) {
  try {
    JSON.parse(JSON.stringify(str, (strKey, strVal) => {
      if (strKey === "__proto__" || strKey === "constructor") {
        throw new Error("Not valid json");
      }
      if (typeof strVal === "function" || typeof strVal === "symbol") {
        throw new Error("Not valid json");
      }
      return strVal;
    }), (propKey, propValue) => {
      if (propKey === "__proto__" || propKey === "constructor") {
        return void 0;
      }
      return propValue;
    });
  } catch (e) {
    return false;
  }
  return true;
}
function serializeObject(object) {
  return Object.getOwnPropertyNames(object).reduce((acc, key) => {
    const value = object[key];
    if (isValidJson(value)) {
      acc[key] = value;
    }
    return acc;
  }, {});
}
function serializeCause(error) {
  if (Array.isArray(error)) {
    return error.map((entry) => {
      if (isValidJson(entry)) {
        return entry;
      } else if (isObject(entry)) {
        return serializeObject(entry);
      }
      return null;
    });
  } else if (isObject(error)) {
    return serializeObject(error);
  }
  if (isValidJson(error)) {
    return error;
  }
  return null;
}
function buildError(error, fallbackError) {
  if (error && typeof error === "object" && "serialize" in error && typeof error.serialize === "function") {
    return error.serialize();
  }
  if (isJsonRpcError(error)) {
    return error;
  }
  const cause = serializeCause(error);
  const fallbackWithCause = _objectSpread2(_objectSpread2({}, fallbackError), {}, {
    data: {
      cause
    }
  });
  return fallbackWithCause;
}
function serializeError(error, {
  fallbackError = FALLBACK_ERROR,
  shouldIncludeStack = true
} = {}) {
  if (!isJsonRpcError(fallbackError)) {
    throw new Error("Must provide fallback error with integer number code and string message.");
  }
  const serialized = buildError(error, fallbackError);
  if (!shouldIncludeStack) {
    delete serialized.stack;
  }
  return serialized;
}
function dataHasCause(data) {
  return isObject(data) && Object.hasOwn(data, "cause") && isObject(data.cause);
}
function isValidEthProviderCode(code) {
  return Number.isInteger(code) && code >= 1e3 && code <= 4999;
}
function stringifyReplacer(_, value) {
  if (value === "[Circular]") {
    return void 0;
  }
  return value;
}
class JsonRpcError extends Error {
  constructor(code, message, data) {
    if (!Number.isInteger(code)) {
      throw new Error('"code" must be an integer.');
    }
    if (!message || typeof message !== "string") {
      throw new Error('"message" must be a non-empty string.');
    }
    if (dataHasCause(data)) {
      super(message, {
        cause: data.cause
      });
      _defineProperty(this, "cause", void 0);
      _defineProperty(this, "code", void 0);
      _defineProperty(this, "data", void 0);
      if (!Object.hasOwn(this, "cause")) {
        Object.assign(this, {
          cause: data.cause
        });
      }
    } else {
      super(message);
      _defineProperty(this, "cause", void 0);
      _defineProperty(this, "code", void 0);
      _defineProperty(this, "data", void 0);
    }
    if (data !== void 0) {
      this.data = data;
    }
    this.code = code;
    this.cause = data === null || data === void 0 ? void 0 : data.cause;
  }
  /**
   * Get the error as JSON-serializable object.
   *
   * @returns A plain object with all public class properties.
   */
  serialize() {
    const serialized = {
      code: this.code,
      message: this.message
    };
    if (this.data !== void 0) {
      serialized.data = this.data;
      if (isPlainObject(this.data)) {
        serialized.data.cause = serializeCause(this.data.cause);
      }
    }
    if (this.stack) {
      serialized.stack = this.stack;
    }
    return serialized;
  }
  /**
   * Get a string representation of the serialized error, omitting any circular
   * references.
   *
   * @returns A string representation of the serialized error.
   */
  toString() {
    return stringify(this.serialize(), {
      replacer: stringifyReplacer,
      space: 2
    });
  }
}
class EthereumProviderError extends JsonRpcError {
  /**
   * Create an Ethereum Provider JSON-RPC error.
   *
   * @param code - The JSON-RPC error code. Must be an integer in the
   * `1000 <= n <= 4999` range.
   * @param message - The JSON-RPC error message.
   * @param data - Optional data to include in the error.
   */
  constructor(code, message, data) {
    if (!isValidEthProviderCode(code)) {
      throw new Error('"code" must be an integer such that: 1000 <= code <= 4999');
    }
    super(code, message, data);
  }
}
function parseOpts(arg) {
  if (arg) {
    if (typeof arg === "string") {
      return [arg];
    } else if (typeof arg === "object" && !Array.isArray(arg)) {
      const {
        message,
        data
      } = arg;
      if (message && typeof message !== "string") {
        throw new Error("Must specify string message.");
      }
      return [message !== null && message !== void 0 ? message : void 0, data];
    }
  }
  return [];
}
function getJsonRpcError(code, arg) {
  const [message, data] = parseOpts(arg);
  return new JsonRpcError(code, message !== null && message !== void 0 ? message : getMessageFromCode(code), data);
}
function getEthProviderError(code, arg) {
  const [message, data] = parseOpts(arg);
  return new EthereumProviderError(code, message !== null && message !== void 0 ? message : getMessageFromCode(code), data);
}
const rpcErrors = {
  /**
   * Get a JSON RPC 2.0 Parse (-32700) error.
   *
   * @param arg - The error message or options bag.
   * @returns An instance of the {@link JsonRpcError} class.
   */
  parse: (arg) => getJsonRpcError(errorCodes.rpc.parse, arg),
  /**
   * Get a JSON RPC 2.0 Invalid Request (-32600) error.
   *
   * @param arg - The error message or options bag.
   * @returns An instance of the {@link JsonRpcError} class.
   */
  invalidRequest: (arg) => getJsonRpcError(errorCodes.rpc.invalidRequest, arg),
  /**
   * Get a JSON RPC 2.0 Invalid Params (-32602) error.
   *
   * @param arg - The error message or options bag.
   * @returns An instance of the {@link JsonRpcError} class.
   */
  invalidParams: (arg) => getJsonRpcError(errorCodes.rpc.invalidParams, arg),
  /**
   * Get a JSON RPC 2.0 Method Not Found (-32601) error.
   *
   * @param arg - The error message or options bag.
   * @returns An instance of the {@link JsonRpcError} class.
   */
  methodNotFound: (arg) => getJsonRpcError(errorCodes.rpc.methodNotFound, arg),
  /**
   * Get a JSON RPC 2.0 Internal (-32603) error.
   *
   * @param arg - The error message or options bag.
   * @returns An instance of the {@link JsonRpcError} class.
   */
  internal: (arg) => getJsonRpcError(errorCodes.rpc.internal, arg),
  /**
   * Get a JSON RPC 2.0 Server error.
   * Permits integer error codes in the [ -32099 <= -32005 ] range.
   * Codes -32000 through -32004 are reserved by EIP-1474.
   *
   * @param opts - The error options bag.
   * @returns An instance of the {@link JsonRpcError} class.
   */
  server: (opts) => {
    if (!opts || typeof opts !== "object" || Array.isArray(opts)) {
      throw new Error("Ethereum RPC Server errors must provide single object argument.");
    }
    const {
      code
    } = opts;
    if (!Number.isInteger(code) || code > -32005 || code < -32099) {
      throw new Error('"code" must be an integer such that: -32099 <= code <= -32005');
    }
    return getJsonRpcError(code, opts);
  },
  /**
   * Get an Ethereum JSON RPC Invalid Input (-32000) error.
   *
   * @param arg - The error message or options bag.
   * @returns An instance of the {@link JsonRpcError} class.
   */
  invalidInput: (arg) => getJsonRpcError(errorCodes.rpc.invalidInput, arg),
  /**
   * Get an Ethereum JSON RPC Resource Not Found (-32001) error.
   *
   * @param arg - The error message or options bag.
   * @returns An instance of the {@link JsonRpcError} class.
   */
  resourceNotFound: (arg) => getJsonRpcError(errorCodes.rpc.resourceNotFound, arg),
  /**
   * Get an Ethereum JSON RPC Resource Unavailable (-32002) error.
   *
   * @param arg - The error message or options bag.
   * @returns An instance of the {@link JsonRpcError} class.
   */
  resourceUnavailable: (arg) => getJsonRpcError(errorCodes.rpc.resourceUnavailable, arg),
  /**
   * Get an Ethereum JSON RPC Transaction Rejected (-32003) error.
   *
   * @param arg - The error message or options bag.
   * @returns An instance of the {@link JsonRpcError} class.
   */
  transactionRejected: (arg) => getJsonRpcError(errorCodes.rpc.transactionRejected, arg),
  /**
   * Get an Ethereum JSON RPC Method Not Supported (-32004) error.
   *
   * @param arg - The error message or options bag.
   * @returns An instance of the {@link JsonRpcError} class.
   */
  methodNotSupported: (arg) => getJsonRpcError(errorCodes.rpc.methodNotSupported, arg),
  /**
   * Get an Ethereum JSON RPC Limit Exceeded (-32005) error.
   *
   * @param arg - The error message or options bag.
   * @returns An instance of the {@link JsonRpcError} class.
   */
  limitExceeded: (arg) => getJsonRpcError(errorCodes.rpc.limitExceeded, arg)
};
const providerErrors = {
  /**
   * Get an Ethereum Provider User Rejected Request (4001) error.
   *
   * @param arg - The error message or options bag.
   * @returns An instance of the {@link EthereumProviderError} class.
   */
  userRejectedRequest: (arg) => {
    return getEthProviderError(errorCodes.provider.userRejectedRequest, arg);
  },
  /**
   * Get an Ethereum Provider Unauthorized (4100) error.
   *
   * @param arg - The error message or options bag.
   * @returns An instance of the {@link EthereumProviderError} class.
   */
  unauthorized: (arg) => {
    return getEthProviderError(errorCodes.provider.unauthorized, arg);
  },
  /**
   * Get an Ethereum Provider Unsupported Method (4200) error.
   *
   * @param arg - The error message or options bag.
   * @returns An instance of the {@link EthereumProviderError} class.
   */
  unsupportedMethod: (arg) => {
    return getEthProviderError(errorCodes.provider.unsupportedMethod, arg);
  },
  /**
   * Get an Ethereum Provider Not Connected (4900) error.
   *
   * @param arg - The error message or options bag.
   * @returns An instance of the {@link EthereumProviderError} class.
   */
  disconnected: (arg) => {
    return getEthProviderError(errorCodes.provider.disconnected, arg);
  },
  /**
   * Get an Ethereum Provider Chain Not Connected (4901) error.
   *
   * @param arg - The error message or options bag.
   * @returns An instance of the {@link EthereumProviderError} class.
   */
  chainDisconnected: (arg) => {
    return getEthProviderError(errorCodes.provider.chainDisconnected, arg);
  },
  /**
   * Get a custom Ethereum Provider error.
   *
   * @param opts - The error options bag.
   * @returns An instance of the {@link EthereumProviderError} class.
   */
  custom: (opts) => {
    if (!opts || typeof opts !== "object" || Array.isArray(opts)) {
      throw new Error("Ethereum Provider custom errors must provide single object argument.");
    }
    const {
      code,
      message,
      data
    } = opts;
    if (!message || typeof message !== "string") {
      throw new Error('"message" must be a nonempty string');
    }
    return new EthereumProviderError(code, message, data);
  }
};
function createAsyncMiddleware(asyncMiddleware) {
  return async (req, res, next, end) => {
    let resolveNextPromise;
    const nextPromise = new Promise((resolve) => {
      resolveNextPromise = resolve;
    });
    let returnHandlerCallback = null;
    let nextWasCalled = false;
    const asyncNext = async () => {
      nextWasCalled = true;
      next((runReturnHandlersCallback) => {
        returnHandlerCallback = runReturnHandlersCallback;
        resolveNextPromise();
      });
      await nextPromise;
    };
    try {
      await asyncMiddleware(req, res, asyncNext);
      if (nextWasCalled) {
        await nextPromise;
        returnHandlerCallback(null);
      } else {
        end(null);
      }
    } catch (err) {
      const error = err;
      if (returnHandlerCallback) {
        returnHandlerCallback(error);
      } else {
        end(error);
      }
    }
  };
}
function constructFallbackError(error) {
  const {
    message = "",
    code = -32603,
    stack = "Stack trace is not available.",
    data = ""
  } = error;
  const codeNumber = parseInt((code === null || code === void 0 ? void 0 : code.toString()) || "-32603");
  return {
    message: message || (error === null || error === void 0 ? void 0 : error.toString()) || getMessageFromCode(codeNumber),
    code: codeNumber,
    stack,
    data: data || message || (error === null || error === void 0 ? void 0 : error.toString())
  };
}
class JRPCEngine extends SafeEventEmitter {
  constructor() {
    super();
    _defineProperty(this, "_middleware", void 0);
    this._middleware = [];
  }
  /**
   * Serially executes the given stack of middleware.
   *
   * @returns An array of any error encountered during middleware execution,
   * a boolean indicating whether the request was completed, and an array of
   * middleware-defined return handlers.
   */
  static async _runAllMiddleware(req, res, middlewareStack) {
    const returnHandlers = [];
    let error = null;
    let isComplete = false;
    for (const middleware of middlewareStack) {
      [error, isComplete] = await JRPCEngine._runMiddleware(req, res, middleware, returnHandlers);
      if (isComplete) {
        break;
      }
    }
    return [error, isComplete, returnHandlers.reverse()];
  }
  /**
   * Runs an individual middleware.
   *
   * @returns An array of any error encountered during middleware execution,
   * and a boolean indicating whether the request should end.
   */
  static _runMiddleware(req, res, middleware, returnHandlers) {
    return new Promise((resolve) => {
      const end = (err) => {
        const error = err || res.error;
        if (error) {
          if (typeof error === "object" && Object.keys(error).includes("stack") === false) error.stack = "Stack trace is not available.";
          loglevel.error(error);
          res.error = serializeError(error, {
            shouldIncludeStack: true,
            fallbackError: constructFallbackError(error)
          });
        }
        resolve([error, true]);
      };
      const next = (returnHandler) => {
        if (res.error) {
          end(res.error);
        } else {
          if (returnHandler) {
            if (typeof returnHandler !== "function") {
              end(new SerializableError({
                code: -32603,
                message: "JRPCEngine: 'next' return handlers must be functions"
              }));
            }
            returnHandlers.push(returnHandler);
          }
          resolve([null, false]);
        }
      };
      try {
        middleware(req, res, next, end);
      } catch (error) {
        end(error);
      }
    });
  }
  /**
   * Serially executes array of return handlers. The request and response are
   * assumed to be in their scope.
   */
  static async _runReturnHandlers(handlers) {
    for (const handler of handlers) {
      await new Promise((resolve, reject) => {
        handler((err) => err ? reject(err) : resolve());
      });
    }
  }
  /**
   * Throws an error if the response has neither a result nor an error, or if
   * the "isComplete" flag is falsy.
   */
  static _checkForCompletion(_req, res, isComplete) {
    if (!("result" in res) && !("error" in res)) {
      throw new SerializableError({
        code: -32603,
        message: "Response has no error or result for request"
      });
    }
    if (!isComplete) {
      throw new SerializableError({
        code: -32603,
        message: "Nothing ended request"
      });
    }
  }
  /**
   * Add a middleware function to the engine's middleware stack.
   *
   * @param middleware - The middleware function to add.
   */
  push(middleware) {
    this._middleware.push(middleware);
  }
  /**
   * Handle a JSON-RPC request, and return a response.
   *
   * @param request - The request to handle.
   * @param callback - An error-first callback that will receive the response.
   */
  /**
   * Handle an array of JSON-RPC requests, and return an array of responses.
   *
   * @param request - The requests to handle.
   * @param callback - An error-first callback that will receive the array of
   * responses.
   */
  /**
   * Handle a JSON-RPC request, and return a response.
   *
   * @param request - The request to handle.
   * @returns A promise that resolves with the response, or rejects with an
   * error.
   */
  /**
   * Handle an array of JSON-RPC requests, and return an array of responses.
   *
   * @param request - The requests to handle.
   * @returns A promise that resolves with the array of responses, or rejects
   * with an error.
   */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  handle(req, cb) {
    if (cb && typeof cb !== "function") {
      throw new Error('"callback" must be a function if provided.');
    }
    if (Array.isArray(req)) {
      if (cb) {
        return this._handleBatch(req, cb);
      }
      return this._handleBatch(req);
    }
    if (cb) {
      return this._handle(req, cb);
    }
    return this._promiseHandle(req);
  }
  /**
   * Returns this engine as a middleware function that can be pushed to other
   * engines.
   *
   * @returns This engine as a middleware function.
   */
  asMiddleware() {
    return async (req, res, next, end) => {
      try {
        const [middlewareError, isComplete, returnHandlers] = await JRPCEngine._runAllMiddleware(req, res, this._middleware);
        if (isComplete) {
          await JRPCEngine._runReturnHandlers(returnHandlers);
          return end(middlewareError);
        }
        return next(async (handlerCallback) => {
          try {
            await JRPCEngine._runReturnHandlers(returnHandlers);
          } catch (error) {
            return handlerCallback(error);
          }
          return handlerCallback();
        });
      } catch (error) {
        return end(error);
      }
    };
  }
  /**
   * Like _handle, but for batch requests.
   */
  /**
   * Like _handle, but for batch requests.
   */
  async _handleBatch(reqs, cb) {
    try {
      const responses = await Promise.all(
        // 1. Begin executing each request in the order received
        reqs.map(this._promiseHandle.bind(this))
      );
      if (cb) {
        return cb(null, responses);
      }
      return responses;
    } catch (error) {
      if (cb) {
        return cb(error);
      }
      throw error;
    }
  }
  /**
   * A promise-wrapped _handle.
   */
  _promiseHandle(req) {
    return new Promise((resolve, reject) => {
      this._handle(req, (_err, res) => {
        if (_err && res === void 0) {
          reject(_err);
        } else resolve(res);
      }).catch(reject);
    });
  }
  /**
   * Ensures that the request object is valid, processes it, and passes any
   * error and the response object to the given callback.
   *
   * Does not reject.
   */
  async _handle(callerReq, cb) {
    if (!callerReq || Array.isArray(callerReq) || typeof callerReq !== "object") {
      const error2 = new SerializableError({
        code: -32603,
        message: "request must be plain object"
      });
      return cb(error2, {
        id: void 0,
        jsonrpc: "2.0",
        error: error2
      });
    }
    if (typeof callerReq.method !== "string") {
      const error2 = new SerializableError({
        code: -32603,
        message: "method must be string"
      });
      return cb(error2, {
        id: callerReq.id,
        jsonrpc: "2.0",
        error: error2
      });
    }
    const req = _objectSpread2({}, callerReq);
    const res = {
      id: req.id,
      jsonrpc: req.jsonrpc
    };
    let error = null;
    try {
      await this._processRequest(req, res);
    } catch (_error) {
      error = _error;
    }
    if (error) {
      delete res.result;
      if (!res.error) {
        if (typeof error === "object" && Object.keys(error).includes("stack") === false) error.stack = "Stack trace is not available.";
        loglevel.error(error);
        res.error = serializeError(error, {
          shouldIncludeStack: true,
          fallbackError: constructFallbackError(error)
        });
      }
    }
    return cb(error, res);
  }
  /**
   * For the given request and response, runs all middleware and their return
   * handlers, if any, and ensures that internal request processing semantics
   * are satisfied.
   */
  async _processRequest(req, res) {
    const [error, isComplete, returnHandlers] = await JRPCEngine._runAllMiddleware(req, res, this._middleware);
    JRPCEngine._checkForCompletion(req, res, isComplete);
    await JRPCEngine._runReturnHandlers(returnHandlers);
    if (error) {
      throw error;
    }
  }
}
function mergeMiddleware(middlewareStack) {
  const engine = new JRPCEngine();
  middlewareStack.forEach((middleware) => {
    engine.push(middleware);
  });
  return engine.asMiddleware();
}
function providerFromEngine(engine) {
  const provider = new SafeEventEmitter();
  provider.sendAsync = async (req) => {
    const res = await engine.handle(req);
    if (res.error) {
      if (typeof res.error === "object" && Object.keys(res.error).includes("stack") === false) res.error.stack = "Stack trace is not available.";
      loglevel.error(res.error);
      const err = serializeError(res.error, {
        fallbackError: constructFallbackError(res.error),
        shouldIncludeStack: true
      });
      throw rpcErrors.internal(err);
    }
    return res.result;
  };
  provider.send = (req, callback) => {
    if (typeof callback !== "function") {
      throw new Error('Must provide callback to "send" method.');
    }
    engine.handle(req, callback);
  };
  if (engine.on) {
    engine.on("notification", (message) => {
      provider.emit("data", null, message);
    });
  }
  provider.request = async (args) => {
    const req = _objectSpread2(_objectSpread2({}, args), {}, {
      id: Math.random().toString(36).slice(2),
      jsonrpc: "2.0"
    });
    const res = await provider.sendAsync(req);
    return res;
  };
  return provider;
}
class BaseController extends SafeEventEmitter {
  /**
   * Creates a BaseController instance. Both initial state and initial
   * configuration options are merged with defaults upon initialization.
   *
   * @param config - Initial options used to configure this controller
   * @param state - Initial state to set on this controller
   */
  constructor({
    config = {},
    state: state2 = {}
  }) {
    super();
    _defineProperty(this, "defaultConfig", {});
    _defineProperty(this, "defaultState", {});
    _defineProperty(this, "disabled", false);
    _defineProperty(this, "name", "BaseController");
    _defineProperty(this, "initialConfig", void 0);
    _defineProperty(this, "initialState", void 0);
    _defineProperty(this, "internalConfig", this.defaultConfig);
    _defineProperty(this, "internalState", this.defaultState);
    this.initialState = state2;
    this.initialConfig = config;
  }
  /**
   * Retrieves current controller configuration options
   *
   * @returns - Current configuration
   */
  get config() {
    return this.internalConfig;
  }
  /**
   * Retrieves current controller state
   *
   * @returns - Current state
   */
  get state() {
    return this.internalState;
  }
  /**
   * Updates controller configuration
   *
   * @param config - New configuration options
   * @param overwrite - Overwrite config instead of merging
   * @param fullUpdate - Boolean that defines if the update is partial or not
   */
  configure(config, overwrite = false, fullUpdate = true) {
    if (fullUpdate) {
      this.internalConfig = overwrite ? config : Object.assign(this.internalConfig, config);
      for (const key in this.internalConfig) {
        if (typeof this.internalConfig[key] !== "undefined") {
          this[key] = this.internalConfig[key];
        }
      }
    } else {
      for (const key in config) {
        if (typeof this.internalConfig[key] !== "undefined") {
          this.internalConfig[key] = config[key];
          this[key] = config[key];
        }
      }
    }
  }
  /**
   * Updates controller state
   *
   * @param state - New state
   * @param overwrite - Overwrite state instead of merging
   */
  update(state2, overwrite = false) {
    this.internalState = overwrite ? _objectSpread2({}, state2) : _objectSpread2(_objectSpread2({}, this.internalState), state2);
    this.emit("store", this.internalState);
  }
  /**
   * Enables the controller. This sets each config option as a member
   * variable on this instance and triggers any defined setters. This
   * also sets initial state and triggers any listeners.
   *
   * @returns - This controller instance
   */
  initialize() {
    this.internalState = this.defaultState;
    this.internalConfig = this.defaultConfig;
    this.configure(this.initialConfig);
    this.update(this.initialState);
    return this;
  }
}
const filterNoop = () => true;
const internalEvents = ["newListener", "removeListener"];
const externalEventFilter = (name) => !internalEvents.includes(name);
function getRawListeners(eventEmitter, name) {
  return typeof eventEmitter.rawListeners !== "undefined" ? eventEmitter.rawListeners(name) : eventEmitter.listeners(name);
}
function createEventEmitterProxy(initialTarget, opts) {
  const finalOpts = {};
  let eventFilter = finalOpts.eventFilter || filterNoop;
  if (typeof eventFilter === "string" && eventFilter === "skipInternal") eventFilter = externalEventFilter;
  if (typeof eventFilter !== "function") throw new Error("createEventEmitterProxy - Invalid eventFilter");
  let target = initialTarget;
  let setTarget = (newTarget) => {
    if (target === newTarget) return;
    const oldTarget = target;
    target = newTarget;
    const eventNames2 = oldTarget.eventNames();
    eventNames2.filter(eventFilter).forEach((name) => {
      getRawListeners(oldTarget, name).forEach((handler) => {
        newTarget.on(name, handler);
      });
    });
    oldTarget.removeAllListeners();
  };
  const proxy = new Proxy({}, {
    get: (_, name) => {
      if (name === "setTarget") return setTarget;
      return target[name];
    },
    set: (_, name, value) => {
      if (name === "setTarget") {
        setTarget = value;
        return true;
      }
      target[name] = value;
      return true;
    },
    has: (_, key) => {
      if (key[0] === "_") {
        return false;
      }
      return key in target;
    }
  });
  return proxy;
}
const RETRIABLE_ERRORS = [
  // ignore server overload errors
  "Gateway timeout",
  "ETIMEDOUT",
  // ignore server sent html error pages
  // or truncated json responses
  "failed to parse response body",
  // ignore errors where http req failed to establish
  "Failed to fetch"
];
function checkForHttpErrors(fetchRes) {
  switch (fetchRes.status) {
    case 405:
      throw rpcErrors.methodNotFound();
    case 418:
      throw rpcErrors.internal({
        message: `Request is being rate limited.`,
        data: {
          cause: fetchRes
        }
      });
    case 503:
    case 504:
      throw rpcErrors.internal({
        message: `Gateway timeout. The request took too long to process.This can happen when querying over too wide a block range.`,
        data: {
          cause: fetchRes
        }
      });
  }
}
function timeout(duration) {
  return new Promise((resolve) => {
    setTimeout(resolve, duration);
  });
}
function parseResponse(fetchRes, body) {
  if (fetchRes.status !== 200) {
    throw rpcErrors.internal({
      message: `Non-200 status code: '${fetchRes.status}'`,
      data: body
    });
  }
  if (body.error) {
    var _body$error;
    throw rpcErrors.internal({
      data: body.error,
      message: (_body$error = body.error) === null || _body$error === void 0 ? void 0 : _body$error.message
    });
  }
  return body.result;
}
function createFetchConfigFromReq({
  req,
  rpcTarget,
  originHttpHeaderKey
}) {
  const parsedUrl = new URL(rpcTarget);
  const payload = {
    id: req.id,
    jsonrpc: req.jsonrpc,
    method: req.method,
    params: req.params
  };
  const originDomain = req.origin;
  const serializedPayload = JSON.stringify(payload);
  const fetchParams = {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json"
    },
    body: serializedPayload
  };
  if (originHttpHeaderKey && originDomain) {
    fetchParams.headers[originHttpHeaderKey] = originDomain;
  }
  return {
    fetchUrl: parsedUrl.href,
    fetchParams
  };
}
function createFetchMiddleware({
  rpcTarget,
  originHttpHeaderKey
}) {
  return createAsyncMiddleware(async (req, res, _next) => {
    const {
      fetchUrl,
      fetchParams
    } = createFetchConfigFromReq({
      req,
      rpcTarget,
      originHttpHeaderKey
    });
    const maxAttempts = 5;
    const retryInterval = 1e3;
    for (let attempt = 0; attempt < maxAttempts; attempt++) {
      try {
        const fetchRes = await fetch(fetchUrl, fetchParams);
        checkForHttpErrors(fetchRes);
        const fetchBody = await fetchRes.json();
        const result = parseResponse(fetchRes, fetchBody);
        res.result = result;
        return;
      } catch (err) {
        const errMsg = (err.message || err).toString();
        const isRetriable = RETRIABLE_ERRORS.some((phrase) => errMsg.includes(phrase));
        if (!isRetriable) {
          throw err;
        }
      }
      await timeout(retryInterval);
    }
  });
}
class BaseProvider extends BaseController {
  constructor({
    config,
    state: state2
  }) {
    super({
      config,
      state: state2
    });
    _defineProperty(this, "_providerEngineProxy", null);
    _defineProperty(this, "keyExportFlagSetByCode", false);
    if (!config.chainConfig) throw WalletInitializationError.invalidProviderConfigError("Please provide chainConfig");
    if (!config.chainConfig.chainId) throw WalletInitializationError.invalidProviderConfigError("Please provide chainId inside chainConfig");
    if (!config.chainConfig.rpcTarget) throw WalletInitializationError.invalidProviderConfigError("Please provide rpcTarget inside chainConfig");
    if (typeof config.keyExportEnabled === "boolean") this.keyExportFlagSetByCode = true;
    this.defaultState = {
      chainId: "loading"
    };
    this.defaultConfig = {
      chainConfig: config.chainConfig,
      networks: {
        [config.chainConfig.chainId]: config.chainConfig
      },
      keyExportEnabled: typeof config.keyExportEnabled === "boolean" ? config.keyExportEnabled : true
    };
    super.initialize();
  }
  get currentChainConfig() {
    return this.config.chainConfig;
  }
  get provider() {
    return this._providerEngineProxy;
  }
  get chainId() {
    return this.state.chainId;
  }
  set provider(_) {
    throw new Error("Method not implemented.");
  }
  async request(args) {
    var _this$provider;
    if (!args || typeof args !== "object" || Array.isArray(args)) {
      throw rpcErrors.invalidRequest({
        message: WalletProviderError.invalidRequestArgs().message,
        data: _objectSpread2(_objectSpread2({}, args || {}), {}, {
          cause: WalletProviderError.invalidRequestArgs().message
        })
      });
    }
    const {
      method,
      params
    } = args;
    if (typeof method !== "string" || method.length === 0) {
      throw rpcErrors.invalidRequest({
        message: WalletProviderError.invalidRequestMethod().message,
        data: _objectSpread2(_objectSpread2({}, args || {}), {}, {
          cause: WalletProviderError.invalidRequestMethod().message
        })
      });
    }
    if (params !== void 0 && !Array.isArray(params) && (typeof params !== "object" || params === null)) {
      throw rpcErrors.invalidRequest({
        message: WalletProviderError.invalidRequestParams().message,
        data: _objectSpread2(_objectSpread2({}, args || {}), {}, {
          cause: WalletProviderError.invalidRequestParams().message
        })
      });
    }
    return (_this$provider = this.provider) === null || _this$provider === void 0 ? void 0 : _this$provider.request(args);
  }
  sendAsync(req, callback) {
    if (callback) return this.send(req, callback);
    return this.request(req);
  }
  send(req, callback) {
    this.request(req).then((res) => callback(null, {
      result: res
    })).catch((err) => callback(err, null));
  }
  addChain(chainConfig) {
    if (!chainConfig.chainId) throw rpcErrors.invalidParams("chainId is required");
    if (!chainConfig.rpcTarget) throw rpcErrors.invalidParams("chainId is required");
    this.configure({
      networks: _objectSpread2(_objectSpread2({}, this.config.networks), {}, {
        [chainConfig.chainId]: chainConfig
      })
    });
  }
  getChainConfig(chainId) {
    var _this$config$networks;
    const chainConfig = (_this$config$networks = this.config.networks) === null || _this$config$networks === void 0 ? void 0 : _this$config$networks[chainId];
    if (!chainConfig) throw rpcErrors.invalidRequest(`Chain ${chainId} is not supported, please add chainConfig for it`);
    return chainConfig;
  }
  updateProviderEngineProxy(provider) {
    if (this._providerEngineProxy) {
      this._providerEngineProxy.setTarget(provider);
    } else {
      this._providerEngineProxy = createEventEmitterProxy(provider);
    }
  }
  setKeyExportFlag(flag) {
    if (!this.keyExportFlagSetByCode) {
      this.configure({
        keyExportEnabled: flag
      });
    }
  }
  getProviderEngineProxy() {
    return this._providerEngineProxy;
  }
}
export {
  ADAPTER_NAMESPACES as A,
  BaseProvider as B,
  CHAIN_NAMESPACES as C,
  JRPCEngine as J,
  SafeEventEmitter as S,
  WalletInitializationError as W,
  _objectSpread2 as _,
  loglevelExports as a,
  _defineProperty as b,
  CustomError as c,
  loglevel as d,
  eventsExports as e,
  WalletLoginError as f,
  WalletOperationsError as g,
  Web3AuthError as h,
  createFetchMiddleware as i,
  providerErrors as j,
  createEventEmitterProxy as k,
  log as l,
  mergeMiddleware as m,
  createAsyncMiddleware as n,
  providerFromEngine as p,
  rpcErrors as r
};
//# sourceMappingURL=baseProvider-B6r4upIP.js.map
