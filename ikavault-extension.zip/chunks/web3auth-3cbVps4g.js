const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["chunks/index-DHrCUe9G.js","chunks/baseProvider-B6r4upIP.js","chunks/_commonjsHelpers-3KnhdHPJ.js","chunks/index-kAnL5Ffb.js","chunks/preload-helper-CmrIWoG2.js","popup.js","assets/popup-DYtoqx_J.css","chunks/index-ZwUBWNbU.js","chunks/index.browser.esm-ClyEp6ip.js"])))=>i.map(i=>d[i]);
import { _ as __vitePreload } from "./preload-helper-CmrIWoG2.js";
const WEB3AUTH_CLIENT_ID = "BO9PskrPIRkdZfOgstbTw2bsqFOxtbWzHw6N5inkdClSP6SBaV6-4B2ferN2ncE_tLW332v0YKfruLY4Nv9Enno";
const SOLANA_DEVNET_CHAIN_CONFIG = {
  chainNamespace: "solana",
  chainId: "0x3",
  // devnet
  rpcTarget: "https://api.devnet.solana.com",
  displayName: "Solana Devnet",
  blockExplorer: "https://explorer.solana.com",
  ticker: "SOL",
  tickerName: "Solana"
};
let web3authInstance = null;
async function initWeb3Auth() {
  const { Web3Auth } = await __vitePreload(async () => {
    const { Web3Auth: Web3Auth2 } = await import("./index-DHrCUe9G.js");
    return { Web3Auth: Web3Auth2 };
  }, true ? __vite__mapDeps([0,1,2,3,4,5,6]) : void 0);
  const { SolanaPrivateKeyProvider } = await __vitePreload(async () => {
    const { SolanaPrivateKeyProvider: SolanaPrivateKeyProvider2 } = await import("./index-ZwUBWNbU.js");
    return { SolanaPrivateKeyProvider: SolanaPrivateKeyProvider2 };
  }, true ? __vite__mapDeps([7,1,2,3,8]) : void 0);
  const privateKeyProvider = new SolanaPrivateKeyProvider({
    config: { chainConfig: SOLANA_DEVNET_CHAIN_CONFIG }
  });
  const web3auth = new Web3Auth({
    clientId: WEB3AUTH_CLIENT_ID,
    web3AuthNetwork: "sapphire_devnet",
    privateKeyProvider
  });
  await web3auth.initModal();
  web3authInstance = web3auth;
}
async function loginWithGoogle() {
  if (!web3authInstance) {
    await initWeb3Auth();
  }
  const { Web3Auth } = await __vitePreload(async () => {
    const { Web3Auth: Web3Auth2 } = await import("./index-DHrCUe9G.js");
    return { Web3Auth: Web3Auth2 };
  }, true ? __vite__mapDeps([0,1,2,3,4,5,6]) : void 0);
  const web3auth = web3authInstance;
  await web3auth.connect();
  const userInfo = await web3auth.getUserInfo();
  const solanaProvider = web3auth.provider;
  if (!solanaProvider) {
    throw new Error("Web3Auth provider not available after login");
  }
  const { PublicKey } = await __vitePreload(async () => {
    const { PublicKey: PublicKey2 } = await import("./index.browser.esm-ClyEp6ip.js").then((n) => n.i);
    return { PublicKey: PublicKey2 };
  }, true ? __vite__mapDeps([8,3,2]) : void 0);
  const accounts = await solanaProvider.request({ method: "getAccounts" });
  const publicKey = (accounts == null ? void 0 : accounts[0]) ?? "";
  new PublicKey(publicKey);
  return {
    status: "authenticated",
    publicKey,
    displayName: userInfo.name ?? void 0,
    profilePicture: userInfo.profileImage ?? void 0
  };
}
function getSolanaProvider() {
  if (!web3authInstance) return null;
  return web3authInstance.provider ?? null;
}
async function logout() {
  if (!web3authInstance) return;
  const { Web3Auth } = await __vitePreload(async () => {
    const { Web3Auth: Web3Auth2 } = await import("./index-DHrCUe9G.js");
    return { Web3Auth: Web3Auth2 };
  }, true ? __vite__mapDeps([0,1,2,3,4,5,6]) : void 0);
  const web3auth = web3authInstance;
  await web3auth.logout();
  web3authInstance = null;
}
async function getAuthStatus() {
  var _a;
  if (!web3authInstance) {
    return { status: "unauthenticated" };
  }
  const { Web3Auth } = await __vitePreload(async () => {
    const { Web3Auth: Web3Auth2 } = await import("./index-DHrCUe9G.js");
    return { Web3Auth: Web3Auth2 };
  }, true ? __vite__mapDeps([0,1,2,3,4,5,6]) : void 0);
  const web3auth = web3authInstance;
  if (web3auth.status === "connected") {
    const userInfo = await web3auth.getUserInfo();
    const accounts = await ((_a = web3auth.provider) == null ? void 0 : _a.request({ method: "getAccounts" }));
    return {
      status: "authenticated",
      publicKey: (accounts == null ? void 0 : accounts[0]) ?? void 0,
      displayName: userInfo.name ?? void 0,
      profilePicture: userInfo.profileImage ?? void 0
    };
  }
  return { status: "unauthenticated" };
}
async function signTransaction(transaction) {
  if (!web3authInstance) {
    throw new Error("Web3Auth not initialized");
  }
  const { Web3Auth } = await __vitePreload(async () => {
    const { Web3Auth: Web3Auth2 } = await import("./index-DHrCUe9G.js");
    return { Web3Auth: Web3Auth2 };
  }, true ? __vite__mapDeps([0,1,2,3,4,5,6]) : void 0);
  const web3auth = web3authInstance;
  if (!web3auth.provider) {
    throw new Error("Web3Auth provider not available");
  }
  return web3auth.provider.request({
    method: "signTransaction",
    params: { message: transaction }
  });
}
export {
  getAuthStatus,
  getSolanaProvider,
  initWeb3Auth,
  loginWithGoogle,
  logout,
  signTransaction
};
//# sourceMappingURL=web3auth-3cbVps4g.js.map
