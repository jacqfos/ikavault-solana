const WALRUS_PUBLISHER = "https://publisher.walrus-testnet.walrus.space";
const WALRUS_AGGREGATOR = "https://aggregator.walrus-testnet.walrus.space";
const DEFAULT_EPOCHS = 3;
function extractBlobId(response) {
  if (response.newlyCreated) return response.newlyCreated.blobObject.blobId;
  if (response.alreadyCertified) return response.alreadyCertified.blobId;
  throw new Error("Walrus response missing blob_id");
}
async function uploadBlob(data, epochs = DEFAULT_EPOCHS) {
  const response = await fetch(
    `${WALRUS_PUBLISHER}/v1/blobs?epochs=${epochs}`,
    {
      method: "PUT",
      headers: { "Content-Type": "application/octet-stream" },
      body: data
    }
  );
  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Walrus upload failed (${response.status}): ${text}`);
  }
  const json = await response.json();
  return extractBlobId(json);
}
async function downloadBlob(blobId) {
  const response = await fetch(`${WALRUS_AGGREGATOR}/v1/blobs/${blobId}`);
  if (!response.ok) {
    throw new Error(`Walrus download failed (${response.status}): ${blobId}`);
  }
  const buffer = await response.arrayBuffer();
  return new Uint8Array(buffer);
}
async function uploadEncryptedCredential(encryptedB64) {
  const bytes = new TextEncoder().encode(encryptedB64);
  return uploadBlob(bytes);
}
async function downloadEncryptedCredential(blobId) {
  const bytes = await downloadBlob(blobId);
  return new TextDecoder().decode(bytes);
}
export {
  downloadBlob,
  downloadEncryptedCredential,
  uploadBlob,
  uploadEncryptedCredential
};
//# sourceMappingURL=walrus-DY1SrR5-.js.map
