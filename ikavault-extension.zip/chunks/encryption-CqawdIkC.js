async function deriveAesKey(keyShareB64) {
  const raw = base64ToBytes(keyShareB64);
  const hashBuffer = await crypto.subtle.digest("SHA-256", raw);
  return crypto.subtle.importKey(
    "raw",
    hashBuffer,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
}
async function encryptCredential(credential, keyShare) {
  const key = await deriveAesKey(keyShare.keyShareB64);
  const nonce = crypto.getRandomValues(new Uint8Array(12));
  const plaintext = new TextEncoder().encode(JSON.stringify(credential));
  const ciphertext = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv: nonce },
    key,
    plaintext
  );
  const packed = new Uint8Array(nonce.byteLength + ciphertext.byteLength);
  packed.set(nonce, 0);
  packed.set(new Uint8Array(ciphertext), nonce.byteLength);
  return bytesToBase64(packed);
}
async function decryptCredential(encryptedB64, keyShare) {
  const key = await deriveAesKey(keyShare.keyShareB64);
  const packed = base64ToBytes(encryptedB64);
  if (packed.length < 13) {
    throw new Error("Ciphertext too short");
  }
  const nonce = packed.slice(0, 12);
  const ciphertext = packed.slice(12);
  const plaintext = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: nonce },
    key,
    ciphertext
  );
  return JSON.parse(new TextDecoder().decode(plaintext));
}
function bytesToBase64(bytes) {
  let binary = "";
  bytes.forEach((b) => binary += String.fromCharCode(b));
  return btoa(binary);
}
function base64ToBytes(b64) {
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}
export {
  bytesToBase64 as a,
  base64ToBytes as b,
  decryptCredential as d,
  encryptCredential as e
};
//# sourceMappingURL=encryption-CqawdIkC.js.map
