import { B as Buffer, b as bnExports, a as Buffer$1, c as BN } from "./index-dYBN74QD.js";
import { i as index_browser_esm, S as SendTransactionError, b as bs58$1, P as PublicKey, a as SystemProgram, T as TransactionInstruction, c as Transaction, C as Connection } from "./index.browser.esm-0xyqW4cy.js";
import { g as getDefaultExportFromCjs, a as getAugmentedNamespace, c as commonjsGlobal$1 } from "./_commonjsHelpers-CcAunmGO.js";
const global = globalThis || void 0 || self;
var camelcase = { exports: {} };
const UPPERCASE = /[\p{Lu}]/u;
const LOWERCASE = /[\p{Ll}]/u;
const LEADING_CAPITAL = /^[\p{Lu}](?![\p{Lu}])/gu;
const IDENTIFIER = /([\p{Alpha}\p{N}_]|$)/u;
const SEPARATORS = /[_.\- ]+/;
const LEADING_SEPARATORS = new RegExp("^" + SEPARATORS.source);
const SEPARATORS_AND_IDENTIFIER = new RegExp(SEPARATORS.source + IDENTIFIER.source, "gu");
const NUMBERS_AND_IDENTIFIER = new RegExp("\\d+" + IDENTIFIER.source, "gu");
const preserveCamelCase = (string2, toLowerCase, toUpperCase) => {
  let isLastCharLower = false;
  let isLastCharUpper = false;
  let isLastLastCharUpper = false;
  for (let i = 0; i < string2.length; i++) {
    const character = string2[i];
    if (isLastCharLower && UPPERCASE.test(character)) {
      string2 = string2.slice(0, i) + "-" + string2.slice(i);
      isLastCharLower = false;
      isLastLastCharUpper = isLastCharUpper;
      isLastCharUpper = true;
      i++;
    } else if (isLastCharUpper && isLastLastCharUpper && LOWERCASE.test(character)) {
      string2 = string2.slice(0, i - 1) + "-" + string2.slice(i - 1);
      isLastLastCharUpper = isLastCharUpper;
      isLastCharUpper = false;
      isLastCharLower = true;
    } else {
      isLastCharLower = toLowerCase(character) === character && toUpperCase(character) !== character;
      isLastLastCharUpper = isLastCharUpper;
      isLastCharUpper = toUpperCase(character) === character && toLowerCase(character) !== character;
    }
  }
  return string2;
};
const preserveConsecutiveUppercase = (input, toLowerCase) => {
  LEADING_CAPITAL.lastIndex = 0;
  return input.replace(LEADING_CAPITAL, (m1) => toLowerCase(m1));
};
const postProcess = (input, toUpperCase) => {
  SEPARATORS_AND_IDENTIFIER.lastIndex = 0;
  NUMBERS_AND_IDENTIFIER.lastIndex = 0;
  return input.replace(SEPARATORS_AND_IDENTIFIER, (_, identifier) => toUpperCase(identifier)).replace(NUMBERS_AND_IDENTIFIER, (m) => toUpperCase(m));
};
const camelCase = (input, options) => {
  if (!(typeof input === "string" || Array.isArray(input))) {
    throw new TypeError("Expected the input to be `string | string[]`");
  }
  options = {
    pascalCase: false,
    preserveConsecutiveUppercase: false,
    ...options
  };
  if (Array.isArray(input)) {
    input = input.map((x) => x.trim()).filter((x) => x.length).join("-");
  } else {
    input = input.trim();
  }
  if (input.length === 0) {
    return "";
  }
  const toLowerCase = options.locale === false ? (string2) => string2.toLowerCase() : (string2) => string2.toLocaleLowerCase(options.locale);
  const toUpperCase = options.locale === false ? (string2) => string2.toUpperCase() : (string2) => string2.toLocaleUpperCase(options.locale);
  if (input.length === 1) {
    return options.pascalCase ? toUpperCase(input) : toLowerCase(input);
  }
  const hasUpperCase = input !== toLowerCase(input);
  if (hasUpperCase) {
    input = preserveCamelCase(input, toLowerCase, toUpperCase);
  }
  input = input.replace(LEADING_SEPARATORS, "");
  if (options.preserveConsecutiveUppercase) {
    input = preserveConsecutiveUppercase(input, toLowerCase);
  } else {
    input = toLowerCase(input);
  }
  if (options.pascalCase) {
    input = toUpperCase(input.charAt(0)) + input.slice(1);
  }
  return postProcess(input, toUpperCase);
};
camelcase.exports = camelCase;
camelcase.exports.default = camelCase;
var camelcaseExports = camelcase.exports;
const camelCase$1 = /* @__PURE__ */ getDefaultExportFromCjs(camelcaseExports);
var dist$1 = {};
var Layout$2 = {};
let Layout$1 = class Layout {
  constructor(span, property) {
    if (!Number.isInteger(span)) {
      throw new TypeError("span must be an integer");
    }
    this.span = span;
    this.property = property;
  }
  /** Function to create an Object into which decoded properties will
   * be written.
   *
   * Used only for layouts that {@link Layout#decode|decode} to Object
   * instances, which means:
   * * {@link Structure}
   * * {@link Union}
   * * {@link VariantLayout}
   * * {@link BitStructure}
   *
   * If left undefined the JavaScript representation of these layouts
   * will be Object instances.
   *
   * See {@link bindConstructorLayout}.
   */
  makeDestinationObject() {
    return {};
  }
  /**
   * Decode from a Buffer into an JavaScript value.
   *
   * @param {Buffer} b - the buffer from which encoded data is read.
   *
   * @param {Number} [offset] - the offset at which the encoded data
   * starts.  If absent a zero offset is inferred.
   *
   * @returns {(Number|Array|Object)} - the value of the decoded data.
   *
   * @abstract
   */
  decode(b, offset2) {
    throw new Error("Layout is abstract");
  }
  /**
   * Encode a JavaScript value into a Buffer.
   *
   * @param {(Number|Array|Object)} src - the value to be encoded into
   * the buffer.  The type accepted depends on the (sub-)type of {@link
   * Layout}.
   *
   * @param {Buffer} b - the buffer into which encoded data will be
   * written.
   *
   * @param {Number} [offset] - the offset at which the encoded data
   * starts.  If absent a zero offset is inferred.
   *
   * @returns {Number} - the number of bytes encoded, including the
   * space skipped for internal padding, but excluding data such as
   * {@link Sequence#count|lengths} when stored {@link
   * ExternalLayout|externally}.  This is the adjustment to `offset`
   * producing the offset where data for the next layout would be
   * written.
   *
   * @abstract
   */
  encode(src, b, offset2) {
    throw new Error("Layout is abstract");
  }
  /**
   * Calculate the span of a specific instance of a layout.
   *
   * @param {Buffer} b - the buffer that contains an encoded instance.
   *
   * @param {Number} [offset] - the offset at which the encoded instance
   * starts.  If absent a zero offset is inferred.
   *
   * @return {Number} - the number of bytes covered by the layout
   * instance.  If this method is not overridden in a subclass the
   * definition-time constant {@link Layout#span|span} will be
   * returned.
   *
   * @throws {RangeError} - if the length of the value cannot be
   * determined.
   */
  getSpan(b, offset2) {
    if (0 > this.span) {
      throw new RangeError("indeterminate span");
    }
    return this.span;
  }
  /**
   * Replicate the layout using a new property.
   *
   * This function must be used to get a structurally-equivalent layout
   * with a different name since all {@link Layout} instances are
   * immutable.
   *
   * **NOTE** This is a shallow copy.  All fields except {@link
   * Layout#property|property} are strictly equal to the origin layout.
   *
   * @param {String} property - the value for {@link
   * Layout#property|property} in the replica.
   *
   * @returns {Layout} - the copy with {@link Layout#property|property}
   * set to `property`.
   */
  replicate(property) {
    const rv = Object.create(this.constructor.prototype);
    Object.assign(rv, this);
    rv.property = property;
    return rv;
  }
  /**
   * Create an object from layout properties and an array of values.
   *
   * **NOTE** This function returns `undefined` if invoked on a layout
   * that does not return its value as an Object.  Objects are
   * returned for things that are a {@link Structure}, which includes
   * {@link VariantLayout|variant layouts} if they are structures, and
   * excludes {@link Union}s.  If you want this feature for a union
   * you must use {@link Union.getVariant|getVariant} to select the
   * desired layout.
   *
   * @param {Array} values - an array of values that correspond to the
   * default order for properties.  As with {@link Layout#decode|decode}
   * layout elements that have no property name are skipped when
   * iterating over the array values.  Only the top-level properties are
   * assigned; arguments are not assigned to properties of contained
   * layouts.  Any unused values are ignored.
   *
   * @return {(Object|undefined)}
   */
  fromArray(values) {
    return void 0;
  }
};
Layout$2.Layout = Layout$1;
function nameWithProperty$1(name, lo) {
  if (lo.property) {
    return name + "[" + lo.property + "]";
  }
  return name;
}
Layout$2.nameWithProperty = nameWithProperty$1;
function bindConstructorLayout(Class, layout) {
  if ("function" !== typeof Class) {
    throw new TypeError("Class must be constructor");
  }
  if (Class.hasOwnProperty("layout_")) {
    throw new Error("Class is already bound to a layout");
  }
  if (!(layout && layout instanceof Layout$1)) {
    throw new TypeError("layout must be a Layout");
  }
  if (layout.hasOwnProperty("boundConstructor_")) {
    throw new Error("layout is already bound to a constructor");
  }
  Class.layout_ = layout;
  layout.boundConstructor_ = Class;
  layout.makeDestinationObject = () => new Class();
  Object.defineProperty(Class.prototype, "encode", {
    value: function(b, offset2) {
      return layout.encode(this, b, offset2);
    },
    writable: true
  });
  Object.defineProperty(Class, "decode", {
    value: function(b, offset2) {
      return layout.decode(b, offset2);
    },
    writable: true
  });
}
Layout$2.bindConstructorLayout = bindConstructorLayout;
let ExternalLayout$1 = class ExternalLayout extends Layout$1 {
  /**
   * Return `true` iff the external layout decodes to an unsigned
   * integer layout.
   *
   * In that case it can be used as the source of {@link
   * Sequence#count|Sequence counts}, {@link Blob#length|Blob lengths},
   * or as {@link UnionLayoutDiscriminator#layout|external union
   * discriminators}.
   *
   * @abstract
   */
  isCount() {
    throw new Error("ExternalLayout is abstract");
  }
};
class GreedyCount extends ExternalLayout$1 {
  constructor(elementSpan, property) {
    if (void 0 === elementSpan) {
      elementSpan = 1;
    }
    if (!Number.isInteger(elementSpan) || 0 >= elementSpan) {
      throw new TypeError("elementSpan must be a (positive) integer");
    }
    super(-1, property);
    this.elementSpan = elementSpan;
  }
  /** @override */
  isCount() {
    return true;
  }
  /** @override */
  decode(b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    const rem = b.length - offset2;
    return Math.floor(rem / this.elementSpan);
  }
  /** @override */
  encode(src, b, offset2) {
    return 0;
  }
}
let OffsetLayout$1 = class OffsetLayout extends ExternalLayout$1 {
  constructor(layout, offset2, property) {
    if (!(layout instanceof Layout$1)) {
      throw new TypeError("layout must be a Layout");
    }
    if (void 0 === offset2) {
      offset2 = 0;
    } else if (!Number.isInteger(offset2)) {
      throw new TypeError("offset must be integer or undefined");
    }
    super(layout.span, property || layout.property);
    this.layout = layout;
    this.offset = offset2;
  }
  /** @override */
  isCount() {
    return this.layout instanceof UInt$1 || this.layout instanceof UIntBE$1;
  }
  /** @override */
  decode(b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    return this.layout.decode(b, offset2 + this.offset);
  }
  /** @override */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    return this.layout.encode(src, b, offset2 + this.offset);
  }
};
let UInt$1 = class UInt extends Layout$1 {
  constructor(span, property) {
    super(span, property);
    if (6 < this.span) {
      throw new RangeError("span must not exceed 6 bytes");
    }
  }
  /** @override */
  decode(b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    return b.readUIntLE(offset2, this.span);
  }
  /** @override */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    b.writeUIntLE(src, offset2, this.span);
    return this.span;
  }
};
let UIntBE$1 = class UIntBE extends Layout$1 {
  constructor(span, property) {
    super(span, property);
    if (6 < this.span) {
      throw new RangeError("span must not exceed 6 bytes");
    }
  }
  /** @override */
  decode(b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    return b.readUIntBE(offset2, this.span);
  }
  /** @override */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    b.writeUIntBE(src, offset2, this.span);
    return this.span;
  }
};
class Int extends Layout$1 {
  constructor(span, property) {
    super(span, property);
    if (6 < this.span) {
      throw new RangeError("span must not exceed 6 bytes");
    }
  }
  /** @override */
  decode(b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    return b.readIntLE(offset2, this.span);
  }
  /** @override */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    b.writeIntLE(src, offset2, this.span);
    return this.span;
  }
}
class IntBE extends Layout$1 {
  constructor(span, property) {
    super(span, property);
    if (6 < this.span) {
      throw new RangeError("span must not exceed 6 bytes");
    }
  }
  /** @override */
  decode(b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    return b.readIntBE(offset2, this.span);
  }
  /** @override */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    b.writeIntBE(src, offset2, this.span);
    return this.span;
  }
}
const V2E32$1 = Math.pow(2, 32);
function divmodInt64$1(src) {
  const hi32 = Math.floor(src / V2E32$1);
  const lo32 = src - hi32 * V2E32$1;
  return { hi32, lo32 };
}
function roundedInt64$1(hi32, lo32) {
  return hi32 * V2E32$1 + lo32;
}
let NearUInt64$1 = class NearUInt64 extends Layout$1 {
  constructor(property) {
    super(8, property);
  }
  /** @override */
  decode(b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    const lo32 = b.readUInt32LE(offset2);
    const hi32 = b.readUInt32LE(offset2 + 4);
    return roundedInt64$1(hi32, lo32);
  }
  /** @override */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    const split = divmodInt64$1(src);
    b.writeUInt32LE(split.lo32, offset2);
    b.writeUInt32LE(split.hi32, offset2 + 4);
    return 8;
  }
};
class NearUInt64BE extends Layout$1 {
  constructor(property) {
    super(8, property);
  }
  /** @override */
  decode(b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    const hi32 = b.readUInt32BE(offset2);
    const lo32 = b.readUInt32BE(offset2 + 4);
    return roundedInt64$1(hi32, lo32);
  }
  /** @override */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    const split = divmodInt64$1(src);
    b.writeUInt32BE(split.hi32, offset2);
    b.writeUInt32BE(split.lo32, offset2 + 4);
    return 8;
  }
}
let NearInt64$1 = class NearInt64 extends Layout$1 {
  constructor(property) {
    super(8, property);
  }
  /** @override */
  decode(b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    const lo32 = b.readUInt32LE(offset2);
    const hi32 = b.readInt32LE(offset2 + 4);
    return roundedInt64$1(hi32, lo32);
  }
  /** @override */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    const split = divmodInt64$1(src);
    b.writeUInt32LE(split.lo32, offset2);
    b.writeInt32LE(split.hi32, offset2 + 4);
    return 8;
  }
};
class NearInt64BE extends Layout$1 {
  constructor(property) {
    super(8, property);
  }
  /** @override */
  decode(b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    const hi32 = b.readInt32BE(offset2);
    const lo32 = b.readUInt32BE(offset2 + 4);
    return roundedInt64$1(hi32, lo32);
  }
  /** @override */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    const split = divmodInt64$1(src);
    b.writeInt32BE(split.hi32, offset2);
    b.writeUInt32BE(split.lo32, offset2 + 4);
    return 8;
  }
}
class Float extends Layout$1 {
  constructor(property) {
    super(4, property);
  }
  /** @override */
  decode(b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    return b.readFloatLE(offset2);
  }
  /** @override */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    b.writeFloatLE(src, offset2);
    return 4;
  }
}
class FloatBE extends Layout$1 {
  constructor(property) {
    super(4, property);
  }
  /** @override */
  decode(b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    return b.readFloatBE(offset2);
  }
  /** @override */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    b.writeFloatBE(src, offset2);
    return 4;
  }
}
class Double extends Layout$1 {
  constructor(property) {
    super(8, property);
  }
  /** @override */
  decode(b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    return b.readDoubleLE(offset2);
  }
  /** @override */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    b.writeDoubleLE(src, offset2);
    return 8;
  }
}
class DoubleBE extends Layout$1 {
  constructor(property) {
    super(8, property);
  }
  /** @override */
  decode(b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    return b.readDoubleBE(offset2);
  }
  /** @override */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    b.writeDoubleBE(src, offset2);
    return 8;
  }
}
class Sequence extends Layout$1 {
  constructor(elementLayout, count, property) {
    if (!(elementLayout instanceof Layout$1)) {
      throw new TypeError("elementLayout must be a Layout");
    }
    if (!(count instanceof ExternalLayout$1 && count.isCount() || Number.isInteger(count) && 0 <= count)) {
      throw new TypeError("count must be non-negative integer or an unsigned integer ExternalLayout");
    }
    let span = -1;
    if (!(count instanceof ExternalLayout$1) && 0 < elementLayout.span) {
      span = count * elementLayout.span;
    }
    super(span, property);
    this.elementLayout = elementLayout;
    this.count = count;
  }
  /** @override */
  getSpan(b, offset2) {
    if (0 <= this.span) {
      return this.span;
    }
    if (void 0 === offset2) {
      offset2 = 0;
    }
    let span = 0;
    let count = this.count;
    if (count instanceof ExternalLayout$1) {
      count = count.decode(b, offset2);
    }
    if (0 < this.elementLayout.span) {
      span = count * this.elementLayout.span;
    } else {
      let idx = 0;
      while (idx < count) {
        span += this.elementLayout.getSpan(b, offset2 + span);
        ++idx;
      }
    }
    return span;
  }
  /** @override */
  decode(b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    const rv = [];
    let i = 0;
    let count = this.count;
    if (count instanceof ExternalLayout$1) {
      count = count.decode(b, offset2);
    }
    while (i < count) {
      rv.push(this.elementLayout.decode(b, offset2));
      offset2 += this.elementLayout.getSpan(b, offset2);
      i += 1;
    }
    return rv;
  }
  /** Implement {@link Layout#encode|encode} for {@link Sequence}.
   *
   * **NOTE** If `src` is shorter than {@link Sequence#count|count} then
   * the unused space in the buffer is left unchanged.  If `src` is
   * longer than {@link Sequence#count|count} the unneeded elements are
   * ignored.
   *
   * **NOTE** If {@link Layout#count|count} is an instance of {@link
   * ExternalLayout} then the length of `src` will be encoded as the
   * count after `src` is encoded. */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    const elo = this.elementLayout;
    const span = src.reduce((span2, v) => {
      return span2 + elo.encode(v, b, offset2 + span2);
    }, 0);
    if (this.count instanceof ExternalLayout$1) {
      this.count.encode(src.length, b, offset2);
    }
    return span;
  }
}
let Structure$1 = class Structure extends Layout$1 {
  constructor(fields, property, decodePrefixes) {
    if (!(Array.isArray(fields) && fields.reduce((acc, v) => acc && v instanceof Layout$1, true))) {
      throw new TypeError("fields must be array of Layout instances");
    }
    if ("boolean" === typeof property && void 0 === decodePrefixes) {
      decodePrefixes = property;
      property = void 0;
    }
    for (const fd of fields) {
      if (0 > fd.span && void 0 === fd.property) {
        throw new Error("fields cannot contain unnamed variable-length layout");
      }
    }
    let span = -1;
    try {
      span = fields.reduce((span2, fd) => span2 + fd.getSpan(), 0);
    } catch (e) {
    }
    super(span, property);
    this.fields = fields;
    this.decodePrefixes = !!decodePrefixes;
  }
  /** @override */
  getSpan(b, offset2) {
    if (0 <= this.span) {
      return this.span;
    }
    if (void 0 === offset2) {
      offset2 = 0;
    }
    let span = 0;
    try {
      span = this.fields.reduce((span2, fd) => {
        const fsp = fd.getSpan(b, offset2);
        offset2 += fsp;
        return span2 + fsp;
      }, 0);
    } catch (e) {
      throw new RangeError("indeterminate span");
    }
    return span;
  }
  /** @override */
  decode(b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    const dest = this.makeDestinationObject();
    for (const fd of this.fields) {
      if (void 0 !== fd.property) {
        dest[fd.property] = fd.decode(b, offset2);
      }
      offset2 += fd.getSpan(b, offset2);
      if (this.decodePrefixes && b.length === offset2) {
        break;
      }
    }
    return dest;
  }
  /** Implement {@link Layout#encode|encode} for {@link Structure}.
   *
   * If `src` is missing a property for a member with a defined {@link
   * Layout#property|property} the corresponding region of the buffer is
   * left unmodified. */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    const firstOffset = offset2;
    let lastOffset = 0;
    let lastWrote = 0;
    for (const fd of this.fields) {
      let span = fd.span;
      lastWrote = 0 < span ? span : 0;
      if (void 0 !== fd.property) {
        const fv = src[fd.property];
        if (void 0 !== fv) {
          lastWrote = fd.encode(fv, b, offset2);
          if (0 > span) {
            span = fd.getSpan(b, offset2);
          }
        }
      }
      lastOffset = offset2;
      offset2 += span;
    }
    return lastOffset + lastWrote - firstOffset;
  }
  /** @override */
  fromArray(values) {
    const dest = this.makeDestinationObject();
    for (const fd of this.fields) {
      if (void 0 !== fd.property && 0 < values.length) {
        dest[fd.property] = values.shift();
      }
    }
    return dest;
  }
  /**
   * Get access to the layout of a given property.
   *
   * @param {String} property - the structure member of interest.
   *
   * @return {Layout} - the layout associated with `property`, or
   * undefined if there is no such property.
   */
  layoutFor(property) {
    if ("string" !== typeof property) {
      throw new TypeError("property must be string");
    }
    for (const fd of this.fields) {
      if (fd.property === property) {
        return fd;
      }
    }
  }
  /**
   * Get the offset of a structure member.
   *
   * @param {String} property - the structure member of interest.
   *
   * @return {Number} - the offset in bytes to the start of `property`
   * within the structure, or undefined if `property` is not a field
   * within the structure.  If the property is a member but follows a
   * variable-length structure member a negative number will be
   * returned.
   */
  offsetOf(property) {
    if ("string" !== typeof property) {
      throw new TypeError("property must be string");
    }
    let offset2 = 0;
    for (const fd of this.fields) {
      if (fd.property === property) {
        return offset2;
      }
      if (0 > fd.span) {
        offset2 = -1;
      } else if (0 <= offset2) {
        offset2 += fd.span;
      }
    }
  }
};
let UnionDiscriminator$1 = class UnionDiscriminator {
  constructor(property) {
    this.property = property;
  }
  /** Analog to {@link Layout#decode|Layout decode} for union discriminators.
   *
   * The implementation of this method need not reference the buffer if
   * variant information is available through other means. */
  decode() {
    throw new Error("UnionDiscriminator is abstract");
  }
  /** Analog to {@link Layout#decode|Layout encode} for union discriminators.
   *
   * The implementation of this method need not store the value if
   * variant information is maintained through other means. */
  encode() {
    throw new Error("UnionDiscriminator is abstract");
  }
};
let UnionLayoutDiscriminator$1 = class UnionLayoutDiscriminator extends UnionDiscriminator$1 {
  constructor(layout, property) {
    if (!(layout instanceof ExternalLayout$1 && layout.isCount())) {
      throw new TypeError("layout must be an unsigned integer ExternalLayout");
    }
    super(property || layout.property || "variant");
    this.layout = layout;
  }
  /** Delegate decoding to {@link UnionLayoutDiscriminator#layout|layout}. */
  decode(b, offset2) {
    return this.layout.decode(b, offset2);
  }
  /** Delegate encoding to {@link UnionLayoutDiscriminator#layout|layout}. */
  encode(src, b, offset2) {
    return this.layout.encode(src, b, offset2);
  }
};
let Union$1 = class Union extends Layout$1 {
  constructor(discr, defaultLayout, property) {
    const upv = discr instanceof UInt$1 || discr instanceof UIntBE$1;
    if (upv) {
      discr = new UnionLayoutDiscriminator$1(new OffsetLayout$1(discr));
    } else if (discr instanceof ExternalLayout$1 && discr.isCount()) {
      discr = new UnionLayoutDiscriminator$1(discr);
    } else if (!(discr instanceof UnionDiscriminator$1)) {
      throw new TypeError("discr must be a UnionDiscriminator or an unsigned integer layout");
    }
    if (void 0 === defaultLayout) {
      defaultLayout = null;
    }
    if (!(null === defaultLayout || defaultLayout instanceof Layout$1)) {
      throw new TypeError("defaultLayout must be null or a Layout");
    }
    if (null !== defaultLayout) {
      if (0 > defaultLayout.span) {
        throw new Error("defaultLayout must have constant span");
      }
      if (void 0 === defaultLayout.property) {
        defaultLayout = defaultLayout.replicate("content");
      }
    }
    let span = -1;
    if (defaultLayout) {
      span = defaultLayout.span;
      if (0 <= span && upv) {
        span += discr.layout.span;
      }
    }
    super(span, property);
    this.discriminator = discr;
    this.usesPrefixDiscriminator = upv;
    this.defaultLayout = defaultLayout;
    this.registry = {};
    let boundGetSourceVariant = this.defaultGetSourceVariant.bind(this);
    this.getSourceVariant = function(src) {
      return boundGetSourceVariant(src);
    };
    this.configGetSourceVariant = function(gsv) {
      boundGetSourceVariant = gsv.bind(this);
    };
  }
  /** @override */
  getSpan(b, offset2) {
    if (0 <= this.span) {
      return this.span;
    }
    if (void 0 === offset2) {
      offset2 = 0;
    }
    const vlo = this.getVariant(b, offset2);
    if (!vlo) {
      throw new Error("unable to determine span for unrecognized variant");
    }
    return vlo.getSpan(b, offset2);
  }
  /**
   * Method to infer a registered Union variant compatible with `src`.
   *
   * The first satisified rule in the following sequence defines the
   * return value:
   * * If `src` has properties matching the Union discriminator and
   *   the default layout, `undefined` is returned regardless of the
   *   value of the discriminator property (this ensures the default
   *   layout will be used);
   * * If `src` has a property matching the Union discriminator, the
   *   value of the discriminator identifies a registered variant, and
   *   either (a) the variant has no layout, or (b) `src` has the
   *   variant's property, then the variant is returned (because the
   *   source satisfies the constraints of the variant it identifies);
   * * If `src` does not have a property matching the Union
   *   discriminator, but does have a property matching a registered
   *   variant, then the variant is returned (because the source
   *   matches a variant without an explicit conflict);
   * * An error is thrown (because we either can't identify a variant,
   *   or we were explicitly told the variant but can't satisfy it).
   *
   * @param {Object} src - an object presumed to be compatible with
   * the content of the Union.
   *
   * @return {(undefined|VariantLayout)} - as described above.
   *
   * @throws {Error} - if `src` cannot be associated with a default or
   * registered variant.
   */
  defaultGetSourceVariant(src) {
    if (src.hasOwnProperty(this.discriminator.property)) {
      if (this.defaultLayout && src.hasOwnProperty(this.defaultLayout.property)) {
        return void 0;
      }
      const vlo = this.registry[src[this.discriminator.property]];
      if (vlo && (!vlo.layout || src.hasOwnProperty(vlo.property))) {
        return vlo;
      }
    } else {
      for (const tag in this.registry) {
        const vlo = this.registry[tag];
        if (src.hasOwnProperty(vlo.property)) {
          return vlo;
        }
      }
    }
    throw new Error("unable to infer src variant");
  }
  /** Implement {@link Layout#decode|decode} for {@link Union}.
   *
   * If the variant is {@link Union#addVariant|registered} the return
   * value is an instance of that variant, with no explicit
   * discriminator.  Otherwise the {@link Union#defaultLayout|default
   * layout} is used to decode the content. */
  decode(b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    let dest;
    const dlo = this.discriminator;
    const discr = dlo.decode(b, offset2);
    let clo = this.registry[discr];
    if (void 0 === clo) {
      let contentOffset = 0;
      clo = this.defaultLayout;
      if (this.usesPrefixDiscriminator) {
        contentOffset = dlo.layout.span;
      }
      dest = this.makeDestinationObject();
      dest[dlo.property] = discr;
      dest[clo.property] = this.defaultLayout.decode(b, offset2 + contentOffset);
    } else {
      dest = clo.decode(b, offset2);
    }
    return dest;
  }
  /** Implement {@link Layout#encode|encode} for {@link Union}.
   *
   * This API assumes the `src` object is consistent with the union's
   * {@link Union#defaultLayout|default layout}.  To encode variants
   * use the appropriate variant-specific {@link VariantLayout#encode}
   * method. */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    const vlo = this.getSourceVariant(src);
    if (void 0 === vlo) {
      const dlo = this.discriminator;
      const clo = this.defaultLayout;
      let contentOffset = 0;
      if (this.usesPrefixDiscriminator) {
        contentOffset = dlo.layout.span;
      }
      dlo.encode(src[dlo.property], b, offset2);
      return contentOffset + clo.encode(
        src[clo.property],
        b,
        offset2 + contentOffset
      );
    }
    return vlo.encode(src, b, offset2);
  }
  /** Register a new variant structure within a union.  The newly
   * created variant is returned.
   *
   * @param {Number} variant - initializer for {@link
   * VariantLayout#variant|variant}.
   *
   * @param {Layout} layout - initializer for {@link
   * VariantLayout#layout|layout}.
   *
   * @param {String} property - initializer for {@link
   * Layout#property|property}.
   *
   * @return {VariantLayout} */
  addVariant(variant, layout, property) {
    const rv = new VariantLayout$1(this, variant, layout, property);
    this.registry[variant] = rv;
    return rv;
  }
  /**
   * Get the layout associated with a registered variant.
   *
   * If `vb` does not produce a registered variant the function returns
   * `undefined`.
   *
   * @param {(Number|Buffer)} vb - either the variant number, or a
   * buffer from which the discriminator is to be read.
   *
   * @param {Number} offset - offset into `vb` for the start of the
   * union.  Used only when `vb` is an instance of {Buffer}.
   *
   * @return {({VariantLayout}|undefined)}
   */
  getVariant(vb, offset2) {
    let variant = vb;
    if (Buffer.isBuffer(vb)) {
      if (void 0 === offset2) {
        offset2 = 0;
      }
      variant = this.discriminator.decode(vb, offset2);
    }
    return this.registry[variant];
  }
};
let VariantLayout$1 = class VariantLayout extends Layout$1 {
  constructor(union2, variant, layout, property) {
    if (!(union2 instanceof Union$1)) {
      throw new TypeError("union must be a Union");
    }
    if (!Number.isInteger(variant) || 0 > variant) {
      throw new TypeError("variant must be a (non-negative) integer");
    }
    if ("string" === typeof layout && void 0 === property) {
      property = layout;
      layout = null;
    }
    if (layout) {
      if (!(layout instanceof Layout$1)) {
        throw new TypeError("layout must be a Layout");
      }
      if (null !== union2.defaultLayout && 0 <= layout.span && layout.span > union2.defaultLayout.span) {
        throw new Error("variant span exceeds span of containing union");
      }
      if ("string" !== typeof property) {
        throw new TypeError("variant must have a String property");
      }
    }
    let span = union2.span;
    if (0 > union2.span) {
      span = layout ? layout.span : 0;
      if (0 <= span && union2.usesPrefixDiscriminator) {
        span += union2.discriminator.layout.span;
      }
    }
    super(span, property);
    this.union = union2;
    this.variant = variant;
    this.layout = layout || null;
  }
  /** @override */
  getSpan(b, offset2) {
    if (0 <= this.span) {
      return this.span;
    }
    if (void 0 === offset2) {
      offset2 = 0;
    }
    let contentOffset = 0;
    if (this.union.usesPrefixDiscriminator) {
      contentOffset = this.union.discriminator.layout.span;
    }
    return contentOffset + this.layout.getSpan(b, offset2 + contentOffset);
  }
  /** @override */
  decode(b, offset2) {
    const dest = this.makeDestinationObject();
    if (void 0 === offset2) {
      offset2 = 0;
    }
    if (this !== this.union.getVariant(b, offset2)) {
      throw new Error("variant mismatch");
    }
    let contentOffset = 0;
    if (this.union.usesPrefixDiscriminator) {
      contentOffset = this.union.discriminator.layout.span;
    }
    if (this.layout) {
      dest[this.property] = this.layout.decode(b, offset2 + contentOffset);
    } else if (this.property) {
      dest[this.property] = true;
    } else if (this.union.usesPrefixDiscriminator) {
      dest[this.union.discriminator.property] = this.variant;
    }
    return dest;
  }
  /** @override */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    let contentOffset = 0;
    if (this.union.usesPrefixDiscriminator) {
      contentOffset = this.union.discriminator.layout.span;
    }
    if (this.layout && !src.hasOwnProperty(this.property)) {
      throw new TypeError("variant lacks property " + this.property);
    }
    this.union.discriminator.encode(this.variant, b, offset2);
    let span = contentOffset;
    if (this.layout) {
      this.layout.encode(src[this.property], b, offset2 + contentOffset);
      span += this.layout.getSpan(b, offset2 + contentOffset);
      if (0 <= this.union.span && span > this.union.span) {
        throw new Error("encoded variant overruns containing union");
      }
    }
    return span;
  }
  /** Delegate {@link Layout#fromArray|fromArray} to {@link
   * VariantLayout#layout|layout}. */
  fromArray(values) {
    if (this.layout) {
      return this.layout.fromArray(values);
    }
  }
};
function fixBitwiseResult(v) {
  if (0 > v) {
    v += 4294967296;
  }
  return v;
}
class BitStructure extends Layout$1 {
  constructor(word, msb, property) {
    if (!(word instanceof UInt$1 || word instanceof UIntBE$1)) {
      throw new TypeError("word must be a UInt or UIntBE layout");
    }
    if ("string" === typeof msb && void 0 === property) {
      property = msb;
      msb = void 0;
    }
    if (4 < word.span) {
      throw new RangeError("word cannot exceed 32 bits");
    }
    super(word.span, property);
    this.word = word;
    this.msb = !!msb;
    this.fields = [];
    let value = 0;
    this._packedSetValue = function(v) {
      value = fixBitwiseResult(v);
      return this;
    };
    this._packedGetValue = function() {
      return value;
    };
  }
  /** @override */
  decode(b, offset2) {
    const dest = this.makeDestinationObject();
    if (void 0 === offset2) {
      offset2 = 0;
    }
    const value = this.word.decode(b, offset2);
    this._packedSetValue(value);
    for (const fd of this.fields) {
      if (void 0 !== fd.property) {
        dest[fd.property] = fd.decode(value);
      }
    }
    return dest;
  }
  /** Implement {@link Layout#encode|encode} for {@link BitStructure}.
   *
   * If `src` is missing a property for a member with a defined {@link
   * Layout#property|property} the corresponding region of the packed
   * value is left unmodified.  Unused bits are also left unmodified. */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    const value = this.word.decode(b, offset2);
    this._packedSetValue(value);
    for (const fd of this.fields) {
      if (void 0 !== fd.property) {
        const fv = src[fd.property];
        if (void 0 !== fv) {
          fd.encode(fv);
        }
      }
    }
    return this.word.encode(this._packedGetValue(), b, offset2);
  }
  /** Register a new bitfield with a containing bit structure.  The
   * resulting bitfield is returned.
   *
   * @param {Number} bits - initializer for {@link BitField#bits|bits}.
   *
   * @param {string} property - initializer for {@link
   * Layout#property|property}.
   *
   * @return {BitField} */
  addField(bits, property) {
    const bf = new BitField(this, bits, property);
    this.fields.push(bf);
    return bf;
  }
  /** As with {@link BitStructure#addField|addField} for single-bit
   * fields with `boolean` value representation.
   *
   * @param {string} property - initializer for {@link
   * Layout#property|property}.
   *
   * @return {Boolean} */
  addBoolean(property) {
    const bf = new Boolean$1(this, property);
    this.fields.push(bf);
    return bf;
  }
  /**
   * Get access to the bit field for a given property.
   *
   * @param {String} property - the bit field of interest.
   *
   * @return {BitField} - the field associated with `property`, or
   * undefined if there is no such property.
   */
  fieldFor(property) {
    if ("string" !== typeof property) {
      throw new TypeError("property must be string");
    }
    for (const fd of this.fields) {
      if (fd.property === property) {
        return fd;
      }
    }
  }
}
class BitField {
  constructor(container, bits, property) {
    if (!(container instanceof BitStructure)) {
      throw new TypeError("container must be a BitStructure");
    }
    if (!Number.isInteger(bits) || 0 >= bits) {
      throw new TypeError("bits must be positive integer");
    }
    const totalBits = 8 * container.span;
    const usedBits = container.fields.reduce((sum, fd) => sum + fd.bits, 0);
    if (bits + usedBits > totalBits) {
      throw new Error("bits too long for span remainder (" + (totalBits - usedBits) + " of " + totalBits + " remain)");
    }
    this.container = container;
    this.bits = bits;
    this.valueMask = (1 << bits) - 1;
    if (32 === bits) {
      this.valueMask = 4294967295;
    }
    this.start = usedBits;
    if (this.container.msb) {
      this.start = totalBits - usedBits - bits;
    }
    this.wordMask = fixBitwiseResult(this.valueMask << this.start);
    this.property = property;
  }
  /** Store a value into the corresponding subsequence of the containing
   * bit field. */
  decode() {
    const word = this.container._packedGetValue();
    const wordValue = fixBitwiseResult(word & this.wordMask);
    const value = wordValue >>> this.start;
    return value;
  }
  /** Store a value into the corresponding subsequence of the containing
   * bit field.
   *
   * **NOTE** This is not a specialization of {@link
   * Layout#encode|Layout.encode} and there is no return value. */
  encode(value) {
    if (!Number.isInteger(value) || value !== fixBitwiseResult(value & this.valueMask)) {
      throw new TypeError(nameWithProperty$1("BitField.encode", this) + " value must be integer not exceeding " + this.valueMask);
    }
    const word = this.container._packedGetValue();
    const wordValue = fixBitwiseResult(value << this.start);
    this.container._packedSetValue(fixBitwiseResult(word & ~this.wordMask) | wordValue);
  }
}
let Boolean$1 = class Boolean2 extends BitField {
  constructor(container, property) {
    super(container, 1, property);
  }
  /** Override {@link BitField#decode|decode} for {@link Boolean|Boolean}.
   *
   * @returns {boolean} */
  decode(b, offset2) {
    return !!BitField.prototype.decode.call(this, b, offset2);
  }
  /** @override */
  encode(value) {
    if ("boolean" === typeof value) {
      value = +value;
    }
    return BitField.prototype.encode.call(this, value);
  }
};
let Blob$2 = class Blob2 extends Layout$1 {
  constructor(length, property) {
    if (!(length instanceof ExternalLayout$1 && length.isCount() || Number.isInteger(length) && 0 <= length)) {
      throw new TypeError("length must be positive integer or an unsigned integer ExternalLayout");
    }
    let span = -1;
    if (!(length instanceof ExternalLayout$1)) {
      span = length;
    }
    super(span, property);
    this.length = length;
  }
  /** @override */
  getSpan(b, offset2) {
    let span = this.span;
    if (0 > span) {
      span = this.length.decode(b, offset2);
    }
    return span;
  }
  /** @override */
  decode(b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    let span = this.span;
    if (0 > span) {
      span = this.length.decode(b, offset2);
    }
    return b.slice(offset2, offset2 + span);
  }
  /** Implement {@link Layout#encode|encode} for {@link Blob}.
   *
   * **NOTE** If {@link Layout#count|count} is an instance of {@link
   * ExternalLayout} then the length of `src` will be encoded as the
   * count after `src` is encoded. */
  encode(src, b, offset2) {
    let span = this.length;
    if (this.length instanceof ExternalLayout$1) {
      span = src.length;
    }
    if (!(Buffer.isBuffer(src) && span === src.length)) {
      throw new TypeError(nameWithProperty$1("Blob.encode", this) + " requires (length " + span + ") Buffer as src");
    }
    if (offset2 + span > b.length) {
      throw new RangeError("encoding overruns Buffer");
    }
    b.write(src.toString("hex"), offset2, span, "hex");
    if (this.length instanceof ExternalLayout$1) {
      this.length.encode(span, b, offset2);
    }
    return span;
  }
};
class CString extends Layout$1 {
  constructor(property) {
    super(-1, property);
  }
  /** @override */
  getSpan(b, offset2) {
    if (!Buffer.isBuffer(b)) {
      throw new TypeError("b must be a Buffer");
    }
    if (void 0 === offset2) {
      offset2 = 0;
    }
    let idx = offset2;
    while (idx < b.length && 0 !== b[idx]) {
      idx += 1;
    }
    return 1 + idx - offset2;
  }
  /** @override */
  decode(b, offset2, dest) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    let span = this.getSpan(b, offset2);
    return b.slice(offset2, offset2 + span - 1).toString("utf-8");
  }
  /** @override */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    if ("string" !== typeof src) {
      src = src.toString();
    }
    const srcb = new Buffer(src, "utf8");
    const span = srcb.length;
    if (offset2 + span > b.length) {
      throw new RangeError("encoding overruns Buffer");
    }
    srcb.copy(b, offset2);
    b[offset2 + span] = 0;
    return span + 1;
  }
}
class UTF8 extends Layout$1 {
  constructor(maxSpan, property) {
    if ("string" === typeof maxSpan && void 0 === property) {
      property = maxSpan;
      maxSpan = void 0;
    }
    if (void 0 === maxSpan) {
      maxSpan = -1;
    } else if (!Number.isInteger(maxSpan)) {
      throw new TypeError("maxSpan must be an integer");
    }
    super(-1, property);
    this.maxSpan = maxSpan;
  }
  /** @override */
  getSpan(b, offset2) {
    if (!Buffer.isBuffer(b)) {
      throw new TypeError("b must be a Buffer");
    }
    if (void 0 === offset2) {
      offset2 = 0;
    }
    return b.length - offset2;
  }
  /** @override */
  decode(b, offset2, dest) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    let span = this.getSpan(b, offset2);
    if (0 <= this.maxSpan && this.maxSpan < span) {
      throw new RangeError("text length exceeds maxSpan");
    }
    return b.slice(offset2, offset2 + span).toString("utf-8");
  }
  /** @override */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    if ("string" !== typeof src) {
      src = src.toString();
    }
    const srcb = new Buffer(src, "utf8");
    const span = srcb.length;
    if (0 <= this.maxSpan && this.maxSpan < span) {
      throw new RangeError("text length exceeds maxSpan");
    }
    if (offset2 + span > b.length) {
      throw new RangeError("encoding overruns Buffer");
    }
    srcb.copy(b, offset2);
    return span;
  }
}
class Constant extends Layout$1 {
  constructor(value, property) {
    super(0, property);
    this.value = value;
  }
  /** @override */
  decode(b, offset2, dest) {
    return this.value;
  }
  /** @override */
  encode(src, b, offset2) {
    return 0;
  }
}
Layout$2.ExternalLayout = ExternalLayout$1;
Layout$2.GreedyCount = GreedyCount;
Layout$2.OffsetLayout = OffsetLayout$1;
Layout$2.UInt = UInt$1;
Layout$2.UIntBE = UIntBE$1;
Layout$2.Int = Int;
Layout$2.IntBE = IntBE;
Layout$2.Float = Float;
Layout$2.FloatBE = FloatBE;
Layout$2.Double = Double;
Layout$2.DoubleBE = DoubleBE;
Layout$2.Sequence = Sequence;
Layout$2.Structure = Structure$1;
Layout$2.UnionDiscriminator = UnionDiscriminator$1;
Layout$2.UnionLayoutDiscriminator = UnionLayoutDiscriminator$1;
Layout$2.Union = Union$1;
Layout$2.VariantLayout = VariantLayout$1;
Layout$2.BitStructure = BitStructure;
Layout$2.BitField = BitField;
Layout$2.Boolean = Boolean$1;
Layout$2.Blob = Blob$2;
Layout$2.CString = CString;
Layout$2.UTF8 = UTF8;
Layout$2.Constant = Constant;
Layout$2.greedy = (elementSpan, property) => new GreedyCount(elementSpan, property);
Layout$2.offset = (layout, offset2, property) => new OffsetLayout$1(layout, offset2, property);
Layout$2.u8 = (property) => new UInt$1(1, property);
Layout$2.u16 = (property) => new UInt$1(2, property);
Layout$2.u24 = (property) => new UInt$1(3, property);
Layout$2.u32 = (property) => new UInt$1(4, property);
Layout$2.u40 = (property) => new UInt$1(5, property);
Layout$2.u48 = (property) => new UInt$1(6, property);
Layout$2.nu64 = (property) => new NearUInt64$1(property);
Layout$2.u16be = (property) => new UIntBE$1(2, property);
Layout$2.u24be = (property) => new UIntBE$1(3, property);
Layout$2.u32be = (property) => new UIntBE$1(4, property);
Layout$2.u40be = (property) => new UIntBE$1(5, property);
Layout$2.u48be = (property) => new UIntBE$1(6, property);
Layout$2.nu64be = (property) => new NearUInt64BE(property);
Layout$2.s8 = (property) => new Int(1, property);
Layout$2.s16 = (property) => new Int(2, property);
Layout$2.s24 = (property) => new Int(3, property);
Layout$2.s32 = (property) => new Int(4, property);
Layout$2.s40 = (property) => new Int(5, property);
Layout$2.s48 = (property) => new Int(6, property);
Layout$2.ns64 = (property) => new NearInt64$1(property);
Layout$2.s16be = (property) => new IntBE(2, property);
Layout$2.s24be = (property) => new IntBE(3, property);
Layout$2.s32be = (property) => new IntBE(4, property);
Layout$2.s40be = (property) => new IntBE(5, property);
Layout$2.s48be = (property) => new IntBE(6, property);
Layout$2.ns64be = (property) => new NearInt64BE(property);
Layout$2.f32 = (property) => new Float(property);
Layout$2.f32be = (property) => new FloatBE(property);
Layout$2.f64 = (property) => new Double(property);
Layout$2.f64be = (property) => new DoubleBE(property);
Layout$2.struct = (fields, property, decodePrefixes) => new Structure$1(fields, property, decodePrefixes);
Layout$2.bits = (word, msb, property) => new BitStructure(word, msb, property);
Layout$2.seq = (elementLayout, count, property) => new Sequence(elementLayout, count, property);
Layout$2.union = (discr, defaultLayout, property) => new Union$1(discr, defaultLayout, property);
Layout$2.unionLayoutDiscriminator = (layout, property) => new UnionLayoutDiscriminator$1(layout, property);
Layout$2.blob = (length, property) => new Blob$2(length, property);
Layout$2.cstr = (property) => new CString(property);
Layout$2.utf8 = (maxSpan, property) => new UTF8(maxSpan, property);
Layout$2.const = (value, property) => new Constant(value, property);
const require$$1 = /* @__PURE__ */ getAugmentedNamespace(index_browser_esm);
(function(exports$1) {
  var __importDefault = commonjsGlobal$1 && commonjsGlobal$1.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : { "default": mod };
  };
  Object.defineProperty(exports$1, "__esModule", { value: true });
  exports$1.struct = exports$1.f64 = exports$1.f32 = exports$1.i32 = exports$1.u32 = exports$1.i16 = exports$1.u16 = exports$1.i8 = exports$1.u8 = void 0;
  exports$1.u64 = u642;
  exports$1.i64 = i64;
  exports$1.u128 = u128;
  exports$1.i128 = i128;
  exports$1.u256 = u256;
  exports$1.i256 = i256;
  exports$1.publicKey = publicKey2;
  exports$1.option = option;
  exports$1.bool = bool;
  exports$1.vec = vec;
  exports$1.tagged = tagged;
  exports$1.vecU8 = vecU8;
  exports$1.str = str;
  exports$1.rustEnum = rustEnum;
  exports$1.array = array2;
  exports$1.map = map;
  const buffer_layout_1 = Layout$2;
  const web3_js_1 = require$$1;
  const bn_js_1 = __importDefault(bnExports);
  var buffer_layout_2 = Layout$2;
  Object.defineProperty(exports$1, "u8", { enumerable: true, get: function() {
    return buffer_layout_2.u8;
  } });
  Object.defineProperty(exports$1, "i8", { enumerable: true, get: function() {
    return buffer_layout_2.s8;
  } });
  Object.defineProperty(exports$1, "u16", { enumerable: true, get: function() {
    return buffer_layout_2.u16;
  } });
  Object.defineProperty(exports$1, "i16", { enumerable: true, get: function() {
    return buffer_layout_2.s16;
  } });
  Object.defineProperty(exports$1, "u32", { enumerable: true, get: function() {
    return buffer_layout_2.u32;
  } });
  Object.defineProperty(exports$1, "i32", { enumerable: true, get: function() {
    return buffer_layout_2.s32;
  } });
  Object.defineProperty(exports$1, "f32", { enumerable: true, get: function() {
    return buffer_layout_2.f32;
  } });
  Object.defineProperty(exports$1, "f64", { enumerable: true, get: function() {
    return buffer_layout_2.f64;
  } });
  Object.defineProperty(exports$1, "struct", { enumerable: true, get: function() {
    return buffer_layout_2.struct;
  } });
  class BNLayout extends buffer_layout_1.Layout {
    constructor(span, signed, property) {
      super(span, property);
      this.blob = (0, buffer_layout_1.blob)(span);
      this.signed = signed;
    }
    decode(b, offset2 = 0) {
      const num = new bn_js_1.default(this.blob.decode(b, offset2), 10, "le");
      if (this.signed) {
        return num.fromTwos(this.span * 8).clone();
      }
      return num;
    }
    encode(src, b, offset2 = 0) {
      if (this.signed) {
        src = src.toTwos(this.span * 8);
      }
      return this.blob.encode(src.toArrayLike(Buffer, "le", this.span), b, offset2);
    }
  }
  function u642(property) {
    return new BNLayout(8, false, property);
  }
  function i64(property) {
    return new BNLayout(8, true, property);
  }
  function u128(property) {
    return new BNLayout(16, false, property);
  }
  function i128(property) {
    return new BNLayout(16, true, property);
  }
  function u256(property) {
    return new BNLayout(32, false, property);
  }
  function i256(property) {
    return new BNLayout(32, true, property);
  }
  class WrappedLayout2 extends buffer_layout_1.Layout {
    constructor(layout, decoder, encoder, property) {
      super(layout.span, property);
      this.layout = layout;
      this.decoder = decoder;
      this.encoder = encoder;
    }
    decode(b, offset2) {
      return this.decoder(this.layout.decode(b, offset2));
    }
    encode(src, b, offset2) {
      return this.layout.encode(this.encoder(src), b, offset2);
    }
    getSpan(b, offset2) {
      return this.layout.getSpan(b, offset2);
    }
  }
  function publicKey2(property) {
    return new WrappedLayout2((0, buffer_layout_1.blob)(32), (b) => new web3_js_1.PublicKey(b), (key) => key.toBuffer(), property);
  }
  class OptionLayout extends buffer_layout_1.Layout {
    constructor(layout, property) {
      super(-1, property);
      this.layout = layout;
      this.discriminator = (0, buffer_layout_1.u8)();
    }
    encode(src, b, offset2 = 0) {
      if (src === null || src === void 0) {
        return this.discriminator.encode(0, b, offset2);
      }
      this.discriminator.encode(1, b, offset2);
      return this.layout.encode(src, b, offset2 + 1) + 1;
    }
    decode(b, offset2 = 0) {
      const discriminator = this.discriminator.decode(b, offset2);
      if (discriminator === 0) {
        return null;
      } else if (discriminator === 1) {
        return this.layout.decode(b, offset2 + 1);
      }
      throw new Error("Invalid option " + this.property);
    }
    getSpan(b, offset2 = 0) {
      const discriminator = this.discriminator.decode(b, offset2);
      if (discriminator === 0) {
        return 1;
      } else if (discriminator === 1) {
        return this.layout.getSpan(b, offset2 + 1) + 1;
      }
      throw new Error("Invalid option " + this.property);
    }
  }
  function option(layout, property) {
    return new OptionLayout(layout, property);
  }
  function bool(property) {
    return new WrappedLayout2((0, buffer_layout_1.u8)(), decodeBool, encodeBool, property);
  }
  function decodeBool(value) {
    if (value === 0) {
      return false;
    } else if (value === 1) {
      return true;
    }
    throw new Error("Invalid bool: " + value);
  }
  function encodeBool(value) {
    return value ? 1 : 0;
  }
  function vec(elementLayout, property) {
    const length = (0, buffer_layout_1.u32)("length");
    const layout = (0, buffer_layout_1.struct)([
      length,
      (0, buffer_layout_1.seq)(elementLayout, (0, buffer_layout_1.offset)(length, -length.span), "values")
    ]);
    return new WrappedLayout2(layout, ({ values }) => values, (values) => ({ values }), property);
  }
  function tagged(tag, layout, property) {
    const wrappedLayout = (0, buffer_layout_1.struct)([
      u642("tag"),
      layout.replicate("data")
    ]);
    function decodeTag({ tag: receivedTag, data }) {
      if (!receivedTag.eq(tag)) {
        throw new Error("Invalid tag, expected: " + tag.toString("hex") + ", got: " + receivedTag.toString("hex"));
      }
      return data;
    }
    return new WrappedLayout2(wrappedLayout, decodeTag, (data) => ({ tag, data }), property);
  }
  function vecU8(property) {
    const length = (0, buffer_layout_1.u32)("length");
    const layout = (0, buffer_layout_1.struct)([
      length,
      (0, buffer_layout_1.blob)((0, buffer_layout_1.offset)(length, -length.span), "data")
    ]);
    return new WrappedLayout2(layout, ({ data }) => data, (data) => ({ data }), property);
  }
  function str(property) {
    return new WrappedLayout2(vecU8(), (data) => data.toString("utf-8"), (s) => Buffer.from(s, "utf-8"), property);
  }
  function rustEnum(variants, property, discriminant) {
    const unionLayout = (0, buffer_layout_1.union)(discriminant !== null && discriminant !== void 0 ? discriminant : (0, buffer_layout_1.u8)(), property);
    variants.forEach((variant, index) => unionLayout.addVariant(index, variant, variant.property));
    return unionLayout;
  }
  function array2(elementLayout, length, property) {
    const layout = (0, buffer_layout_1.struct)([
      (0, buffer_layout_1.seq)(elementLayout, length, "values")
    ]);
    return new WrappedLayout2(layout, ({ values }) => values, (values) => ({ values }), property);
  }
  class MapEntryLayout extends buffer_layout_1.Layout {
    constructor(keyLayout, valueLayout, property) {
      super(keyLayout.span + valueLayout.span, property);
      this.keyLayout = keyLayout;
      this.valueLayout = valueLayout;
    }
    decode(b, offset2) {
      offset2 = offset2 || 0;
      const key = this.keyLayout.decode(b, offset2);
      const value = this.valueLayout.decode(b, offset2 + this.keyLayout.getSpan(b, offset2));
      return [key, value];
    }
    encode(src, b, offset2) {
      offset2 = offset2 || 0;
      const keyBytes = this.keyLayout.encode(src[0], b, offset2);
      const valueBytes = this.valueLayout.encode(src[1], b, offset2 + keyBytes);
      return keyBytes + valueBytes;
    }
    getSpan(b, offset2) {
      return this.keyLayout.getSpan(b, offset2) + this.valueLayout.getSpan(b, offset2);
    }
  }
  function map(keyLayout, valueLayout, property) {
    const length = (0, buffer_layout_1.u32)("length");
    const layout = (0, buffer_layout_1.struct)([
      length,
      (0, buffer_layout_1.seq)(new MapEntryLayout(keyLayout, valueLayout), (0, buffer_layout_1.offset)(length, -length.span), "values")
    ]);
    return new WrappedLayout2(layout, ({ values }) => new Map(values), (values) => ({ values: Array.from(values.entries()) }), property);
  }
})(dist$1);
function zero$1(buf) {
  let len = buf.length;
  while (--len >= 0) {
    buf[len] = 0;
  }
}
const MIN_MATCH$1 = 3;
const MAX_MATCH$1 = 258;
const LENGTH_CODES$1 = 29;
const LITERALS$1 = 256;
const L_CODES$1 = LITERALS$1 + 1 + LENGTH_CODES$1;
const D_CODES$1 = 30;
const DIST_CODE_LEN = 512;
const static_ltree = new Array((L_CODES$1 + 2) * 2);
zero$1(static_ltree);
const static_dtree = new Array(D_CODES$1 * 2);
zero$1(static_dtree);
const _dist_code = new Array(DIST_CODE_LEN);
zero$1(_dist_code);
const _length_code = new Array(MAX_MATCH$1 - MIN_MATCH$1 + 1);
zero$1(_length_code);
const base_length = new Array(LENGTH_CODES$1);
zero$1(base_length);
const base_dist = new Array(D_CODES$1);
zero$1(base_dist);
const adler32 = (adler, buf, len, pos) => {
  let s1 = adler & 65535 | 0, s2 = adler >>> 16 & 65535 | 0, n = 0;
  while (len !== 0) {
    n = len > 2e3 ? 2e3 : len;
    len -= n;
    do {
      s1 = s1 + buf[pos++] | 0;
      s2 = s2 + s1 | 0;
    } while (--n);
    s1 %= 65521;
    s2 %= 65521;
  }
  return s1 | s2 << 16 | 0;
};
var adler32_1 = adler32;
const makeTable = () => {
  let c, table = [];
  for (var n = 0; n < 256; n++) {
    c = n;
    for (var k = 0; k < 8; k++) {
      c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
    }
    table[n] = c;
  }
  return table;
};
const crcTable = new Uint32Array(makeTable());
const crc32 = (crc, buf, len, pos) => {
  const t = crcTable;
  const end = pos + len;
  crc ^= -1;
  for (let i = pos; i < end; i++) {
    crc = crc >>> 8 ^ t[(crc ^ buf[i]) & 255];
  }
  return crc ^ -1;
};
var crc32_1 = crc32;
var messages = {
  2: "need dictionary",
  /* Z_NEED_DICT       2  */
  1: "stream end",
  /* Z_STREAM_END      1  */
  0: "",
  /* Z_OK              0  */
  "-1": "file error",
  /* Z_ERRNO         (-1) */
  "-2": "stream error",
  /* Z_STREAM_ERROR  (-2) */
  "-3": "data error",
  /* Z_DATA_ERROR    (-3) */
  "-4": "insufficient memory",
  /* Z_MEM_ERROR     (-4) */
  "-5": "buffer error",
  /* Z_BUF_ERROR     (-5) */
  "-6": "incompatible version"
  /* Z_VERSION_ERROR (-6) */
};
var constants$2 = {
  /* Allowed flush values; see deflate() and inflate() below for details */
  Z_NO_FLUSH: 0,
  Z_FINISH: 4,
  Z_BLOCK: 5,
  Z_TREES: 6,
  /* Return codes for the compression/decompression functions. Negative values
  * are errors, positive values are used for special but normal events.
  */
  Z_OK: 0,
  Z_STREAM_END: 1,
  Z_NEED_DICT: 2,
  Z_STREAM_ERROR: -2,
  Z_DATA_ERROR: -3,
  Z_MEM_ERROR: -4,
  Z_BUF_ERROR: -5,
  /* The deflate compression method */
  Z_DEFLATED: 8
  //Z_NULL:                 null // Use -1 or null inline, depending on var type
};
const _has = (obj, key) => {
  return Object.prototype.hasOwnProperty.call(obj, key);
};
var assign = function(obj) {
  const sources = Array.prototype.slice.call(arguments, 1);
  while (sources.length) {
    const source = sources.shift();
    if (!source) {
      continue;
    }
    if (typeof source !== "object") {
      throw new TypeError(source + "must be non-object");
    }
    for (const p in source) {
      if (_has(source, p)) {
        obj[p] = source[p];
      }
    }
  }
  return obj;
};
var flattenChunks = (chunks2) => {
  let len = 0;
  for (let i = 0, l = chunks2.length; i < l; i++) {
    len += chunks2[i].length;
  }
  const result = new Uint8Array(len);
  for (let i = 0, pos = 0, l = chunks2.length; i < l; i++) {
    let chunk = chunks2[i];
    result.set(chunk, pos);
    pos += chunk.length;
  }
  return result;
};
var common = {
  assign,
  flattenChunks
};
let STR_APPLY_UIA_OK = true;
try {
  String.fromCharCode.apply(null, new Uint8Array(1));
} catch (__) {
  STR_APPLY_UIA_OK = false;
}
const _utf8len = new Uint8Array(256);
for (let q = 0; q < 256; q++) {
  _utf8len[q] = q >= 252 ? 6 : q >= 248 ? 5 : q >= 240 ? 4 : q >= 224 ? 3 : q >= 192 ? 2 : 1;
}
_utf8len[254] = _utf8len[254] = 1;
var string2buf = (str) => {
  if (typeof TextEncoder === "function" && TextEncoder.prototype.encode) {
    return new TextEncoder().encode(str);
  }
  let buf, c, c2, m_pos, i, str_len = str.length, buf_len = 0;
  for (m_pos = 0; m_pos < str_len; m_pos++) {
    c = str.charCodeAt(m_pos);
    if ((c & 64512) === 55296 && m_pos + 1 < str_len) {
      c2 = str.charCodeAt(m_pos + 1);
      if ((c2 & 64512) === 56320) {
        c = 65536 + (c - 55296 << 10) + (c2 - 56320);
        m_pos++;
      }
    }
    buf_len += c < 128 ? 1 : c < 2048 ? 2 : c < 65536 ? 3 : 4;
  }
  buf = new Uint8Array(buf_len);
  for (i = 0, m_pos = 0; i < buf_len; m_pos++) {
    c = str.charCodeAt(m_pos);
    if ((c & 64512) === 55296 && m_pos + 1 < str_len) {
      c2 = str.charCodeAt(m_pos + 1);
      if ((c2 & 64512) === 56320) {
        c = 65536 + (c - 55296 << 10) + (c2 - 56320);
        m_pos++;
      }
    }
    if (c < 128) {
      buf[i++] = c;
    } else if (c < 2048) {
      buf[i++] = 192 | c >>> 6;
      buf[i++] = 128 | c & 63;
    } else if (c < 65536) {
      buf[i++] = 224 | c >>> 12;
      buf[i++] = 128 | c >>> 6 & 63;
      buf[i++] = 128 | c & 63;
    } else {
      buf[i++] = 240 | c >>> 18;
      buf[i++] = 128 | c >>> 12 & 63;
      buf[i++] = 128 | c >>> 6 & 63;
      buf[i++] = 128 | c & 63;
    }
  }
  return buf;
};
const buf2binstring = (buf, len) => {
  if (len < 65534) {
    if (buf.subarray && STR_APPLY_UIA_OK) {
      return String.fromCharCode.apply(null, buf.length === len ? buf : buf.subarray(0, len));
    }
  }
  let result = "";
  for (let i = 0; i < len; i++) {
    result += String.fromCharCode(buf[i]);
  }
  return result;
};
var buf2string = (buf, max) => {
  const len = max || buf.length;
  if (typeof TextDecoder === "function" && TextDecoder.prototype.decode) {
    return new TextDecoder().decode(buf.subarray(0, max));
  }
  let i, out;
  const utf16buf = new Array(len * 2);
  for (out = 0, i = 0; i < len; ) {
    let c = buf[i++];
    if (c < 128) {
      utf16buf[out++] = c;
      continue;
    }
    let c_len = _utf8len[c];
    if (c_len > 4) {
      utf16buf[out++] = 65533;
      i += c_len - 1;
      continue;
    }
    c &= c_len === 2 ? 31 : c_len === 3 ? 15 : 7;
    while (c_len > 1 && i < len) {
      c = c << 6 | buf[i++] & 63;
      c_len--;
    }
    if (c_len > 1) {
      utf16buf[out++] = 65533;
      continue;
    }
    if (c < 65536) {
      utf16buf[out++] = c;
    } else {
      c -= 65536;
      utf16buf[out++] = 55296 | c >> 10 & 1023;
      utf16buf[out++] = 56320 | c & 1023;
    }
  }
  return buf2binstring(utf16buf, out);
};
var utf8border = (buf, max) => {
  max = max || buf.length;
  if (max > buf.length) {
    max = buf.length;
  }
  let pos = max - 1;
  while (pos >= 0 && (buf[pos] & 192) === 128) {
    pos--;
  }
  if (pos < 0) {
    return max;
  }
  if (pos === 0) {
    return max;
  }
  return pos + _utf8len[buf[pos]] > max ? pos : max;
};
var strings = {
  string2buf,
  buf2string,
  utf8border
};
function ZStream() {
  this.input = null;
  this.next_in = 0;
  this.avail_in = 0;
  this.total_in = 0;
  this.output = null;
  this.next_out = 0;
  this.avail_out = 0;
  this.total_out = 0;
  this.msg = "";
  this.state = null;
  this.data_type = 2;
  this.adler = 0;
}
var zstream = ZStream;
const BAD$1 = 16209;
const TYPE$1 = 16191;
var inffast = function inflate_fast(strm, start) {
  let _in;
  let last;
  let _out;
  let beg;
  let end;
  let dmax;
  let wsize;
  let whave;
  let wnext;
  let s_window;
  let hold;
  let bits;
  let lcode;
  let dcode;
  let lmask;
  let dmask;
  let here;
  let op;
  let len;
  let dist2;
  let from;
  let from_source;
  let input, output;
  const state = strm.state;
  _in = strm.next_in;
  input = strm.input;
  last = _in + (strm.avail_in - 5);
  _out = strm.next_out;
  output = strm.output;
  beg = _out - (start - strm.avail_out);
  end = _out + (strm.avail_out - 257);
  dmax = state.dmax;
  wsize = state.wsize;
  whave = state.whave;
  wnext = state.wnext;
  s_window = state.window;
  hold = state.hold;
  bits = state.bits;
  lcode = state.lencode;
  dcode = state.distcode;
  lmask = (1 << state.lenbits) - 1;
  dmask = (1 << state.distbits) - 1;
  top:
    do {
      if (bits < 15) {
        hold += input[_in++] << bits;
        bits += 8;
        hold += input[_in++] << bits;
        bits += 8;
      }
      here = lcode[hold & lmask];
      dolen:
        for (; ; ) {
          op = here >>> 24;
          hold >>>= op;
          bits -= op;
          op = here >>> 16 & 255;
          if (op === 0) {
            output[_out++] = here & 65535;
          } else if (op & 16) {
            len = here & 65535;
            op &= 15;
            if (op) {
              if (bits < op) {
                hold += input[_in++] << bits;
                bits += 8;
              }
              len += hold & (1 << op) - 1;
              hold >>>= op;
              bits -= op;
            }
            if (bits < 15) {
              hold += input[_in++] << bits;
              bits += 8;
              hold += input[_in++] << bits;
              bits += 8;
            }
            here = dcode[hold & dmask];
            dodist:
              for (; ; ) {
                op = here >>> 24;
                hold >>>= op;
                bits -= op;
                op = here >>> 16 & 255;
                if (op & 16) {
                  dist2 = here & 65535;
                  op &= 15;
                  if (bits < op) {
                    hold += input[_in++] << bits;
                    bits += 8;
                    if (bits < op) {
                      hold += input[_in++] << bits;
                      bits += 8;
                    }
                  }
                  dist2 += hold & (1 << op) - 1;
                  if (dist2 > dmax) {
                    strm.msg = "invalid distance too far back";
                    state.mode = BAD$1;
                    break top;
                  }
                  hold >>>= op;
                  bits -= op;
                  op = _out - beg;
                  if (dist2 > op) {
                    op = dist2 - op;
                    if (op > whave) {
                      if (state.sane) {
                        strm.msg = "invalid distance too far back";
                        state.mode = BAD$1;
                        break top;
                      }
                    }
                    from = 0;
                    from_source = s_window;
                    if (wnext === 0) {
                      from += wsize - op;
                      if (op < len) {
                        len -= op;
                        do {
                          output[_out++] = s_window[from++];
                        } while (--op);
                        from = _out - dist2;
                        from_source = output;
                      }
                    } else if (wnext < op) {
                      from += wsize + wnext - op;
                      op -= wnext;
                      if (op < len) {
                        len -= op;
                        do {
                          output[_out++] = s_window[from++];
                        } while (--op);
                        from = 0;
                        if (wnext < len) {
                          op = wnext;
                          len -= op;
                          do {
                            output[_out++] = s_window[from++];
                          } while (--op);
                          from = _out - dist2;
                          from_source = output;
                        }
                      }
                    } else {
                      from += wnext - op;
                      if (op < len) {
                        len -= op;
                        do {
                          output[_out++] = s_window[from++];
                        } while (--op);
                        from = _out - dist2;
                        from_source = output;
                      }
                    }
                    while (len > 2) {
                      output[_out++] = from_source[from++];
                      output[_out++] = from_source[from++];
                      output[_out++] = from_source[from++];
                      len -= 3;
                    }
                    if (len) {
                      output[_out++] = from_source[from++];
                      if (len > 1) {
                        output[_out++] = from_source[from++];
                      }
                    }
                  } else {
                    from = _out - dist2;
                    do {
                      output[_out++] = output[from++];
                      output[_out++] = output[from++];
                      output[_out++] = output[from++];
                      len -= 3;
                    } while (len > 2);
                    if (len) {
                      output[_out++] = output[from++];
                      if (len > 1) {
                        output[_out++] = output[from++];
                      }
                    }
                  }
                } else if ((op & 64) === 0) {
                  here = dcode[(here & 65535) + (hold & (1 << op) - 1)];
                  continue dodist;
                } else {
                  strm.msg = "invalid distance code";
                  state.mode = BAD$1;
                  break top;
                }
                break;
              }
          } else if ((op & 64) === 0) {
            here = lcode[(here & 65535) + (hold & (1 << op) - 1)];
            continue dolen;
          } else if (op & 32) {
            state.mode = TYPE$1;
            break top;
          } else {
            strm.msg = "invalid literal/length code";
            state.mode = BAD$1;
            break top;
          }
          break;
        }
    } while (_in < last && _out < end);
  len = bits >> 3;
  _in -= len;
  bits -= len << 3;
  hold &= (1 << bits) - 1;
  strm.next_in = _in;
  strm.next_out = _out;
  strm.avail_in = _in < last ? 5 + (last - _in) : 5 - (_in - last);
  strm.avail_out = _out < end ? 257 + (end - _out) : 257 - (_out - end);
  state.hold = hold;
  state.bits = bits;
  return;
};
const MAXBITS = 15;
const ENOUGH_LENS$1 = 852;
const ENOUGH_DISTS$1 = 592;
const CODES$1 = 0;
const LENS$1 = 1;
const DISTS$1 = 2;
const lbase = new Uint16Array([
  /* Length codes 257..285 base */
  3,
  4,
  5,
  6,
  7,
  8,
  9,
  10,
  11,
  13,
  15,
  17,
  19,
  23,
  27,
  31,
  35,
  43,
  51,
  59,
  67,
  83,
  99,
  115,
  131,
  163,
  195,
  227,
  258,
  0,
  0
]);
const lext = new Uint8Array([
  /* Length codes 257..285 extra */
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  17,
  17,
  17,
  17,
  18,
  18,
  18,
  18,
  19,
  19,
  19,
  19,
  20,
  20,
  20,
  20,
  21,
  21,
  21,
  21,
  16,
  72,
  78
]);
const dbase = new Uint16Array([
  /* Distance codes 0..29 base */
  1,
  2,
  3,
  4,
  5,
  7,
  9,
  13,
  17,
  25,
  33,
  49,
  65,
  97,
  129,
  193,
  257,
  385,
  513,
  769,
  1025,
  1537,
  2049,
  3073,
  4097,
  6145,
  8193,
  12289,
  16385,
  24577,
  0,
  0
]);
const dext = new Uint8Array([
  /* Distance codes 0..29 extra */
  16,
  16,
  16,
  16,
  17,
  17,
  18,
  18,
  19,
  19,
  20,
  20,
  21,
  21,
  22,
  22,
  23,
  23,
  24,
  24,
  25,
  25,
  26,
  26,
  27,
  27,
  28,
  28,
  29,
  29,
  64,
  64
]);
const inflate_table = (type2, lens, lens_index, codes, table, table_index, work, opts) => {
  const bits = opts.bits;
  let len = 0;
  let sym = 0;
  let min = 0, max = 0;
  let root = 0;
  let curr = 0;
  let drop = 0;
  let left = 0;
  let used = 0;
  let huff = 0;
  let incr;
  let fill;
  let low;
  let mask2;
  let next;
  let base = null;
  let match;
  const count = new Uint16Array(MAXBITS + 1);
  const offs = new Uint16Array(MAXBITS + 1);
  let extra = null;
  let here_bits, here_op, here_val;
  for (len = 0; len <= MAXBITS; len++) {
    count[len] = 0;
  }
  for (sym = 0; sym < codes; sym++) {
    count[lens[lens_index + sym]]++;
  }
  root = bits;
  for (max = MAXBITS; max >= 1; max--) {
    if (count[max] !== 0) {
      break;
    }
  }
  if (root > max) {
    root = max;
  }
  if (max === 0) {
    table[table_index++] = 1 << 24 | 64 << 16 | 0;
    table[table_index++] = 1 << 24 | 64 << 16 | 0;
    opts.bits = 1;
    return 0;
  }
  for (min = 1; min < max; min++) {
    if (count[min] !== 0) {
      break;
    }
  }
  if (root < min) {
    root = min;
  }
  left = 1;
  for (len = 1; len <= MAXBITS; len++) {
    left <<= 1;
    left -= count[len];
    if (left < 0) {
      return -1;
    }
  }
  if (left > 0 && (type2 === CODES$1 || max !== 1)) {
    return -1;
  }
  offs[1] = 0;
  for (len = 1; len < MAXBITS; len++) {
    offs[len + 1] = offs[len] + count[len];
  }
  for (sym = 0; sym < codes; sym++) {
    if (lens[lens_index + sym] !== 0) {
      work[offs[lens[lens_index + sym]]++] = sym;
    }
  }
  if (type2 === CODES$1) {
    base = extra = work;
    match = 20;
  } else if (type2 === LENS$1) {
    base = lbase;
    extra = lext;
    match = 257;
  } else {
    base = dbase;
    extra = dext;
    match = 0;
  }
  huff = 0;
  sym = 0;
  len = min;
  next = table_index;
  curr = root;
  drop = 0;
  low = -1;
  used = 1 << root;
  mask2 = used - 1;
  if (type2 === LENS$1 && used > ENOUGH_LENS$1 || type2 === DISTS$1 && used > ENOUGH_DISTS$1) {
    return 1;
  }
  for (; ; ) {
    here_bits = len - drop;
    if (work[sym] + 1 < match) {
      here_op = 0;
      here_val = work[sym];
    } else if (work[sym] >= match) {
      here_op = extra[work[sym] - match];
      here_val = base[work[sym] - match];
    } else {
      here_op = 32 + 64;
      here_val = 0;
    }
    incr = 1 << len - drop;
    fill = 1 << curr;
    min = fill;
    do {
      fill -= incr;
      table[next + (huff >> drop) + fill] = here_bits << 24 | here_op << 16 | here_val | 0;
    } while (fill !== 0);
    incr = 1 << len - 1;
    while (huff & incr) {
      incr >>= 1;
    }
    if (incr !== 0) {
      huff &= incr - 1;
      huff += incr;
    } else {
      huff = 0;
    }
    sym++;
    if (--count[len] === 0) {
      if (len === max) {
        break;
      }
      len = lens[lens_index + work[sym]];
    }
    if (len > root && (huff & mask2) !== low) {
      if (drop === 0) {
        drop = root;
      }
      next += min;
      curr = len - drop;
      left = 1 << curr;
      while (curr + drop < max) {
        left -= count[curr + drop];
        if (left <= 0) {
          break;
        }
        curr++;
        left <<= 1;
      }
      used += 1 << curr;
      if (type2 === LENS$1 && used > ENOUGH_LENS$1 || type2 === DISTS$1 && used > ENOUGH_DISTS$1) {
        return 1;
      }
      low = huff & mask2;
      table[low] = root << 24 | curr << 16 | next - table_index | 0;
    }
  }
  if (huff !== 0) {
    table[next + huff] = len - drop << 24 | 64 << 16 | 0;
  }
  opts.bits = root;
  return 0;
};
var inftrees = inflate_table;
const CODES = 0;
const LENS = 1;
const DISTS = 2;
const {
  Z_FINISH: Z_FINISH$1,
  Z_BLOCK,
  Z_TREES,
  Z_OK: Z_OK$1,
  Z_STREAM_END: Z_STREAM_END$1,
  Z_NEED_DICT: Z_NEED_DICT$1,
  Z_STREAM_ERROR: Z_STREAM_ERROR$1,
  Z_DATA_ERROR: Z_DATA_ERROR$1,
  Z_MEM_ERROR: Z_MEM_ERROR$1,
  Z_BUF_ERROR,
  Z_DEFLATED
} = constants$2;
const HEAD = 16180;
const FLAGS = 16181;
const TIME = 16182;
const OS = 16183;
const EXLEN = 16184;
const EXTRA = 16185;
const NAME = 16186;
const COMMENT = 16187;
const HCRC = 16188;
const DICTID = 16189;
const DICT = 16190;
const TYPE = 16191;
const TYPEDO = 16192;
const STORED = 16193;
const COPY_ = 16194;
const COPY = 16195;
const TABLE = 16196;
const LENLENS = 16197;
const CODELENS = 16198;
const LEN_ = 16199;
const LEN = 16200;
const LENEXT = 16201;
const DIST = 16202;
const DISTEXT = 16203;
const MATCH = 16204;
const LIT = 16205;
const CHECK = 16206;
const LENGTH = 16207;
const DONE = 16208;
const BAD = 16209;
const MEM = 16210;
const SYNC = 16211;
const ENOUGH_LENS = 852;
const ENOUGH_DISTS = 592;
const MAX_WBITS = 15;
const DEF_WBITS = MAX_WBITS;
const zswap32 = (q) => {
  return (q >>> 24 & 255) + (q >>> 8 & 65280) + ((q & 65280) << 8) + ((q & 255) << 24);
};
function InflateState() {
  this.strm = null;
  this.mode = 0;
  this.last = false;
  this.wrap = 0;
  this.havedict = false;
  this.flags = 0;
  this.dmax = 0;
  this.check = 0;
  this.total = 0;
  this.head = null;
  this.wbits = 0;
  this.wsize = 0;
  this.whave = 0;
  this.wnext = 0;
  this.window = null;
  this.hold = 0;
  this.bits = 0;
  this.length = 0;
  this.offset = 0;
  this.extra = 0;
  this.lencode = null;
  this.distcode = null;
  this.lenbits = 0;
  this.distbits = 0;
  this.ncode = 0;
  this.nlen = 0;
  this.ndist = 0;
  this.have = 0;
  this.next = null;
  this.lens = new Uint16Array(320);
  this.work = new Uint16Array(288);
  this.lendyn = null;
  this.distdyn = null;
  this.sane = 0;
  this.back = 0;
  this.was = 0;
}
const inflateStateCheck = (strm) => {
  if (!strm) {
    return 1;
  }
  const state = strm.state;
  if (!state || state.strm !== strm || state.mode < HEAD || state.mode > SYNC) {
    return 1;
  }
  return 0;
};
const inflateResetKeep = (strm) => {
  if (inflateStateCheck(strm)) {
    return Z_STREAM_ERROR$1;
  }
  const state = strm.state;
  strm.total_in = strm.total_out = state.total = 0;
  strm.msg = "";
  if (state.wrap) {
    strm.adler = state.wrap & 1;
  }
  state.mode = HEAD;
  state.last = 0;
  state.havedict = 0;
  state.flags = -1;
  state.dmax = 32768;
  state.head = null;
  state.hold = 0;
  state.bits = 0;
  state.lencode = state.lendyn = new Int32Array(ENOUGH_LENS);
  state.distcode = state.distdyn = new Int32Array(ENOUGH_DISTS);
  state.sane = 1;
  state.back = -1;
  return Z_OK$1;
};
const inflateReset = (strm) => {
  if (inflateStateCheck(strm)) {
    return Z_STREAM_ERROR$1;
  }
  const state = strm.state;
  state.wsize = 0;
  state.whave = 0;
  state.wnext = 0;
  return inflateResetKeep(strm);
};
const inflateReset2 = (strm, windowBits) => {
  let wrap;
  if (inflateStateCheck(strm)) {
    return Z_STREAM_ERROR$1;
  }
  const state = strm.state;
  if (windowBits < 0) {
    wrap = 0;
    windowBits = -windowBits;
  } else {
    wrap = (windowBits >> 4) + 5;
    if (windowBits < 48) {
      windowBits &= 15;
    }
  }
  if (windowBits && (windowBits < 8 || windowBits > 15)) {
    return Z_STREAM_ERROR$1;
  }
  if (state.window !== null && state.wbits !== windowBits) {
    state.window = null;
  }
  state.wrap = wrap;
  state.wbits = windowBits;
  return inflateReset(strm);
};
const inflateInit2 = (strm, windowBits) => {
  if (!strm) {
    return Z_STREAM_ERROR$1;
  }
  const state = new InflateState();
  strm.state = state;
  state.strm = strm;
  state.window = null;
  state.mode = HEAD;
  const ret = inflateReset2(strm, windowBits);
  if (ret !== Z_OK$1) {
    strm.state = null;
  }
  return ret;
};
const inflateInit = (strm) => {
  return inflateInit2(strm, DEF_WBITS);
};
let virgin = true;
let lenfix, distfix;
const fixedtables = (state) => {
  if (virgin) {
    lenfix = new Int32Array(512);
    distfix = new Int32Array(32);
    let sym = 0;
    while (sym < 144) {
      state.lens[sym++] = 8;
    }
    while (sym < 256) {
      state.lens[sym++] = 9;
    }
    while (sym < 280) {
      state.lens[sym++] = 7;
    }
    while (sym < 288) {
      state.lens[sym++] = 8;
    }
    inftrees(LENS, state.lens, 0, 288, lenfix, 0, state.work, { bits: 9 });
    sym = 0;
    while (sym < 32) {
      state.lens[sym++] = 5;
    }
    inftrees(DISTS, state.lens, 0, 32, distfix, 0, state.work, { bits: 5 });
    virgin = false;
  }
  state.lencode = lenfix;
  state.lenbits = 9;
  state.distcode = distfix;
  state.distbits = 5;
};
const updatewindow = (strm, src, end, copy) => {
  let dist2;
  const state = strm.state;
  if (state.window === null) {
    state.wsize = 1 << state.wbits;
    state.wnext = 0;
    state.whave = 0;
    state.window = new Uint8Array(state.wsize);
  }
  if (copy >= state.wsize) {
    state.window.set(src.subarray(end - state.wsize, end), 0);
    state.wnext = 0;
    state.whave = state.wsize;
  } else {
    dist2 = state.wsize - state.wnext;
    if (dist2 > copy) {
      dist2 = copy;
    }
    state.window.set(src.subarray(end - copy, end - copy + dist2), state.wnext);
    copy -= dist2;
    if (copy) {
      state.window.set(src.subarray(end - copy, end), 0);
      state.wnext = copy;
      state.whave = state.wsize;
    } else {
      state.wnext += dist2;
      if (state.wnext === state.wsize) {
        state.wnext = 0;
      }
      if (state.whave < state.wsize) {
        state.whave += dist2;
      }
    }
  }
  return 0;
};
const inflate$2 = (strm, flush) => {
  let state;
  let input, output;
  let next;
  let put;
  let have, left;
  let hold;
  let bits;
  let _in, _out;
  let copy;
  let from;
  let from_source;
  let here = 0;
  let here_bits, here_op, here_val;
  let last_bits, last_op, last_val;
  let len;
  let ret;
  const hbuf = new Uint8Array(4);
  let opts;
  let n;
  const order = (
    /* permutation of code lengths */
    new Uint8Array([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15])
  );
  if (inflateStateCheck(strm) || !strm.output || !strm.input && strm.avail_in !== 0) {
    return Z_STREAM_ERROR$1;
  }
  state = strm.state;
  if (state.mode === TYPE) {
    state.mode = TYPEDO;
  }
  put = strm.next_out;
  output = strm.output;
  left = strm.avail_out;
  next = strm.next_in;
  input = strm.input;
  have = strm.avail_in;
  hold = state.hold;
  bits = state.bits;
  _in = have;
  _out = left;
  ret = Z_OK$1;
  inf_leave:
    for (; ; ) {
      switch (state.mode) {
        case HEAD:
          if (state.wrap === 0) {
            state.mode = TYPEDO;
            break;
          }
          while (bits < 16) {
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          if (state.wrap & 2 && hold === 35615) {
            if (state.wbits === 0) {
              state.wbits = 15;
            }
            state.check = 0;
            hbuf[0] = hold & 255;
            hbuf[1] = hold >>> 8 & 255;
            state.check = crc32_1(state.check, hbuf, 2, 0);
            hold = 0;
            bits = 0;
            state.mode = FLAGS;
            break;
          }
          if (state.head) {
            state.head.done = false;
          }
          if (!(state.wrap & 1) || /* check if zlib header allowed */
          (((hold & 255) << 8) + (hold >> 8)) % 31) {
            strm.msg = "incorrect header check";
            state.mode = BAD;
            break;
          }
          if ((hold & 15) !== Z_DEFLATED) {
            strm.msg = "unknown compression method";
            state.mode = BAD;
            break;
          }
          hold >>>= 4;
          bits -= 4;
          len = (hold & 15) + 8;
          if (state.wbits === 0) {
            state.wbits = len;
          }
          if (len > 15 || len > state.wbits) {
            strm.msg = "invalid window size";
            state.mode = BAD;
            break;
          }
          state.dmax = 1 << state.wbits;
          state.flags = 0;
          strm.adler = state.check = 1;
          state.mode = hold & 512 ? DICTID : TYPE;
          hold = 0;
          bits = 0;
          break;
        case FLAGS:
          while (bits < 16) {
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          state.flags = hold;
          if ((state.flags & 255) !== Z_DEFLATED) {
            strm.msg = "unknown compression method";
            state.mode = BAD;
            break;
          }
          if (state.flags & 57344) {
            strm.msg = "unknown header flags set";
            state.mode = BAD;
            break;
          }
          if (state.head) {
            state.head.text = hold >> 8 & 1;
          }
          if (state.flags & 512 && state.wrap & 4) {
            hbuf[0] = hold & 255;
            hbuf[1] = hold >>> 8 & 255;
            state.check = crc32_1(state.check, hbuf, 2, 0);
          }
          hold = 0;
          bits = 0;
          state.mode = TIME;
        case TIME:
          while (bits < 32) {
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          if (state.head) {
            state.head.time = hold;
          }
          if (state.flags & 512 && state.wrap & 4) {
            hbuf[0] = hold & 255;
            hbuf[1] = hold >>> 8 & 255;
            hbuf[2] = hold >>> 16 & 255;
            hbuf[3] = hold >>> 24 & 255;
            state.check = crc32_1(state.check, hbuf, 4, 0);
          }
          hold = 0;
          bits = 0;
          state.mode = OS;
        case OS:
          while (bits < 16) {
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          if (state.head) {
            state.head.xflags = hold & 255;
            state.head.os = hold >> 8;
          }
          if (state.flags & 512 && state.wrap & 4) {
            hbuf[0] = hold & 255;
            hbuf[1] = hold >>> 8 & 255;
            state.check = crc32_1(state.check, hbuf, 2, 0);
          }
          hold = 0;
          bits = 0;
          state.mode = EXLEN;
        case EXLEN:
          if (state.flags & 1024) {
            while (bits < 16) {
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold += input[next++] << bits;
              bits += 8;
            }
            state.length = hold;
            if (state.head) {
              state.head.extra_len = hold;
            }
            if (state.flags & 512 && state.wrap & 4) {
              hbuf[0] = hold & 255;
              hbuf[1] = hold >>> 8 & 255;
              state.check = crc32_1(state.check, hbuf, 2, 0);
            }
            hold = 0;
            bits = 0;
          } else if (state.head) {
            state.head.extra = null;
          }
          state.mode = EXTRA;
        case EXTRA:
          if (state.flags & 1024) {
            copy = state.length;
            if (copy > have) {
              copy = have;
            }
            if (copy) {
              if (state.head) {
                len = state.head.extra_len - state.length;
                if (!state.head.extra) {
                  state.head.extra = new Uint8Array(state.head.extra_len);
                }
                state.head.extra.set(
                  input.subarray(
                    next,
                    // extra field is limited to 65536 bytes
                    // - no need for additional size check
                    next + copy
                  ),
                  /*len + copy > state.head.extra_max - len ? state.head.extra_max : copy,*/
                  len
                );
              }
              if (state.flags & 512 && state.wrap & 4) {
                state.check = crc32_1(state.check, input, copy, next);
              }
              have -= copy;
              next += copy;
              state.length -= copy;
            }
            if (state.length) {
              break inf_leave;
            }
          }
          state.length = 0;
          state.mode = NAME;
        case NAME:
          if (state.flags & 2048) {
            if (have === 0) {
              break inf_leave;
            }
            copy = 0;
            do {
              len = input[next + copy++];
              if (state.head && len && state.length < 65536) {
                state.head.name += String.fromCharCode(len);
              }
            } while (len && copy < have);
            if (state.flags & 512 && state.wrap & 4) {
              state.check = crc32_1(state.check, input, copy, next);
            }
            have -= copy;
            next += copy;
            if (len) {
              break inf_leave;
            }
          } else if (state.head) {
            state.head.name = null;
          }
          state.length = 0;
          state.mode = COMMENT;
        case COMMENT:
          if (state.flags & 4096) {
            if (have === 0) {
              break inf_leave;
            }
            copy = 0;
            do {
              len = input[next + copy++];
              if (state.head && len && state.length < 65536) {
                state.head.comment += String.fromCharCode(len);
              }
            } while (len && copy < have);
            if (state.flags & 512 && state.wrap & 4) {
              state.check = crc32_1(state.check, input, copy, next);
            }
            have -= copy;
            next += copy;
            if (len) {
              break inf_leave;
            }
          } else if (state.head) {
            state.head.comment = null;
          }
          state.mode = HCRC;
        case HCRC:
          if (state.flags & 512) {
            while (bits < 16) {
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold += input[next++] << bits;
              bits += 8;
            }
            if (state.wrap & 4 && hold !== (state.check & 65535)) {
              strm.msg = "header crc mismatch";
              state.mode = BAD;
              break;
            }
            hold = 0;
            bits = 0;
          }
          if (state.head) {
            state.head.hcrc = state.flags >> 9 & 1;
            state.head.done = true;
          }
          strm.adler = state.check = 0;
          state.mode = TYPE;
          break;
        case DICTID:
          while (bits < 32) {
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          strm.adler = state.check = zswap32(hold);
          hold = 0;
          bits = 0;
          state.mode = DICT;
        case DICT:
          if (state.havedict === 0) {
            strm.next_out = put;
            strm.avail_out = left;
            strm.next_in = next;
            strm.avail_in = have;
            state.hold = hold;
            state.bits = bits;
            return Z_NEED_DICT$1;
          }
          strm.adler = state.check = 1;
          state.mode = TYPE;
        case TYPE:
          if (flush === Z_BLOCK || flush === Z_TREES) {
            break inf_leave;
          }
        case TYPEDO:
          if (state.last) {
            hold >>>= bits & 7;
            bits -= bits & 7;
            state.mode = CHECK;
            break;
          }
          while (bits < 3) {
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          state.last = hold & 1;
          hold >>>= 1;
          bits -= 1;
          switch (hold & 3) {
            case 0:
              state.mode = STORED;
              break;
            case 1:
              fixedtables(state);
              state.mode = LEN_;
              if (flush === Z_TREES) {
                hold >>>= 2;
                bits -= 2;
                break inf_leave;
              }
              break;
            case 2:
              state.mode = TABLE;
              break;
            case 3:
              strm.msg = "invalid block type";
              state.mode = BAD;
          }
          hold >>>= 2;
          bits -= 2;
          break;
        case STORED:
          hold >>>= bits & 7;
          bits -= bits & 7;
          while (bits < 32) {
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          if ((hold & 65535) !== (hold >>> 16 ^ 65535)) {
            strm.msg = "invalid stored block lengths";
            state.mode = BAD;
            break;
          }
          state.length = hold & 65535;
          hold = 0;
          bits = 0;
          state.mode = COPY_;
          if (flush === Z_TREES) {
            break inf_leave;
          }
        case COPY_:
          state.mode = COPY;
        case COPY:
          copy = state.length;
          if (copy) {
            if (copy > have) {
              copy = have;
            }
            if (copy > left) {
              copy = left;
            }
            if (copy === 0) {
              break inf_leave;
            }
            output.set(input.subarray(next, next + copy), put);
            have -= copy;
            next += copy;
            left -= copy;
            put += copy;
            state.length -= copy;
            break;
          }
          state.mode = TYPE;
          break;
        case TABLE:
          while (bits < 14) {
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          state.nlen = (hold & 31) + 257;
          hold >>>= 5;
          bits -= 5;
          state.ndist = (hold & 31) + 1;
          hold >>>= 5;
          bits -= 5;
          state.ncode = (hold & 15) + 4;
          hold >>>= 4;
          bits -= 4;
          if (state.nlen > 286 || state.ndist > 30) {
            strm.msg = "too many length or distance symbols";
            state.mode = BAD;
            break;
          }
          state.have = 0;
          state.mode = LENLENS;
        case LENLENS:
          while (state.have < state.ncode) {
            while (bits < 3) {
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold += input[next++] << bits;
              bits += 8;
            }
            state.lens[order[state.have++]] = hold & 7;
            hold >>>= 3;
            bits -= 3;
          }
          while (state.have < 19) {
            state.lens[order[state.have++]] = 0;
          }
          state.lencode = state.lendyn;
          state.lenbits = 7;
          opts = { bits: state.lenbits };
          ret = inftrees(CODES, state.lens, 0, 19, state.lencode, 0, state.work, opts);
          state.lenbits = opts.bits;
          if (ret) {
            strm.msg = "invalid code lengths set";
            state.mode = BAD;
            break;
          }
          state.have = 0;
          state.mode = CODELENS;
        case CODELENS:
          while (state.have < state.nlen + state.ndist) {
            for (; ; ) {
              here = state.lencode[hold & (1 << state.lenbits) - 1];
              here_bits = here >>> 24;
              here_op = here >>> 16 & 255;
              here_val = here & 65535;
              if (here_bits <= bits) {
                break;
              }
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold += input[next++] << bits;
              bits += 8;
            }
            if (here_val < 16) {
              hold >>>= here_bits;
              bits -= here_bits;
              state.lens[state.have++] = here_val;
            } else {
              if (here_val === 16) {
                n = here_bits + 2;
                while (bits < n) {
                  if (have === 0) {
                    break inf_leave;
                  }
                  have--;
                  hold += input[next++] << bits;
                  bits += 8;
                }
                hold >>>= here_bits;
                bits -= here_bits;
                if (state.have === 0) {
                  strm.msg = "invalid bit length repeat";
                  state.mode = BAD;
                  break;
                }
                len = state.lens[state.have - 1];
                copy = 3 + (hold & 3);
                hold >>>= 2;
                bits -= 2;
              } else if (here_val === 17) {
                n = here_bits + 3;
                while (bits < n) {
                  if (have === 0) {
                    break inf_leave;
                  }
                  have--;
                  hold += input[next++] << bits;
                  bits += 8;
                }
                hold >>>= here_bits;
                bits -= here_bits;
                len = 0;
                copy = 3 + (hold & 7);
                hold >>>= 3;
                bits -= 3;
              } else {
                n = here_bits + 7;
                while (bits < n) {
                  if (have === 0) {
                    break inf_leave;
                  }
                  have--;
                  hold += input[next++] << bits;
                  bits += 8;
                }
                hold >>>= here_bits;
                bits -= here_bits;
                len = 0;
                copy = 11 + (hold & 127);
                hold >>>= 7;
                bits -= 7;
              }
              if (state.have + copy > state.nlen + state.ndist) {
                strm.msg = "invalid bit length repeat";
                state.mode = BAD;
                break;
              }
              while (copy--) {
                state.lens[state.have++] = len;
              }
            }
          }
          if (state.mode === BAD) {
            break;
          }
          if (state.lens[256] === 0) {
            strm.msg = "invalid code -- missing end-of-block";
            state.mode = BAD;
            break;
          }
          state.lenbits = 9;
          opts = { bits: state.lenbits };
          ret = inftrees(LENS, state.lens, 0, state.nlen, state.lencode, 0, state.work, opts);
          state.lenbits = opts.bits;
          if (ret) {
            strm.msg = "invalid literal/lengths set";
            state.mode = BAD;
            break;
          }
          state.distbits = 6;
          state.distcode = state.distdyn;
          opts = { bits: state.distbits };
          ret = inftrees(DISTS, state.lens, state.nlen, state.ndist, state.distcode, 0, state.work, opts);
          state.distbits = opts.bits;
          if (ret) {
            strm.msg = "invalid distances set";
            state.mode = BAD;
            break;
          }
          state.mode = LEN_;
          if (flush === Z_TREES) {
            break inf_leave;
          }
        case LEN_:
          state.mode = LEN;
        case LEN:
          if (have >= 6 && left >= 258) {
            strm.next_out = put;
            strm.avail_out = left;
            strm.next_in = next;
            strm.avail_in = have;
            state.hold = hold;
            state.bits = bits;
            inffast(strm, _out);
            put = strm.next_out;
            output = strm.output;
            left = strm.avail_out;
            next = strm.next_in;
            input = strm.input;
            have = strm.avail_in;
            hold = state.hold;
            bits = state.bits;
            if (state.mode === TYPE) {
              state.back = -1;
            }
            break;
          }
          state.back = 0;
          for (; ; ) {
            here = state.lencode[hold & (1 << state.lenbits) - 1];
            here_bits = here >>> 24;
            here_op = here >>> 16 & 255;
            here_val = here & 65535;
            if (here_bits <= bits) {
              break;
            }
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          if (here_op && (here_op & 240) === 0) {
            last_bits = here_bits;
            last_op = here_op;
            last_val = here_val;
            for (; ; ) {
              here = state.lencode[last_val + ((hold & (1 << last_bits + last_op) - 1) >> last_bits)];
              here_bits = here >>> 24;
              here_op = here >>> 16 & 255;
              here_val = here & 65535;
              if (last_bits + here_bits <= bits) {
                break;
              }
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold += input[next++] << bits;
              bits += 8;
            }
            hold >>>= last_bits;
            bits -= last_bits;
            state.back += last_bits;
          }
          hold >>>= here_bits;
          bits -= here_bits;
          state.back += here_bits;
          state.length = here_val;
          if (here_op === 0) {
            state.mode = LIT;
            break;
          }
          if (here_op & 32) {
            state.back = -1;
            state.mode = TYPE;
            break;
          }
          if (here_op & 64) {
            strm.msg = "invalid literal/length code";
            state.mode = BAD;
            break;
          }
          state.extra = here_op & 15;
          state.mode = LENEXT;
        case LENEXT:
          if (state.extra) {
            n = state.extra;
            while (bits < n) {
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold += input[next++] << bits;
              bits += 8;
            }
            state.length += hold & (1 << state.extra) - 1;
            hold >>>= state.extra;
            bits -= state.extra;
            state.back += state.extra;
          }
          state.was = state.length;
          state.mode = DIST;
        case DIST:
          for (; ; ) {
            here = state.distcode[hold & (1 << state.distbits) - 1];
            here_bits = here >>> 24;
            here_op = here >>> 16 & 255;
            here_val = here & 65535;
            if (here_bits <= bits) {
              break;
            }
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          if ((here_op & 240) === 0) {
            last_bits = here_bits;
            last_op = here_op;
            last_val = here_val;
            for (; ; ) {
              here = state.distcode[last_val + ((hold & (1 << last_bits + last_op) - 1) >> last_bits)];
              here_bits = here >>> 24;
              here_op = here >>> 16 & 255;
              here_val = here & 65535;
              if (last_bits + here_bits <= bits) {
                break;
              }
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold += input[next++] << bits;
              bits += 8;
            }
            hold >>>= last_bits;
            bits -= last_bits;
            state.back += last_bits;
          }
          hold >>>= here_bits;
          bits -= here_bits;
          state.back += here_bits;
          if (here_op & 64) {
            strm.msg = "invalid distance code";
            state.mode = BAD;
            break;
          }
          state.offset = here_val;
          state.extra = here_op & 15;
          state.mode = DISTEXT;
        case DISTEXT:
          if (state.extra) {
            n = state.extra;
            while (bits < n) {
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold += input[next++] << bits;
              bits += 8;
            }
            state.offset += hold & (1 << state.extra) - 1;
            hold >>>= state.extra;
            bits -= state.extra;
            state.back += state.extra;
          }
          if (state.offset > state.dmax) {
            strm.msg = "invalid distance too far back";
            state.mode = BAD;
            break;
          }
          state.mode = MATCH;
        case MATCH:
          if (left === 0) {
            break inf_leave;
          }
          copy = _out - left;
          if (state.offset > copy) {
            copy = state.offset - copy;
            if (copy > state.whave) {
              if (state.sane) {
                strm.msg = "invalid distance too far back";
                state.mode = BAD;
                break;
              }
            }
            if (copy > state.wnext) {
              copy -= state.wnext;
              from = state.wsize - copy;
            } else {
              from = state.wnext - copy;
            }
            if (copy > state.length) {
              copy = state.length;
            }
            from_source = state.window;
          } else {
            from_source = output;
            from = put - state.offset;
            copy = state.length;
          }
          if (copy > left) {
            copy = left;
          }
          left -= copy;
          state.length -= copy;
          do {
            output[put++] = from_source[from++];
          } while (--copy);
          if (state.length === 0) {
            state.mode = LEN;
          }
          break;
        case LIT:
          if (left === 0) {
            break inf_leave;
          }
          output[put++] = state.length;
          left--;
          state.mode = LEN;
          break;
        case CHECK:
          if (state.wrap) {
            while (bits < 32) {
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold |= input[next++] << bits;
              bits += 8;
            }
            _out -= left;
            strm.total_out += _out;
            state.total += _out;
            if (state.wrap & 4 && _out) {
              strm.adler = state.check = /*UPDATE_CHECK(state.check, put - _out, _out);*/
              state.flags ? crc32_1(state.check, output, _out, put - _out) : adler32_1(state.check, output, _out, put - _out);
            }
            _out = left;
            if (state.wrap & 4 && (state.flags ? hold : zswap32(hold)) !== state.check) {
              strm.msg = "incorrect data check";
              state.mode = BAD;
              break;
            }
            hold = 0;
            bits = 0;
          }
          state.mode = LENGTH;
        case LENGTH:
          if (state.wrap && state.flags) {
            while (bits < 32) {
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold += input[next++] << bits;
              bits += 8;
            }
            if (state.wrap & 4 && hold !== (state.total & 4294967295)) {
              strm.msg = "incorrect length check";
              state.mode = BAD;
              break;
            }
            hold = 0;
            bits = 0;
          }
          state.mode = DONE;
        case DONE:
          ret = Z_STREAM_END$1;
          break inf_leave;
        case BAD:
          ret = Z_DATA_ERROR$1;
          break inf_leave;
        case MEM:
          return Z_MEM_ERROR$1;
        case SYNC:
        default:
          return Z_STREAM_ERROR$1;
      }
    }
  strm.next_out = put;
  strm.avail_out = left;
  strm.next_in = next;
  strm.avail_in = have;
  state.hold = hold;
  state.bits = bits;
  if (state.wsize || _out !== strm.avail_out && state.mode < BAD && (state.mode < CHECK || flush !== Z_FINISH$1)) {
    if (updatewindow(strm, strm.output, strm.next_out, _out - strm.avail_out)) ;
  }
  _in -= strm.avail_in;
  _out -= strm.avail_out;
  strm.total_in += _in;
  strm.total_out += _out;
  state.total += _out;
  if (state.wrap & 4 && _out) {
    strm.adler = state.check = /*UPDATE_CHECK(state.check, strm.next_out - _out, _out);*/
    state.flags ? crc32_1(state.check, output, _out, strm.next_out - _out) : adler32_1(state.check, output, _out, strm.next_out - _out);
  }
  strm.data_type = state.bits + (state.last ? 64 : 0) + (state.mode === TYPE ? 128 : 0) + (state.mode === LEN_ || state.mode === COPY_ ? 256 : 0);
  if ((_in === 0 && _out === 0 || flush === Z_FINISH$1) && ret === Z_OK$1) {
    ret = Z_BUF_ERROR;
  }
  return ret;
};
const inflateEnd = (strm) => {
  if (inflateStateCheck(strm)) {
    return Z_STREAM_ERROR$1;
  }
  let state = strm.state;
  if (state.window) {
    state.window = null;
  }
  strm.state = null;
  return Z_OK$1;
};
const inflateGetHeader = (strm, head) => {
  if (inflateStateCheck(strm)) {
    return Z_STREAM_ERROR$1;
  }
  const state = strm.state;
  if ((state.wrap & 2) === 0) {
    return Z_STREAM_ERROR$1;
  }
  state.head = head;
  head.done = false;
  return Z_OK$1;
};
const inflateSetDictionary = (strm, dictionary) => {
  const dictLength = dictionary.length;
  let state;
  let dictid;
  let ret;
  if (inflateStateCheck(strm)) {
    return Z_STREAM_ERROR$1;
  }
  state = strm.state;
  if (state.wrap !== 0 && state.mode !== DICT) {
    return Z_STREAM_ERROR$1;
  }
  if (state.mode === DICT) {
    dictid = 1;
    dictid = adler32_1(dictid, dictionary, dictLength, 0);
    if (dictid !== state.check) {
      return Z_DATA_ERROR$1;
    }
  }
  ret = updatewindow(strm, dictionary, dictLength, dictLength);
  if (ret) {
    state.mode = MEM;
    return Z_MEM_ERROR$1;
  }
  state.havedict = 1;
  return Z_OK$1;
};
var inflateReset_1 = inflateReset;
var inflateReset2_1 = inflateReset2;
var inflateResetKeep_1 = inflateResetKeep;
var inflateInit_1 = inflateInit;
var inflateInit2_1 = inflateInit2;
var inflate_2$1 = inflate$2;
var inflateEnd_1 = inflateEnd;
var inflateGetHeader_1 = inflateGetHeader;
var inflateSetDictionary_1 = inflateSetDictionary;
var inflateInfo = "pako inflate (from Nodeca project)";
var inflate_1$2 = {
  inflateReset: inflateReset_1,
  inflateReset2: inflateReset2_1,
  inflateResetKeep: inflateResetKeep_1,
  inflateInit: inflateInit_1,
  inflateInit2: inflateInit2_1,
  inflate: inflate_2$1,
  inflateEnd: inflateEnd_1,
  inflateGetHeader: inflateGetHeader_1,
  inflateSetDictionary: inflateSetDictionary_1,
  inflateInfo
};
function GZheader() {
  this.text = 0;
  this.time = 0;
  this.xflags = 0;
  this.os = 0;
  this.extra = null;
  this.extra_len = 0;
  this.name = "";
  this.comment = "";
  this.hcrc = 0;
  this.done = false;
}
var gzheader = GZheader;
const toString = Object.prototype.toString;
const {
  Z_NO_FLUSH,
  Z_FINISH,
  Z_OK,
  Z_STREAM_END,
  Z_NEED_DICT,
  Z_STREAM_ERROR,
  Z_DATA_ERROR,
  Z_MEM_ERROR
} = constants$2;
function Inflate$1(options) {
  this.options = common.assign({
    chunkSize: 1024 * 64,
    windowBits: 15,
    to: ""
  }, options || {});
  const opt = this.options;
  if (opt.raw && opt.windowBits >= 0 && opt.windowBits < 16) {
    opt.windowBits = -opt.windowBits;
    if (opt.windowBits === 0) {
      opt.windowBits = -15;
    }
  }
  if (opt.windowBits >= 0 && opt.windowBits < 16 && !(options && options.windowBits)) {
    opt.windowBits += 32;
  }
  if (opt.windowBits > 15 && opt.windowBits < 48) {
    if ((opt.windowBits & 15) === 0) {
      opt.windowBits |= 15;
    }
  }
  this.err = 0;
  this.msg = "";
  this.ended = false;
  this.chunks = [];
  this.strm = new zstream();
  this.strm.avail_out = 0;
  let status = inflate_1$2.inflateInit2(
    this.strm,
    opt.windowBits
  );
  if (status !== Z_OK) {
    throw new Error(messages[status]);
  }
  this.header = new gzheader();
  inflate_1$2.inflateGetHeader(this.strm, this.header);
  if (opt.dictionary) {
    if (typeof opt.dictionary === "string") {
      opt.dictionary = strings.string2buf(opt.dictionary);
    } else if (toString.call(opt.dictionary) === "[object ArrayBuffer]") {
      opt.dictionary = new Uint8Array(opt.dictionary);
    }
    if (opt.raw) {
      status = inflate_1$2.inflateSetDictionary(this.strm, opt.dictionary);
      if (status !== Z_OK) {
        throw new Error(messages[status]);
      }
    }
  }
}
Inflate$1.prototype.push = function(data, flush_mode) {
  const strm = this.strm;
  const chunkSize = this.options.chunkSize;
  const dictionary = this.options.dictionary;
  let status, _flush_mode, last_avail_out;
  if (this.ended) return false;
  if (flush_mode === ~~flush_mode) _flush_mode = flush_mode;
  else _flush_mode = flush_mode === true ? Z_FINISH : Z_NO_FLUSH;
  if (toString.call(data) === "[object ArrayBuffer]") {
    strm.input = new Uint8Array(data);
  } else {
    strm.input = data;
  }
  strm.next_in = 0;
  strm.avail_in = strm.input.length;
  for (; ; ) {
    if (strm.avail_out === 0) {
      strm.output = new Uint8Array(chunkSize);
      strm.next_out = 0;
      strm.avail_out = chunkSize;
    }
    status = inflate_1$2.inflate(strm, _flush_mode);
    if (status === Z_NEED_DICT && dictionary) {
      status = inflate_1$2.inflateSetDictionary(strm, dictionary);
      if (status === Z_OK) {
        status = inflate_1$2.inflate(strm, _flush_mode);
      } else if (status === Z_DATA_ERROR) {
        status = Z_NEED_DICT;
      }
    }
    while (strm.avail_in > 0 && status === Z_STREAM_END && strm.state.wrap > 0 && data[strm.next_in] !== 0) {
      inflate_1$2.inflateReset(strm);
      status = inflate_1$2.inflate(strm, _flush_mode);
    }
    switch (status) {
      case Z_STREAM_ERROR:
      case Z_DATA_ERROR:
      case Z_NEED_DICT:
      case Z_MEM_ERROR:
        this.onEnd(status);
        this.ended = true;
        return false;
    }
    last_avail_out = strm.avail_out;
    if (strm.next_out) {
      if (strm.avail_out === 0 || status === Z_STREAM_END) {
        if (this.options.to === "string") {
          let next_out_utf8 = strings.utf8border(strm.output, strm.next_out);
          let tail = strm.next_out - next_out_utf8;
          let utf8str = strings.buf2string(strm.output, next_out_utf8);
          strm.next_out = tail;
          strm.avail_out = chunkSize - tail;
          if (tail) strm.output.set(strm.output.subarray(next_out_utf8, next_out_utf8 + tail), 0);
          this.onData(utf8str);
        } else {
          this.onData(strm.output.length === strm.next_out ? strm.output : strm.output.subarray(0, strm.next_out));
        }
      }
    }
    if (status === Z_OK && last_avail_out === 0) continue;
    if (status === Z_STREAM_END) {
      status = inflate_1$2.inflateEnd(this.strm);
      this.onEnd(status);
      this.ended = true;
      return true;
    }
    if (strm.avail_in === 0) break;
  }
  return true;
};
Inflate$1.prototype.onData = function(chunk) {
  this.chunks.push(chunk);
};
Inflate$1.prototype.onEnd = function(status) {
  if (status === Z_OK) {
    if (this.options.to === "string") {
      this.result = this.chunks.join("");
    } else {
      this.result = common.flattenChunks(this.chunks);
    }
  }
  this.chunks = [];
  this.err = status;
  this.msg = this.strm.msg;
};
function inflate$1(input, options) {
  const inflator = new Inflate$1(options);
  inflator.push(input);
  if (inflator.err) throw inflator.msg || messages[inflator.err];
  return inflator.result;
}
var inflate_2 = inflate$1;
var inflate_1$1 = {
  inflate: inflate_2
};
const { inflate } = inflate_1$1;
var inflate_1 = inflate;
var eventemitter3 = { exports: {} };
(function(module) {
  var has = Object.prototype.hasOwnProperty, prefix = "~";
  function Events() {
  }
  if (Object.create) {
    Events.prototype = /* @__PURE__ */ Object.create(null);
    if (!new Events().__proto__) prefix = false;
  }
  function EE(fn, context, once) {
    this.fn = fn;
    this.context = context;
    this.once = once || false;
  }
  function addListener(emitter, event, fn, context, once) {
    if (typeof fn !== "function") {
      throw new TypeError("The listener must be a function");
    }
    var listener = new EE(fn, context || emitter, once), evt = prefix ? prefix + event : event;
    if (!emitter._events[evt]) emitter._events[evt] = listener, emitter._eventsCount++;
    else if (!emitter._events[evt].fn) emitter._events[evt].push(listener);
    else emitter._events[evt] = [emitter._events[evt], listener];
    return emitter;
  }
  function clearEvent(emitter, evt) {
    if (--emitter._eventsCount === 0) emitter._events = new Events();
    else delete emitter._events[evt];
  }
  function EventEmitter2() {
    this._events = new Events();
    this._eventsCount = 0;
  }
  EventEmitter2.prototype.eventNames = function eventNames() {
    var names = [], events, name;
    if (this._eventsCount === 0) return names;
    for (name in events = this._events) {
      if (has.call(events, name)) names.push(prefix ? name.slice(1) : name);
    }
    if (Object.getOwnPropertySymbols) {
      return names.concat(Object.getOwnPropertySymbols(events));
    }
    return names;
  };
  EventEmitter2.prototype.listeners = function listeners(event) {
    var evt = prefix ? prefix + event : event, handlers = this._events[evt];
    if (!handlers) return [];
    if (handlers.fn) return [handlers.fn];
    for (var i = 0, l = handlers.length, ee = new Array(l); i < l; i++) {
      ee[i] = handlers[i].fn;
    }
    return ee;
  };
  EventEmitter2.prototype.listenerCount = function listenerCount(event) {
    var evt = prefix ? prefix + event : event, listeners = this._events[evt];
    if (!listeners) return 0;
    if (listeners.fn) return 1;
    return listeners.length;
  };
  EventEmitter2.prototype.emit = function emit(event, a1, a2, a3, a4, a5) {
    var evt = prefix ? prefix + event : event;
    if (!this._events[evt]) return false;
    var listeners = this._events[evt], len = arguments.length, args, i;
    if (listeners.fn) {
      if (listeners.once) this.removeListener(event, listeners.fn, void 0, true);
      switch (len) {
        case 1:
          return listeners.fn.call(listeners.context), true;
        case 2:
          return listeners.fn.call(listeners.context, a1), true;
        case 3:
          return listeners.fn.call(listeners.context, a1, a2), true;
        case 4:
          return listeners.fn.call(listeners.context, a1, a2, a3), true;
        case 5:
          return listeners.fn.call(listeners.context, a1, a2, a3, a4), true;
        case 6:
          return listeners.fn.call(listeners.context, a1, a2, a3, a4, a5), true;
      }
      for (i = 1, args = new Array(len - 1); i < len; i++) {
        args[i - 1] = arguments[i];
      }
      listeners.fn.apply(listeners.context, args);
    } else {
      var length = listeners.length, j;
      for (i = 0; i < length; i++) {
        if (listeners[i].once) this.removeListener(event, listeners[i].fn, void 0, true);
        switch (len) {
          case 1:
            listeners[i].fn.call(listeners[i].context);
            break;
          case 2:
            listeners[i].fn.call(listeners[i].context, a1);
            break;
          case 3:
            listeners[i].fn.call(listeners[i].context, a1, a2);
            break;
          case 4:
            listeners[i].fn.call(listeners[i].context, a1, a2, a3);
            break;
          default:
            if (!args) for (j = 1, args = new Array(len - 1); j < len; j++) {
              args[j - 1] = arguments[j];
            }
            listeners[i].fn.apply(listeners[i].context, args);
        }
      }
    }
    return true;
  };
  EventEmitter2.prototype.on = function on(event, fn, context) {
    return addListener(this, event, fn, context, false);
  };
  EventEmitter2.prototype.once = function once(event, fn, context) {
    return addListener(this, event, fn, context, true);
  };
  EventEmitter2.prototype.removeListener = function removeListener(event, fn, context, once) {
    var evt = prefix ? prefix + event : event;
    if (!this._events[evt]) return this;
    if (!fn) {
      clearEvent(this, evt);
      return this;
    }
    var listeners = this._events[evt];
    if (listeners.fn) {
      if (listeners.fn === fn && (!once || listeners.once) && (!context || listeners.context === context)) {
        clearEvent(this, evt);
      }
    } else {
      for (var i = 0, events = [], length = listeners.length; i < length; i++) {
        if (listeners[i].fn !== fn || once && !listeners[i].once || context && listeners[i].context !== context) {
          events.push(listeners[i]);
        }
      }
      if (events.length) this._events[evt] = events.length === 1 ? events[0] : events;
      else clearEvent(this, evt);
    }
    return this;
  };
  EventEmitter2.prototype.removeAllListeners = function removeAllListeners(event) {
    var evt;
    if (event) {
      evt = prefix ? prefix + event : event;
      if (this._events[evt]) clearEvent(this, evt);
    } else {
      this._events = new Events();
      this._eventsCount = 0;
    }
    return this;
  };
  EventEmitter2.prototype.off = EventEmitter2.prototype.removeListener;
  EventEmitter2.prototype.addListener = EventEmitter2.prototype.on;
  EventEmitter2.prefixed = prefix;
  EventEmitter2.EventEmitter = EventEmitter2;
  {
    module.exports = EventEmitter2;
  }
})(eventemitter3);
var eventemitter3Exports = eventemitter3.exports;
const EventEmitter = /* @__PURE__ */ getDefaultExportFromCjs(eventemitter3Exports);
function chunks(array2, size) {
  return Array.apply(0, new Array(Math.ceil(array2.length / size))).map((_, index) => array2.slice(index * size, (index + 1) * size));
}
const isVersionedTransaction = (tx) => {
  return "version" in tx;
};
function decode$2(array2) {
  const decoder = new TextDecoder("utf-8");
  return decoder.decode(array2);
}
function encode$1(data) {
  return bs58$1.encode(data);
}
function decode(data) {
  return Buffer$1.from(data, "base64");
}
function isCompositeAccounts(accountItem) {
  return "accounts" in accountItem;
}
async function idlAddress(programId) {
  const base = (await PublicKey.findProgramAddress([], programId))[0];
  return await PublicKey.createWithSeed(base, seed(), programId);
}
function seed() {
  return "anchor:idl";
}
const IDL_ACCOUNT_LAYOUT = dist$1.struct([
  dist$1.publicKey("authority"),
  dist$1.vecU8("data")
]);
function decodeIdlAccount(data) {
  return IDL_ACCOUNT_LAYOUT.decode(data);
}
function convertIdlToCamelCase(idl) {
  const KEYS_TO_CONVERT = ["name", "path", "account", "relations", "generic"];
  const toCamelCase = (s) => s.split(".").map((part) => camelCase$1(part, { locale: false })).join(".");
  const recursivelyConvertNamesToCamelCase = (obj) => {
    for (const key in obj) {
      const val = obj[key];
      if (KEYS_TO_CONVERT.includes(key)) {
        obj[key] = Array.isArray(val) ? val.map(toCamelCase) : toCamelCase(val);
      } else if (typeof val === "object") {
        recursivelyConvertNamesToCamelCase(val);
      }
    }
  };
  const camelCasedIdl = structuredClone(idl);
  recursivelyConvertNamesToCamelCase(camelCasedIdl);
  return camelCasedIdl;
}
function handleDefinedFields(fields, unitCb, namedCb, tupleCb) {
  if (!(fields === null || fields === void 0 ? void 0 : fields.length))
    return unitCb();
  if (fields[0].name) {
    return namedCb(fields);
  }
  return tupleCb(fields);
}
function parseIdlErrors(idl) {
  const errors2 = /* @__PURE__ */ new Map();
  if (idl.errors) {
    idl.errors.forEach((e) => {
      var _a;
      let msg = (_a = e.msg) !== null && _a !== void 0 ? _a : e.name;
      errors2.set(e.code, msg);
    });
  }
  return errors2;
}
function toInstruction(idlIx, ...args) {
  if (idlIx.args.length != args.length) {
    throw new Error("Invalid argument length");
  }
  const ix = {};
  let idx = 0;
  idlIx.args.forEach((ixArg) => {
    ix[ixArg.name] = args[idx];
    idx += 1;
  });
  return ix;
}
function validateAccounts(ixAccounts, accounts2 = {}) {
  ixAccounts.forEach((acc) => {
    if (isCompositeAccounts(acc)) {
      validateAccounts(acc.accounts, accounts2[acc.name]);
    } else {
      if (!accounts2[acc.name]) {
        throw new Error(`Account \`${acc.name}\` not provided.`);
      }
    }
  });
}
function translateAddress(address2) {
  return address2 instanceof PublicKey ? address2 : new PublicKey(address2);
}
class StructError extends TypeError {
  constructor(failure, failures) {
    let cached;
    const {
      message,
      ...rest
    } = failure;
    const {
      path
    } = failure;
    const msg = path.length === 0 ? message : "At path: " + path.join(".") + " -- " + message;
    super(msg);
    this.value = void 0;
    this.key = void 0;
    this.type = void 0;
    this.refinement = void 0;
    this.path = void 0;
    this.branch = void 0;
    this.failures = void 0;
    Object.assign(this, rest);
    this.name = this.constructor.name;
    this.failures = () => {
      var _cached;
      return (_cached = cached) != null ? _cached : cached = [failure, ...failures()];
    };
  }
}
function isIterable(x) {
  return isObject(x) && typeof x[Symbol.iterator] === "function";
}
function isObject(x) {
  return typeof x === "object" && x != null;
}
function print(value) {
  return typeof value === "string" ? JSON.stringify(value) : "" + value;
}
function shiftIterator(input) {
  const {
    done,
    value
  } = input.next();
  return done ? void 0 : value;
}
function toFailure(result, context, struct2, value) {
  if (result === true) {
    return;
  } else if (result === false) {
    result = {};
  } else if (typeof result === "string") {
    result = {
      message: result
    };
  }
  const {
    path,
    branch
  } = context;
  const {
    type: type2
  } = struct2;
  const {
    refinement,
    message = "Expected a value of type `" + type2 + "`" + (refinement ? " with refinement `" + refinement + "`" : "") + ", but received: `" + print(value) + "`"
  } = result;
  return {
    value,
    type: type2,
    refinement,
    key: path[path.length - 1],
    path,
    branch,
    ...result,
    message
  };
}
function* toFailures(result, context, struct2, value) {
  if (!isIterable(result)) {
    result = [result];
  }
  for (const r of result) {
    const failure = toFailure(r, context, struct2, value);
    if (failure) {
      yield failure;
    }
  }
}
function* run(value, struct2, options) {
  if (options === void 0) {
    options = {};
  }
  const {
    path = [],
    branch = [value],
    coerce: coerce2 = false,
    mask: mask2 = false
  } = options;
  const ctx = {
    path,
    branch
  };
  if (coerce2) {
    value = struct2.coercer(value, ctx);
    if (mask2 && struct2.type !== "type" && isObject(struct2.schema) && isObject(value) && !Array.isArray(value)) {
      for (const key in value) {
        if (struct2.schema[key] === void 0) {
          delete value[key];
        }
      }
    }
  }
  let valid = true;
  for (const failure of struct2.validator(value, ctx)) {
    valid = false;
    yield [failure, void 0];
  }
  for (let [k, v, s] of struct2.entries(value, ctx)) {
    const ts = run(v, s, {
      path: k === void 0 ? path : [...path, k],
      branch: k === void 0 ? branch : [...branch, v],
      coerce: coerce2,
      mask: mask2
    });
    for (const t of ts) {
      if (t[0]) {
        valid = false;
        yield [t[0], void 0];
      } else if (coerce2) {
        v = t[1];
        if (k === void 0) {
          value = v;
        } else if (value instanceof Map) {
          value.set(k, v);
        } else if (value instanceof Set) {
          value.add(v);
        } else if (isObject(value)) {
          value[k] = v;
        }
      }
    }
  }
  if (valid) {
    for (const failure of struct2.refiner(value, ctx)) {
      valid = false;
      yield [failure, void 0];
    }
  }
  if (valid) {
    yield [void 0, value];
  }
}
class Struct {
  constructor(props) {
    this.TYPE = void 0;
    this.type = void 0;
    this.schema = void 0;
    this.coercer = void 0;
    this.validator = void 0;
    this.refiner = void 0;
    this.entries = void 0;
    const {
      type: type2,
      schema,
      validator,
      refiner,
      coercer = (value) => value,
      entries = function* () {
      }
    } = props;
    this.type = type2;
    this.schema = schema;
    this.entries = entries;
    this.coercer = coercer;
    if (validator) {
      this.validator = (value, context) => {
        const result = validator(value, context);
        return toFailures(result, context, this, value);
      };
    } else {
      this.validator = () => [];
    }
    if (refiner) {
      this.refiner = (value, context) => {
        const result = refiner(value, context);
        return toFailures(result, context, this, value);
      };
    } else {
      this.refiner = () => [];
    }
  }
  /**
   * Assert that a value passes the struct's validation, throwing if it doesn't.
   */
  assert(value) {
    return assert(value, this);
  }
  /**
   * Create a value with the struct's coercion logic, then validate it.
   */
  create(value) {
    return create(value, this);
  }
  /**
   * Check if a value passes the struct's validation.
   */
  is(value) {
    return is(value, this);
  }
  /**
   * Mask a value, coercing and validating it, but returning only the subset of
   * properties defined by the struct's schema.
   */
  mask(value) {
    return mask(value, this);
  }
  /**
   * Validate a value with the struct's validation logic, returning a tuple
   * representing the result.
   *
   * You may optionally pass `true` for the `withCoercion` argument to coerce
   * the value before attempting to validate it. If you do, the result will
   * contain the coerced result when successful.
   */
  validate(value, options) {
    if (options === void 0) {
      options = {};
    }
    return validate(value, this, options);
  }
}
function assert(value, struct2) {
  const result = validate(value, struct2);
  if (result[0]) {
    throw result[0];
  }
}
function create(value, struct2) {
  const result = validate(value, struct2, {
    coerce: true
  });
  if (result[0]) {
    throw result[0];
  } else {
    return result[1];
  }
}
function mask(value, struct2) {
  const result = validate(value, struct2, {
    coerce: true,
    mask: true
  });
  if (result[0]) {
    throw result[0];
  } else {
    return result[1];
  }
}
function is(value, struct2) {
  const result = validate(value, struct2);
  return !result[0];
}
function validate(value, struct2, options) {
  if (options === void 0) {
    options = {};
  }
  const tuples = run(value, struct2, options);
  const tuple = shiftIterator(tuples);
  if (tuple[0]) {
    const error = new StructError(tuple[0], function* () {
      for (const t of tuples) {
        if (t[0]) {
          yield t[0];
        }
      }
    });
    return [error, void 0];
  } else {
    const v = tuple[1];
    return [void 0, v];
  }
}
function define(name, validator) {
  return new Struct({
    type: name,
    schema: null,
    validator
  });
}
function any() {
  return define("any", () => true);
}
function array(Element) {
  return new Struct({
    type: "array",
    schema: Element,
    *entries(value) {
      if (Element && Array.isArray(value)) {
        for (const [i, v] of value.entries()) {
          yield [i, v, Element];
        }
      }
    },
    coercer(value) {
      return Array.isArray(value) ? value.slice() : value;
    },
    validator(value) {
      return Array.isArray(value) || "Expected an array value, but received: " + print(value);
    }
  });
}
function boolean() {
  return define("boolean", (value) => {
    return typeof value === "boolean";
  });
}
function literal(constant) {
  const description = print(constant);
  return new Struct({
    type: "literal",
    schema: constant,
    validator(value) {
      return value === constant || "Expected the literal `" + description + "`, but received: " + print(value);
    }
  });
}
function nullable(struct2) {
  return new Struct({
    ...struct2,
    validator: (value, ctx) => value === null || struct2.validator(value, ctx),
    refiner: (value, ctx) => value === null || struct2.refiner(value, ctx)
  });
}
function number() {
  return define("number", (value) => {
    return typeof value === "number" && !isNaN(value) || "Expected a number, but received: " + print(value);
  });
}
function optional(struct2) {
  return new Struct({
    ...struct2,
    validator: (value, ctx) => value === void 0 || struct2.validator(value, ctx),
    refiner: (value, ctx) => value === void 0 || struct2.refiner(value, ctx)
  });
}
function string() {
  return define("string", (value) => {
    return typeof value === "string" || "Expected a string, but received: " + print(value);
  });
}
function type(schema) {
  const keys = Object.keys(schema);
  return new Struct({
    type: "type",
    schema,
    *entries(value) {
      if (isObject(value)) {
        for (const k of keys) {
          yield [k, value[k], schema[k]];
        }
      }
    },
    validator(value) {
      return isObject(value) || "Expected an object, but received: " + print(value);
    }
  });
}
function union$1(Structs) {
  const description = Structs.map((s) => s.type).join(" | ");
  return new Struct({
    type: "union",
    schema: null,
    coercer(value, ctx) {
      const firstMatch = Structs.find((s) => {
        const [e] = s.validate(value, {
          coerce: true
        });
        return !e;
      }) || unknown();
      return firstMatch.coercer(value, ctx);
    },
    validator(value, ctx) {
      const failures = [];
      for (const S of Structs) {
        const [...tuples] = run(value, S, ctx);
        const [first] = tuples;
        if (!first[0]) {
          return [];
        } else {
          for (const [failure] of tuples) {
            if (failure) {
              failures.push(failure);
            }
          }
        }
      }
      return ["Expected the value to satisfy a union of `" + description + "`, but received: " + print(value), ...failures];
    }
  });
}
function unknown() {
  return define("unknown", () => true);
}
function coerce(struct2, condition, coercer) {
  return new Struct({
    ...struct2,
    coercer: (value, ctx) => {
      return is(value, condition) ? struct2.coercer(coercer(value, ctx), ctx) : struct2.coercer(value, ctx);
    }
  });
}
const GET_MULTIPLE_ACCOUNTS_LIMIT = 99;
async function getMultipleAccountsAndContext(connection2, publicKeys, commitment) {
  if (publicKeys.length <= GET_MULTIPLE_ACCOUNTS_LIMIT) {
    return await getMultipleAccountsAndContextCore(connection2, publicKeys, commitment);
  } else {
    const batches = chunks(publicKeys, GET_MULTIPLE_ACCOUNTS_LIMIT);
    const results = await Promise.all(batches.map((batch) => getMultipleAccountsAndContextCore(connection2, batch, commitment)));
    return results.flat();
  }
}
async function getMultipleAccountsAndContextCore(connection2, publicKeys, commitmentOverride) {
  const commitment = commitmentOverride !== null && commitmentOverride !== void 0 ? commitmentOverride : connection2.commitment;
  const { value: accountInfos, context } = await connection2.getMultipleAccountsInfoAndContext(publicKeys, commitment);
  const accounts2 = accountInfos.map((account, idx) => {
    if (account === null) {
      return null;
    }
    return {
      publicKey: publicKeys[idx],
      account,
      context
    };
  });
  return accounts2;
}
async function simulateTransaction(connection2, transaction, signers, commitment, includeAccounts) {
  var _a;
  if (signers && signers.length > 0) {
    transaction.sign(...signers);
  }
  const message = transaction._compile();
  const signData = message.serialize();
  const wireTransaction = transaction._serialize(signData);
  const encodedTransaction = wireTransaction.toString("base64");
  const config = {
    encoding: "base64",
    commitment: commitment !== null && commitment !== void 0 ? commitment : connection2.commitment
  };
  if (includeAccounts) {
    const addresses = (Array.isArray(includeAccounts) ? includeAccounts : message.nonProgramIds()).map((key) => key.toBase58());
    config["accounts"] = {
      encoding: "base64",
      addresses
    };
  }
  if (signers && signers.length > 0) {
    config.sigVerify = true;
  }
  const args = [encodedTransaction, config];
  const unsafeRes = await connection2._rpcRequest("simulateTransaction", args);
  const res = create(unsafeRes, SimulatedTransactionResponseStruct);
  if ("error" in res) {
    let logs;
    if ("data" in res.error) {
      logs = (_a = res.error.data) === null || _a === void 0 ? void 0 : _a.logs;
      if (logs && Array.isArray(logs)) {
        const traceIndent = "\n    ";
        const logTrace = traceIndent + logs.join(traceIndent);
        console.error(res.error.message, logTrace);
      }
    }
    throw new SendTransactionError("failed to simulate transaction: " + res.error.message, logs);
  }
  return res.result;
}
function jsonRpcResult(schema) {
  return coerce(createRpcResult(schema), UnknownRpcResult, (value) => {
    if ("error" in value) {
      return value;
    } else {
      return {
        ...value,
        result: create(value.result, schema)
      };
    }
  });
}
const UnknownRpcResult = createRpcResult(unknown());
function createRpcResult(result) {
  return union$1([
    type({
      jsonrpc: literal("2.0"),
      id: string(),
      result
    }),
    type({
      jsonrpc: literal("2.0"),
      id: string(),
      error: type({
        code: unknown(),
        message: string(),
        data: optional(any())
      })
    })
  ]);
}
function jsonRpcResultAndContext(value) {
  return jsonRpcResult(type({
    context: type({
      slot: number()
    }),
    value
  }));
}
const SimulatedTransactionResponseStruct = jsonRpcResultAndContext(type({
  err: nullable(union$1([type({}), string()])),
  logs: nullable(array(string())),
  accounts: optional(nullable(array(nullable(type({
    executable: boolean(),
    owner: string(),
    lamports: number(),
    data: array(string()),
    rentEpoch: optional(number())
  }))))),
  unitsConsumed: optional(number())
}));
class AnchorProvider {
  /**
   * @param connection The cluster connection where the program is deployed.
   * @param wallet     The wallet used to pay for and sign all transactions.
   * @param opts       Transaction confirmation options to use by default.
   */
  constructor(connection2, wallet, opts = AnchorProvider.defaultOptions()) {
    this.connection = connection2;
    this.wallet = wallet;
    this.opts = opts;
    this.publicKey = wallet === null || wallet === void 0 ? void 0 : wallet.publicKey;
  }
  static defaultOptions() {
    return {
      preflightCommitment: "processed",
      commitment: "processed"
    };
  }
  /**
   * Returns a `Provider` with a wallet read from the local filesystem.
   *
   * @param url  The network cluster url.
   * @param opts The default transaction confirmation options.
   *
   * (This api is for Node only.)
   */
  static local(url, opts = AnchorProvider.defaultOptions()) {
    {
      throw new Error(`Provider local is not available on browser.`);
    }
  }
  /**
   * Returns a `Provider` read from the `ANCHOR_PROVIDER_URL` environment
   * variable
   *
   * (This api is for Node only.)
   */
  static env() {
    {
      throw new Error(`Provider env is not available on browser.`);
    }
  }
  /**
   * Sends the given transaction, paid for and signed by the provider's wallet.
   *
   * @param tx      The transaction to send.
   * @param signers The signers of the transaction.
   * @param opts    Transaction confirmation options.
   */
  async sendAndConfirm(tx, signers, opts) {
    var _a, _b, _c, _d;
    if (opts === void 0) {
      opts = this.opts;
    }
    if (isVersionedTransaction(tx)) {
      if (signers) {
        tx.sign(signers);
      }
    } else {
      tx.feePayer = (_a = tx.feePayer) !== null && _a !== void 0 ? _a : this.wallet.publicKey;
      tx.recentBlockhash = (await this.connection.getLatestBlockhash(opts.preflightCommitment)).blockhash;
      if (signers) {
        for (const signer of signers) {
          tx.partialSign(signer);
        }
      }
    }
    tx = await this.wallet.signTransaction(tx);
    const rawTx = tx.serialize();
    try {
      return await sendAndConfirmRawTransaction(this.connection, rawTx, opts);
    } catch (err) {
      if (err instanceof ConfirmError) {
        const txSig = encode$1(isVersionedTransaction(tx) ? ((_b = tx.signatures) === null || _b === void 0 ? void 0 : _b[0]) || new Uint8Array() : (_c = tx.signature) !== null && _c !== void 0 ? _c : new Uint8Array());
        const maxVer = isVersionedTransaction(tx) ? 0 : void 0;
        const failedTx = await this.connection.getTransaction(txSig, {
          commitment: "confirmed",
          maxSupportedTransactionVersion: maxVer
        });
        if (!failedTx) {
          throw err;
        } else {
          const logs = (_d = failedTx.meta) === null || _d === void 0 ? void 0 : _d.logMessages;
          throw !logs ? err : new SendTransactionError(err.message, logs);
        }
      } else {
        throw err;
      }
    }
  }
  /**
   * Similar to `send`, but for an array of transactions and signers.
   * All transactions need to be of the same type, it doesn't support a mix of `VersionedTransaction`s and `Transaction`s.
   *
   * @param txWithSigners Array of transactions and signers.
   * @param opts          Transaction confirmation options.
   */
  async sendAll(txWithSigners, opts) {
    var _a, _b, _c;
    if (opts === void 0) {
      opts = this.opts;
    }
    const recentBlockhash = (await this.connection.getLatestBlockhash(opts.preflightCommitment)).blockhash;
    let txs = txWithSigners.map((r) => {
      var _a2, _b2;
      if (isVersionedTransaction(r.tx)) {
        let tx = r.tx;
        if (r.signers) {
          tx.sign(r.signers);
        }
        return tx;
      } else {
        let tx = r.tx;
        let signers = (_a2 = r.signers) !== null && _a2 !== void 0 ? _a2 : [];
        tx.feePayer = (_b2 = tx.feePayer) !== null && _b2 !== void 0 ? _b2 : this.wallet.publicKey;
        tx.recentBlockhash = recentBlockhash;
        signers.forEach((kp) => {
          tx.partialSign(kp);
        });
        return tx;
      }
    });
    const signedTxs = await this.wallet.signAllTransactions(txs);
    const sigs = [];
    for (let k = 0; k < txs.length; k += 1) {
      const tx = signedTxs[k];
      const rawTx = tx.serialize();
      try {
        sigs.push(await sendAndConfirmRawTransaction(this.connection, rawTx, opts));
      } catch (err) {
        if (err instanceof ConfirmError) {
          const txSig = encode$1(isVersionedTransaction(tx) ? ((_a = tx.signatures) === null || _a === void 0 ? void 0 : _a[0]) || new Uint8Array() : (_b = tx.signature) !== null && _b !== void 0 ? _b : new Uint8Array());
          const maxVer = isVersionedTransaction(tx) ? 0 : void 0;
          const failedTx = await this.connection.getTransaction(txSig, {
            commitment: "confirmed",
            maxSupportedTransactionVersion: maxVer
          });
          if (!failedTx) {
            throw err;
          } else {
            const logs = (_c = failedTx.meta) === null || _c === void 0 ? void 0 : _c.logMessages;
            throw !logs ? err : new SendTransactionError(err.message, logs);
          }
        } else {
          throw err;
        }
      }
    }
    return sigs;
  }
  /**
   * Simulates the given transaction, returning emitted logs from execution.
   *
   * @param tx      The transaction to send.
   * @param signers The signers of the transaction. If unset, the transaction
   *                will be simulated with the "sigVerify: false" option. This
   *                allows for simulation of transactions without asking the
   *                wallet for a signature.
   * @param opts    Transaction confirmation options.
   */
  async simulate(tx, signers, commitment, includeAccounts) {
    let recentBlockhash = (await this.connection.getLatestBlockhash(commitment !== null && commitment !== void 0 ? commitment : this.connection.commitment)).blockhash;
    let result;
    if (isVersionedTransaction(tx)) {
      if (signers && signers.length > 0) {
        tx.sign(signers);
        tx = await this.wallet.signTransaction(tx);
      }
      result = await this.connection.simulateTransaction(tx, { commitment });
    } else {
      tx.feePayer = tx.feePayer || this.wallet.publicKey;
      tx.recentBlockhash = recentBlockhash;
      if (signers && signers.length > 0) {
        tx = await this.wallet.signTransaction(tx);
      }
      result = await simulateTransaction(this.connection, tx, signers, commitment, includeAccounts);
    }
    if (result.value.err) {
      throw new SimulateError(result.value);
    }
    return result.value;
  }
}
class SimulateError extends Error {
  constructor(simulationResponse, message) {
    super(message);
    this.simulationResponse = simulationResponse;
  }
}
async function sendAndConfirmRawTransaction(connection2, rawTransaction, options) {
  const sendOptions = options ? {
    skipPreflight: options.skipPreflight,
    preflightCommitment: options.preflightCommitment || options.commitment,
    maxRetries: options.maxRetries,
    minContextSlot: options.minContextSlot
  } : {};
  let status;
  const startTime = Date.now();
  while (Date.now() - startTime < 6e4) {
    try {
      const signature = await connection2.sendRawTransaction(rawTransaction, sendOptions);
      if (options === null || options === void 0 ? void 0 : options.blockhash) {
        if (sendOptions.maxRetries === 0) {
          const abortSignal = AbortSignal.timeout(15e3);
          status = (await connection2.confirmTransaction({ abortSignal, signature, ...options.blockhash }, options && options.commitment)).value;
        } else {
          status = (await connection2.confirmTransaction({ signature, ...options.blockhash }, options && options.commitment)).value;
        }
      } else {
        status = (await connection2.confirmTransaction(signature, options && options.commitment)).value;
      }
      if (status.err) {
        throw new ConfirmError(`Raw transaction ${signature} failed (${JSON.stringify(status)})`);
      }
      return signature;
    } catch (err) {
      if (err.name === "TimeoutError") {
        continue;
      }
      throw err;
    }
  }
  throw Error("Transaction failed to confirm in 60s");
}
class ConfirmError extends Error {
  constructor(message) {
    super(message);
  }
}
function setProvider(provider) {
  _provider = provider;
}
function getProvider() {
  if (_provider === null) {
    return AnchorProvider.local();
  }
  return _provider;
}
let _provider = null;
var commonjsGlobal = typeof globalThis !== "undefined" ? globalThis : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : {};
var dist = {};
Object.defineProperty(dist, "__esModule", { value: true });
var ANCHOR_ERROR__REQUIRE_EQ_VIOLATED = dist.ANCHOR_ERROR__REQUIRE_EQ_VIOLATED = ANCHOR_ERROR__REQUIRE_VIOLATED = dist.ANCHOR_ERROR__REQUIRE_VIOLATED = ANCHOR_ERROR__CONSTRAINT_MINT_TRANSFER_HOOK_EXTENSION_PROGRAM_ID = dist.ANCHOR_ERROR__CONSTRAINT_MINT_TRANSFER_HOOK_EXTENSION_PROGRAM_ID = ANCHOR_ERROR__CONSTRAINT_MINT_TRANSFER_HOOK_EXTENSION_AUTHORITY = dist.ANCHOR_ERROR__CONSTRAINT_MINT_TRANSFER_HOOK_EXTENSION_AUTHORITY = ANCHOR_ERROR__CONSTRAINT_MINT_TRANSFER_HOOK_EXTENSION = dist.ANCHOR_ERROR__CONSTRAINT_MINT_TRANSFER_HOOK_EXTENSION = ANCHOR_ERROR__CONSTRAINT_MINT_PERMANENT_DELEGATE_EXTENSION_DELEGATE = dist.ANCHOR_ERROR__CONSTRAINT_MINT_PERMANENT_DELEGATE_EXTENSION_DELEGATE = ANCHOR_ERROR__CONSTRAINT_MINT_PERMANENT_DELEGATE_EXTENSION = dist.ANCHOR_ERROR__CONSTRAINT_MINT_PERMANENT_DELEGATE_EXTENSION = ANCHOR_ERROR__CONSTRAINT_MINT_CLOSE_AUTHORITY_EXTENSION_AUTHORITY = dist.ANCHOR_ERROR__CONSTRAINT_MINT_CLOSE_AUTHORITY_EXTENSION_AUTHORITY = ANCHOR_ERROR__CONSTRAINT_MINT_CLOSE_AUTHORITY_EXTENSION = dist.ANCHOR_ERROR__CONSTRAINT_MINT_CLOSE_AUTHORITY_EXTENSION = ANCHOR_ERROR__CONSTRAINT_MINT_METADATA_POINTER_EXTENSION_METADATA_ADDRESS = dist.ANCHOR_ERROR__CONSTRAINT_MINT_METADATA_POINTER_EXTENSION_METADATA_ADDRESS = ANCHOR_ERROR__CONSTRAINT_MINT_METADATA_POINTER_EXTENSION_AUTHORITY = dist.ANCHOR_ERROR__CONSTRAINT_MINT_METADATA_POINTER_EXTENSION_AUTHORITY = ANCHOR_ERROR__CONSTRAINT_MINT_METADATA_POINTER_EXTENSION = dist.ANCHOR_ERROR__CONSTRAINT_MINT_METADATA_POINTER_EXTENSION = ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_MEMBER_POINTER_EXTENSION_MEMBER_ADDRESS = dist.ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_MEMBER_POINTER_EXTENSION_MEMBER_ADDRESS = ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_MEMBER_POINTER_EXTENSION_AUTHORITY = dist.ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_MEMBER_POINTER_EXTENSION_AUTHORITY = ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_MEMBER_POINTER_EXTENSION = dist.ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_MEMBER_POINTER_EXTENSION = ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_POINTER_EXTENSION_GROUP_ADDRESS = dist.ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_POINTER_EXTENSION_GROUP_ADDRESS = ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_POINTER_EXTENSION_AUTHORITY = dist.ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_POINTER_EXTENSION_AUTHORITY = ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_POINTER_EXTENSION = dist.ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_POINTER_EXTENSION = ANCHOR_ERROR__CONSTRAINT_ASSOCIATED_TOKEN_TOKEN_PROGRAM = dist.ANCHOR_ERROR__CONSTRAINT_ASSOCIATED_TOKEN_TOKEN_PROGRAM = ANCHOR_ERROR__CONSTRAINT_MINT_TOKEN_PROGRAM = dist.ANCHOR_ERROR__CONSTRAINT_MINT_TOKEN_PROGRAM = ANCHOR_ERROR__CONSTRAINT_TOKEN_TOKEN_PROGRAM = dist.ANCHOR_ERROR__CONSTRAINT_TOKEN_TOKEN_PROGRAM = ANCHOR_ERROR__CONSTRAINT_ACCOUNT_IS_NONE = dist.ANCHOR_ERROR__CONSTRAINT_ACCOUNT_IS_NONE = ANCHOR_ERROR__CONSTRAINT_SPACE = dist.ANCHOR_ERROR__CONSTRAINT_SPACE = ANCHOR_ERROR__CONSTRAINT_MINT_DECIMALS = dist.ANCHOR_ERROR__CONSTRAINT_MINT_DECIMALS = ANCHOR_ERROR__CONSTRAINT_MINT_FREEZE_AUTHORITY = dist.ANCHOR_ERROR__CONSTRAINT_MINT_FREEZE_AUTHORITY = ANCHOR_ERROR__CONSTRAINT_MINT_MINT_AUTHORITY = dist.ANCHOR_ERROR__CONSTRAINT_MINT_MINT_AUTHORITY = ANCHOR_ERROR__CONSTRAINT_TOKEN_OWNER = dist.ANCHOR_ERROR__CONSTRAINT_TOKEN_OWNER = ANCHOR_ERROR__CONSTRAINT_TOKEN_MINT = dist.ANCHOR_ERROR__CONSTRAINT_TOKEN_MINT = ANCHOR_ERROR__CONSTRAINT_ZERO = dist.ANCHOR_ERROR__CONSTRAINT_ZERO = ANCHOR_ERROR__CONSTRAINT_ADDRESS = dist.ANCHOR_ERROR__CONSTRAINT_ADDRESS = ANCHOR_ERROR__CONSTRAINT_CLOSE = dist.ANCHOR_ERROR__CONSTRAINT_CLOSE = ANCHOR_ERROR__CONSTRAINT_ASSOCIATED_INIT = dist.ANCHOR_ERROR__CONSTRAINT_ASSOCIATED_INIT = ANCHOR_ERROR__CONSTRAINT_ASSOCIATED = dist.ANCHOR_ERROR__CONSTRAINT_ASSOCIATED = ANCHOR_ERROR__CONSTRAINT_STATE = dist.ANCHOR_ERROR__CONSTRAINT_STATE = ANCHOR_ERROR__CONSTRAINT_EXECUTABLE = dist.ANCHOR_ERROR__CONSTRAINT_EXECUTABLE = ANCHOR_ERROR__CONSTRAINT_SEEDS = dist.ANCHOR_ERROR__CONSTRAINT_SEEDS = ANCHOR_ERROR__CONSTRAINT_RENT_EXEMPT = dist.ANCHOR_ERROR__CONSTRAINT_RENT_EXEMPT = ANCHOR_ERROR__CONSTRAINT_OWNER = dist.ANCHOR_ERROR__CONSTRAINT_OWNER = ANCHOR_ERROR__CONSTRAINT_RAW = dist.ANCHOR_ERROR__CONSTRAINT_RAW = ANCHOR_ERROR__CONSTRAINT_SIGNER = dist.ANCHOR_ERROR__CONSTRAINT_SIGNER = ANCHOR_ERROR__CONSTRAINT_HAS_ONE = dist.ANCHOR_ERROR__CONSTRAINT_HAS_ONE = ANCHOR_ERROR__CONSTRAINT_MUT = dist.ANCHOR_ERROR__CONSTRAINT_MUT = ANCHOR_ERROR__EVENT_INSTRUCTION_STUB = dist.ANCHOR_ERROR__EVENT_INSTRUCTION_STUB = ANCHOR_ERROR__IDL_ACCOUNT_NOT_EMPTY = dist.ANCHOR_ERROR__IDL_ACCOUNT_NOT_EMPTY = ANCHOR_ERROR__IDL_INSTRUCTION_INVALID_PROGRAM = dist.ANCHOR_ERROR__IDL_INSTRUCTION_INVALID_PROGRAM = ANCHOR_ERROR__IDL_INSTRUCTION_STUB = dist.ANCHOR_ERROR__IDL_INSTRUCTION_STUB = ANCHOR_ERROR__INSTRUCTION_DID_NOT_SERIALIZE = dist.ANCHOR_ERROR__INSTRUCTION_DID_NOT_SERIALIZE = ANCHOR_ERROR__INSTRUCTION_DID_NOT_DESERIALIZE = dist.ANCHOR_ERROR__INSTRUCTION_DID_NOT_DESERIALIZE = ANCHOR_ERROR__INSTRUCTION_FALLBACK_NOT_FOUND = dist.ANCHOR_ERROR__INSTRUCTION_FALLBACK_NOT_FOUND = ANCHOR_ERROR__INSTRUCTION_MISSING = dist.ANCHOR_ERROR__INSTRUCTION_MISSING = void 0;
var ANCHOR_ERROR__DEPRECATED = dist.ANCHOR_ERROR__DEPRECATED = ANCHOR_ERROR__INVALID_NUMERIC_CONVERSION = dist.ANCHOR_ERROR__INVALID_NUMERIC_CONVERSION = ANCHOR_ERROR__TRYING_TO_INIT_PAYER_AS_PROGRAM_ACCOUNT = dist.ANCHOR_ERROR__TRYING_TO_INIT_PAYER_AS_PROGRAM_ACCOUNT = ANCHOR_ERROR__DECLARED_PROGRAM_ID_MISMATCH = dist.ANCHOR_ERROR__DECLARED_PROGRAM_ID_MISMATCH = ANCHOR_ERROR__ACCOUNT_DUPLICATE_REALLOCS = dist.ANCHOR_ERROR__ACCOUNT_DUPLICATE_REALLOCS = ANCHOR_ERROR__ACCOUNT_REALLOC_EXCEEDS_LIMIT = dist.ANCHOR_ERROR__ACCOUNT_REALLOC_EXCEEDS_LIMIT = ANCHOR_ERROR__ACCOUNT_SYSVAR_MISMATCH = dist.ANCHOR_ERROR__ACCOUNT_SYSVAR_MISMATCH = ANCHOR_ERROR__ACCOUNT_NOT_ASSOCIATED_TOKEN_ACCOUNT = dist.ANCHOR_ERROR__ACCOUNT_NOT_ASSOCIATED_TOKEN_ACCOUNT = ANCHOR_ERROR__ACCOUNT_NOT_PROGRAM_DATA = dist.ANCHOR_ERROR__ACCOUNT_NOT_PROGRAM_DATA = ANCHOR_ERROR__ACCOUNT_NOT_INITIALIZED = dist.ANCHOR_ERROR__ACCOUNT_NOT_INITIALIZED = ANCHOR_ERROR__ACCOUNT_NOT_SYSTEM_OWNED = dist.ANCHOR_ERROR__ACCOUNT_NOT_SYSTEM_OWNED = ANCHOR_ERROR__ACCOUNT_NOT_SIGNER = dist.ANCHOR_ERROR__ACCOUNT_NOT_SIGNER = ANCHOR_ERROR__INVALID_PROGRAM_EXECUTABLE = dist.ANCHOR_ERROR__INVALID_PROGRAM_EXECUTABLE = ANCHOR_ERROR__INVALID_PROGRAM_ID = dist.ANCHOR_ERROR__INVALID_PROGRAM_ID = ANCHOR_ERROR__ACCOUNT_OWNED_BY_WRONG_PROGRAM = dist.ANCHOR_ERROR__ACCOUNT_OWNED_BY_WRONG_PROGRAM = ANCHOR_ERROR__ACCOUNT_NOT_MUTABLE = dist.ANCHOR_ERROR__ACCOUNT_NOT_MUTABLE = ANCHOR_ERROR__ACCOUNT_NOT_ENOUGH_KEYS = dist.ANCHOR_ERROR__ACCOUNT_NOT_ENOUGH_KEYS = ANCHOR_ERROR__ACCOUNT_DID_NOT_SERIALIZE = dist.ANCHOR_ERROR__ACCOUNT_DID_NOT_SERIALIZE = ANCHOR_ERROR__ACCOUNT_DID_NOT_DESERIALIZE = dist.ANCHOR_ERROR__ACCOUNT_DID_NOT_DESERIALIZE = ANCHOR_ERROR__ACCOUNT_DISCRIMINATOR_MISMATCH = dist.ANCHOR_ERROR__ACCOUNT_DISCRIMINATOR_MISMATCH = ANCHOR_ERROR__ACCOUNT_DISCRIMINATOR_NOT_FOUND = dist.ANCHOR_ERROR__ACCOUNT_DISCRIMINATOR_NOT_FOUND = ANCHOR_ERROR__ACCOUNT_DISCRIMINATOR_ALREADY_SET = dist.ANCHOR_ERROR__ACCOUNT_DISCRIMINATOR_ALREADY_SET = ANCHOR_ERROR__REQUIRE_GTE_VIOLATED = dist.ANCHOR_ERROR__REQUIRE_GTE_VIOLATED = ANCHOR_ERROR__REQUIRE_GT_VIOLATED = dist.ANCHOR_ERROR__REQUIRE_GT_VIOLATED = ANCHOR_ERROR__REQUIRE_KEYS_NEQ_VIOLATED = dist.ANCHOR_ERROR__REQUIRE_KEYS_NEQ_VIOLATED = ANCHOR_ERROR__REQUIRE_NEQ_VIOLATED = dist.ANCHOR_ERROR__REQUIRE_NEQ_VIOLATED = ANCHOR_ERROR__REQUIRE_KEYS_EQ_VIOLATED = dist.ANCHOR_ERROR__REQUIRE_KEYS_EQ_VIOLATED = void 0;
var ANCHOR_ERROR__INSTRUCTION_MISSING = dist.ANCHOR_ERROR__INSTRUCTION_MISSING = 100;
var ANCHOR_ERROR__INSTRUCTION_FALLBACK_NOT_FOUND = dist.ANCHOR_ERROR__INSTRUCTION_FALLBACK_NOT_FOUND = 101;
var ANCHOR_ERROR__INSTRUCTION_DID_NOT_DESERIALIZE = dist.ANCHOR_ERROR__INSTRUCTION_DID_NOT_DESERIALIZE = 102;
var ANCHOR_ERROR__INSTRUCTION_DID_NOT_SERIALIZE = dist.ANCHOR_ERROR__INSTRUCTION_DID_NOT_SERIALIZE = 103;
var ANCHOR_ERROR__IDL_INSTRUCTION_STUB = dist.ANCHOR_ERROR__IDL_INSTRUCTION_STUB = 1e3;
var ANCHOR_ERROR__IDL_INSTRUCTION_INVALID_PROGRAM = dist.ANCHOR_ERROR__IDL_INSTRUCTION_INVALID_PROGRAM = 1001;
var ANCHOR_ERROR__IDL_ACCOUNT_NOT_EMPTY = dist.ANCHOR_ERROR__IDL_ACCOUNT_NOT_EMPTY = 1002;
var ANCHOR_ERROR__EVENT_INSTRUCTION_STUB = dist.ANCHOR_ERROR__EVENT_INSTRUCTION_STUB = 1500;
var ANCHOR_ERROR__CONSTRAINT_MUT = dist.ANCHOR_ERROR__CONSTRAINT_MUT = 2e3;
var ANCHOR_ERROR__CONSTRAINT_HAS_ONE = dist.ANCHOR_ERROR__CONSTRAINT_HAS_ONE = 2001;
var ANCHOR_ERROR__CONSTRAINT_SIGNER = dist.ANCHOR_ERROR__CONSTRAINT_SIGNER = 2002;
var ANCHOR_ERROR__CONSTRAINT_RAW = dist.ANCHOR_ERROR__CONSTRAINT_RAW = 2003;
var ANCHOR_ERROR__CONSTRAINT_OWNER = dist.ANCHOR_ERROR__CONSTRAINT_OWNER = 2004;
var ANCHOR_ERROR__CONSTRAINT_RENT_EXEMPT = dist.ANCHOR_ERROR__CONSTRAINT_RENT_EXEMPT = 2005;
var ANCHOR_ERROR__CONSTRAINT_SEEDS = dist.ANCHOR_ERROR__CONSTRAINT_SEEDS = 2006;
var ANCHOR_ERROR__CONSTRAINT_EXECUTABLE = dist.ANCHOR_ERROR__CONSTRAINT_EXECUTABLE = 2007;
var ANCHOR_ERROR__CONSTRAINT_STATE = dist.ANCHOR_ERROR__CONSTRAINT_STATE = 2008;
var ANCHOR_ERROR__CONSTRAINT_ASSOCIATED = dist.ANCHOR_ERROR__CONSTRAINT_ASSOCIATED = 2009;
var ANCHOR_ERROR__CONSTRAINT_ASSOCIATED_INIT = dist.ANCHOR_ERROR__CONSTRAINT_ASSOCIATED_INIT = 2010;
var ANCHOR_ERROR__CONSTRAINT_CLOSE = dist.ANCHOR_ERROR__CONSTRAINT_CLOSE = 2011;
var ANCHOR_ERROR__CONSTRAINT_ADDRESS = dist.ANCHOR_ERROR__CONSTRAINT_ADDRESS = 2012;
var ANCHOR_ERROR__CONSTRAINT_ZERO = dist.ANCHOR_ERROR__CONSTRAINT_ZERO = 2013;
var ANCHOR_ERROR__CONSTRAINT_TOKEN_MINT = dist.ANCHOR_ERROR__CONSTRAINT_TOKEN_MINT = 2014;
var ANCHOR_ERROR__CONSTRAINT_TOKEN_OWNER = dist.ANCHOR_ERROR__CONSTRAINT_TOKEN_OWNER = 2015;
var ANCHOR_ERROR__CONSTRAINT_MINT_MINT_AUTHORITY = dist.ANCHOR_ERROR__CONSTRAINT_MINT_MINT_AUTHORITY = 2016;
var ANCHOR_ERROR__CONSTRAINT_MINT_FREEZE_AUTHORITY = dist.ANCHOR_ERROR__CONSTRAINT_MINT_FREEZE_AUTHORITY = 2017;
var ANCHOR_ERROR__CONSTRAINT_MINT_DECIMALS = dist.ANCHOR_ERROR__CONSTRAINT_MINT_DECIMALS = 2018;
var ANCHOR_ERROR__CONSTRAINT_SPACE = dist.ANCHOR_ERROR__CONSTRAINT_SPACE = 2019;
var ANCHOR_ERROR__CONSTRAINT_ACCOUNT_IS_NONE = dist.ANCHOR_ERROR__CONSTRAINT_ACCOUNT_IS_NONE = 2020;
var ANCHOR_ERROR__CONSTRAINT_TOKEN_TOKEN_PROGRAM = dist.ANCHOR_ERROR__CONSTRAINT_TOKEN_TOKEN_PROGRAM = 2021;
var ANCHOR_ERROR__CONSTRAINT_MINT_TOKEN_PROGRAM = dist.ANCHOR_ERROR__CONSTRAINT_MINT_TOKEN_PROGRAM = 2022;
var ANCHOR_ERROR__CONSTRAINT_ASSOCIATED_TOKEN_TOKEN_PROGRAM = dist.ANCHOR_ERROR__CONSTRAINT_ASSOCIATED_TOKEN_TOKEN_PROGRAM = 2023;
var ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_POINTER_EXTENSION = dist.ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_POINTER_EXTENSION = 2024;
var ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_POINTER_EXTENSION_AUTHORITY = dist.ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_POINTER_EXTENSION_AUTHORITY = 2025;
var ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_POINTER_EXTENSION_GROUP_ADDRESS = dist.ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_POINTER_EXTENSION_GROUP_ADDRESS = 2026;
var ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_MEMBER_POINTER_EXTENSION = dist.ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_MEMBER_POINTER_EXTENSION = 2027;
var ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_MEMBER_POINTER_EXTENSION_AUTHORITY = dist.ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_MEMBER_POINTER_EXTENSION_AUTHORITY = 2028;
var ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_MEMBER_POINTER_EXTENSION_MEMBER_ADDRESS = dist.ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_MEMBER_POINTER_EXTENSION_MEMBER_ADDRESS = 2029;
var ANCHOR_ERROR__CONSTRAINT_MINT_METADATA_POINTER_EXTENSION = dist.ANCHOR_ERROR__CONSTRAINT_MINT_METADATA_POINTER_EXTENSION = 2030;
var ANCHOR_ERROR__CONSTRAINT_MINT_METADATA_POINTER_EXTENSION_AUTHORITY = dist.ANCHOR_ERROR__CONSTRAINT_MINT_METADATA_POINTER_EXTENSION_AUTHORITY = 2031;
var ANCHOR_ERROR__CONSTRAINT_MINT_METADATA_POINTER_EXTENSION_METADATA_ADDRESS = dist.ANCHOR_ERROR__CONSTRAINT_MINT_METADATA_POINTER_EXTENSION_METADATA_ADDRESS = 2032;
var ANCHOR_ERROR__CONSTRAINT_MINT_CLOSE_AUTHORITY_EXTENSION = dist.ANCHOR_ERROR__CONSTRAINT_MINT_CLOSE_AUTHORITY_EXTENSION = 2033;
var ANCHOR_ERROR__CONSTRAINT_MINT_CLOSE_AUTHORITY_EXTENSION_AUTHORITY = dist.ANCHOR_ERROR__CONSTRAINT_MINT_CLOSE_AUTHORITY_EXTENSION_AUTHORITY = 2034;
var ANCHOR_ERROR__CONSTRAINT_MINT_PERMANENT_DELEGATE_EXTENSION = dist.ANCHOR_ERROR__CONSTRAINT_MINT_PERMANENT_DELEGATE_EXTENSION = 2035;
var ANCHOR_ERROR__CONSTRAINT_MINT_PERMANENT_DELEGATE_EXTENSION_DELEGATE = dist.ANCHOR_ERROR__CONSTRAINT_MINT_PERMANENT_DELEGATE_EXTENSION_DELEGATE = 2036;
var ANCHOR_ERROR__CONSTRAINT_MINT_TRANSFER_HOOK_EXTENSION = dist.ANCHOR_ERROR__CONSTRAINT_MINT_TRANSFER_HOOK_EXTENSION = 2037;
var ANCHOR_ERROR__CONSTRAINT_MINT_TRANSFER_HOOK_EXTENSION_AUTHORITY = dist.ANCHOR_ERROR__CONSTRAINT_MINT_TRANSFER_HOOK_EXTENSION_AUTHORITY = 2038;
var ANCHOR_ERROR__CONSTRAINT_MINT_TRANSFER_HOOK_EXTENSION_PROGRAM_ID = dist.ANCHOR_ERROR__CONSTRAINT_MINT_TRANSFER_HOOK_EXTENSION_PROGRAM_ID = 2039;
var ANCHOR_ERROR__REQUIRE_VIOLATED = dist.ANCHOR_ERROR__REQUIRE_VIOLATED = 2500;
ANCHOR_ERROR__REQUIRE_EQ_VIOLATED = dist.ANCHOR_ERROR__REQUIRE_EQ_VIOLATED = 2501;
var ANCHOR_ERROR__REQUIRE_KEYS_EQ_VIOLATED = dist.ANCHOR_ERROR__REQUIRE_KEYS_EQ_VIOLATED = 2502;
var ANCHOR_ERROR__REQUIRE_NEQ_VIOLATED = dist.ANCHOR_ERROR__REQUIRE_NEQ_VIOLATED = 2503;
var ANCHOR_ERROR__REQUIRE_KEYS_NEQ_VIOLATED = dist.ANCHOR_ERROR__REQUIRE_KEYS_NEQ_VIOLATED = 2504;
var ANCHOR_ERROR__REQUIRE_GT_VIOLATED = dist.ANCHOR_ERROR__REQUIRE_GT_VIOLATED = 2505;
var ANCHOR_ERROR__REQUIRE_GTE_VIOLATED = dist.ANCHOR_ERROR__REQUIRE_GTE_VIOLATED = 2506;
var ANCHOR_ERROR__ACCOUNT_DISCRIMINATOR_ALREADY_SET = dist.ANCHOR_ERROR__ACCOUNT_DISCRIMINATOR_ALREADY_SET = 3e3;
var ANCHOR_ERROR__ACCOUNT_DISCRIMINATOR_NOT_FOUND = dist.ANCHOR_ERROR__ACCOUNT_DISCRIMINATOR_NOT_FOUND = 3001;
var ANCHOR_ERROR__ACCOUNT_DISCRIMINATOR_MISMATCH = dist.ANCHOR_ERROR__ACCOUNT_DISCRIMINATOR_MISMATCH = 3002;
var ANCHOR_ERROR__ACCOUNT_DID_NOT_DESERIALIZE = dist.ANCHOR_ERROR__ACCOUNT_DID_NOT_DESERIALIZE = 3003;
var ANCHOR_ERROR__ACCOUNT_DID_NOT_SERIALIZE = dist.ANCHOR_ERROR__ACCOUNT_DID_NOT_SERIALIZE = 3004;
var ANCHOR_ERROR__ACCOUNT_NOT_ENOUGH_KEYS = dist.ANCHOR_ERROR__ACCOUNT_NOT_ENOUGH_KEYS = 3005;
var ANCHOR_ERROR__ACCOUNT_NOT_MUTABLE = dist.ANCHOR_ERROR__ACCOUNT_NOT_MUTABLE = 3006;
var ANCHOR_ERROR__ACCOUNT_OWNED_BY_WRONG_PROGRAM = dist.ANCHOR_ERROR__ACCOUNT_OWNED_BY_WRONG_PROGRAM = 3007;
var ANCHOR_ERROR__INVALID_PROGRAM_ID = dist.ANCHOR_ERROR__INVALID_PROGRAM_ID = 3008;
var ANCHOR_ERROR__INVALID_PROGRAM_EXECUTABLE = dist.ANCHOR_ERROR__INVALID_PROGRAM_EXECUTABLE = 3009;
var ANCHOR_ERROR__ACCOUNT_NOT_SIGNER = dist.ANCHOR_ERROR__ACCOUNT_NOT_SIGNER = 3010;
var ANCHOR_ERROR__ACCOUNT_NOT_SYSTEM_OWNED = dist.ANCHOR_ERROR__ACCOUNT_NOT_SYSTEM_OWNED = 3011;
var ANCHOR_ERROR__ACCOUNT_NOT_INITIALIZED = dist.ANCHOR_ERROR__ACCOUNT_NOT_INITIALIZED = 3012;
var ANCHOR_ERROR__ACCOUNT_NOT_PROGRAM_DATA = dist.ANCHOR_ERROR__ACCOUNT_NOT_PROGRAM_DATA = 3013;
var ANCHOR_ERROR__ACCOUNT_NOT_ASSOCIATED_TOKEN_ACCOUNT = dist.ANCHOR_ERROR__ACCOUNT_NOT_ASSOCIATED_TOKEN_ACCOUNT = 3014;
var ANCHOR_ERROR__ACCOUNT_SYSVAR_MISMATCH = dist.ANCHOR_ERROR__ACCOUNT_SYSVAR_MISMATCH = 3015;
var ANCHOR_ERROR__ACCOUNT_REALLOC_EXCEEDS_LIMIT = dist.ANCHOR_ERROR__ACCOUNT_REALLOC_EXCEEDS_LIMIT = 3016;
var ANCHOR_ERROR__ACCOUNT_DUPLICATE_REALLOCS = dist.ANCHOR_ERROR__ACCOUNT_DUPLICATE_REALLOCS = 3017;
var ANCHOR_ERROR__DECLARED_PROGRAM_ID_MISMATCH = dist.ANCHOR_ERROR__DECLARED_PROGRAM_ID_MISMATCH = 4100;
var ANCHOR_ERROR__TRYING_TO_INIT_PAYER_AS_PROGRAM_ACCOUNT = dist.ANCHOR_ERROR__TRYING_TO_INIT_PAYER_AS_PROGRAM_ACCOUNT = 4101;
var ANCHOR_ERROR__INVALID_NUMERIC_CONVERSION = dist.ANCHOR_ERROR__INVALID_NUMERIC_CONVERSION = 4102;
ANCHOR_ERROR__DEPRECATED = dist.ANCHOR_ERROR__DEPRECATED = 5e3;
const _FEATURES = /* @__PURE__ */ new Map();
function isSet(key) {
  return _FEATURES.get(key) !== void 0;
}
class IdlError extends Error {
  constructor(message) {
    super(message);
    this.name = "IdlError";
  }
}
class ProgramErrorStack {
  constructor(stack) {
    this.stack = stack;
  }
  static parse(logs) {
    var _a;
    const programKeyRegex = /^Program (\w*) invoke/;
    const successRegex = /^Program \w* success/;
    const programStack = [];
    for (let i = 0; i < logs.length; i++) {
      if (successRegex.exec(logs[i])) {
        programStack.pop();
        continue;
      }
      const programKey = (_a = programKeyRegex.exec(logs[i])) === null || _a === void 0 ? void 0 : _a[1];
      if (!programKey) {
        continue;
      }
      programStack.push(new PublicKey(programKey));
    }
    return new ProgramErrorStack(programStack);
  }
}
class AnchorError extends Error {
  constructor(errorCode, errorMessage, errorLogs, logs, origin, comparedValues) {
    super(errorLogs.join("\n").replace("Program log: ", ""));
    this.errorLogs = errorLogs;
    this.logs = logs;
    this.error = { errorCode, errorMessage, comparedValues, origin };
    this._programErrorStack = ProgramErrorStack.parse(logs);
  }
  static parse(logs) {
    if (!logs) {
      return null;
    }
    const anchorErrorLogIndex = logs.findIndex((log) => log.startsWith("Program log: AnchorError"));
    if (anchorErrorLogIndex === -1) {
      return null;
    }
    const anchorErrorLog = logs[anchorErrorLogIndex];
    const errorLogs = [anchorErrorLog];
    let comparedValues;
    if (anchorErrorLogIndex + 1 < logs.length) {
      if (logs[anchorErrorLogIndex + 1] === "Program log: Left:") {
        const pubkeyRegex = /^Program log: (.*)$/;
        const leftPubkey = pubkeyRegex.exec(logs[anchorErrorLogIndex + 2])[1];
        const rightPubkey = pubkeyRegex.exec(logs[anchorErrorLogIndex + 4])[1];
        comparedValues = [
          new PublicKey(leftPubkey),
          new PublicKey(rightPubkey)
        ];
        errorLogs.push(...logs.slice(anchorErrorLogIndex + 1, anchorErrorLogIndex + 5));
      } else if (logs[anchorErrorLogIndex + 1].startsWith("Program log: Left:")) {
        const valueRegex = /^Program log: (Left|Right): (.*)$/;
        const leftValue = valueRegex.exec(logs[anchorErrorLogIndex + 1])[2];
        const rightValue = valueRegex.exec(logs[anchorErrorLogIndex + 2])[2];
        errorLogs.push(...logs.slice(anchorErrorLogIndex + 1, anchorErrorLogIndex + 3));
        comparedValues = [leftValue, rightValue];
      }
    }
    const regexNoInfo = /^Program log: AnchorError occurred\. Error Code: (.*)\. Error Number: (\d*)\. Error Message: (.*)\./;
    const noInfoAnchorErrorLog = regexNoInfo.exec(anchorErrorLog);
    const regexFileLine = /^Program log: AnchorError thrown in (.*):(\d*)\. Error Code: (.*)\. Error Number: (\d*)\. Error Message: (.*)\./;
    const fileLineAnchorErrorLog = regexFileLine.exec(anchorErrorLog);
    const regexAccountName = /^Program log: AnchorError caused by account: (.*)\. Error Code: (.*)\. Error Number: (\d*)\. Error Message: (.*)\./;
    const accountNameAnchorErrorLog = regexAccountName.exec(anchorErrorLog);
    if (noInfoAnchorErrorLog) {
      const [errorCodeString, errorNumber, errorMessage] = noInfoAnchorErrorLog.slice(1, 4);
      const errorCode = {
        code: errorCodeString,
        number: parseInt(errorNumber)
      };
      return new AnchorError(errorCode, errorMessage, errorLogs, logs, void 0, comparedValues);
    } else if (fileLineAnchorErrorLog) {
      const [file, line, errorCodeString, errorNumber, errorMessage] = fileLineAnchorErrorLog.slice(1, 6);
      const errorCode = {
        code: errorCodeString,
        number: parseInt(errorNumber)
      };
      const fileLine = { file, line: parseInt(line) };
      return new AnchorError(errorCode, errorMessage, errorLogs, logs, fileLine, comparedValues);
    } else if (accountNameAnchorErrorLog) {
      const [accountName, errorCodeString, errorNumber, errorMessage] = accountNameAnchorErrorLog.slice(1, 5);
      const origin = accountName;
      const errorCode = {
        code: errorCodeString,
        number: parseInt(errorNumber)
      };
      return new AnchorError(errorCode, errorMessage, errorLogs, logs, origin, comparedValues);
    } else {
      return null;
    }
  }
  get program() {
    return this._programErrorStack.stack[this._programErrorStack.stack.length - 1];
  }
  get programErrorStack() {
    return this._programErrorStack.stack;
  }
  toString() {
    return this.message;
  }
}
class ProgramError extends Error {
  constructor(code, msg, logs) {
    super();
    this.code = code;
    this.msg = msg;
    this.logs = logs;
    if (logs) {
      this._programErrorStack = ProgramErrorStack.parse(logs);
    }
  }
  static parse(err, idlErrors) {
    const errString = err.toString();
    let unparsedErrorCode;
    if (errString.includes("custom program error:")) {
      let components = errString.split("custom program error: ");
      if (components.length !== 2) {
        return null;
      } else {
        unparsedErrorCode = components[1];
      }
    } else {
      const matches = errString.match(/"Custom":([0-9]+)}/g);
      if (!matches || matches.length > 1) {
        return null;
      }
      unparsedErrorCode = matches[0].match(/([0-9]+)/g)[0];
    }
    let errorCode;
    try {
      errorCode = parseInt(unparsedErrorCode);
    } catch (parseErr) {
      return null;
    }
    let errorMsg = idlErrors.get(errorCode);
    if (errorMsg !== void 0) {
      return new ProgramError(errorCode, errorMsg, err.logs);
    }
    errorMsg = LangErrorMessage.get(errorCode);
    if (errorMsg !== void 0) {
      return new ProgramError(errorCode, errorMsg, err.logs);
    }
    return null;
  }
  get program() {
    var _a;
    return (_a = this._programErrorStack) === null || _a === void 0 ? void 0 : _a.stack[this._programErrorStack.stack.length - 1];
  }
  get programErrorStack() {
    var _a;
    return (_a = this._programErrorStack) === null || _a === void 0 ? void 0 : _a.stack;
  }
  toString() {
    return this.msg;
  }
}
function translateError(err, idlErrors) {
  if (isSet("debug-logs")) {
    console.log("Translating error:", err);
  }
  const anchorError = AnchorError.parse(err.logs);
  if (anchorError) {
    return anchorError;
  }
  const programError = ProgramError.parse(err, idlErrors);
  if (programError) {
    return programError;
  }
  if (err.logs) {
    const handler = {
      get: function(target, prop) {
        if (prop === "programErrorStack") {
          return target.programErrorStack.stack;
        } else if (prop === "program") {
          return target.programErrorStack.stack[err.programErrorStack.stack.length - 1];
        } else {
          return Reflect.get(...arguments);
        }
      }
    };
    err.programErrorStack = ProgramErrorStack.parse(err.logs);
    return new Proxy(err, handler);
  }
  return err;
}
const LangErrorCode = {
  // Instructions.
  InstructionMissing: ANCHOR_ERROR__INSTRUCTION_MISSING,
  InstructionFallbackNotFound: ANCHOR_ERROR__INSTRUCTION_FALLBACK_NOT_FOUND,
  InstructionDidNotDeserialize: ANCHOR_ERROR__INSTRUCTION_DID_NOT_DESERIALIZE,
  InstructionDidNotSerialize: ANCHOR_ERROR__INSTRUCTION_DID_NOT_SERIALIZE,
  // IDL instructions.
  IdlInstructionStub: ANCHOR_ERROR__IDL_INSTRUCTION_STUB,
  IdlInstructionInvalidProgram: ANCHOR_ERROR__IDL_INSTRUCTION_INVALID_PROGRAM,
  IdlAccountNotEmpty: ANCHOR_ERROR__IDL_ACCOUNT_NOT_EMPTY,
  // Event instructions.
  EventInstructionStub: ANCHOR_ERROR__EVENT_INSTRUCTION_STUB,
  // Constraints.
  ConstraintMut: ANCHOR_ERROR__CONSTRAINT_MUT,
  ConstraintHasOne: ANCHOR_ERROR__CONSTRAINT_HAS_ONE,
  ConstraintSigner: ANCHOR_ERROR__CONSTRAINT_SIGNER,
  ConstraintRaw: ANCHOR_ERROR__CONSTRAINT_RAW,
  ConstraintOwner: ANCHOR_ERROR__CONSTRAINT_OWNER,
  ConstraintRentExempt: ANCHOR_ERROR__CONSTRAINT_RENT_EXEMPT,
  ConstraintSeeds: ANCHOR_ERROR__CONSTRAINT_SEEDS,
  ConstraintExecutable: ANCHOR_ERROR__CONSTRAINT_EXECUTABLE,
  ConstraintState: ANCHOR_ERROR__CONSTRAINT_STATE,
  ConstraintAssociated: ANCHOR_ERROR__CONSTRAINT_ASSOCIATED,
  ConstraintAssociatedInit: ANCHOR_ERROR__CONSTRAINT_ASSOCIATED_INIT,
  ConstraintClose: ANCHOR_ERROR__CONSTRAINT_CLOSE,
  ConstraintAddress: ANCHOR_ERROR__CONSTRAINT_ADDRESS,
  ConstraintZero: ANCHOR_ERROR__CONSTRAINT_ZERO,
  ConstraintTokenMint: ANCHOR_ERROR__CONSTRAINT_TOKEN_MINT,
  ConstraintTokenOwner: ANCHOR_ERROR__CONSTRAINT_TOKEN_OWNER,
  ConstraintMintMintAuthority: ANCHOR_ERROR__CONSTRAINT_MINT_MINT_AUTHORITY,
  ConstraintMintFreezeAuthority: ANCHOR_ERROR__CONSTRAINT_MINT_FREEZE_AUTHORITY,
  ConstraintMintDecimals: ANCHOR_ERROR__CONSTRAINT_MINT_DECIMALS,
  ConstraintSpace: ANCHOR_ERROR__CONSTRAINT_SPACE,
  ConstraintAccountIsNone: ANCHOR_ERROR__CONSTRAINT_ACCOUNT_IS_NONE,
  ConstraintTokenTokenProgram: ANCHOR_ERROR__CONSTRAINT_TOKEN_TOKEN_PROGRAM,
  ConstraintMintTokenProgram: ANCHOR_ERROR__CONSTRAINT_MINT_TOKEN_PROGRAM,
  ConstraintAssociatedTokenTokenProgram: ANCHOR_ERROR__CONSTRAINT_ASSOCIATED_TOKEN_TOKEN_PROGRAM,
  ConstraintMintGroupPointerExtension: ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_POINTER_EXTENSION,
  ConstraintMintGroupPointerExtensionAuthority: ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_POINTER_EXTENSION_AUTHORITY,
  ConstraintMintGroupPointerExtensionGroupAddress: ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_POINTER_EXTENSION_GROUP_ADDRESS,
  ConstraintMintGroupMemberPointerExtension: ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_MEMBER_POINTER_EXTENSION,
  ConstraintMintGroupMemberPointerExtensionAuthority: ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_MEMBER_POINTER_EXTENSION_AUTHORITY,
  ConstraintMintGroupMemberPointerExtensionMemberAddress: ANCHOR_ERROR__CONSTRAINT_MINT_GROUP_MEMBER_POINTER_EXTENSION_MEMBER_ADDRESS,
  ConstraintMintMetadataPointerExtension: ANCHOR_ERROR__CONSTRAINT_MINT_METADATA_POINTER_EXTENSION,
  ConstraintMintMetadataPointerExtensionAuthority: ANCHOR_ERROR__CONSTRAINT_MINT_METADATA_POINTER_EXTENSION_AUTHORITY,
  ConstraintMintMetadataPointerExtensionMetadataAddress: ANCHOR_ERROR__CONSTRAINT_MINT_METADATA_POINTER_EXTENSION_METADATA_ADDRESS,
  ConstraintMintCloseAuthorityExtension: ANCHOR_ERROR__CONSTRAINT_MINT_CLOSE_AUTHORITY_EXTENSION,
  ConstraintMintCloseAuthorityExtensionAuthority: ANCHOR_ERROR__CONSTRAINT_MINT_CLOSE_AUTHORITY_EXTENSION_AUTHORITY,
  ConstraintMintPermanentDelegateExtension: ANCHOR_ERROR__CONSTRAINT_MINT_PERMANENT_DELEGATE_EXTENSION,
  ConstraintMintPermanentDelegateExtensionDelegate: ANCHOR_ERROR__CONSTRAINT_MINT_PERMANENT_DELEGATE_EXTENSION_DELEGATE,
  ConstraintMintTransferHookExtension: ANCHOR_ERROR__CONSTRAINT_MINT_TRANSFER_HOOK_EXTENSION,
  ConstraintMintTransferHookExtensionAuthority: ANCHOR_ERROR__CONSTRAINT_MINT_TRANSFER_HOOK_EXTENSION_AUTHORITY,
  ConstraintMintTransferHookExtensionProgramId: ANCHOR_ERROR__CONSTRAINT_MINT_TRANSFER_HOOK_EXTENSION_PROGRAM_ID,
  // Require.
  RequireViolated: ANCHOR_ERROR__REQUIRE_VIOLATED,
  RequireEqViolated: ANCHOR_ERROR__REQUIRE_EQ_VIOLATED,
  RequireKeysEqViolated: ANCHOR_ERROR__REQUIRE_KEYS_EQ_VIOLATED,
  RequireNeqViolated: ANCHOR_ERROR__REQUIRE_NEQ_VIOLATED,
  RequireKeysNeqViolated: ANCHOR_ERROR__REQUIRE_KEYS_NEQ_VIOLATED,
  RequireGtViolated: ANCHOR_ERROR__REQUIRE_GT_VIOLATED,
  RequireGteViolated: ANCHOR_ERROR__REQUIRE_GTE_VIOLATED,
  // Accounts.
  AccountDiscriminatorAlreadySet: ANCHOR_ERROR__ACCOUNT_DISCRIMINATOR_ALREADY_SET,
  AccountDiscriminatorNotFound: ANCHOR_ERROR__ACCOUNT_DISCRIMINATOR_NOT_FOUND,
  AccountDiscriminatorMismatch: ANCHOR_ERROR__ACCOUNT_DISCRIMINATOR_MISMATCH,
  AccountDidNotDeserialize: ANCHOR_ERROR__ACCOUNT_DID_NOT_DESERIALIZE,
  AccountDidNotSerialize: ANCHOR_ERROR__ACCOUNT_DID_NOT_SERIALIZE,
  AccountNotEnoughKeys: ANCHOR_ERROR__ACCOUNT_NOT_ENOUGH_KEYS,
  AccountNotMutable: ANCHOR_ERROR__ACCOUNT_NOT_MUTABLE,
  AccountOwnedByWrongProgram: ANCHOR_ERROR__ACCOUNT_OWNED_BY_WRONG_PROGRAM,
  InvalidProgramId: ANCHOR_ERROR__INVALID_PROGRAM_ID,
  InvalidProgramExecutable: ANCHOR_ERROR__INVALID_PROGRAM_EXECUTABLE,
  AccountNotSigner: ANCHOR_ERROR__ACCOUNT_NOT_SIGNER,
  AccountNotSystemOwned: ANCHOR_ERROR__ACCOUNT_NOT_SYSTEM_OWNED,
  AccountNotInitialized: ANCHOR_ERROR__ACCOUNT_NOT_INITIALIZED,
  AccountNotProgramData: ANCHOR_ERROR__ACCOUNT_NOT_PROGRAM_DATA,
  AccountNotAssociatedTokenAccount: ANCHOR_ERROR__ACCOUNT_NOT_ASSOCIATED_TOKEN_ACCOUNT,
  AccountSysvarMismatch: ANCHOR_ERROR__ACCOUNT_SYSVAR_MISMATCH,
  AccountReallocExceedsLimit: ANCHOR_ERROR__ACCOUNT_REALLOC_EXCEEDS_LIMIT,
  AccountDuplicateReallocs: ANCHOR_ERROR__ACCOUNT_DUPLICATE_REALLOCS,
  // Miscellaneous
  DeclaredProgramIdMismatch: ANCHOR_ERROR__DECLARED_PROGRAM_ID_MISMATCH,
  TryingToInitPayerAsProgramAccount: ANCHOR_ERROR__TRYING_TO_INIT_PAYER_AS_PROGRAM_ACCOUNT,
  InvalidNumericConversion: ANCHOR_ERROR__INVALID_NUMERIC_CONVERSION,
  // Used for APIs that shouldn't be used anymore.
  Deprecated: ANCHOR_ERROR__DEPRECATED
};
const LangErrorMessage = /* @__PURE__ */ new Map([
  // Instructions.
  [LangErrorCode.InstructionMissing, "Instruction discriminator not provided"],
  [
    LangErrorCode.InstructionFallbackNotFound,
    "Fallback functions are not supported"
  ],
  [
    LangErrorCode.InstructionDidNotDeserialize,
    "The program could not deserialize the given instruction"
  ],
  [
    LangErrorCode.InstructionDidNotSerialize,
    "The program could not serialize the given instruction"
  ],
  // Idl instructions.
  [
    LangErrorCode.IdlInstructionStub,
    "The program was compiled without idl instructions"
  ],
  [
    LangErrorCode.IdlInstructionInvalidProgram,
    "The transaction was given an invalid program for the IDL instruction"
  ],
  [
    LangErrorCode.IdlAccountNotEmpty,
    "IDL account must be empty in order to resize, try closing first"
  ],
  // Event instructions.
  [
    LangErrorCode.EventInstructionStub,
    "The program was compiled without `event-cpi` feature"
  ],
  // Constraints.
  [LangErrorCode.ConstraintMut, "A mut constraint was violated"],
  [LangErrorCode.ConstraintHasOne, "A has one constraint was violated"],
  [LangErrorCode.ConstraintSigner, "A signer constraint was violated"],
  [LangErrorCode.ConstraintRaw, "A raw constraint was violated"],
  [LangErrorCode.ConstraintOwner, "An owner constraint was violated"],
  [
    LangErrorCode.ConstraintRentExempt,
    "A rent exemption constraint was violated"
  ],
  [LangErrorCode.ConstraintSeeds, "A seeds constraint was violated"],
  [LangErrorCode.ConstraintExecutable, "An executable constraint was violated"],
  [
    LangErrorCode.ConstraintState,
    "Deprecated Error, feel free to replace with something else"
  ],
  [LangErrorCode.ConstraintAssociated, "An associated constraint was violated"],
  [
    LangErrorCode.ConstraintAssociatedInit,
    "An associated init constraint was violated"
  ],
  [LangErrorCode.ConstraintClose, "A close constraint was violated"],
  [LangErrorCode.ConstraintAddress, "An address constraint was violated"],
  [LangErrorCode.ConstraintZero, "Expected zero account discriminant"],
  [LangErrorCode.ConstraintTokenMint, "A token mint constraint was violated"],
  [LangErrorCode.ConstraintTokenOwner, "A token owner constraint was violated"],
  [
    LangErrorCode.ConstraintMintMintAuthority,
    "A mint mint authority constraint was violated"
  ],
  [
    LangErrorCode.ConstraintMintFreezeAuthority,
    "A mint freeze authority constraint was violated"
  ],
  [
    LangErrorCode.ConstraintMintDecimals,
    "A mint decimals constraint was violated"
  ],
  [LangErrorCode.ConstraintSpace, "A space constraint was violated"],
  [
    LangErrorCode.ConstraintAccountIsNone,
    "A required account for the constraint is None"
  ],
  [
    LangErrorCode.ConstraintTokenTokenProgram,
    "A token account token program constraint was violated"
  ],
  [
    LangErrorCode.ConstraintMintTokenProgram,
    "A mint token program constraint was violated"
  ],
  [
    LangErrorCode.ConstraintAssociatedTokenTokenProgram,
    "An associated token account token program constraint was violated"
  ],
  [
    LangErrorCode.ConstraintMintGroupPointerExtension,
    "A group pointer extension constraint was violated"
  ],
  [
    LangErrorCode.ConstraintMintGroupPointerExtensionAuthority,
    "A group pointer extension authority constraint was violated"
  ],
  [
    LangErrorCode.ConstraintMintGroupPointerExtensionGroupAddress,
    "A group pointer extension group address constraint was violated"
  ],
  [
    LangErrorCode.ConstraintMintGroupMemberPointerExtension,
    "A group member pointer extension constraint was violated"
  ],
  [
    LangErrorCode.ConstraintMintGroupMemberPointerExtensionAuthority,
    "A group member pointer extension authority constraint was violated"
  ],
  [
    LangErrorCode.ConstraintMintGroupMemberPointerExtensionMemberAddress,
    "A group member pointer extension group address constraint was violated"
  ],
  [
    LangErrorCode.ConstraintMintMetadataPointerExtension,
    "A metadata pointer extension constraint was violated"
  ],
  [
    LangErrorCode.ConstraintMintMetadataPointerExtensionAuthority,
    "A metadata pointer extension authority constraint was violated"
  ],
  [
    LangErrorCode.ConstraintMintMetadataPointerExtensionMetadataAddress,
    "A metadata pointer extension metadata address constraint was violated"
  ],
  [
    LangErrorCode.ConstraintMintCloseAuthorityExtension,
    "A close authority constraint was violated"
  ],
  [
    LangErrorCode.ConstraintMintCloseAuthorityExtensionAuthority,
    "A close authority extension authority constraint was violated"
  ],
  [
    LangErrorCode.ConstraintMintPermanentDelegateExtension,
    "A permanent delegate extension constraint was violated"
  ],
  [
    LangErrorCode.ConstraintMintPermanentDelegateExtensionDelegate,
    "A permanent delegate extension delegate constraint was violated"
  ],
  [
    LangErrorCode.ConstraintMintTransferHookExtension,
    "A transfer hook extension constraint was violated"
  ],
  [
    LangErrorCode.ConstraintMintTransferHookExtensionAuthority,
    "A transfer hook extension authority constraint was violated"
  ],
  [
    LangErrorCode.ConstraintMintTransferHookExtensionProgramId,
    "A transfer hook extension transfer hook program id constraint was violated"
  ],
  // Require.
  [LangErrorCode.RequireViolated, "A require expression was violated"],
  [LangErrorCode.RequireEqViolated, "A require_eq expression was violated"],
  [
    LangErrorCode.RequireKeysEqViolated,
    "A require_keys_eq expression was violated"
  ],
  [LangErrorCode.RequireNeqViolated, "A require_neq expression was violated"],
  [
    LangErrorCode.RequireKeysNeqViolated,
    "A require_keys_neq expression was violated"
  ],
  [LangErrorCode.RequireGtViolated, "A require_gt expression was violated"],
  [LangErrorCode.RequireGteViolated, "A require_gte expression was violated"],
  // Accounts.
  [
    LangErrorCode.AccountDiscriminatorAlreadySet,
    "The account discriminator was already set on this account"
  ],
  [
    LangErrorCode.AccountDiscriminatorNotFound,
    "No discriminator was found on the account"
  ],
  [
    LangErrorCode.AccountDiscriminatorMismatch,
    "Account discriminator did not match what was expected"
  ],
  [LangErrorCode.AccountDidNotDeserialize, "Failed to deserialize the account"],
  [LangErrorCode.AccountDidNotSerialize, "Failed to serialize the account"],
  [
    LangErrorCode.AccountNotEnoughKeys,
    "Not enough account keys given to the instruction"
  ],
  [LangErrorCode.AccountNotMutable, "The given account is not mutable"],
  [
    LangErrorCode.AccountOwnedByWrongProgram,
    "The given account is owned by a different program than expected"
  ],
  [LangErrorCode.InvalidProgramId, "Program ID was not as expected"],
  [LangErrorCode.InvalidProgramExecutable, "Program account is not executable"],
  [LangErrorCode.AccountNotSigner, "The given account did not sign"],
  [
    LangErrorCode.AccountNotSystemOwned,
    "The given account is not owned by the system program"
  ],
  [
    LangErrorCode.AccountNotInitialized,
    "The program expected this account to be already initialized"
  ],
  [
    LangErrorCode.AccountNotProgramData,
    "The given account is not a program data account"
  ],
  [
    LangErrorCode.AccountNotAssociatedTokenAccount,
    "The given account is not the associated token account"
  ],
  [
    LangErrorCode.AccountSysvarMismatch,
    "The given public key does not match the required sysvar"
  ],
  [
    LangErrorCode.AccountReallocExceedsLimit,
    "The account reallocation exceeds the MAX_PERMITTED_DATA_INCREASE limit"
  ],
  [
    LangErrorCode.AccountDuplicateReallocs,
    "The account was duplicated for more than one reallocation"
  ],
  // Miscellaneous
  [
    LangErrorCode.DeclaredProgramIdMismatch,
    "The declared program id does not match the actual program id"
  ],
  [
    LangErrorCode.TryingToInitPayerAsProgramAccount,
    "You cannot/should not initialize the payer account as a program account"
  ],
  [
    LangErrorCode.InvalidNumericConversion,
    "The program could not perform the numeric conversion, out of range integral type conversion attempted"
  ],
  // Deprecated
  [
    LangErrorCode.Deprecated,
    "The API being used is deprecated and should no longer be used"
  ]
]);
class IdlCoder {
  static fieldLayout(field, types2 = [], genericArgs) {
    const fieldName = field.name;
    switch (field.type) {
      case "bool": {
        return dist$1.bool(fieldName);
      }
      case "u8": {
        return dist$1.u8(fieldName);
      }
      case "i8": {
        return dist$1.i8(fieldName);
      }
      case "u16": {
        return dist$1.u16(fieldName);
      }
      case "i16": {
        return dist$1.i16(fieldName);
      }
      case "u32": {
        return dist$1.u32(fieldName);
      }
      case "i32": {
        return dist$1.i32(fieldName);
      }
      case "f32": {
        return dist$1.f32(fieldName);
      }
      case "u64": {
        return dist$1.u64(fieldName);
      }
      case "i64": {
        return dist$1.i64(fieldName);
      }
      case "f64": {
        return dist$1.f64(fieldName);
      }
      case "u128": {
        return dist$1.u128(fieldName);
      }
      case "i128": {
        return dist$1.i128(fieldName);
      }
      case "u256": {
        return dist$1.u256(fieldName);
      }
      case "i256": {
        return dist$1.i256(fieldName);
      }
      case "bytes": {
        return dist$1.vecU8(fieldName);
      }
      case "string": {
        return dist$1.str(fieldName);
      }
      case "pubkey": {
        return dist$1.publicKey(fieldName);
      }
      default: {
        if ("option" in field.type) {
          return dist$1.option(IdlCoder.fieldLayout({ type: field.type.option }, types2, genericArgs), fieldName);
        }
        if ("vec" in field.type) {
          return dist$1.vec(IdlCoder.fieldLayout({ type: field.type.vec }, types2, genericArgs), fieldName);
        }
        if ("array" in field.type) {
          let [type2, len] = field.type.array;
          len = IdlCoder.resolveArrayLen(len, genericArgs);
          return dist$1.array(IdlCoder.fieldLayout({ type: type2 }, types2, genericArgs), len, fieldName);
        }
        if ("defined" in field.type) {
          if (!types2) {
            throw new IdlError("User defined types not provided");
          }
          const definedName = field.type.defined.name;
          const typeDef = types2.find((t) => t.name === definedName);
          if (!typeDef) {
            throw new IdlError(`Type not found: ${field.name}`);
          }
          return IdlCoder.typeDefLayout({
            typeDef,
            types: types2,
            genericArgs: genericArgs !== null && genericArgs !== void 0 ? genericArgs : field.type.defined.generics,
            name: fieldName
          });
        }
        if ("generic" in field.type) {
          const genericArg = genericArgs === null || genericArgs === void 0 ? void 0 : genericArgs.at(0);
          if ((genericArg === null || genericArg === void 0 ? void 0 : genericArg.kind) !== "type") {
            throw new IdlError(`Invalid generic field: ${field.name}`);
          }
          return IdlCoder.fieldLayout({ ...field, type: genericArg.type }, types2);
        }
        throw new IdlError(`Not yet implemented: ${JSON.stringify(field.type)}`);
      }
    }
  }
  /**
   * Get the type layout of the given defined type(struct or enum).
   */
  static typeDefLayout({ typeDef, types: types2, name, genericArgs }) {
    switch (typeDef.type.kind) {
      case "struct": {
        const fieldLayouts = handleDefinedFields(typeDef.type.fields, () => [], (fields) => fields.map((f) => {
          const genArgs = genericArgs ? IdlCoder.resolveGenericArgs({
            type: f.type,
            typeDef,
            genericArgs
          }) : genericArgs;
          return IdlCoder.fieldLayout(f, types2, genArgs);
        }), (fields) => fields.map((f, i) => {
          const genArgs = genericArgs ? IdlCoder.resolveGenericArgs({
            type: f,
            typeDef,
            genericArgs
          }) : genericArgs;
          return IdlCoder.fieldLayout({ name: i.toString(), type: f }, types2, genArgs);
        }));
        return dist$1.struct(fieldLayouts, name);
      }
      case "enum": {
        const variants = typeDef.type.variants.map((variant) => {
          const fieldLayouts = handleDefinedFields(variant.fields, () => [], (fields) => fields.map((f) => {
            const genArgs = genericArgs ? IdlCoder.resolveGenericArgs({
              type: f.type,
              typeDef,
              genericArgs
            }) : genericArgs;
            return IdlCoder.fieldLayout(f, types2, genArgs);
          }), (fields) => fields.map((f, i) => {
            const genArgs = genericArgs ? IdlCoder.resolveGenericArgs({
              type: f,
              typeDef,
              genericArgs
            }) : genericArgs;
            return IdlCoder.fieldLayout({ name: i.toString(), type: f }, types2, genArgs);
          }));
          return dist$1.struct(fieldLayouts, variant.name);
        });
        if (name !== void 0) {
          return dist$1.rustEnum(variants).replicate(name);
        }
        return dist$1.rustEnum(variants, name);
      }
      case "type": {
        return IdlCoder.fieldLayout({ type: typeDef.type.alias, name }, types2);
      }
    }
  }
  /**
   * Get the type of the size in bytes. Returns `1` for variable length types.
   */
  static typeSize(ty, idl, genericArgs) {
    var _a;
    switch (ty) {
      case "bool":
        return 1;
      case "u8":
        return 1;
      case "i8":
        return 1;
      case "i16":
        return 2;
      case "u16":
        return 2;
      case "u32":
        return 4;
      case "i32":
        return 4;
      case "f32":
        return 4;
      case "u64":
        return 8;
      case "i64":
        return 8;
      case "f64":
        return 8;
      case "u128":
        return 16;
      case "i128":
        return 16;
      case "u256":
        return 32;
      case "i256":
        return 32;
      case "bytes":
        return 1;
      case "string":
        return 1;
      case "pubkey":
        return 32;
      default:
        if ("option" in ty) {
          return 1 + IdlCoder.typeSize(ty.option, idl, genericArgs);
        }
        if ("coption" in ty) {
          return 4 + IdlCoder.typeSize(ty.coption, idl, genericArgs);
        }
        if ("vec" in ty) {
          return 1;
        }
        if ("array" in ty) {
          let [type2, len] = ty.array;
          len = IdlCoder.resolveArrayLen(len, genericArgs);
          return IdlCoder.typeSize(type2, idl, genericArgs) * len;
        }
        if ("defined" in ty) {
          const typeDef = (_a = idl.types) === null || _a === void 0 ? void 0 : _a.find((t) => t.name === ty.defined.name);
          if (!typeDef) {
            throw new IdlError(`Type not found: ${JSON.stringify(ty)}`);
          }
          const typeSize = (type2) => {
            const genArgs = genericArgs !== null && genericArgs !== void 0 ? genericArgs : ty.defined.generics;
            const args = genArgs ? IdlCoder.resolveGenericArgs({
              type: type2,
              typeDef,
              genericArgs: genArgs
            }) : genArgs;
            return IdlCoder.typeSize(type2, idl, args);
          };
          switch (typeDef.type.kind) {
            case "struct": {
              return handleDefinedFields(typeDef.type.fields, () => [0], (fields) => fields.map((f) => typeSize(f.type)), (fields) => fields.map((f) => typeSize(f))).reduce((acc, size) => acc + size, 0);
            }
            case "enum": {
              const variantSizes = typeDef.type.variants.map((variant) => {
                return handleDefinedFields(variant.fields, () => [0], (fields) => fields.map((f) => typeSize(f.type)), (fields) => fields.map((f) => typeSize(f))).reduce((acc, size) => acc + size, 0);
              });
              return Math.max(...variantSizes) + 1;
            }
            case "type": {
              return IdlCoder.typeSize(typeDef.type.alias, idl, genericArgs);
            }
          }
        }
        if ("generic" in ty) {
          const genericArg = genericArgs === null || genericArgs === void 0 ? void 0 : genericArgs.at(0);
          if ((genericArg === null || genericArg === void 0 ? void 0 : genericArg.kind) !== "type") {
            throw new IdlError(`Invalid generic: ${ty.generic}`);
          }
          return IdlCoder.typeSize(genericArg.type, idl, genericArgs);
        }
        throw new Error(`Invalid type ${JSON.stringify(ty)}`);
    }
  }
  /**
   * Resolve the generic array length or return the constant-sized array length.
   */
  static resolveArrayLen(len, genericArgs) {
    if (typeof len === "number")
      return len;
    if (genericArgs) {
      const genericLen = genericArgs.find((g) => g.kind === "const");
      if ((genericLen === null || genericLen === void 0 ? void 0 : genericLen.kind) === "const") {
        len = +genericLen.value;
      }
    }
    if (typeof len !== "number") {
      throw new IdlError("Generic array length did not resolve");
    }
    return len;
  }
  /**
   * Recursively resolve generic arguments i.e. replace all generics with the
   * actual type that they hold based on the initial `genericArgs` given.
   */
  static resolveGenericArgs({ type: type2, typeDef, genericArgs, isDefined }) {
    if (typeof type2 !== "object")
      return null;
    for (const index in typeDef.generics) {
      const defGeneric = typeDef.generics[index];
      if ("generic" in type2 && defGeneric.name === type2.generic) {
        return [genericArgs[index]];
      }
      if ("option" in type2) {
        const args = IdlCoder.resolveGenericArgs({
          type: type2.option,
          typeDef,
          genericArgs,
          isDefined
        });
        if (!args || !isDefined)
          return args;
        if (args[0].kind === "type") {
          return [
            {
              kind: "type",
              type: { option: args[0].type }
            }
          ];
        }
      }
      if ("vec" in type2) {
        const args = IdlCoder.resolveGenericArgs({
          type: type2.vec,
          typeDef,
          genericArgs,
          isDefined
        });
        if (!args || !isDefined)
          return args;
        if (args[0].kind === "type") {
          return [
            {
              kind: "type",
              type: { vec: args[0].type }
            }
          ];
        }
      }
      if ("array" in type2) {
        const [elTy, len] = type2.array;
        const isGenericLen = typeof len === "object";
        const args = IdlCoder.resolveGenericArgs({
          type: elTy,
          typeDef,
          genericArgs,
          isDefined
        }) || [];
        if (isGenericLen) {
          const matchingGeneric = typeDef.generics.findIndex((g) => g.name === len.generic);
          if (matchingGeneric !== -1) {
            args.push(genericArgs[matchingGeneric]);
          }
        }
        if (args.length > 0) {
          if (!isDefined)
            return args;
          if (args[0].kind === "type" && args[1].kind === "const") {
            return [
              {
                kind: "type",
                type: { array: [args[0].type, +args[1].value] }
              }
            ];
          }
        }
        if (isGenericLen && defGeneric.name === len.generic) {
          const arg = genericArgs[index];
          if (!isDefined)
            return [arg];
          return [
            {
              kind: "type",
              type: { array: [elTy, +arg.value] }
            }
          ];
        }
        return null;
      }
      if ("defined" in type2) {
        if (!type2.defined.generics)
          return null;
        return type2.defined.generics.flatMap((g) => {
          switch (g.kind) {
            case "type":
              return IdlCoder.resolveGenericArgs({
                type: g.type,
                typeDef,
                genericArgs,
                isDefined: true
              });
            case "const":
              return [g];
          }
        }).filter((g) => g !== null);
      }
    }
    return null;
  }
}
class BorshInstructionCoder {
  constructor(idl) {
    this.idl = idl;
    const ixLayouts = idl.instructions.map((ix) => {
      const name = ix.name;
      const fieldLayouts = ix.args.map((arg) => IdlCoder.fieldLayout(arg, idl.types));
      const layout = dist$1.struct(fieldLayouts, name);
      return [name, { discriminator: ix.discriminator, layout }];
    });
    this.ixLayouts = new Map(ixLayouts);
  }
  /**
   * Encodes a program instruction.
   */
  encode(ixName, ix) {
    const buffer = Buffer$1.alloc(1e3);
    const encoder = this.ixLayouts.get(ixName);
    if (!encoder) {
      throw new Error(`Unknown method: ${ixName}`);
    }
    const len = encoder.layout.encode(ix, buffer);
    const data = buffer.slice(0, len);
    return Buffer$1.concat([Buffer$1.from(encoder.discriminator), data]);
  }
  /**
   * Decodes a program instruction.
   */
  decode(ix, encoding = "hex") {
    if (typeof ix === "string") {
      ix = encoding === "hex" ? Buffer$1.from(ix, "hex") : bs58$1.decode(ix);
    }
    for (const [name, layout] of this.ixLayouts) {
      const givenDisc = ix.subarray(0, layout.discriminator.length);
      const matches = givenDisc.equals(Buffer$1.from(layout.discriminator));
      if (matches) {
        return {
          name,
          data: layout.layout.decode(ix.subarray(givenDisc.length))
        };
      }
    }
    return null;
  }
  /**
   * Returns a formatted table of all the fields in the given instruction data.
   */
  format(ix, accountMetas) {
    return InstructionFormatter.format(ix, accountMetas, this.idl);
  }
}
class InstructionFormatter {
  static format(ix, accountMetas, idl) {
    const idlIx = idl.instructions.find((i) => ix.name === i.name);
    if (!idlIx) {
      console.error("Invalid instruction given");
      return null;
    }
    const args = idlIx.args.map((idlField) => {
      return {
        name: idlField.name,
        type: InstructionFormatter.formatIdlType(idlField.type),
        data: InstructionFormatter.formatIdlData(idlField, ix.data[idlField.name], idl.types)
      };
    });
    const flatIdlAccounts = InstructionFormatter.flattenIdlAccounts(idlIx.accounts);
    const accounts2 = accountMetas.map((meta, idx) => {
      if (idx < flatIdlAccounts.length) {
        return {
          name: flatIdlAccounts[idx].name,
          ...meta
        };
      } else {
        return {
          name: void 0,
          ...meta
        };
      }
    });
    return {
      args,
      accounts: accounts2
    };
  }
  static formatIdlType(idlType) {
    if (typeof idlType === "string") {
      return idlType;
    }
    if ("option" in idlType) {
      return `Option<${this.formatIdlType(idlType.option)}>`;
    }
    if ("coption" in idlType) {
      return `COption<${this.formatIdlType(idlType.coption)}>`;
    }
    if ("vec" in idlType) {
      return `Vec<${this.formatIdlType(idlType.vec)}>`;
    }
    if ("array" in idlType) {
      return `Array<${idlType.array[0]}; ${idlType.array[1]}>`;
    }
    if ("defined" in idlType) {
      const name = idlType.defined.name;
      if (idlType.defined.generics) {
        const generics = idlType.defined.generics.map((g) => {
          switch (g.kind) {
            case "type":
              return InstructionFormatter.formatIdlType(g.type);
            case "const":
              return g.value;
          }
        }).join(", ");
        return `${name}<${generics}>`;
      }
      return name;
    }
    throw new Error(`Unknown IDL type: ${idlType}`);
  }
  static formatIdlData(idlField, data, types2) {
    if (typeof idlField.type === "string") {
      return data.toString();
    }
    if ("vec" in idlField.type) {
      return "[" + data.map((d) => this.formatIdlData({ name: "", type: idlField.type.vec }, d, types2)).join(", ") + "]";
    }
    if ("option" in idlField.type) {
      return data === null ? "null" : this.formatIdlData({ name: "", type: idlField.type.option }, data, types2);
    }
    if ("defined" in idlField.type) {
      if (!types2) {
        throw new Error("User defined types not provided");
      }
      const definedName = idlField.type.defined.name;
      const typeDef = types2.find((t) => t.name === definedName);
      if (!typeDef) {
        throw new Error(`Type not found: ${definedName}`);
      }
      return InstructionFormatter.formatIdlDataDefined(typeDef, data, types2);
    }
    return "unknown";
  }
  static formatIdlDataDefined(typeDef, data, types2) {
    switch (typeDef.type.kind) {
      case "struct": {
        return "{ " + handleDefinedFields(typeDef.type.fields, () => "", (fields) => {
          return Object.entries(data).map(([key, val]) => {
            const field = fields.find((f) => f.name === key);
            if (!field) {
              throw new Error(`Field not found: ${key}`);
            }
            return key + ": " + InstructionFormatter.formatIdlData(field, val, types2);
          }).join(", ");
        }, (fields) => {
          return Object.entries(data).map(([key, val]) => {
            return key + ": " + InstructionFormatter.formatIdlData({ name: "", type: fields[key] }, val, types2);
          }).join(", ");
        }) + " }";
      }
      case "enum": {
        const variantName = Object.keys(data)[0];
        const variant = typeDef.type.variants.find((v) => v.name === variantName);
        if (!variant) {
          throw new Error(`Unable to find variant: ${variantName}`);
        }
        const enumValue = data[variantName];
        return handleDefinedFields(variant.fields, () => variantName, (fields) => {
          const namedFields = Object.keys(enumValue).map((f) => {
            const fieldData = enumValue[f];
            const idlField = fields.find((v) => v.name === f);
            if (!idlField) {
              throw new Error(`Field not found: ${f}`);
            }
            return f + ": " + InstructionFormatter.formatIdlData(idlField, fieldData, types2);
          }).join(", ");
          return `${variantName} { ${namedFields} }`;
        }, (fields) => {
          const tupleFields = Object.entries(enumValue).map(([key, val]) => {
            return key + ": " + InstructionFormatter.formatIdlData({ name: "", type: fields[key] }, val, types2);
          }).join(", ");
          return `${variantName} { ${tupleFields} }`;
        });
      }
      case "type": {
        return InstructionFormatter.formatIdlType(typeDef.type.alias);
      }
    }
  }
  static flattenIdlAccounts(accounts2, prefix) {
    return accounts2.map((account) => {
      const accName = sentenceCase(account.name);
      if (account.hasOwnProperty("accounts")) {
        const newPrefix = prefix ? `${prefix} > ${accName}` : accName;
        return InstructionFormatter.flattenIdlAccounts(account.accounts, newPrefix);
      } else {
        return {
          ...account,
          name: prefix ? `${prefix} > ${accName}` : accName
        };
      }
    }).flat();
  }
}
function sentenceCase(field) {
  const result = field.replace(/([A-Z])/g, " $1");
  return result.charAt(0).toUpperCase() + result.slice(1);
}
class BorshAccountsCoder {
  constructor(idl) {
    this.idl = idl;
    if (!idl.accounts) {
      this.accountLayouts = /* @__PURE__ */ new Map();
      return;
    }
    const types2 = idl.types;
    if (!types2) {
      throw new Error("Accounts require `idl.types`");
    }
    const layouts = idl.accounts.map((acc) => {
      const typeDef = types2.find((ty) => ty.name === acc.name);
      if (!typeDef) {
        throw new Error(`Account not found: ${acc.name}`);
      }
      return [
        acc.name,
        {
          discriminator: acc.discriminator,
          layout: IdlCoder.typeDefLayout({ typeDef, types: types2 })
        }
      ];
    });
    this.accountLayouts = new Map(layouts);
  }
  async encode(accountName, account) {
    const buffer = Buffer$1.alloc(1e3);
    const layout = this.accountLayouts.get(accountName);
    if (!layout) {
      throw new Error(`Unknown account: ${accountName}`);
    }
    const len = layout.layout.encode(account, buffer);
    const accountData = buffer.slice(0, len);
    const discriminator = this.accountDiscriminator(accountName);
    return Buffer$1.concat([discriminator, accountData]);
  }
  decode(accountName, data) {
    const discriminator = this.accountDiscriminator(accountName);
    if (discriminator.compare(data.slice(0, discriminator.length))) {
      throw new Error("Invalid account discriminator");
    }
    return this.decodeUnchecked(accountName, data);
  }
  decodeAny(data) {
    for (const [name, layout] of this.accountLayouts) {
      const givenDisc = data.subarray(0, layout.discriminator.length);
      const matches = givenDisc.equals(Buffer$1.from(layout.discriminator));
      if (matches)
        return this.decodeUnchecked(name, data);
    }
    throw new Error("Account not found");
  }
  decodeUnchecked(accountName, acc) {
    const discriminator = this.accountDiscriminator(accountName);
    const data = acc.subarray(discriminator.length);
    const layout = this.accountLayouts.get(accountName);
    if (!layout) {
      throw new Error(`Unknown account: ${accountName}`);
    }
    return layout.layout.decode(data);
  }
  memcmp(accountName, appendData) {
    const discriminator = this.accountDiscriminator(accountName);
    return {
      offset: 0,
      bytes: bs58$1.encode(appendData ? Buffer$1.concat([discriminator, appendData]) : discriminator)
    };
  }
  size(accountName) {
    return this.accountDiscriminator(accountName).length + IdlCoder.typeSize({ defined: { name: accountName } }, this.idl);
  }
  /**
   * Get the unique discriminator prepended to all anchor accounts.
   *
   * @param name The name of the account to get the discriminator of.
   */
  accountDiscriminator(name) {
    var _a;
    const account = (_a = this.idl.accounts) === null || _a === void 0 ? void 0 : _a.find((acc) => acc.name === name);
    if (!account) {
      throw new Error(`Account not found: ${name}`);
    }
    return Buffer$1.from(account.discriminator);
  }
}
class BorshEventCoder {
  constructor(idl) {
    if (!idl.events) {
      this.layouts = /* @__PURE__ */ new Map();
      return;
    }
    const types2 = idl.types;
    if (!types2) {
      throw new Error("Events require `idl.types`");
    }
    const layouts = idl.events.map((ev) => {
      const typeDef = types2.find((ty) => ty.name === ev.name);
      if (!typeDef) {
        throw new Error(`Event not found: ${ev.name}`);
      }
      return [
        ev.name,
        {
          discriminator: ev.discriminator,
          layout: IdlCoder.typeDefLayout({ typeDef, types: types2 })
        }
      ];
    });
    this.layouts = new Map(layouts);
  }
  decode(log) {
    let logArr;
    try {
      logArr = decode(log);
    } catch (e) {
      return null;
    }
    for (const [name, layout] of this.layouts) {
      const givenDisc = logArr.subarray(0, layout.discriminator.length);
      const matches = givenDisc.equals(Buffer$1.from(layout.discriminator));
      if (matches) {
        return {
          name,
          data: layout.layout.decode(logArr.subarray(givenDisc.length))
        };
      }
    }
    return null;
  }
}
class BorshTypesCoder {
  constructor(idl) {
    const types2 = idl.types;
    if (!types2) {
      this.typeLayouts = /* @__PURE__ */ new Map();
      return;
    }
    const layouts = types2.filter((ty) => !ty.generics).map((ty) => [
      ty.name,
      IdlCoder.typeDefLayout({ typeDef: ty, types: types2 })
    ]);
    this.typeLayouts = new Map(layouts);
  }
  encode(name, type2) {
    const buffer = Buffer$1.alloc(1e3);
    const layout = this.typeLayouts.get(name);
    if (!layout) {
      throw new Error(`Unknown type: ${name}`);
    }
    const len = layout.encode(type2, buffer);
    return buffer.slice(0, len);
  }
  decode(name, data) {
    const layout = this.typeLayouts.get(name);
    if (!layout) {
      throw new Error(`Unknown type: ${name}`);
    }
    return layout.decode(data);
  }
}
class BorshCoder {
  constructor(idl) {
    this.instruction = new BorshInstructionCoder(idl);
    this.accounts = new BorshAccountsCoder(idl);
    this.events = new BorshEventCoder(idl);
    this.types = new BorshTypesCoder(idl);
  }
}
class Layout2 {
  constructor(span, property) {
    if (!Number.isInteger(span)) {
      throw new TypeError("span must be an integer");
    }
    this.span = span;
    this.property = property;
  }
  /** Function to create an Object into which decoded properties will
   * be written.
   *
   * Used only for layouts that {@link Layout#decode|decode} to Object
   * instances, which means:
   * * {@link Structure}
   * * {@link Union}
   * * {@link VariantLayout}
   * * {@link BitStructure}
   *
   * If left undefined the JavaScript representation of these layouts
   * will be Object instances.
   *
   * See {@link bindConstructorLayout}.
   */
  makeDestinationObject() {
    return {};
  }
  /**
   * Decode from a Buffer into an JavaScript value.
   *
   * @param {Buffer} b - the buffer from which encoded data is read.
   *
   * @param {Number} [offset] - the offset at which the encoded data
   * starts.  If absent a zero offset is inferred.
   *
   * @returns {(Number|Array|Object)} - the value of the decoded data.
   *
   * @abstract
   */
  decode(b, offset2) {
    throw new Error("Layout is abstract");
  }
  /**
   * Encode a JavaScript value into a Buffer.
   *
   * @param {(Number|Array|Object)} src - the value to be encoded into
   * the buffer.  The type accepted depends on the (sub-)type of {@link
   * Layout}.
   *
   * @param {Buffer} b - the buffer into which encoded data will be
   * written.
   *
   * @param {Number} [offset] - the offset at which the encoded data
   * starts.  If absent a zero offset is inferred.
   *
   * @returns {Number} - the number of bytes encoded, including the
   * space skipped for internal padding, but excluding data such as
   * {@link Sequence#count|lengths} when stored {@link
   * ExternalLayout|externally}.  This is the adjustment to `offset`
   * producing the offset where data for the next layout would be
   * written.
   *
   * @abstract
   */
  encode(src, b, offset2) {
    throw new Error("Layout is abstract");
  }
  /**
   * Calculate the span of a specific instance of a layout.
   *
   * @param {Buffer} b - the buffer that contains an encoded instance.
   *
   * @param {Number} [offset] - the offset at which the encoded instance
   * starts.  If absent a zero offset is inferred.
   *
   * @return {Number} - the number of bytes covered by the layout
   * instance.  If this method is not overridden in a subclass the
   * definition-time constant {@link Layout#span|span} will be
   * returned.
   *
   * @throws {RangeError} - if the length of the value cannot be
   * determined.
   */
  getSpan(b, offset2) {
    if (0 > this.span) {
      throw new RangeError("indeterminate span");
    }
    return this.span;
  }
  /**
   * Replicate the layout using a new property.
   *
   * This function must be used to get a structurally-equivalent layout
   * with a different name since all {@link Layout} instances are
   * immutable.
   *
   * **NOTE** This is a shallow copy.  All fields except {@link
   * Layout#property|property} are strictly equal to the origin layout.
   *
   * @param {String} property - the value for {@link
   * Layout#property|property} in the replica.
   *
   * @returns {Layout} - the copy with {@link Layout#property|property}
   * set to `property`.
   */
  replicate(property) {
    const rv = Object.create(this.constructor.prototype);
    Object.assign(rv, this);
    rv.property = property;
    return rv;
  }
  /**
   * Create an object from layout properties and an array of values.
   *
   * **NOTE** This function returns `undefined` if invoked on a layout
   * that does not return its value as an Object.  Objects are
   * returned for things that are a {@link Structure}, which includes
   * {@link VariantLayout|variant layouts} if they are structures, and
   * excludes {@link Union}s.  If you want this feature for a union
   * you must use {@link Union.getVariant|getVariant} to select the
   * desired layout.
   *
   * @param {Array} values - an array of values that correspond to the
   * default order for properties.  As with {@link Layout#decode|decode}
   * layout elements that have no property name are skipped when
   * iterating over the array values.  Only the top-level properties are
   * assigned; arguments are not assigned to properties of contained
   * layouts.  Any unused values are ignored.
   *
   * @return {(Object|undefined)}
   */
  fromArray(values) {
    return void 0;
  }
}
var Layout_2 = Layout2;
function nameWithProperty(name, lo) {
  if (lo.property) {
    return name + "[" + lo.property + "]";
  }
  return name;
}
class ExternalLayout2 extends Layout2 {
  /**
   * Return `true` iff the external layout decodes to an unsigned
   * integer layout.
   *
   * In that case it can be used as the source of {@link
   * Sequence#count|Sequence counts}, {@link Blob#length|Blob lengths},
   * or as {@link UnionLayoutDiscriminator#layout|external union
   * discriminators}.
   *
   * @abstract
   */
  isCount() {
    throw new Error("ExternalLayout is abstract");
  }
}
class OffsetLayout2 extends ExternalLayout2 {
  constructor(layout, offset2, property) {
    if (!(layout instanceof Layout2)) {
      throw new TypeError("layout must be a Layout");
    }
    if (void 0 === offset2) {
      offset2 = 0;
    } else if (!Number.isInteger(offset2)) {
      throw new TypeError("offset must be integer or undefined");
    }
    super(layout.span, property || layout.property);
    this.layout = layout;
    this.offset = offset2;
  }
  /** @override */
  isCount() {
    return this.layout instanceof UInt2 || this.layout instanceof UIntBE2;
  }
  /** @override */
  decode(b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    return this.layout.decode(b, offset2 + this.offset);
  }
  /** @override */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    return this.layout.encode(src, b, offset2 + this.offset);
  }
}
class UInt2 extends Layout2 {
  constructor(span, property) {
    super(span, property);
    if (6 < this.span) {
      throw new RangeError("span must not exceed 6 bytes");
    }
  }
  /** @override */
  decode(b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    return b.readUIntLE(offset2, this.span);
  }
  /** @override */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    b.writeUIntLE(src, offset2, this.span);
    return this.span;
  }
}
class UIntBE2 extends Layout2 {
  constructor(span, property) {
    super(span, property);
    if (6 < this.span) {
      throw new RangeError("span must not exceed 6 bytes");
    }
  }
  /** @override */
  decode(b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    return b.readUIntBE(offset2, this.span);
  }
  /** @override */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    b.writeUIntBE(src, offset2, this.span);
    return this.span;
  }
}
const V2E32 = Math.pow(2, 32);
function divmodInt64(src) {
  const hi32 = Math.floor(src / V2E32);
  const lo32 = src - hi32 * V2E32;
  return { hi32, lo32 };
}
function roundedInt64(hi32, lo32) {
  return hi32 * V2E32 + lo32;
}
class NearUInt642 extends Layout2 {
  constructor(property) {
    super(8, property);
  }
  /** @override */
  decode(b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    const lo32 = b.readUInt32LE(offset2);
    const hi32 = b.readUInt32LE(offset2 + 4);
    return roundedInt64(hi32, lo32);
  }
  /** @override */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    const split = divmodInt64(src);
    b.writeUInt32LE(split.lo32, offset2);
    b.writeUInt32LE(split.hi32, offset2 + 4);
    return 8;
  }
}
class NearInt642 extends Layout2 {
  constructor(property) {
    super(8, property);
  }
  /** @override */
  decode(b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    const lo32 = b.readUInt32LE(offset2);
    const hi32 = b.readInt32LE(offset2 + 4);
    return roundedInt64(hi32, lo32);
  }
  /** @override */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    const split = divmodInt64(src);
    b.writeUInt32LE(split.lo32, offset2);
    b.writeInt32LE(split.hi32, offset2 + 4);
    return 8;
  }
}
class Structure2 extends Layout2 {
  constructor(fields, property, decodePrefixes) {
    if (!(Array.isArray(fields) && fields.reduce((acc, v) => acc && v instanceof Layout2, true))) {
      throw new TypeError("fields must be array of Layout instances");
    }
    if ("boolean" === typeof property && void 0 === decodePrefixes) {
      decodePrefixes = property;
      property = void 0;
    }
    for (const fd of fields) {
      if (0 > fd.span && void 0 === fd.property) {
        throw new Error("fields cannot contain unnamed variable-length layout");
      }
    }
    let span = -1;
    try {
      span = fields.reduce((span2, fd) => span2 + fd.getSpan(), 0);
    } catch (e) {
    }
    super(span, property);
    this.fields = fields;
    this.decodePrefixes = !!decodePrefixes;
  }
  /** @override */
  getSpan(b, offset2) {
    if (0 <= this.span) {
      return this.span;
    }
    if (void 0 === offset2) {
      offset2 = 0;
    }
    let span = 0;
    try {
      span = this.fields.reduce((span2, fd) => {
        const fsp = fd.getSpan(b, offset2);
        offset2 += fsp;
        return span2 + fsp;
      }, 0);
    } catch (e) {
      throw new RangeError("indeterminate span");
    }
    return span;
  }
  /** @override */
  decode(b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    const dest = this.makeDestinationObject();
    for (const fd of this.fields) {
      if (void 0 !== fd.property) {
        dest[fd.property] = fd.decode(b, offset2);
      }
      offset2 += fd.getSpan(b, offset2);
      if (this.decodePrefixes && b.length === offset2) {
        break;
      }
    }
    return dest;
  }
  /** Implement {@link Layout#encode|encode} for {@link Structure}.
   *
   * If `src` is missing a property for a member with a defined {@link
   * Layout#property|property} the corresponding region of the buffer is
   * left unmodified. */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    const firstOffset = offset2;
    let lastOffset = 0;
    let lastWrote = 0;
    for (const fd of this.fields) {
      let span = fd.span;
      lastWrote = 0 < span ? span : 0;
      if (void 0 !== fd.property) {
        const fv = src[fd.property];
        if (void 0 !== fv) {
          lastWrote = fd.encode(fv, b, offset2);
          if (0 > span) {
            span = fd.getSpan(b, offset2);
          }
        }
      }
      lastOffset = offset2;
      offset2 += span;
    }
    return lastOffset + lastWrote - firstOffset;
  }
  /** @override */
  fromArray(values) {
    const dest = this.makeDestinationObject();
    for (const fd of this.fields) {
      if (void 0 !== fd.property && 0 < values.length) {
        dest[fd.property] = values.shift();
      }
    }
    return dest;
  }
  /**
   * Get access to the layout of a given property.
   *
   * @param {String} property - the structure member of interest.
   *
   * @return {Layout} - the layout associated with `property`, or
   * undefined if there is no such property.
   */
  layoutFor(property) {
    if ("string" !== typeof property) {
      throw new TypeError("property must be string");
    }
    for (const fd of this.fields) {
      if (fd.property === property) {
        return fd;
      }
    }
  }
  /**
   * Get the offset of a structure member.
   *
   * @param {String} property - the structure member of interest.
   *
   * @return {Number} - the offset in bytes to the start of `property`
   * within the structure, or undefined if `property` is not a field
   * within the structure.  If the property is a member but follows a
   * variable-length structure member a negative number will be
   * returned.
   */
  offsetOf(property) {
    if ("string" !== typeof property) {
      throw new TypeError("property must be string");
    }
    let offset2 = 0;
    for (const fd of this.fields) {
      if (fd.property === property) {
        return offset2;
      }
      if (0 > fd.span) {
        offset2 = -1;
      } else if (0 <= offset2) {
        offset2 += fd.span;
      }
    }
  }
}
class UnionDiscriminator2 {
  constructor(property) {
    this.property = property;
  }
  /** Analog to {@link Layout#decode|Layout decode} for union discriminators.
   *
   * The implementation of this method need not reference the buffer if
   * variant information is available through other means. */
  decode() {
    throw new Error("UnionDiscriminator is abstract");
  }
  /** Analog to {@link Layout#decode|Layout encode} for union discriminators.
   *
   * The implementation of this method need not store the value if
   * variant information is maintained through other means. */
  encode() {
    throw new Error("UnionDiscriminator is abstract");
  }
}
class UnionLayoutDiscriminator2 extends UnionDiscriminator2 {
  constructor(layout, property) {
    if (!(layout instanceof ExternalLayout2 && layout.isCount())) {
      throw new TypeError("layout must be an unsigned integer ExternalLayout");
    }
    super(property || layout.property || "variant");
    this.layout = layout;
  }
  /** Delegate decoding to {@link UnionLayoutDiscriminator#layout|layout}. */
  decode(b, offset2) {
    return this.layout.decode(b, offset2);
  }
  /** Delegate encoding to {@link UnionLayoutDiscriminator#layout|layout}. */
  encode(src, b, offset2) {
    return this.layout.encode(src, b, offset2);
  }
}
class Union2 extends Layout2 {
  constructor(discr, defaultLayout, property) {
    const upv = discr instanceof UInt2 || discr instanceof UIntBE2;
    if (upv) {
      discr = new UnionLayoutDiscriminator2(new OffsetLayout2(discr));
    } else if (discr instanceof ExternalLayout2 && discr.isCount()) {
      discr = new UnionLayoutDiscriminator2(discr);
    } else if (!(discr instanceof UnionDiscriminator2)) {
      throw new TypeError("discr must be a UnionDiscriminator or an unsigned integer layout");
    }
    if (void 0 === defaultLayout) {
      defaultLayout = null;
    }
    if (!(null === defaultLayout || defaultLayout instanceof Layout2)) {
      throw new TypeError("defaultLayout must be null or a Layout");
    }
    if (null !== defaultLayout) {
      if (0 > defaultLayout.span) {
        throw new Error("defaultLayout must have constant span");
      }
      if (void 0 === defaultLayout.property) {
        defaultLayout = defaultLayout.replicate("content");
      }
    }
    let span = -1;
    if (defaultLayout) {
      span = defaultLayout.span;
      if (0 <= span && upv) {
        span += discr.layout.span;
      }
    }
    super(span, property);
    this.discriminator = discr;
    this.usesPrefixDiscriminator = upv;
    this.defaultLayout = defaultLayout;
    this.registry = {};
    let boundGetSourceVariant = this.defaultGetSourceVariant.bind(this);
    this.getSourceVariant = function(src) {
      return boundGetSourceVariant(src);
    };
    this.configGetSourceVariant = function(gsv) {
      boundGetSourceVariant = gsv.bind(this);
    };
  }
  /** @override */
  getSpan(b, offset2) {
    if (0 <= this.span) {
      return this.span;
    }
    if (void 0 === offset2) {
      offset2 = 0;
    }
    const vlo = this.getVariant(b, offset2);
    if (!vlo) {
      throw new Error("unable to determine span for unrecognized variant");
    }
    return vlo.getSpan(b, offset2);
  }
  /**
   * Method to infer a registered Union variant compatible with `src`.
   *
   * The first satisified rule in the following sequence defines the
   * return value:
   * * If `src` has properties matching the Union discriminator and
   *   the default layout, `undefined` is returned regardless of the
   *   value of the discriminator property (this ensures the default
   *   layout will be used);
   * * If `src` has a property matching the Union discriminator, the
   *   value of the discriminator identifies a registered variant, and
   *   either (a) the variant has no layout, or (b) `src` has the
   *   variant's property, then the variant is returned (because the
   *   source satisfies the constraints of the variant it identifies);
   * * If `src` does not have a property matching the Union
   *   discriminator, but does have a property matching a registered
   *   variant, then the variant is returned (because the source
   *   matches a variant without an explicit conflict);
   * * An error is thrown (because we either can't identify a variant,
   *   or we were explicitly told the variant but can't satisfy it).
   *
   * @param {Object} src - an object presumed to be compatible with
   * the content of the Union.
   *
   * @return {(undefined|VariantLayout)} - as described above.
   *
   * @throws {Error} - if `src` cannot be associated with a default or
   * registered variant.
   */
  defaultGetSourceVariant(src) {
    if (src.hasOwnProperty(this.discriminator.property)) {
      if (this.defaultLayout && src.hasOwnProperty(this.defaultLayout.property)) {
        return void 0;
      }
      const vlo = this.registry[src[this.discriminator.property]];
      if (vlo && (!vlo.layout || src.hasOwnProperty(vlo.property))) {
        return vlo;
      }
    } else {
      for (const tag in this.registry) {
        const vlo = this.registry[tag];
        if (src.hasOwnProperty(vlo.property)) {
          return vlo;
        }
      }
    }
    throw new Error("unable to infer src variant");
  }
  /** Implement {@link Layout#decode|decode} for {@link Union}.
   *
   * If the variant is {@link Union#addVariant|registered} the return
   * value is an instance of that variant, with no explicit
   * discriminator.  Otherwise the {@link Union#defaultLayout|default
   * layout} is used to decode the content. */
  decode(b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    let dest;
    const dlo = this.discriminator;
    const discr = dlo.decode(b, offset2);
    let clo = this.registry[discr];
    if (void 0 === clo) {
      let contentOffset = 0;
      clo = this.defaultLayout;
      if (this.usesPrefixDiscriminator) {
        contentOffset = dlo.layout.span;
      }
      dest = this.makeDestinationObject();
      dest[dlo.property] = discr;
      dest[clo.property] = this.defaultLayout.decode(b, offset2 + contentOffset);
    } else {
      dest = clo.decode(b, offset2);
    }
    return dest;
  }
  /** Implement {@link Layout#encode|encode} for {@link Union}.
   *
   * This API assumes the `src` object is consistent with the union's
   * {@link Union#defaultLayout|default layout}.  To encode variants
   * use the appropriate variant-specific {@link VariantLayout#encode}
   * method. */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    const vlo = this.getSourceVariant(src);
    if (void 0 === vlo) {
      const dlo = this.discriminator;
      const clo = this.defaultLayout;
      let contentOffset = 0;
      if (this.usesPrefixDiscriminator) {
        contentOffset = dlo.layout.span;
      }
      dlo.encode(src[dlo.property], b, offset2);
      return contentOffset + clo.encode(
        src[clo.property],
        b,
        offset2 + contentOffset
      );
    }
    return vlo.encode(src, b, offset2);
  }
  /** Register a new variant structure within a union.  The newly
   * created variant is returned.
   *
   * @param {Number} variant - initializer for {@link
   * VariantLayout#variant|variant}.
   *
   * @param {Layout} layout - initializer for {@link
   * VariantLayout#layout|layout}.
   *
   * @param {String} property - initializer for {@link
   * Layout#property|property}.
   *
   * @return {VariantLayout} */
  addVariant(variant, layout, property) {
    const rv = new VariantLayout2(this, variant, layout, property);
    this.registry[variant] = rv;
    return rv;
  }
  /**
   * Get the layout associated with a registered variant.
   *
   * If `vb` does not produce a registered variant the function returns
   * `undefined`.
   *
   * @param {(Number|Buffer)} vb - either the variant number, or a
   * buffer from which the discriminator is to be read.
   *
   * @param {Number} offset - offset into `vb` for the start of the
   * union.  Used only when `vb` is an instance of {Buffer}.
   *
   * @return {({VariantLayout}|undefined)}
   */
  getVariant(vb, offset2) {
    let variant = vb;
    if (Buffer.isBuffer(vb)) {
      if (void 0 === offset2) {
        offset2 = 0;
      }
      variant = this.discriminator.decode(vb, offset2);
    }
    return this.registry[variant];
  }
}
class VariantLayout2 extends Layout2 {
  constructor(union2, variant, layout, property) {
    if (!(union2 instanceof Union2)) {
      throw new TypeError("union must be a Union");
    }
    if (!Number.isInteger(variant) || 0 > variant) {
      throw new TypeError("variant must be a (non-negative) integer");
    }
    if ("string" === typeof layout && void 0 === property) {
      property = layout;
      layout = null;
    }
    if (layout) {
      if (!(layout instanceof Layout2)) {
        throw new TypeError("layout must be a Layout");
      }
      if (null !== union2.defaultLayout && 0 <= layout.span && layout.span > union2.defaultLayout.span) {
        throw new Error("variant span exceeds span of containing union");
      }
      if ("string" !== typeof property) {
        throw new TypeError("variant must have a String property");
      }
    }
    let span = union2.span;
    if (0 > union2.span) {
      span = layout ? layout.span : 0;
      if (0 <= span && union2.usesPrefixDiscriminator) {
        span += union2.discriminator.layout.span;
      }
    }
    super(span, property);
    this.union = union2;
    this.variant = variant;
    this.layout = layout || null;
  }
  /** @override */
  getSpan(b, offset2) {
    if (0 <= this.span) {
      return this.span;
    }
    if (void 0 === offset2) {
      offset2 = 0;
    }
    let contentOffset = 0;
    if (this.union.usesPrefixDiscriminator) {
      contentOffset = this.union.discriminator.layout.span;
    }
    return contentOffset + this.layout.getSpan(b, offset2 + contentOffset);
  }
  /** @override */
  decode(b, offset2) {
    const dest = this.makeDestinationObject();
    if (void 0 === offset2) {
      offset2 = 0;
    }
    if (this !== this.union.getVariant(b, offset2)) {
      throw new Error("variant mismatch");
    }
    let contentOffset = 0;
    if (this.union.usesPrefixDiscriminator) {
      contentOffset = this.union.discriminator.layout.span;
    }
    if (this.layout) {
      dest[this.property] = this.layout.decode(b, offset2 + contentOffset);
    } else if (this.property) {
      dest[this.property] = true;
    } else if (this.union.usesPrefixDiscriminator) {
      dest[this.union.discriminator.property] = this.variant;
    }
    return dest;
  }
  /** @override */
  encode(src, b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    let contentOffset = 0;
    if (this.union.usesPrefixDiscriminator) {
      contentOffset = this.union.discriminator.layout.span;
    }
    if (this.layout && !src.hasOwnProperty(this.property)) {
      throw new TypeError("variant lacks property " + this.property);
    }
    this.union.discriminator.encode(this.variant, b, offset2);
    let span = contentOffset;
    if (this.layout) {
      this.layout.encode(src[this.property], b, offset2 + contentOffset);
      span += this.layout.getSpan(b, offset2 + contentOffset);
      if (0 <= this.union.span && span > this.union.span) {
        throw new Error("encoded variant overruns containing union");
      }
    }
    return span;
  }
  /** Delegate {@link Layout#fromArray|fromArray} to {@link
   * VariantLayout#layout|layout}. */
  fromArray(values) {
    if (this.layout) {
      return this.layout.fromArray(values);
    }
  }
}
class Blob$1 extends Layout2 {
  constructor(length, property) {
    if (!(length instanceof ExternalLayout2 && length.isCount() || Number.isInteger(length) && 0 <= length)) {
      throw new TypeError("length must be positive integer or an unsigned integer ExternalLayout");
    }
    let span = -1;
    if (!(length instanceof ExternalLayout2)) {
      span = length;
    }
    super(span, property);
    this.length = length;
  }
  /** @override */
  getSpan(b, offset2) {
    let span = this.span;
    if (0 > span) {
      span = this.length.decode(b, offset2);
    }
    return span;
  }
  /** @override */
  decode(b, offset2) {
    if (void 0 === offset2) {
      offset2 = 0;
    }
    let span = this.span;
    if (0 > span) {
      span = this.length.decode(b, offset2);
    }
    return b.slice(offset2, offset2 + span);
  }
  /** Implement {@link Layout#encode|encode} for {@link Blob}.
   *
   * **NOTE** If {@link Layout#count|count} is an instance of {@link
   * ExternalLayout} then the length of `src` will be encoded as the
   * count after `src` is encoded. */
  encode(src, b, offset2) {
    let span = this.length;
    if (this.length instanceof ExternalLayout2) {
      span = src.length;
    }
    if (!(Buffer.isBuffer(src) && span === src.length)) {
      throw new TypeError(nameWithProperty("Blob.encode", this) + " requires (length " + span + ") Buffer as src");
    }
    if (offset2 + span > b.length) {
      throw new RangeError("encoding overruns Buffer");
    }
    b.write(src.toString("hex"), offset2, span, "hex");
    if (this.length instanceof ExternalLayout2) {
      this.length.encode(span, b, offset2);
    }
    return span;
  }
}
var offset = (layout, offset2, property) => new OffsetLayout2(layout, offset2, property);
var u8 = (property) => new UInt2(1, property);
var u32 = (property) => new UInt2(4, property);
var nu64 = (property) => new NearUInt642(property);
var ns64 = (property) => new NearInt642(property);
var struct = (fields, property, decodePrefixes) => new Structure2(fields, property, decodePrefixes);
var union = (discr, defaultLayout, property) => new Union2(discr, defaultLayout, property);
var blob = (length, property) => new Blob$1(length, property);
class RustStringLayout extends Layout_2 {
  constructor(property) {
    super(-1, property);
    this.property = property;
    this.layout = struct([
      u32("length"),
      u32("lengthPadding"),
      blob(offset(u32(), -8), "chars")
    ], this.property);
  }
  encode(src, b, offset2 = 0) {
    if (src === null || src === void 0) {
      return this.layout.span;
    }
    const data = {
      chars: Buffer.from(src, "utf8")
    };
    return this.layout.encode(data, b, offset2);
  }
  decode(b, offset2 = 0) {
    const data = this.layout.decode(b, offset2);
    return data["chars"].toString();
  }
  getSpan(b, offset2 = 0) {
    return u32().span + u32().span + new BN(new Uint8Array(b).slice(offset2, offset2 + 4), 10, "le").toNumber();
  }
}
function rustStringLayout(property) {
  return new RustStringLayout(property);
}
function publicKey$2(property) {
  return blob(32, property);
}
const LAYOUT = union(u32("instruction"));
LAYOUT.addVariant(0, struct([
  ns64("lamports"),
  ns64("space"),
  publicKey$2("owner")
]), "createAccount");
LAYOUT.addVariant(1, struct([publicKey$2("owner")]), "assign");
LAYOUT.addVariant(2, struct([ns64("lamports")]), "transfer");
LAYOUT.addVariant(3, struct([
  publicKey$2("base"),
  rustStringLayout("seed"),
  ns64("lamports"),
  ns64("space"),
  publicKey$2("owner")
]), "createAccountWithSeed");
LAYOUT.addVariant(4, struct([publicKey$2("authorized")]), "advanceNonceAccount");
LAYOUT.addVariant(5, struct([ns64("lamports")]), "withdrawNonceAccount");
LAYOUT.addVariant(6, struct([publicKey$2("authorized")]), "initializeNonceAccount");
LAYOUT.addVariant(7, struct([publicKey$2("authorized")]), "authorizeNonceAccount");
LAYOUT.addVariant(8, struct([ns64("space")]), "allocate");
LAYOUT.addVariant(9, struct([
  publicKey$2("base"),
  rustStringLayout("seed"),
  ns64("space"),
  publicKey$2("owner")
]), "allocateWithSeed");
LAYOUT.addVariant(10, struct([
  publicKey$2("base"),
  rustStringLayout("seed"),
  publicKey$2("owner")
]), "assignWithSeed");
LAYOUT.addVariant(11, struct([
  ns64("lamports"),
  rustStringLayout("seed"),
  publicKey$2("owner")
]), "transferWithSeed");
Math.max(...Object.values(LAYOUT.registry).map((r) => r.span));
class WrappedLayout$1 extends Layout_2 {
  constructor(layout, decoder, encoder, property) {
    super(layout.span, property);
    this.layout = layout;
    this.decoder = decoder;
    this.encoder = encoder;
  }
  decode(b, offset2) {
    return this.decoder(this.layout.decode(b, offset2));
  }
  encode(src, b, offset2) {
    return this.layout.encode(this.encoder(src), b, offset2);
  }
  getSpan(b, offset2) {
    return this.layout.getSpan(b, offset2);
  }
}
function publicKey$1(property) {
  return new WrappedLayout$1(blob(32), (b) => new PublicKey(b), (key) => key.toBuffer(), property);
}
struct([
  u32("version"),
  u32("state"),
  publicKey$1("authorizedPubkey"),
  publicKey$1("nonce"),
  struct([nu64("lamportsPerSignature")], "feeCalculator")
]);
new PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA");
new PublicKey("ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL");
var browserPonyfill = { exports: {} };
(function(module, exports$1) {
  var global2 = typeof self !== "undefined" ? self : commonjsGlobal;
  var __self__ = function() {
    function F() {
      this.fetch = false;
      this.DOMException = global2.DOMException;
    }
    F.prototype = global2;
    return new F();
  }();
  (function(self2) {
    (function(exports$12) {
      var support = {
        searchParams: "URLSearchParams" in self2,
        iterable: "Symbol" in self2 && "iterator" in Symbol,
        blob: "FileReader" in self2 && "Blob" in self2 && function() {
          try {
            new Blob();
            return true;
          } catch (e) {
            return false;
          }
        }(),
        formData: "FormData" in self2,
        arrayBuffer: "ArrayBuffer" in self2
      };
      function isDataView(obj) {
        return obj && DataView.prototype.isPrototypeOf(obj);
      }
      if (support.arrayBuffer) {
        var viewClasses = [
          "[object Int8Array]",
          "[object Uint8Array]",
          "[object Uint8ClampedArray]",
          "[object Int16Array]",
          "[object Uint16Array]",
          "[object Int32Array]",
          "[object Uint32Array]",
          "[object Float32Array]",
          "[object Float64Array]"
        ];
        var isArrayBufferView = ArrayBuffer.isView || function(obj) {
          return obj && viewClasses.indexOf(Object.prototype.toString.call(obj)) > -1;
        };
      }
      function normalizeName(name) {
        if (typeof name !== "string") {
          name = String(name);
        }
        if (/[^a-z0-9\-#$%&'*+.^_`|~]/i.test(name)) {
          throw new TypeError("Invalid character in header field name");
        }
        return name.toLowerCase();
      }
      function normalizeValue(value) {
        if (typeof value !== "string") {
          value = String(value);
        }
        return value;
      }
      function iteratorFor(items) {
        var iterator = {
          next: function() {
            var value = items.shift();
            return { done: value === void 0, value };
          }
        };
        if (support.iterable) {
          iterator[Symbol.iterator] = function() {
            return iterator;
          };
        }
        return iterator;
      }
      function Headers(headers) {
        this.map = {};
        if (headers instanceof Headers) {
          headers.forEach(function(value, name) {
            this.append(name, value);
          }, this);
        } else if (Array.isArray(headers)) {
          headers.forEach(function(header) {
            this.append(header[0], header[1]);
          }, this);
        } else if (headers) {
          Object.getOwnPropertyNames(headers).forEach(function(name) {
            this.append(name, headers[name]);
          }, this);
        }
      }
      Headers.prototype.append = function(name, value) {
        name = normalizeName(name);
        value = normalizeValue(value);
        var oldValue = this.map[name];
        this.map[name] = oldValue ? oldValue + ", " + value : value;
      };
      Headers.prototype["delete"] = function(name) {
        delete this.map[normalizeName(name)];
      };
      Headers.prototype.get = function(name) {
        name = normalizeName(name);
        return this.has(name) ? this.map[name] : null;
      };
      Headers.prototype.has = function(name) {
        return this.map.hasOwnProperty(normalizeName(name));
      };
      Headers.prototype.set = function(name, value) {
        this.map[normalizeName(name)] = normalizeValue(value);
      };
      Headers.prototype.forEach = function(callback, thisArg) {
        for (var name in this.map) {
          if (this.map.hasOwnProperty(name)) {
            callback.call(thisArg, this.map[name], name, this);
          }
        }
      };
      Headers.prototype.keys = function() {
        var items = [];
        this.forEach(function(value, name) {
          items.push(name);
        });
        return iteratorFor(items);
      };
      Headers.prototype.values = function() {
        var items = [];
        this.forEach(function(value) {
          items.push(value);
        });
        return iteratorFor(items);
      };
      Headers.prototype.entries = function() {
        var items = [];
        this.forEach(function(value, name) {
          items.push([name, value]);
        });
        return iteratorFor(items);
      };
      if (support.iterable) {
        Headers.prototype[Symbol.iterator] = Headers.prototype.entries;
      }
      function consumed(body) {
        if (body.bodyUsed) {
          return Promise.reject(new TypeError("Already read"));
        }
        body.bodyUsed = true;
      }
      function fileReaderReady(reader) {
        return new Promise(function(resolve, reject) {
          reader.onload = function() {
            resolve(reader.result);
          };
          reader.onerror = function() {
            reject(reader.error);
          };
        });
      }
      function readBlobAsArrayBuffer(blob2) {
        var reader = new FileReader();
        var promise = fileReaderReady(reader);
        reader.readAsArrayBuffer(blob2);
        return promise;
      }
      function readBlobAsText(blob2) {
        var reader = new FileReader();
        var promise = fileReaderReady(reader);
        reader.readAsText(blob2);
        return promise;
      }
      function readArrayBufferAsText(buf) {
        var view = new Uint8Array(buf);
        var chars = new Array(view.length);
        for (var i = 0; i < view.length; i++) {
          chars[i] = String.fromCharCode(view[i]);
        }
        return chars.join("");
      }
      function bufferClone(buf) {
        if (buf.slice) {
          return buf.slice(0);
        } else {
          var view = new Uint8Array(buf.byteLength);
          view.set(new Uint8Array(buf));
          return view.buffer;
        }
      }
      function Body() {
        this.bodyUsed = false;
        this._initBody = function(body) {
          this._bodyInit = body;
          if (!body) {
            this._bodyText = "";
          } else if (typeof body === "string") {
            this._bodyText = body;
          } else if (support.blob && Blob.prototype.isPrototypeOf(body)) {
            this._bodyBlob = body;
          } else if (support.formData && FormData.prototype.isPrototypeOf(body)) {
            this._bodyFormData = body;
          } else if (support.searchParams && URLSearchParams.prototype.isPrototypeOf(body)) {
            this._bodyText = body.toString();
          } else if (support.arrayBuffer && support.blob && isDataView(body)) {
            this._bodyArrayBuffer = bufferClone(body.buffer);
            this._bodyInit = new Blob([this._bodyArrayBuffer]);
          } else if (support.arrayBuffer && (ArrayBuffer.prototype.isPrototypeOf(body) || isArrayBufferView(body))) {
            this._bodyArrayBuffer = bufferClone(body);
          } else {
            this._bodyText = body = Object.prototype.toString.call(body);
          }
          if (!this.headers.get("content-type")) {
            if (typeof body === "string") {
              this.headers.set("content-type", "text/plain;charset=UTF-8");
            } else if (this._bodyBlob && this._bodyBlob.type) {
              this.headers.set("content-type", this._bodyBlob.type);
            } else if (support.searchParams && URLSearchParams.prototype.isPrototypeOf(body)) {
              this.headers.set("content-type", "application/x-www-form-urlencoded;charset=UTF-8");
            }
          }
        };
        if (support.blob) {
          this.blob = function() {
            var rejected = consumed(this);
            if (rejected) {
              return rejected;
            }
            if (this._bodyBlob) {
              return Promise.resolve(this._bodyBlob);
            } else if (this._bodyArrayBuffer) {
              return Promise.resolve(new Blob([this._bodyArrayBuffer]));
            } else if (this._bodyFormData) {
              throw new Error("could not read FormData body as blob");
            } else {
              return Promise.resolve(new Blob([this._bodyText]));
            }
          };
          this.arrayBuffer = function() {
            if (this._bodyArrayBuffer) {
              return consumed(this) || Promise.resolve(this._bodyArrayBuffer);
            } else {
              return this.blob().then(readBlobAsArrayBuffer);
            }
          };
        }
        this.text = function() {
          var rejected = consumed(this);
          if (rejected) {
            return rejected;
          }
          if (this._bodyBlob) {
            return readBlobAsText(this._bodyBlob);
          } else if (this._bodyArrayBuffer) {
            return Promise.resolve(readArrayBufferAsText(this._bodyArrayBuffer));
          } else if (this._bodyFormData) {
            throw new Error("could not read FormData body as text");
          } else {
            return Promise.resolve(this._bodyText);
          }
        };
        if (support.formData) {
          this.formData = function() {
            return this.text().then(decode2);
          };
        }
        this.json = function() {
          return this.text().then(JSON.parse);
        };
        return this;
      }
      var methods = ["DELETE", "GET", "HEAD", "OPTIONS", "POST", "PUT"];
      function normalizeMethod(method) {
        var upcased = method.toUpperCase();
        return methods.indexOf(upcased) > -1 ? upcased : method;
      }
      function Request(input, options) {
        options = options || {};
        var body = options.body;
        if (input instanceof Request) {
          if (input.bodyUsed) {
            throw new TypeError("Already read");
          }
          this.url = input.url;
          this.credentials = input.credentials;
          if (!options.headers) {
            this.headers = new Headers(input.headers);
          }
          this.method = input.method;
          this.mode = input.mode;
          this.signal = input.signal;
          if (!body && input._bodyInit != null) {
            body = input._bodyInit;
            input.bodyUsed = true;
          }
        } else {
          this.url = String(input);
        }
        this.credentials = options.credentials || this.credentials || "same-origin";
        if (options.headers || !this.headers) {
          this.headers = new Headers(options.headers);
        }
        this.method = normalizeMethod(options.method || this.method || "GET");
        this.mode = options.mode || this.mode || null;
        this.signal = options.signal || this.signal;
        this.referrer = null;
        if ((this.method === "GET" || this.method === "HEAD") && body) {
          throw new TypeError("Body not allowed for GET or HEAD requests");
        }
        this._initBody(body);
      }
      Request.prototype.clone = function() {
        return new Request(this, { body: this._bodyInit });
      };
      function decode2(body) {
        var form = new FormData();
        body.trim().split("&").forEach(function(bytes) {
          if (bytes) {
            var split = bytes.split("=");
            var name = split.shift().replace(/\+/g, " ");
            var value = split.join("=").replace(/\+/g, " ");
            form.append(decodeURIComponent(name), decodeURIComponent(value));
          }
        });
        return form;
      }
      function parseHeaders(rawHeaders) {
        var headers = new Headers();
        var preProcessedHeaders = rawHeaders.replace(/\r?\n[\t ]+/g, " ");
        preProcessedHeaders.split(/\r?\n/).forEach(function(line) {
          var parts = line.split(":");
          var key = parts.shift().trim();
          if (key) {
            var value = parts.join(":").trim();
            headers.append(key, value);
          }
        });
        return headers;
      }
      Body.call(Request.prototype);
      function Response(bodyInit, options) {
        if (!options) {
          options = {};
        }
        this.type = "default";
        this.status = options.status === void 0 ? 200 : options.status;
        this.ok = this.status >= 200 && this.status < 300;
        this.statusText = "statusText" in options ? options.statusText : "OK";
        this.headers = new Headers(options.headers);
        this.url = options.url || "";
        this._initBody(bodyInit);
      }
      Body.call(Response.prototype);
      Response.prototype.clone = function() {
        return new Response(this._bodyInit, {
          status: this.status,
          statusText: this.statusText,
          headers: new Headers(this.headers),
          url: this.url
        });
      };
      Response.error = function() {
        var response = new Response(null, { status: 0, statusText: "" });
        response.type = "error";
        return response;
      };
      var redirectStatuses = [301, 302, 303, 307, 308];
      Response.redirect = function(url, status) {
        if (redirectStatuses.indexOf(status) === -1) {
          throw new RangeError("Invalid status code");
        }
        return new Response(null, { status, headers: { location: url } });
      };
      exports$12.DOMException = self2.DOMException;
      try {
        new exports$12.DOMException();
      } catch (err) {
        exports$12.DOMException = function(message, name) {
          this.message = message;
          this.name = name;
          var error = Error(message);
          this.stack = error.stack;
        };
        exports$12.DOMException.prototype = Object.create(Error.prototype);
        exports$12.DOMException.prototype.constructor = exports$12.DOMException;
      }
      function fetch(input, init) {
        return new Promise(function(resolve, reject) {
          var request = new Request(input, init);
          if (request.signal && request.signal.aborted) {
            return reject(new exports$12.DOMException("Aborted", "AbortError"));
          }
          var xhr = new XMLHttpRequest();
          function abortXhr() {
            xhr.abort();
          }
          xhr.onload = function() {
            var options = {
              status: xhr.status,
              statusText: xhr.statusText,
              headers: parseHeaders(xhr.getAllResponseHeaders() || "")
            };
            options.url = "responseURL" in xhr ? xhr.responseURL : options.headers.get("X-Request-URL");
            var body = "response" in xhr ? xhr.response : xhr.responseText;
            resolve(new Response(body, options));
          };
          xhr.onerror = function() {
            reject(new TypeError("Network request failed"));
          };
          xhr.ontimeout = function() {
            reject(new TypeError("Network request failed"));
          };
          xhr.onabort = function() {
            reject(new exports$12.DOMException("Aborted", "AbortError"));
          };
          xhr.open(request.method, request.url, true);
          if (request.credentials === "include") {
            xhr.withCredentials = true;
          } else if (request.credentials === "omit") {
            xhr.withCredentials = false;
          }
          if ("responseType" in xhr && support.blob) {
            xhr.responseType = "blob";
          }
          request.headers.forEach(function(value, name) {
            xhr.setRequestHeader(name, value);
          });
          if (request.signal) {
            request.signal.addEventListener("abort", abortXhr);
            xhr.onreadystatechange = function() {
              if (xhr.readyState === 4) {
                request.signal.removeEventListener("abort", abortXhr);
              }
            };
          }
          xhr.send(typeof request._bodyInit === "undefined" ? null : request._bodyInit);
        });
      }
      fetch.polyfill = true;
      if (!self2.fetch) {
        self2.fetch = fetch;
        self2.Headers = Headers;
        self2.Request = Request;
        self2.Response = Response;
      }
      exports$12.Headers = Headers;
      exports$12.Request = Request;
      exports$12.Response = Response;
      exports$12.fetch = fetch;
      Object.defineProperty(exports$12, "__esModule", { value: true });
      return exports$12;
    })({});
  })(__self__);
  __self__.fetch.ponyfill = true;
  delete __self__.fetch.polyfill;
  var ctx = __self__;
  exports$1 = ctx.fetch;
  exports$1.default = ctx.fetch;
  exports$1.fetch = ctx.fetch;
  exports$1.Headers = ctx.Headers;
  exports$1.Request = ctx.Request;
  exports$1.Response = ctx.Response;
  module.exports = exports$1;
})(browserPonyfill, browserPonyfill.exports);
dist$1.rustEnum([
  dist$1.struct([], "uninitialized"),
  dist$1.struct([dist$1.option(dist$1.publicKey(), "authorityAddress")], "buffer"),
  dist$1.struct([dist$1.publicKey("programdataAddress")], "program"),
  dist$1.struct([
    dist$1.u64("slot"),
    dist$1.option(dist$1.publicKey(), "upgradeAuthorityAddress")
  ], "programData")
], void 0, dist$1.u32());
const PROGRAM_LOG = "Program log: ";
const PROGRAM_DATA = "Program data: ";
const PROGRAM_LOG_START_INDEX = PROGRAM_LOG.length;
const PROGRAM_DATA_START_INDEX = PROGRAM_DATA.length;
class EventManager {
  constructor(programId, provider, coder) {
    this._programId = programId;
    this._provider = provider;
    this._eventParser = new EventParser(programId, coder);
    this._eventCallbacks = /* @__PURE__ */ new Map();
    this._eventListeners = /* @__PURE__ */ new Map();
    this._listenerIdCount = 0;
  }
  addEventListener(eventName, callback, commitment) {
    var _a;
    let listener = this._listenerIdCount;
    this._listenerIdCount += 1;
    if (!this._eventListeners.has(eventName)) {
      this._eventListeners.set(eventName, []);
    }
    this._eventListeners.set(eventName, ((_a = this._eventListeners.get(eventName)) !== null && _a !== void 0 ? _a : []).concat(listener));
    this._eventCallbacks.set(listener, [eventName, callback]);
    if (this._onLogsSubscriptionId !== void 0) {
      return listener;
    }
    this._onLogsSubscriptionId = this._provider.connection.onLogs(this._programId, (logs, ctx) => {
      if (logs.err) {
        return;
      }
      for (const event of this._eventParser.parseLogs(logs.logs)) {
        const allListeners = this._eventListeners.get(event.name);
        if (allListeners) {
          allListeners.forEach((listener2) => {
            const listenerCb = this._eventCallbacks.get(listener2);
            if (listenerCb) {
              const [, callback2] = listenerCb;
              callback2(event.data, ctx.slot, logs.signature);
            }
          });
        }
      }
    }, commitment);
    return listener;
  }
  async removeEventListener(listener) {
    const callback = this._eventCallbacks.get(listener);
    if (!callback) {
      throw new Error(`Event listener ${listener} doesn't exist!`);
    }
    const [eventName] = callback;
    let listeners = this._eventListeners.get(eventName);
    if (!listeners) {
      throw new Error(`Event listeners don't exist for ${eventName}!`);
    }
    this._eventCallbacks.delete(listener);
    listeners = listeners.filter((l) => l !== listener);
    this._eventListeners.set(eventName, listeners);
    if (listeners.length === 0) {
      this._eventListeners.delete(eventName);
    }
    if (this._eventCallbacks.size === 0) {
      if (this._eventListeners.size !== 0) {
        throw new Error(`Expected event listeners size to be 0 but got ${this._eventListeners.size}`);
      }
      if (this._onLogsSubscriptionId !== void 0) {
        await this._provider.connection.removeOnLogsListener(this._onLogsSubscriptionId);
        this._onLogsSubscriptionId = void 0;
      }
    }
  }
}
class EventParser {
  constructor(programId, coder) {
    this.coder = coder;
    this.programId = programId;
  }
  // Each log given, represents an array of messages emitted by
  // a single transaction, which can execute many different programs across
  // CPI boundaries. However, the subscription is only interested in the
  // events emitted by *this* program. In achieving this, we keep track of the
  // program execution context by parsing each log and looking for a CPI
  // `invoke` call. If one exists, we know a new program is executing. So we
  // push the programId onto a stack and switch the program context. This
  // allows us to track, for a given log, which program was executing during
  // its emission, thereby allowing us to know if a given log event was
  // emitted by *this* program. If it was, then we parse the raw string and
  // emit the event if the string matches the event being subscribed to.
  *parseLogs(logs, errorOnDecodeFailure = false) {
    const scanner = new LogScanner([...logs]);
    const execution = new ExecutionContext();
    const firstLog = scanner.next();
    if (firstLog === null)
      return;
    const firstCap = EventParser.INVOKE_RE.exec(firstLog);
    if (!firstCap || firstCap[2] !== EventParser.ROOT_DEPTH) {
      throw new Error(`Unexpected first log line: ${firstLog}`);
    }
    execution.push(firstCap[1]);
    while (scanner.peek() !== null) {
      const log = scanner.next();
      if (log === null)
        break;
      let [event, newProgram, didPop] = this.handleLog(execution, log, errorOnDecodeFailure);
      if (event)
        yield event;
      if (newProgram)
        execution.push(newProgram);
      if (didPop) {
        execution.pop();
        const nextLog = scanner.peek();
        if (nextLog && nextLog.endsWith("invoke [1]")) {
          const m = EventParser.INVOKE_RE.exec(nextLog);
          if (m)
            execution.push(m[1]);
        }
      }
    }
  }
  // Main log handler. Returns a three element array of the event, the
  // next program that was invoked for CPI, and a boolean indicating if
  // a program has completed execution (and thus should be popped off the
  // execution stack).
  handleLog(execution, log, errorOnDecodeFailure) {
    if (execution.stack.length > 0 && execution.program() === this.programId.toString()) {
      return this.handleProgramLog(log, errorOnDecodeFailure);
    } else {
      return [null, ...this.handleSystemLog(log)];
    }
  }
  // Handles logs from *this* program.
  handleProgramLog(log, errorOnDecodeFailure) {
    if (log.startsWith(PROGRAM_LOG) || log.startsWith(PROGRAM_DATA)) {
      const logStr = log.startsWith(PROGRAM_LOG) ? log.slice(PROGRAM_LOG_START_INDEX) : log.slice(PROGRAM_DATA_START_INDEX);
      const event = this.coder.events.decode(logStr);
      if (errorOnDecodeFailure && event === null) {
        throw new Error(`Unable to decode event ${logStr}`);
      }
      return [event, null, false];
    } else {
      return [null, ...this.handleSystemLog(log)];
    }
  }
  // Handles logs when the current program being executing is *not* this.
  handleSystemLog(log) {
    if (log.startsWith(`Program ${this.programId.toString()} log:`)) {
      return [this.programId.toString(), false];
    } else if (log.includes("invoke") && !log.endsWith("[1]")) {
      return ["cpi", false];
    } else {
      let regex = /^Program ([1-9A-HJ-NP-Za-km-z]+) success$/;
      if (regex.test(log)) {
        return [null, true];
      } else {
        return [null, false];
      }
    }
  }
}
EventParser.INVOKE_RE = /^Program ([1-9A-HJ-NP-Za-km-z]+) invoke \[(\d+)\]$/;
EventParser.ROOT_DEPTH = "1";
class ExecutionContext {
  constructor() {
    this.stack = [];
  }
  program() {
    if (!this.stack.length) {
      throw new Error("Expected the stack to have elements");
    }
    return this.stack[this.stack.length - 1];
  }
  push(newProgram) {
    this.stack.push(newProgram);
  }
  pop() {
    if (!this.stack.length) {
      throw new Error("Expected the stack to have elements");
    }
    this.stack.pop();
  }
}
class LogScanner {
  constructor(logs) {
    this.logs = logs;
    this.logs = this.logs.filter((log) => log.startsWith("Program "));
  }
  next() {
    if (this.logs.length === 0) {
      return null;
    }
    let l = this.logs[0];
    this.logs = this.logs.slice(1);
    return l;
  }
  peek() {
    return this.logs.length > 0 ? this.logs[0] : null;
  }
}
function splitArgsAndCtx(idlIx, args) {
  var _a, _b;
  let options = {};
  const inputLen = idlIx.args ? idlIx.args.length : 0;
  if (args.length > inputLen) {
    if (args.length !== inputLen + 1) {
      throw new Error(`provided too many arguments ${args} to instruction ${idlIx === null || idlIx === void 0 ? void 0 : idlIx.name} expecting: ${(_b = (_a = idlIx.args) === null || _a === void 0 ? void 0 : _a.map((a) => a.name)) !== null && _b !== void 0 ? _b : []}`);
    }
    options = args.pop();
  }
  return [args, options];
}
class InstructionNamespaceFactory {
  static build(idlIx, encodeFn, programId) {
    if (idlIx.name === "_inner") {
      throw new IdlError("the _inner name is reserved");
    }
    const ix = (...args) => {
      const [ixArgs, ctx] = splitArgsAndCtx(idlIx, [...args]);
      validateAccounts(idlIx.accounts, ctx.accounts);
      validateInstruction(idlIx, ...args);
      const keys = ix.accounts(ctx.accounts);
      if (ctx.remainingAccounts !== void 0) {
        keys.push(...ctx.remainingAccounts);
      }
      if (isSet("debug-logs")) {
        console.log("Outgoing account metas:", keys);
      }
      return new TransactionInstruction({
        keys,
        programId,
        data: encodeFn(idlIx.name, toInstruction(idlIx, ...ixArgs))
      });
    };
    ix["accounts"] = (accs) => {
      return InstructionNamespaceFactory.accountsArray(accs, idlIx.accounts, programId, idlIx.name);
    };
    return ix;
  }
  static accountsArray(ctx, accounts2, programId, ixName) {
    if (!ctx) {
      return [];
    }
    return accounts2.map((acc) => {
      if (isCompositeAccounts(acc)) {
        const rpcAccs = ctx[acc.name];
        return InstructionNamespaceFactory.accountsArray(rpcAccs, acc.accounts, programId, ixName).flat();
      }
      let pubkey;
      try {
        pubkey = translateAddress(ctx[acc.name]);
      } catch (err) {
        throw new Error(`Wrong input type for account "${acc.name}" in the instruction accounts object${ixName !== void 0 ? ' for instruction "' + ixName + '"' : ""}. Expected PublicKey or string.`);
      }
      const isOptional = acc.optional && pubkey.equals(programId);
      const isWritable = Boolean(acc.writable && !isOptional);
      const isSigner = Boolean(acc.signer && !isOptional);
      return {
        pubkey,
        isWritable,
        isSigner
      };
    }).flat();
  }
}
function validateInstruction(ix, ...args) {
}
class TransactionFactory {
  static build(idlIx, ixFn) {
    const txFn = (...args) => {
      var _a, _b, _c;
      const [, ctx] = splitArgsAndCtx(idlIx, [...args]);
      const tx = new Transaction();
      if (ctx.preInstructions && ctx.instructions) {
        throw new Error("instructions is deprecated, use preInstructions");
      }
      (_a = ctx.preInstructions) === null || _a === void 0 ? void 0 : _a.forEach((ix) => tx.add(ix));
      (_b = ctx.instructions) === null || _b === void 0 ? void 0 : _b.forEach((ix) => tx.add(ix));
      tx.add(ixFn(...args));
      (_c = ctx.postInstructions) === null || _c === void 0 ? void 0 : _c.forEach((ix) => tx.add(ix));
      return tx;
    };
    return txFn;
  }
}
class RpcFactory {
  static build(idlIx, txFn, idlErrors, provider) {
    const rpc = async (...args) => {
      var _a;
      const tx = txFn(...args);
      const [, ctx] = splitArgsAndCtx(idlIx, [...args]);
      if (provider.sendAndConfirm === void 0) {
        throw new Error("This function requires 'Provider.sendAndConfirm' to be implemented.");
      }
      try {
        return await provider.sendAndConfirm(tx, (_a = ctx.signers) !== null && _a !== void 0 ? _a : [], ctx.options);
      } catch (err) {
        throw translateError(err, idlErrors);
      }
    };
    return rpc;
  }
}
class AccountFactory {
  static build(idl, coder, programId, provider) {
    var _a;
    return ((_a = idl.accounts) !== null && _a !== void 0 ? _a : []).reduce((accountFns, acc) => {
      accountFns[acc.name] = new AccountClient(idl, acc, programId, provider, coder);
      return accountFns;
    }, {});
  }
}
class AccountClient {
  /**
   * Returns the number of bytes in this account.
   */
  get size() {
    return this._size;
  }
  /**
   * Returns the program ID owning all accounts.
   */
  get programId() {
    return this._programId;
  }
  /**
   * Returns the client's wallet and network provider.
   */
  get provider() {
    return this._provider;
  }
  /**
   * Returns the coder.
   */
  get coder() {
    return this._coder;
  }
  constructor(idl, idlAccount, programId, provider, coder) {
    this._idlAccount = idlAccount;
    this._programId = programId;
    this._provider = provider !== null && provider !== void 0 ? provider : getProvider();
    this._coder = coder !== null && coder !== void 0 ? coder : new BorshCoder(idl);
    this._size = this._coder.accounts.size(idlAccount.name);
  }
  /**
   * Returns a deserialized account, returning null if it doesn't exist.
   *
   * @param address The address of the account to fetch.
   */
  async fetchNullable(address2, commitment) {
    const { data } = await this.fetchNullableAndContext(address2, commitment);
    return data;
  }
  /**
   * Returns a deserialized account along with the associated rpc response context, returning null if it doesn't exist.
   *
   * @param address The address of the account to fetch.
   */
  async fetchNullableAndContext(address2, commitment) {
    const accountInfo = await this.getAccountInfoAndContext(address2, commitment);
    const { value, context } = accountInfo;
    return {
      data: value && value.data.length !== 0 ? this._coder.accounts.decode(this._idlAccount.name, value.data) : null,
      context
    };
  }
  /**
   * Returns a deserialized account.
   *
   * @param address The address of the account to fetch.
   */
  async fetch(address2, commitment) {
    const { data } = await this.fetchNullableAndContext(address2, commitment);
    if (data === null) {
      throw new Error(`Account does not exist or has no data ${address2.toString()}`);
    }
    return data;
  }
  /**
   * Returns a deserialized account along with the associated rpc response context.
   *
   * @param address The address of the account to fetch.
   */
  async fetchAndContext(address2, commitment) {
    const { data, context } = await this.fetchNullableAndContext(address2, commitment);
    if (data === null) {
      throw new Error(`Account does not exist ${address2.toString()}`);
    }
    return { data, context };
  }
  /**
   * Returns multiple deserialized accounts.
   * Accounts not found or with wrong discriminator are returned as null.
   *
   * @param addresses The addresses of the accounts to fetch.
   */
  async fetchMultiple(addresses, commitment) {
    const accounts2 = await this.fetchMultipleAndContext(addresses, commitment);
    return accounts2.map((account) => account ? account.data : null);
  }
  /**
   * Returns multiple deserialized accounts.
   * Accounts not found or with wrong discriminator are returned as null.
   *
   * @param addresses The addresses of the accounts to fetch.
   */
  async fetchMultipleAndContext(addresses, commitment) {
    const accounts2 = await getMultipleAccountsAndContext(this._provider.connection, addresses.map((address2) => translateAddress(address2)), commitment);
    return accounts2.map((result) => {
      if (result == null) {
        return null;
      }
      const { account, context } = result;
      return {
        data: this._coder.accounts.decode(this._idlAccount.name, account.data),
        context
      };
    });
  }
  /**
   * Returns all instances of this account type for the program.
   *
   * @param filters User-provided filters to narrow the results from `connection.getProgramAccounts`.
   *
   *                When filters are not defined this method returns all
   *                the account instances.
   *
   *                When filters are of type `Buffer`, the filters are appended
   *                after the discriminator.
   *
   *                When filters are of type `GetProgramAccountsFilter[]`,
   *                filters are appended after the discriminator filter.
   */
  async all(filters) {
    const filter = this.coder.accounts.memcmp(this._idlAccount.name, filters instanceof Buffer ? filters : void 0);
    const coderFilters = [];
    if ((filter === null || filter === void 0 ? void 0 : filter.offset) != void 0 && (filter === null || filter === void 0 ? void 0 : filter.bytes) != void 0) {
      coderFilters.push({
        memcmp: { offset: filter.offset, bytes: filter.bytes }
      });
    }
    if ((filter === null || filter === void 0 ? void 0 : filter.dataSize) != void 0) {
      coderFilters.push({ dataSize: filter.dataSize });
    }
    let resp = await this._provider.connection.getProgramAccounts(this._programId, {
      commitment: this._provider.connection.commitment,
      filters: [...coderFilters, ...Array.isArray(filters) ? filters : []]
    });
    return resp.map(({ pubkey, account }) => {
      return {
        publicKey: pubkey,
        account: this._coder.accounts.decode(this._idlAccount.name, account.data)
      };
    });
  }
  /**
   * Returns an `EventEmitter` emitting a "change" event whenever the account
   * changes.
   */
  subscribe(address2, commitment) {
    const sub = subscriptions.get(address2.toString());
    if (sub) {
      return sub.ee;
    }
    const ee = new EventEmitter();
    address2 = translateAddress(address2);
    const listener = this._provider.connection.onAccountChange(address2, (acc) => {
      const account = this._coder.accounts.decode(this._idlAccount.name, acc.data);
      ee.emit("change", account);
    }, commitment);
    subscriptions.set(address2.toString(), {
      ee,
      listener
    });
    return ee;
  }
  /**
   * Unsubscribes from the account at the given address.
   */
  async unsubscribe(address2) {
    let sub = subscriptions.get(address2.toString());
    if (!sub) {
      console.warn("Address is not subscribed");
      return;
    }
    if (subscriptions) {
      await this._provider.connection.removeAccountChangeListener(sub.listener).then(() => {
        subscriptions.delete(address2.toString());
      }).catch(console.error);
    }
  }
  /**
   * Returns an instruction for creating this account.
   */
  async createInstruction(signer, sizeOverride) {
    const size = this.size;
    if (this._provider.publicKey === void 0) {
      throw new Error("This function requires the Provider interface implementor to have a 'publicKey' field.");
    }
    return SystemProgram.createAccount({
      fromPubkey: this._provider.publicKey,
      newAccountPubkey: signer.publicKey,
      space: sizeOverride !== null && sizeOverride !== void 0 ? sizeOverride : size,
      lamports: await this._provider.connection.getMinimumBalanceForRentExemption(sizeOverride !== null && sizeOverride !== void 0 ? sizeOverride : size),
      programId: this._programId
    });
  }
  async getAccountInfo(address2, commitment) {
    return await this._provider.connection.getAccountInfo(translateAddress(address2), commitment);
  }
  async getAccountInfoAndContext(address2, commitment) {
    return await this._provider.connection.getAccountInfoAndContext(translateAddress(address2), commitment);
  }
}
const subscriptions = /* @__PURE__ */ new Map();
class SimulateFactory {
  static build(idlIx, txFn, idlErrors, provider, coder, programId, idl) {
    const simulate = async (...args) => {
      var _a;
      const tx = txFn(...args);
      const [, ctx] = splitArgsAndCtx(idlIx, [...args]);
      let resp = void 0;
      if (provider.simulate === void 0) {
        throw new Error("This function requires 'Provider.simulate' to be implemented.");
      }
      try {
        resp = await provider.simulate(tx, ctx.signers, (_a = ctx.options) === null || _a === void 0 ? void 0 : _a.commitment);
      } catch (err) {
        throw translateError(err, idlErrors);
      }
      if (resp === void 0) {
        throw new Error("Unable to simulate transaction");
      }
      const logs = resp.logs;
      if (!logs) {
        throw new Error("Simulated logs not found");
      }
      const events = [];
      if (idl.events) {
        let parser = new EventParser(programId, coder);
        for (const event of parser.parseLogs(logs)) {
          events.push(event);
        }
      }
      return { events, raw: logs };
    };
    return simulate;
  }
}
function uint64(property) {
  return new WrappedLayout(blob(8), (b) => u64.fromBuffer(b), (n) => n.toBuffer(), property);
}
function publicKey(property) {
  return new WrappedLayout(blob(32), (b) => new PublicKey(b), (key) => key.toBuffer(), property);
}
function coption(layout, property) {
  return new COptionLayout(layout, property);
}
class WrappedLayout extends Layout_2 {
  constructor(layout, decoder, encoder, property) {
    super(layout.span, property);
    this.layout = layout;
    this.decoder = decoder;
    this.encoder = encoder;
  }
  decode(b, offset2) {
    return this.decoder(this.layout.decode(b, offset2));
  }
  encode(src, b, offset2) {
    return this.layout.encode(this.encoder(src), b, offset2);
  }
  getSpan(b, offset2) {
    return this.layout.getSpan(b, offset2);
  }
}
class COptionLayout extends Layout_2 {
  constructor(layout, property) {
    super(-1, property);
    this.layout = layout;
    this.discriminator = u32();
  }
  encode(src, b, offset2 = 0) {
    if (src === null || src === void 0) {
      return this.layout.span + this.discriminator.encode(0, b, offset2);
    }
    this.discriminator.encode(1, b, offset2);
    return this.layout.encode(src, b, offset2 + 4) + 4;
  }
  decode(b, offset2 = 0) {
    const discriminator = this.discriminator.decode(b, offset2);
    if (discriminator === 0) {
      return null;
    } else if (discriminator === 1) {
      return this.layout.decode(b, offset2 + 4);
    }
    throw new Error("Invalid coption " + this.layout.property);
  }
  getSpan(b, offset2 = 0) {
    return this.layout.getSpan(b, offset2 + 4) + 4;
  }
}
class u64 extends BN {
  /**
   * Convert to Buffer representation
   */
  toBuffer() {
    const a = super.toArray().reverse();
    const b = Buffer.from(a);
    if (b.length === 8) {
      return b;
    }
    if (b.length >= 8) {
      throw new Error("u64 too large");
    }
    const zeroPad = Buffer.alloc(8);
    b.copy(zeroPad);
    return zeroPad;
  }
  /**
   * Construct a u64 from Buffer representation
   */
  static fromBuffer(buffer) {
    if (buffer.length !== 8) {
      throw new Error(`Invalid buffer length: ${buffer.length}`);
    }
    return new u64([...buffer].reverse().map((i) => `00${i.toString(16)}`.slice(-2)).join(""), 16);
  }
}
const TOKEN_ACCOUNT_LAYOUT = struct([
  publicKey("mint"),
  publicKey("owner"),
  uint64("amount"),
  coption(publicKey(), "delegate"),
  ((p) => {
    const U = union(u8("discriminator"), null, p);
    U.addVariant(0, struct([]), "uninitialized");
    U.addVariant(1, struct([]), "initialized");
    U.addVariant(2, struct([]), "frozen");
    return U;
  })("state"),
  coption(uint64(), "isNative"),
  uint64("delegatedAmount"),
  coption(publicKey(), "closeAuthority")
]);
function decodeTokenAccount(b) {
  return TOKEN_ACCOUNT_LAYOUT.decode(b);
}
class AccountsResolver {
  constructor(_args, _accounts, _provider2, _programId, _idlIx, accountNamespace, _idlTypes, _customResolver) {
    this._args = _args;
    this._accounts = _accounts;
    this._provider = _provider2;
    this._programId = _programId;
    this._idlIx = _idlIx;
    this._idlTypes = _idlTypes;
    this._customResolver = _customResolver;
    this._accountStore = new AccountStore(_provider2, accountNamespace, _programId);
  }
  args(args) {
    this._args = args;
  }
  // Note: We serially resolve PDAs one by one rather than doing them
  //       in parallel because there can be dependencies between
  //       addresses. That is, one PDA can be used as a seed in another.
  async resolve() {
    this.resolveEventCpi(this._idlIx.accounts);
    this.resolveConst(this._idlIx.accounts);
    let depth = 0;
    while (await this.resolvePdasAndRelations(this._idlIx.accounts) + await this.resolveCustom() > 0) {
      depth++;
      if (depth === 16) {
        const isResolvable = (acc) => {
          if (!isCompositeAccounts(acc)) {
            return !!(acc.address || acc.pda || acc.relations);
          }
          return acc.accounts.some(isResolvable);
        };
        const getPaths = (accs, path = [], paths = []) => {
          for (const acc of accs) {
            if (isCompositeAccounts(acc)) {
              paths.push(...getPaths(acc.accounts, [...path, acc.name]));
            } else {
              paths.push([...path, acc.name]);
            }
          }
          return paths;
        };
        const resolvableAccs = this._idlIx.accounts.filter(isResolvable);
        const unresolvedAccs = getPaths(resolvableAccs).filter((path) => !this.get(path)).map((path) => path.reduce((acc, p) => acc + "." + p)).map((acc) => `\`${acc}\``).join(", ");
        throw new Error([
          `Reached maximum depth for account resolution.`,
          `Unresolved accounts: ${unresolvedAccs}`
        ].join(" "));
      }
    }
  }
  resolveOptionals(accounts2) {
    Object.assign(this._accounts, this.resolveOptionalsHelper(accounts2, this._idlIx.accounts));
  }
  get(path) {
    const ret = path.reduce((acc, subPath) => acc && acc[subPath], this._accounts);
    if (ret && ret.toBase58) {
      return ret;
    }
  }
  set(path, value) {
    let cur = this._accounts;
    path.forEach((p, i) => {
      var _a;
      const isLast = i === path.length - 1;
      if (isLast) {
        cur[p] = value;
      }
      cur[p] = (_a = cur[p]) !== null && _a !== void 0 ? _a : {};
      cur = cur[p];
    });
  }
  resolveOptionalsHelper(partialAccounts, accounts2) {
    const nestedAccountsGeneric = {};
    for (const accountItem of accounts2) {
      const accountName = accountItem.name;
      const partialAccount = partialAccounts[accountName];
      if (partialAccount === void 0)
        continue;
      if (isPartialAccounts(partialAccount)) {
        if (isCompositeAccounts(accountItem)) {
          nestedAccountsGeneric[accountName] = this.resolveOptionalsHelper(partialAccount, accountItem["accounts"]);
        } else {
          nestedAccountsGeneric[accountName] = flattenPartialAccounts(partialAccount);
        }
      } else {
        if (partialAccount !== null) {
          nestedAccountsGeneric[accountName] = translateAddress(partialAccount);
        } else if (accountItem["optional"]) {
          nestedAccountsGeneric[accountName] = this._programId;
        }
      }
    }
    return nestedAccountsGeneric;
  }
  async resolveCustom() {
    if (this._customResolver) {
      const { accounts: accounts2, resolved } = await this._customResolver({
        args: this._args,
        accounts: this._accounts,
        provider: this._provider,
        programId: this._programId,
        idlIx: this._idlIx
      });
      this._accounts = accounts2;
      return resolved;
    }
    return 0;
  }
  /**
   * Resolve event CPI accounts `eventAuthority` and `program`.
   *
   * Accounts will only be resolved if they are declared next to each other to
   * reduce the chance of name collision.
   */
  resolveEventCpi(accounts2, path = []) {
    for (const i in accounts2) {
      const accountOrAccounts = accounts2[i];
      if (isCompositeAccounts(accountOrAccounts)) {
        this.resolveEventCpi(accountOrAccounts.accounts, [
          ...path,
          accountOrAccounts.name
        ]);
      }
      const nextIndex = +i + 1;
      if (nextIndex === accounts2.length)
        return;
      const currentName = accounts2[i].name;
      const nextName = accounts2[nextIndex].name;
      if (currentName === "eventAuthority" && nextName === "program") {
        const currentPath = [...path, currentName];
        const nextPath = [...path, nextName];
        if (!this.get(currentPath)) {
          this.set(currentPath, PublicKey.findProgramAddressSync([Buffer.from("__event_authority")], this._programId)[0]);
        }
        if (!this.get(nextPath)) {
          this.set(nextPath, this._programId);
        }
        return;
      }
    }
  }
  resolveConst(accounts2, path = []) {
    for (const accountOrAccounts of accounts2) {
      const name = accountOrAccounts.name;
      if (isCompositeAccounts(accountOrAccounts)) {
        this.resolveConst(accountOrAccounts.accounts, [...path, name]);
      } else {
        const account = accountOrAccounts;
        if ((account.signer || account.address) && !this.get([...path, name])) {
          if (account.signer) {
            if (!this._provider.publicKey) {
              throw new Error("This function requires the `Provider` interface implementor to have a `publicKey` field.");
            }
            this.set([...path, name], this._provider.publicKey);
          }
          if (account.address) {
            this.set([...path, name], translateAddress(account.address));
          }
        }
      }
    }
  }
  async resolvePdasAndRelations(accounts2, path = []) {
    let found = 0;
    for (const accountOrAccounts of accounts2) {
      const name = accountOrAccounts.name;
      if (isCompositeAccounts(accountOrAccounts)) {
        found += await this.resolvePdasAndRelations(accountOrAccounts.accounts, [...path, name]);
      } else {
        const account = accountOrAccounts;
        if ((account.pda || account.relations) && !this.get([...path, name])) {
          found++;
          try {
            if (account.pda) {
              const seeds = await Promise.all(account.pda.seeds.map((seed2) => this.toBuffer(seed2, path)));
              if (seeds.some((seed2) => !seed2)) {
                continue;
              }
              const programId = await this.parseProgramId(account, path);
              const [pubkey] = PublicKey.findProgramAddressSync(seeds, programId);
              this.set([...path, name], pubkey);
            }
          } catch {
          }
          try {
            if (account.relations) {
              const accountKey = this.get([...path, account.relations[0]]);
              if (accountKey) {
                const account2 = await this._accountStore.fetchAccount({
                  publicKey: accountKey
                });
                this.set([...path, name], account2[name]);
              }
            }
          } catch {
          }
        }
      }
    }
    return found;
  }
  async parseProgramId(account, path = []) {
    var _a;
    if (!((_a = account.pda) === null || _a === void 0 ? void 0 : _a.program)) {
      return this._programId;
    }
    const buf = await this.toBuffer(account.pda.program, path);
    if (!buf) {
      throw new Error(`Program seed not resolved: ${account.name}`);
    }
    return new PublicKey(buf);
  }
  async toBuffer(seed2, path = []) {
    switch (seed2.kind) {
      case "const":
        return this.toBufferConst(seed2);
      case "arg":
        return await this.toBufferArg(seed2);
      case "account":
        return await this.toBufferAccount(seed2, path);
      default:
        throw new Error(`Unexpected seed: ${seed2}`);
    }
  }
  toBufferConst(seed2) {
    return this.toBufferValue("bytes", seed2.value);
  }
  async toBufferArg(seed2) {
    const [name, ...path] = seed2.path.split(".");
    const index = this._idlIx.args.findIndex((arg) => arg.name === name);
    if (index === -1) {
      throw new Error(`Unable to find argument for seed: ${name}`);
    }
    const value = path.reduce((acc, path2) => (acc !== null && acc !== void 0 ? acc : {})[path2], this._args[index]);
    if (value === void 0) {
      return;
    }
    const type2 = this.getType(this._idlIx.args[index].type, path);
    return this.toBufferValue(type2, value);
  }
  async toBufferAccount(seed2, path = []) {
    const [name, ...paths] = seed2.path.split(".");
    const fieldPubkey = this.get([...path, name]);
    if (!fieldPubkey)
      return;
    if (!paths.length) {
      return this.toBufferValue("pubkey", fieldPubkey);
    }
    if (!seed2.account) {
      throw new Error(`Seed account is required in order to resolve type: ${seed2.path}`);
    }
    const account = await this._accountStore.fetchAccount({
      publicKey: fieldPubkey,
      name: seed2.account
    });
    let accountValue = account;
    let currentPaths = paths;
    while (currentPaths.length > 0) {
      accountValue = accountValue[currentPaths[0]];
      currentPaths = currentPaths.slice(1);
    }
    if (accountValue === void 0)
      return;
    const type2 = this.getType({ defined: { name: seed2.account } }, paths);
    return this.toBufferValue(type2, accountValue);
  }
  /**
   * Converts the given idl valaue into a Buffer. The values here must be
   * primitives, e.g. no structs.
   */
  toBufferValue(type2, value) {
    switch (type2) {
      case "u8":
      case "i8":
        return Buffer.from([value]);
      case "u16":
      case "i16":
        return new BN(value).toArrayLike(Buffer, "le", 2);
      case "u32":
      case "i32":
        return new BN(value).toArrayLike(Buffer, "le", 4);
      case "u64":
      case "i64":
        return new BN(value).toArrayLike(Buffer, "le", 8);
      case "u128":
      case "i128":
        return new BN(value).toArrayLike(Buffer, "le", 16);
      case "u256":
      case "i256":
        return new BN(value).toArrayLike(Buffer, "le", 32);
      case "string":
        return Buffer.from(value);
      case "pubkey":
        return value.toBuffer();
      case "bytes":
        return Buffer.from(value);
      default:
        if (type2 === null || type2 === void 0 ? void 0 : type2.array) {
          return Buffer.from(value);
        }
        throw new Error(`Unexpected seed type: ${type2}`);
    }
  }
  /**
   * Recursively get the type at some path of either a primitive or a user
   * defined struct.
   */
  getType(type2, path = []) {
    var _a;
    const typeName = (_a = type2 === null || type2 === void 0 ? void 0 : type2.defined) === null || _a === void 0 ? void 0 : _a.name;
    if (typeName) {
      if (typeName === "tokenAccount") {
        switch (path.at(0)) {
          case "mint":
          case "owner":
            return "pubkey";
          case "amount":
          case "delagatedAmount":
            return "u64";
          default:
            throw new Error(`Unknown token account path: ${path}`);
        }
      }
      const definedType = this._idlTypes.find((t) => t.name === typeName);
      if (!definedType) {
        throw new Error(`Type not found: ${typeName}`);
      }
      const [fieldName, ...subPath] = path;
      const fields = definedType.type.fields;
      const field = fields.find((field2) => field2.name === fieldName);
      if (!field) {
        throw new Error(`Field not found: ${fieldName}`);
      }
      return this.getType(field.type, subPath);
    }
    return type2;
  }
}
class AccountStore {
  constructor(_provider2, accounts2, programId) {
    this._provider = _provider2;
    this._cache = /* @__PURE__ */ new Map();
    this._idls = {};
    this._idls[programId.toBase58()] = accounts2;
  }
  async fetchAccount({ publicKey: publicKey2, name }) {
    const address2 = publicKey2.toBase58();
    if (!this._cache.has(address2)) {
      const accountInfo = await this._provider.connection.getAccountInfo(publicKey2);
      if (accountInfo === null) {
        throw new Error(`Account not found: ${address2}`);
      }
      if (name === "tokenAccount") {
        const account = decodeTokenAccount(accountInfo.data);
        this._cache.set(address2, account);
      } else {
        const accounts2 = await this.getAccountsNs(accountInfo.owner);
        if (accounts2) {
          const accountNs = Object.values(accounts2)[0];
          if (accountNs) {
            const account = accountNs.coder.accounts.decodeAny(accountInfo.data);
            this._cache.set(address2, account);
          }
        }
      }
    }
    return this._cache.get(address2);
  }
  async getAccountsNs(programId) {
    const programIdStr = programId.toBase58();
    if (!this._idls[programIdStr]) {
      const idl = await Program.fetchIdl(programId, this._provider);
      if (idl) {
        const program = new Program(idl, this._provider);
        this._idls[programIdStr] = program.account;
      }
    }
    return this._idls[programIdStr];
  }
}
class MethodsBuilderFactory {
  static build(provider, programId, idlIx, ixFn, txFn, rpcFn, simulateFn, viewFn, accountNamespace, idlTypes, customResolver) {
    return (...args) => new MethodsBuilder(args, ixFn, txFn, rpcFn, simulateFn, viewFn, provider, programId, idlIx, accountNamespace, idlTypes, customResolver);
  }
}
function isPartialAccounts(partialAccount) {
  return typeof partialAccount === "object" && partialAccount !== null && !("_bn" in partialAccount);
}
function flattenPartialAccounts(partialAccounts, throwOnNull) {
  const toReturn = {};
  for (const accountName in partialAccounts) {
    const account = partialAccounts[accountName];
    if (account === null) {
      throw new Error("Failed to resolve optionals due to IDL type mismatch with input accounts!");
    }
    toReturn[accountName] = isPartialAccounts(account) ? flattenPartialAccounts(account) : translateAddress(account);
  }
  return toReturn;
}
class MethodsBuilder {
  constructor(_args, _ixFn, _txFn, _rpcFn, _simulateFn, _viewFn, provider, programId, idlIx, accountNamespace, idlTypes, customResolver) {
    this._args = _args;
    this._ixFn = _ixFn;
    this._txFn = _txFn;
    this._rpcFn = _rpcFn;
    this._simulateFn = _simulateFn;
    this._viewFn = _viewFn;
    this._accounts = {};
    this._remainingAccounts = [];
    this._signers = [];
    this._preInstructions = [];
    this._postInstructions = [];
    this._resolveAccounts = true;
    this._accountsResolver = new AccountsResolver(_args, this._accounts, provider, programId, idlIx, accountNamespace, idlTypes, customResolver);
  }
  args(args) {
    this._args = args;
    this._accountsResolver.args(args);
  }
  /**
   * Set instruction accounts with account resolution.
   *
   * This method only accepts accounts that cannot be resolved.
   *
   * See {@link accountsPartial} for overriding the account resolution or
   * {@link accountsStrict} for strictly specifying all accounts.
   */
  accounts(accounts2) {
    return this.accountsPartial(accounts2);
  }
  /**
   * Set instruction accounts with account resolution.
   *
   * There is no functional difference between this method and {@link accounts}
   * method, the only difference is this method allows specifying all accounts
   * even if they can be resolved. On the other hand, {@link accounts} method
   * doesn't accept accounts that can be resolved.
   */
  accountsPartial(accounts2) {
    this._resolveAccounts = true;
    this._accountsResolver.resolveOptionals(accounts2);
    return this;
  }
  /**
   * Set instruction accounts without account resolution.
   *
   * All accounts strictly need to be specified when this method is used.
   *
   * See {@link accounts} and {@link accountsPartial} methods for automatically
   * resolving accounts.
   *
   * @param accounts instruction accounts
   */
  accountsStrict(accounts2) {
    this._resolveAccounts = false;
    this._accountsResolver.resolveOptionals(accounts2);
    return this;
  }
  /**
   * Set instruction signers.
   *
   * Note that calling this method appends the given signers to the existing
   * signers (instead of overriding them).
   *
   * @param signers signers to append
   */
  signers(signers) {
    this._signers = this._signers.concat(signers);
    return this;
  }
  /**
   * Set remaining accounts.
   *
   * Note that calling this method appends the given accounts to the existing
   * remaining accounts (instead of overriding them).
   *
   * @param accounts remaining accounts
   */
  remainingAccounts(accounts2) {
    this._remainingAccounts = this._remainingAccounts.concat(accounts2);
    return this;
  }
  /**
   * Set previous instructions.
   *
   * See {@link postInstructions} to set the post instructions instead.
   *
   * @param ixs instructions
   * @param prepend whether to prepend to the existing previous instructions
   */
  preInstructions(ixs, prepend = false) {
    if (prepend) {
      this._preInstructions = ixs.concat(this._preInstructions);
    } else {
      this._preInstructions = this._preInstructions.concat(ixs);
    }
    return this;
  }
  /**
   * Set post instructions.
   *
   * See {@link preInstructions} to set the previous instructions instead.
   *
   * @param ixs instructions
   */
  postInstructions(ixs) {
    this._postInstructions = this._postInstructions.concat(ixs);
    return this;
  }
  /**
   * Get the public keys of the instruction accounts.
   *
   * The return type is an object with account names as keys and their public
   * keys as their values.
   *
   * Note that an account key is `undefined` if the account hasn't yet been
   * specified or resolved.
   */
  async pubkeys() {
    if (this._resolveAccounts) {
      await this._accountsResolver.resolve();
    }
    return this._accounts;
  }
  /**
   * Create an instruction based on the current configuration.
   *
   * See {@link transaction} to create a transaction instead.
   *
   * @returns the transaction instruction
   */
  async instruction() {
    if (this._resolveAccounts) {
      await this._accountsResolver.resolve();
    }
    return this._ixFn(...this._args, {
      accounts: this._accounts,
      signers: this._signers,
      remainingAccounts: this._remainingAccounts,
      preInstructions: this._preInstructions,
      postInstructions: this._postInstructions
    });
  }
  /**
   * Create a transaction based on the current configuration.
   *
   * This method doesn't send the created transaction. Use {@link rpc} method
   * to conveniently send an confirm the configured transaction.
   *
   * See {@link instruction} to only create an instruction instead.
   *
   * @returns the transaction
   */
  async transaction() {
    if (this._resolveAccounts) {
      await this._accountsResolver.resolve();
    }
    return this._txFn(...this._args, {
      accounts: this._accounts,
      signers: this._signers,
      remainingAccounts: this._remainingAccounts,
      preInstructions: this._preInstructions,
      postInstructions: this._postInstructions
    });
  }
  /**
   * Simulate the configured transaction.
   *
   * @param options confirmation options
   * @returns the simulation response
   */
  async simulate(options) {
    if (this._resolveAccounts) {
      await this._accountsResolver.resolve();
    }
    return this._simulateFn(...this._args, {
      accounts: this._accounts,
      signers: this._signers,
      remainingAccounts: this._remainingAccounts,
      preInstructions: this._preInstructions,
      postInstructions: this._postInstructions,
      options
    });
  }
  /**
   * View the configured transaction.
   *
   * Note that to use this method, the instruction needs to return a value and
   * all its accounts must be read-only.
   *
   * @param options confirmation options
   * @returns the return value of the instruction
   */
  async view(options) {
    if (this._resolveAccounts) {
      await this._accountsResolver.resolve();
    }
    if (!this._viewFn) {
      throw new Error([
        "Method does not support views.",
        "The instruction should return a value, and its accounts must be read-only"
      ].join(" "));
    }
    return this._viewFn(...this._args, {
      accounts: this._accounts,
      signers: this._signers,
      remainingAccounts: this._remainingAccounts,
      preInstructions: this._preInstructions,
      postInstructions: this._postInstructions,
      options
    });
  }
  /**
   * Send and confirm the configured transaction.
   *
   * See {@link rpcAndKeys} to both send the transaction and get the resolved
   * account public keys.
   *
   * @param options confirmation options
   * @returns the transaction signature
   */
  async rpc(options) {
    if (this._resolveAccounts) {
      await this._accountsResolver.resolve();
    }
    return this._rpcFn(...this._args, {
      accounts: this._accounts,
      signers: this._signers,
      remainingAccounts: this._remainingAccounts,
      preInstructions: this._preInstructions,
      postInstructions: this._postInstructions,
      options
    });
  }
  /**
   * Conveniently call both {@link rpc} and {@link pubkeys} methods.
   *
   * @param options confirmation options
   * @returns the transaction signature and account public keys
   */
  async rpcAndKeys(options) {
    return {
      signature: await this.rpc(options),
      pubkeys: await this.pubkeys()
    };
  }
  /**
   * Get instruction information necessary to include the instruction inside a
   * transaction.
   *
   * # Example
   *
   * ```ts
   * const { instruction, signers, pubkeys } = await method.prepare();
   * ```
   */
  async prepare() {
    return {
      instruction: await this.instruction(),
      signers: this._signers,
      pubkeys: await this.pubkeys()
    };
  }
}
class ViewFactory {
  static build(programId, idlIx, simulateFn, idl) {
    const isWritable = idlIx.accounts.find((a) => a.writable);
    const hasReturn = !!idlIx.returns;
    if (isWritable || !hasReturn)
      return;
    const view = async (...args) => {
      let simulationResult = await simulateFn(...args);
      const returnPrefix = `Program return: ${programId} `;
      let returnLog = simulationResult.raw.find((l) => l.startsWith(returnPrefix));
      if (!returnLog) {
        throw new Error("View expected return log");
      }
      let returnData = decode(returnLog.slice(returnPrefix.length));
      let returnType = idlIx.returns;
      if (!returnType) {
        throw new Error("View expected return type");
      }
      const coder = IdlCoder.fieldLayout({ type: returnType }, idl.types);
      return coder.decode(returnData);
    };
    return view;
  }
}
class NamespaceFactory {
  /**
   * Generates all namespaces for a given program.
   */
  static build(idl, coder, programId, provider, getCustomResolver) {
    const rpc = {};
    const instruction = {};
    const transaction = {};
    const simulate = {};
    const methods = {};
    const view = {};
    const idlErrors = parseIdlErrors(idl);
    const account = idl.accounts ? AccountFactory.build(idl, coder, programId, provider) : {};
    idl.instructions.forEach((idlIx) => {
      const ixItem = InstructionNamespaceFactory.build(idlIx, (ixName, ix) => coder.instruction.encode(ixName, ix), programId);
      const txItem = TransactionFactory.build(idlIx, ixItem);
      const rpcItem = RpcFactory.build(idlIx, txItem, idlErrors, provider);
      const simulateItem = SimulateFactory.build(idlIx, txItem, idlErrors, provider, coder, programId, idl);
      const viewItem = ViewFactory.build(programId, idlIx, simulateItem, idl);
      const methodItem = MethodsBuilderFactory.build(provider, programId, idlIx, ixItem, txItem, rpcItem, simulateItem, viewItem, account, idl.types || [], getCustomResolver === null || getCustomResolver === void 0 ? void 0 : getCustomResolver(idlIx));
      const name = idlIx.name;
      instruction[name] = ixItem;
      transaction[name] = txItem;
      rpc[name] = rpcItem;
      simulate[name] = simulateItem;
      methods[name] = methodItem;
      if (viewItem) {
        view[name] = viewItem;
      }
    });
    return [
      rpc,
      instruction,
      transaction,
      account,
      simulate,
      methods,
      view
    ];
  }
}
class Program {
  /**
   * Address of the program.
   */
  get programId() {
    return this._programId;
  }
  /**
   * IDL in camelCase format to work in TypeScript.
   *
   * See {@link rawIdl} field if you need the original IDL.
   */
  get idl() {
    return this._idl;
  }
  /**
   * Raw IDL i.e. the original IDL without camelCase conversion.
   *
   * See {@link idl} field if you need the camelCased version of the IDL.
   */
  get rawIdl() {
    return this._rawIdl;
  }
  /**
   * Coder for serializing requests.
   */
  get coder() {
    return this._coder;
  }
  /**
   * Wallet and network provider.
   */
  get provider() {
    return this._provider;
  }
  /**
   * @param idl       The interface definition.
   * @param provider  The network and wallet context to use. If not provided
   *                  then uses [[getProvider]].
   * @param getCustomResolver A function that returns a custom account resolver
   *                          for the given instruction. This is useful for resolving
   *                          public keys of missing accounts when building instructions
   */
  constructor(idl, provider = getProvider(), coder, getCustomResolver) {
    this._idl = convertIdlToCamelCase(idl);
    this._rawIdl = idl;
    this._provider = provider;
    this._programId = translateAddress(idl.address);
    this._coder = coder !== null && coder !== void 0 ? coder : new BorshCoder(this._idl);
    this._events = new EventManager(this._programId, provider, this._coder);
    const [rpc, instruction, transaction, account, simulate, methods, views] = NamespaceFactory.build(this._idl, this._coder, this._programId, provider, getCustomResolver);
    this.rpc = rpc;
    this.instruction = instruction;
    this.transaction = transaction;
    this.account = account;
    this.simulate = simulate;
    this.methods = methods;
    this.views = views;
  }
  /**
   * Generates a Program client by fetching the IDL from the network.
   *
   * In order to use this method, an IDL must have been previously initialized
   * via the anchor CLI's `anchor idl init` command.
   *
   * @param programId The on-chain address of the program.
   * @param provider  The network and wallet context.
   */
  static async at(address2, provider) {
    const programId = translateAddress(address2);
    const idl = await Program.fetchIdl(programId, provider);
    if (!idl) {
      throw new Error(`IDL not found for program: ${address2.toString()}`);
    }
    return new Program(idl, provider);
  }
  /**
   * Fetches an idl from the blockchain.
   *
   * In order to use this method, an IDL must have been previously initialized
   * via the anchor CLI's `anchor idl init` command.
   *
   * @param programId The on-chain address of the program.
   * @param provider  The network and wallet context.
   */
  static async fetchIdl(address2, provider) {
    provider = provider !== null && provider !== void 0 ? provider : getProvider();
    const programId = translateAddress(address2);
    const idlAddr = await idlAddress(programId);
    const accountInfo = await provider.connection.getAccountInfo(idlAddr);
    if (!accountInfo) {
      return null;
    }
    let idlAccount = decodeIdlAccount(accountInfo.data.slice(8));
    const inflatedIdl = inflate_1(idlAccount.data);
    return JSON.parse(decode$2(inflatedIdl));
  }
  /**
   * Invokes the given callback every time the given event is emitted.
   *
   * @param eventName The PascalCase name of the event, provided by the IDL.
   * @param callback  The function to invoke whenever the event is emitted from
   *                  program logs.
   */
  addEventListener(eventName, callback, commitment) {
    return this._events.addEventListener(eventName, callback, commitment);
  }
  /**
   * Unsubscribes from the given eventName.
   */
  async removeEventListener(listener) {
    return await this._events.removeEventListener(listener);
  }
}
new PublicKey("11111111111111111111111111111111");
const address = "F29V68fXr6zxnyw4svarp4pjiLEcPAcP4BRgA9fqXKsv";
const metadata = {
  name: "ikavault",
  version: "0.1.0",
  spec: "0.1.0"
};
const instructions = [
  {
    name: "add_entry",
    docs: [
      "Store a new credential entry (pointer to Walrus-encrypted blob)."
    ],
    discriminator: [
      170,
      45,
      66,
      212,
      251,
      230,
      45,
      38
    ],
    accounts: [
      {
        name: "user_profile",
        writable: true,
        pda: {
          seeds: [
            {
              kind: "const",
              value: [
                117,
                115,
                101,
                114,
                95,
                112,
                114,
                111,
                102,
                105,
                108,
                101
              ]
            },
            {
              kind: "account",
              path: "owner"
            }
          ]
        }
      },
      {
        name: "vault_entry",
        writable: true,
        pda: {
          seeds: [
            {
              kind: "const",
              value: [
                118,
                97,
                117,
                108,
                116,
                95,
                101,
                110,
                116,
                114,
                121
              ]
            },
            {
              kind: "account",
              path: "owner"
            },
            {
              kind: "account",
              path: "user_profile.entry_count",
              account: "UserProfile"
            }
          ]
        }
      },
      {
        name: "owner",
        writable: true,
        signer: true,
        relations: [
          "user_profile"
        ]
      },
      {
        name: "system_program",
        address: "11111111111111111111111111111111"
      }
    ],
    args: [
      {
        name: "label",
        type: "string"
      },
      {
        name: "url",
        type: "string"
      },
      {
        name: "username",
        type: "string"
      },
      {
        name: "encrypted_blob_id",
        type: "string"
      }
    ]
  },
  {
    name: "delete_entry",
    docs: [
      "Soft-delete a credential entry."
    ],
    discriminator: [
      227,
      198,
      83,
      191,
      70,
      23,
      194,
      58
    ],
    accounts: [
      {
        name: "user_profile",
        writable: true,
        pda: {
          seeds: [
            {
              kind: "const",
              value: [
                117,
                115,
                101,
                114,
                95,
                112,
                114,
                111,
                102,
                105,
                108,
                101
              ]
            },
            {
              kind: "account",
              path: "owner"
            }
          ]
        }
      },
      {
        name: "vault_entry",
        writable: true,
        pda: {
          seeds: [
            {
              kind: "const",
              value: [
                118,
                97,
                117,
                108,
                116,
                95,
                101,
                110,
                116,
                114,
                121
              ]
            },
            {
              kind: "account",
              path: "owner"
            },
            {
              kind: "arg",
              path: "entry_index"
            }
          ]
        }
      },
      {
        name: "owner",
        writable: true,
        signer: true,
        relations: [
          "user_profile",
          "vault_entry"
        ]
      }
    ],
    args: [
      {
        name: "entry_index",
        type: "u32"
      }
    ]
  },
  {
    name: "init_vault",
    docs: [
      "Initialize a new vault for a user.",
      "Must be called once after Web3Auth login + dWallet creation."
    ],
    discriminator: [
      77,
      79,
      85,
      150,
      33,
      217,
      52,
      106
    ],
    accounts: [
      {
        name: "user_profile",
        writable: true,
        pda: {
          seeds: [
            {
              kind: "const",
              value: [
                117,
                115,
                101,
                114,
                95,
                112,
                114,
                111,
                102,
                105,
                108,
                101
              ]
            },
            {
              kind: "account",
              path: "owner"
            }
          ]
        }
      },
      {
        name: "owner",
        writable: true,
        signer: true
      },
      {
        name: "system_program",
        address: "11111111111111111111111111111111"
      }
    ],
    args: [
      {
        name: "dwallet_id",
        type: "string"
      },
      {
        name: "initial_blob_id",
        type: "string"
      }
    ]
  },
  {
    name: "share_entry",
    docs: [
      "Share a credential with another user (stretch goal).",
      "Caller must pre-compute recipient-encrypted blob off-chain."
    ],
    discriminator: [
      86,
      158,
      151,
      228,
      143,
      91,
      246,
      20
    ],
    accounts: [
      {
        name: "user_profile",
        writable: true,
        pda: {
          seeds: [
            {
              kind: "const",
              value: [
                117,
                115,
                101,
                114,
                95,
                112,
                114,
                111,
                102,
                105,
                108,
                101
              ]
            },
            {
              kind: "account",
              path: "owner"
            }
          ]
        }
      },
      {
        name: "vault_entry",
        pda: {
          seeds: [
            {
              kind: "const",
              value: [
                118,
                97,
                117,
                108,
                116,
                95,
                101,
                110,
                116,
                114,
                121
              ]
            },
            {
              kind: "account",
              path: "owner"
            },
            {
              kind: "arg",
              path: "entry_index"
            }
          ]
        }
      },
      {
        name: "shared_entry",
        writable: true,
        pda: {
          seeds: [
            {
              kind: "const",
              value: [
                115,
                104,
                97,
                114,
                101,
                100,
                95,
                101,
                110,
                116,
                114,
                121
              ]
            },
            {
              kind: "account",
              path: "owner"
            },
            {
              kind: "account",
              path: "recipient"
            },
            {
              kind: "arg",
              path: "entry_index"
            }
          ]
        }
      },
      {
        name: "recipient"
      },
      {
        name: "owner",
        writable: true,
        signer: true,
        relations: [
          "user_profile",
          "vault_entry"
        ]
      },
      {
        name: "system_program",
        address: "11111111111111111111111111111111"
      }
    ],
    args: [
      {
        name: "entry_index",
        type: "u32"
      },
      {
        name: "recipient_encrypted_blob_id",
        type: "string"
      }
    ]
  },
  {
    name: "update_entry",
    docs: [
      "Update an existing credential entry.",
      "Pass None for fields that should not change."
    ],
    discriminator: [
      70,
      47,
      181,
      2,
      1,
      40,
      2,
      92
    ],
    accounts: [
      {
        name: "user_profile",
        writable: true,
        pda: {
          seeds: [
            {
              kind: "const",
              value: [
                117,
                115,
                101,
                114,
                95,
                112,
                114,
                111,
                102,
                105,
                108,
                101
              ]
            },
            {
              kind: "account",
              path: "owner"
            }
          ]
        }
      },
      {
        name: "vault_entry",
        writable: true,
        pda: {
          seeds: [
            {
              kind: "const",
              value: [
                118,
                97,
                117,
                108,
                116,
                95,
                101,
                110,
                116,
                114,
                121
              ]
            },
            {
              kind: "account",
              path: "owner"
            },
            {
              kind: "arg",
              path: "entry_index"
            }
          ]
        }
      },
      {
        name: "owner",
        writable: true,
        signer: true,
        relations: [
          "user_profile",
          "vault_entry"
        ]
      }
    ],
    args: [
      {
        name: "entry_index",
        type: "u32"
      },
      {
        name: "label",
        type: {
          option: "string"
        }
      },
      {
        name: "url",
        type: {
          option: "string"
        }
      },
      {
        name: "username",
        type: {
          option: "string"
        }
      },
      {
        name: "encrypted_blob_id",
        type: {
          option: "string"
        }
      }
    ]
  }
];
const accounts = [
  {
    name: "SharedVaultEntry",
    discriminator: [
      103,
      93,
      118,
      43,
      5,
      185,
      210,
      233
    ]
  },
  {
    name: "UserProfile",
    discriminator: [
      32,
      37,
      119,
      205,
      179,
      180,
      13,
      194
    ]
  },
  {
    name: "VaultEntry",
    discriminator: [
      247,
      13,
      244,
      166,
      187,
      153,
      172,
      22
    ]
  }
];
const errors = [
  {
    code: 6e3,
    name: "BlobIdTooLong",
    msg: "Vault blob ID exceeds maximum length"
  },
  {
    code: 6001,
    name: "UrlTooLong",
    msg: "URL exceeds maximum length"
  },
  {
    code: 6002,
    name: "UsernameTooLong",
    msg: "Username exceeds maximum length"
  },
  {
    code: 6003,
    name: "LabelTooLong",
    msg: "Label exceeds maximum length"
  },
  {
    code: 6004,
    name: "EntryNotFound",
    msg: "Vault entry not found"
  },
  {
    code: 6005,
    name: "VaultFull",
    msg: "Vault is at maximum capacity"
  },
  {
    code: 6006,
    name: "Unauthorized",
    msg: "Unauthorized: signer does not own this vault"
  },
  {
    code: 6007,
    name: "DwalletIdTooLong",
    msg: "dWallet ID exceeds maximum length"
  },
  {
    code: 6008,
    name: "AlreadyShared",
    msg: "Shared vault: recipient already has access"
  }
];
const types = [
  {
    name: "SharedVaultEntry",
    docs: [
      'PDA seeds: ["shared_entry", owner.key(), recipient.key(), entry_index as u32 LE bytes]',
      "Created when owner shares a credential with a recipient.",
      "Contains a *separate* Walrus blob encrypted for the recipient's dWallet key."
    ],
    type: {
      kind: "struct",
      fields: [
        {
          name: "owner",
          docs: [
            "Original credential owner"
          ],
          type: "pubkey"
        },
        {
          name: "recipient",
          docs: [
            "Recipient who can read this shared credential"
          ],
          type: "pubkey"
        },
        {
          name: "origin_index",
          docs: [
            "Index of the original VaultEntry"
          ],
          type: "u32"
        },
        {
          name: "label",
          docs: [
            "Human-readable label (copied from original for recipient UX)"
          ],
          type: "string"
        },
        {
          name: "url",
          docs: [
            "URL (copied from original)"
          ],
          type: "string"
        },
        {
          name: "username",
          docs: [
            "Username (copied from original)"
          ],
          type: "string"
        },
        {
          name: "encrypted_blob_id",
          docs: [
            "Walrus blob ID encrypted specifically for the recipient's dWallet key"
          ],
          type: "string"
        },
        {
          name: "shared_at",
          docs: [
            "Unix timestamp of sharing"
          ],
          type: "i64"
        },
        {
          name: "bump",
          docs: [
            "Bump for PDA derivation"
          ],
          type: "u8"
        }
      ]
    }
  },
  {
    name: "UserProfile",
    docs: [
      'PDA seeds: ["user_profile", owner.key()]',
      "One per user — holds their dWallet ID and overall vault metadata."
    ],
    type: {
      kind: "struct",
      fields: [
        {
          name: "owner",
          docs: [
            "The wallet that owns this profile (used in PDA seed)"
          ],
          type: "pubkey"
        },
        {
          name: "dwallet_id",
          docs: [
            "Ika dWallet ID for this user (mock in pre-alpha)"
          ],
          type: "string"
        },
        {
          name: "vault_blob_id",
          docs: [
            "Walrus blob ID of the latest encrypted vault snapshot"
          ],
          type: "string"
        },
        {
          name: "entry_count",
          docs: [
            "Number of active vault entries"
          ],
          type: "u32"
        },
        {
          name: "updated_at",
          docs: [
            "Unix timestamp of last update"
          ],
          type: "i64"
        },
        {
          name: "bump",
          docs: [
            "Bump for PDA derivation"
          ],
          type: "u8"
        }
      ]
    }
  },
  {
    name: "VaultEntry",
    docs: [
      'PDA seeds: ["vault_entry", owner.key(), entry_index as u32 LE bytes]',
      "One per stored credential. Holds a pointer to the Walrus encrypted blob."
    ],
    type: {
      kind: "struct",
      fields: [
        {
          name: "owner",
          docs: [
            "Owner's wallet pubkey"
          ],
          type: "pubkey"
        },
        {
          name: "index",
          docs: [
            "Sequential index (matches PDA seed)"
          ],
          type: "u32"
        },
        {
          name: "label",
          docs: [
            "Human-readable label for the credential"
          ],
          type: "string"
        },
        {
          name: "url",
          docs: [
            "URL/domain the credential belongs to"
          ],
          type: "string"
        },
        {
          name: "username",
          docs: [
            "Plaintext username/email (not sensitive — password is in blob)"
          ],
          type: "string"
        },
        {
          name: "encrypted_blob_id",
          docs: [
            "Walrus blob ID of the encrypted credential payload"
          ],
          type: "string"
        },
        {
          name: "is_active",
          docs: [
            "Whether this entry is active (soft-delete pattern)"
          ],
          type: "bool"
        },
        {
          name: "created_at",
          docs: [
            "Unix timestamp of creation"
          ],
          type: "i64"
        },
        {
          name: "updated_at",
          docs: [
            "Unix timestamp of last update"
          ],
          type: "i64"
        },
        {
          name: "bump",
          docs: [
            "Bump for PDA derivation"
          ],
          type: "u8"
        }
      ]
    }
  }
];
const IDL = {
  address,
  metadata,
  instructions,
  accounts,
  errors,
  types
};
const SOLANA_RPC = "https://api.testnet.solana.com";
const PROGRAM_ID = new PublicKey(
  "F29V68fXr6zxnyw4svarp4pjiLEcPAcP4BRgA9fqXKsv"
);
const connection = new Connection(SOLANA_RPC, "confirmed");
function getUserProfilePDA(owner) {
  return PublicKey.findProgramAddressSync(
    [Buffer.from("user_profile"), owner.toBuffer()],
    PROGRAM_ID
  );
}
function getVaultEntryPDA(owner, index) {
  const indexBuf = Buffer.alloc(4);
  indexBuf.writeUInt32LE(index, 0);
  return PublicKey.findProgramAddressSync(
    [Buffer.from("vault_entry"), owner.toBuffer(), indexBuf],
    PROGRAM_ID
  );
}
function getSharedEntryPDA(owner, recipient, entryIndex) {
  const indexBuf = Buffer.alloc(4);
  indexBuf.writeUInt32LE(entryIndex, 0);
  return PublicKey.findProgramAddressSync(
    [
      Buffer.from("shared_entry"),
      owner.toBuffer(),
      recipient.toBuffer(),
      indexBuf
    ],
    PROGRAM_ID
  );
}
function makeProgram(solanaProvider) {
  var _a;
  const wallet = {
    publicKey: new PublicKey(((_a = solanaProvider._providerProxy) == null ? void 0 : _a.publicKey) ?? PublicKey.default),
    signTransaction: async (tx) => {
      const signed = await solanaProvider.request({
        method: "signTransaction",
        params: { message: tx }
      });
      return signed;
    },
    signAllTransactions: async (txs) => {
      return Promise.all(txs.map((tx) => wallet.signTransaction(tx)));
    }
  };
  const provider = new AnchorProvider(connection, wallet, {
    commitment: "confirmed"
  });
  setProvider(provider);
  return new Program(IDL, provider);
}
async function initVault(owner, solanaProvider, dwalletId, initialBlobId) {
  const program = makeProgram(solanaProvider);
  const [userProfilePda] = getUserProfilePDA(owner);
  const tx = await program.methods.init_vault(dwalletId, initialBlobId).accounts({
    userProfile: userProfilePda,
    owner,
    systemProgram: PublicKey.default
  }).rpc();
  return tx;
}
async function addEntry(owner, solanaProvider, params) {
  const program = makeProgram(solanaProvider);
  const [userProfilePda] = getUserProfilePDA(owner);
  const [vaultEntryPda] = getVaultEntryPDA(owner, params.entryIndex);
  const tx = await program.methods.add_entry(params.label, params.url, params.username, params.encryptedBlobId).accounts({
    userProfile: userProfilePda,
    vaultEntry: vaultEntryPda,
    owner,
    systemProgram: PublicKey.default
  }).rpc();
  return tx;
}
async function deleteEntry(owner, solanaProvider, entryIndex) {
  const program = makeProgram(solanaProvider);
  const [userProfilePda] = getUserProfilePDA(owner);
  const [vaultEntryPda] = getVaultEntryPDA(owner, entryIndex);
  const tx = await program.methods.delete_entry(entryIndex).accounts({
    userProfile: userProfilePda,
    vaultEntry: vaultEntryPda,
    owner
  }).rpc();
  return tx;
}
async function fetchUserProfile(owner) {
  const [pda] = getUserProfilePDA(owner);
  const info = await connection.getAccountInfo(pda);
  if (!info) return null;
  const data = info.data;
  let offset2 = 8 + 32;
  const dwalletIdLen = data.readUInt32LE(offset2);
  offset2 += 4;
  const dwalletId = data.slice(offset2, offset2 + dwalletIdLen).toString("utf8");
  offset2 += dwalletIdLen;
  const blobIdLen = data.readUInt32LE(offset2);
  offset2 += 4;
  const vaultBlobId = data.slice(offset2, offset2 + blobIdLen).toString("utf8");
  offset2 += blobIdLen;
  const entryCount = data.readUInt32LE(offset2);
  offset2 += 4;
  const updatedAt = Number(data.readBigInt64LE(offset2));
  return { owner: owner.toBase58(), dwalletId, vaultBlobId, entryCount, updatedAt };
}
async function fetchVaultEntries(owner, entryCount) {
  const entries = [];
  for (let i = 0; i < entryCount; i++) {
    const [pda] = getVaultEntryPDA(owner, i);
    const info = await connection.getAccountInfo(pda);
    if (!info) continue;
    const entry = deserializeVaultEntry(info.data, i);
    if (entry == null ? void 0 : entry.isActive) entries.push(entry);
  }
  return entries;
}
function deserializeVaultEntry(data, index) {
  try {
    let offset2 = 8 + 32 + 4;
    const labelLen = data.readUInt32LE(offset2);
    offset2 += 4;
    const label = data.slice(offset2, offset2 + labelLen).toString("utf8");
    offset2 += labelLen;
    const urlLen = data.readUInt32LE(offset2);
    offset2 += 4;
    const url = data.slice(offset2, offset2 + urlLen).toString("utf8");
    offset2 += urlLen;
    const usernameLen = data.readUInt32LE(offset2);
    offset2 += 4;
    const username = data.slice(offset2, offset2 + usernameLen).toString("utf8");
    offset2 += usernameLen;
    const blobIdLen = data.readUInt32LE(offset2);
    offset2 += 4;
    const encryptedBlobId = data.slice(offset2, offset2 + blobIdLen).toString("utf8");
    offset2 += blobIdLen;
    const isActive = data[offset2] === 1;
    offset2 += 1;
    const createdAt = Number(data.readBigInt64LE(offset2));
    offset2 += 8;
    const updatedAt = Number(data.readBigInt64LE(offset2));
    return { index, label, url, username, encryptedBlobId, isActive, createdAt, updatedAt };
  } catch {
    return null;
  }
}
export {
  PROGRAM_ID,
  SOLANA_RPC,
  addEntry,
  connection,
  deleteEntry,
  fetchUserProfile,
  fetchVaultEntries,
  getSharedEntryPDA,
  getUserProfilePDA,
  getVaultEntryPDA,
  initVault
};
//# sourceMappingURL=solana-XkfuQnWF.js.map
