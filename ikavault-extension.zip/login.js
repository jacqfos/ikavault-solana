const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["chunks/web3auth-Bh15kId2.js","chunks/index-BSBJ23dz.js","assets/index-YWcpY_SI.css"])))=>i.map(i=>d[i]);
import { c as createRoot, j as jsxRuntimeExports, r as reactExports } from "./chunks/index-BSBJ23dz.js";
const scriptRel = "modulepreload";
const assetsURL = function(dep) {
  return "/" + dep;
};
const seen = {};
const __vitePreload = function preload(baseModule, deps, importerUrl) {
  let promise = Promise.resolve();
  if (deps && deps.length > 0) {
    document.getElementsByTagName("link");
    const cspNonceMeta = document.querySelector(
      "meta[property=csp-nonce]"
    );
    const cspNonce = (cspNonceMeta == null ? void 0 : cspNonceMeta.nonce) || (cspNonceMeta == null ? void 0 : cspNonceMeta.getAttribute("nonce"));
    promise = Promise.allSettled(
      deps.map((dep) => {
        dep = assetsURL(dep);
        if (dep in seen) return;
        seen[dep] = true;
        const isCss = dep.endsWith(".css");
        const cssSelector = isCss ? '[rel="stylesheet"]' : "";
        if (document.querySelector(`link[href="${dep}"]${cssSelector}`)) {
          return;
        }
        const link = document.createElement("link");
        link.rel = isCss ? "stylesheet" : scriptRel;
        if (!isCss) {
          link.as = "script";
        }
        link.crossOrigin = "";
        link.href = dep;
        if (cspNonce) {
          link.setAttribute("nonce", cspNonce);
        }
        document.head.appendChild(link);
        if (isCss) {
          return new Promise((res, rej) => {
            link.addEventListener("load", res);
            link.addEventListener(
              "error",
              () => rej(new Error(`Unable to preload CSS for ${dep}`))
            );
          });
        }
      })
    );
  }
  function handlePreloadError(err) {
    const e = new Event("vite:preloadError", {
      cancelable: true
    });
    e.payload = err;
    window.dispatchEvent(e);
    if (!e.defaultPrevented) {
      throw err;
    }
  }
  return promise.then((res) => {
    for (const item of res || []) {
      if (item.status !== "rejected") continue;
      handlePreloadError(item.reason);
    }
    return baseModule().catch(handlePreloadError);
  });
};
function LoginPage() {
  const [status, setStatus] = reactExports.useState("idle");
  const [error, setError] = reactExports.useState();
  reactExports.useEffect(() => {
    handleLogin();
  }, []);
  async function handleLogin() {
    setStatus("loading");
    setError(void 0);
    try {
      const { initWeb3Auth, loginWithGoogle } = await __vitePreload(async () => {
        const { initWeb3Auth: initWeb3Auth2, loginWithGoogle: loginWithGoogle2 } = await import("./chunks/web3auth-Bh15kId2.js");
        return { initWeb3Auth: initWeb3Auth2, loginWithGoogle: loginWithGoogle2 };
      }, true ? __vite__mapDeps([0,1,2]) : void 0);
      await initWeb3Auth();
      const auth = await loginWithGoogle();
      await chrome.storage.local.set({ authState: auth });
      await chrome.runtime.sendMessage({
        type: "INIT_VAULT",
        payload: { publicKey: auth.publicKey }
      });
      setStatus("success");
      setTimeout(() => window.close(), 1200);
    } catch (err) {
      setStatus("error");
      setError(err instanceof Error ? err.message : "Login failed");
    }
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-black flex flex-col items-center justify-center gap-6 px-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-xl bg-gradient-to-br from-purple-600 to-purple-900 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-white font-bold text-base", children: "IV" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-white font-semibold text-xl tracking-tight", children: [
        "Ika",
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-purple-400", children: "Vault" })
      ] })
    ] }),
    status === "loading" && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-gray-400 text-sm", children: "Signing in with Google…" })
    ] }),
    status === "success" && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-6 h-6 text-green-400", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M5 13l4 4L19 7" }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-green-400 text-sm", children: "Signed in — closing tab…" })
    ] }),
    status === "error" && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-red-400 text-sm text-center max-w-xs", children: error }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: handleLogin,
          className: "px-5 py-2 rounded-lg bg-purple-700 hover:bg-purple-600 text-white text-sm font-medium transition-colors",
          children: "Try again"
        }
      )
    ] })
  ] });
}
const root = document.getElementById("root");
createRoot(root).render(/* @__PURE__ */ jsxRuntimeExports.jsx(LoginPage, {}));
export {
  __vitePreload as _
};
//# sourceMappingURL=login.js.map
