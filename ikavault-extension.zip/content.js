const observer = new MutationObserver(() => detectAndInject());
observer.observe(document.body, { childList: true, subtree: true });
detectAndInject();
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "AUTOFILL") {
    const { username, password } = message.payload;
    autofill(username, password);
    sendResponse({ success: true });
    return false;
  }
});
function detectAndInject() {
  const fields = findPasswordFields();
  if (fields.length === 0) return;
  for (const field of fields) {
    injectAutofillButton(field);
  }
  chrome.runtime.sendMessage({
    type: "GET_CREDENTIALS_FOR_URL",
    payload: {
      publicKey: getStoredPublicKey(),
      url: window.location.href
    }
  });
}
function findPasswordFields() {
  const passwordInputs = Array.from(
    document.querySelectorAll(
      'input[type="password"]:not([data-ikavault-injected])'
    )
  );
  return passwordInputs.map((input) => {
    const form = input.closest("form");
    const usernameInput = findUsernameInput(input, form);
    return { input, usernameInput: usernameInput ?? void 0, form };
  });
}
function findUsernameInput(passwordInput, form) {
  const searchRoot = form ?? document;
  const candidates = Array.from(
    searchRoot.querySelectorAll(
      'input[type="email"], input[type="text"], input[autocomplete="username"]'
    )
  );
  const allInputs = Array.from(document.querySelectorAll("input"));
  const passwordIndex = allInputs.indexOf(passwordInput);
  const before = candidates.filter(
    (c) => allInputs.indexOf(c) < passwordIndex
  );
  return before[before.length - 1] ?? null;
}
function injectAutofillButton(field) {
  field.input.setAttribute("data-ikavault-injected", "true");
  const wrapper = field.input.parentElement;
  if (!wrapper) return;
  const style = getComputedStyle(wrapper);
  if (style.position === "static") {
    wrapper.style.position = "relative";
  }
  const button = document.createElement("button");
  button.type = "button";
  button.title = "Autofill with IkaVault";
  button.style.cssText = `
    position: absolute;
    right: 8px;
    top: 50%;
    transform: translateY(-50%);
    width: 20px;
    height: 20px;
    background: none;
    border: none;
    cursor: pointer;
    padding: 0;
    z-index: 9999;
    opacity: 0.6;
    transition: opacity 0.15s;
  `;
  button.innerHTML = `
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#9945FF" stroke-width="2">
      <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
      <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
    </svg>
  `;
  button.addEventListener("mouseenter", () => button.style.opacity = "1");
  button.addEventListener("mouseleave", () => button.style.opacity = "0.6");
  button.addEventListener("click", () => triggerAutofill());
  wrapper.appendChild(button);
}
async function triggerAutofill(field) {
  var _a;
  const publicKey = getStoredPublicKey();
  if (!publicKey) {
    chrome.runtime.sendMessage({ type: "OPEN_POPUP" });
    return;
  }
  const response = await chrome.runtime.sendMessage({
    type: "GET_CREDENTIALS_FOR_URL",
    payload: { publicKey, url: window.location.href }
  });
  if (!(response == null ? void 0 : response.success) || !((_a = response.data) == null ? void 0 : _a.length)) return;
  const entries = response.data;
  if (entries.length === 1) {
    const { username, encryptedBlobId } = entries[0];
    const decryptResponse = await chrome.runtime.sendMessage({
      type: "DECRYPT_CREDENTIAL",
      payload: { publicKey, encryptedBlobId }
    });
    if (decryptResponse == null ? void 0 : decryptResponse.success) {
      autofill(username, decryptResponse.data.password);
    }
  }
}
function autofill(username, password) {
  const passwordInput = document.querySelector('input[type="password"]');
  if (!passwordInput) return;
  fillInput(passwordInput, password);
  const field = findPasswordFields().find((f) => f.input === passwordInput);
  if (field == null ? void 0 : field.usernameInput) {
    fillInput(field.usernameInput, username);
  }
}
function fillInput(input, value) {
  var _a;
  const nativeInputValueSetter = (_a = Object.getOwnPropertyDescriptor(
    window.HTMLInputElement.prototype,
    "value"
  )) == null ? void 0 : _a.set;
  if (nativeInputValueSetter) {
    nativeInputValueSetter.call(input, value);
  } else {
    input.value = value;
  }
  input.dispatchEvent(new Event("input", { bubbles: true }));
  input.dispatchEvent(new Event("change", { bubbles: true }));
}
function getStoredPublicKey() {
  return sessionStorage.getItem("ikavault_pubkey");
}
chrome.runtime.onMessage.addListener((message) => {
  var _a;
  if (message.type === "AUTH_UPDATE" && ((_a = message.payload) == null ? void 0 : _a.publicKey)) {
    sessionStorage.setItem("ikavault_pubkey", message.payload.publicKey);
  }
});
//# sourceMappingURL=content.js.map
