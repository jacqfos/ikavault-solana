import { r as reactExports, j as jsxRuntimeExports, c as createRoot, R as React } from "./chunks/index-BSBJ23dz.js";
import { b as base64ToBytes, a as bytesToBase64 } from "./chunks/encryption-CqawdIkC.js";
const PBKDF2_ITERATIONS = 1e5;
async function setupPin(publicKey, pin) {
  const oldResult = await chrome.storage.local.get(`keyShare_${publicKey}`);
  let keyShare = oldResult[`keyShare_${publicKey}`];
  if (!keyShare) {
    const arr = new Uint8Array(32);
    crypto.getRandomValues(arr);
    keyShare = {
      dwalletId: `mock_${publicKey.slice(0, 8)}`,
      keyShareB64: bytesToBase64(arr)
    };
  }
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const aesKey = await derivePinKey(pin, salt);
  const plaintext = new TextEncoder().encode(JSON.stringify(keyShare));
  const ciphertext = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, aesKey, plaintext);
  const stored = {
    salt: bytesToBase64(salt),
    iv: bytesToBase64(iv),
    ciphertext: bytesToBase64(new Uint8Array(ciphertext))
  };
  await chrome.storage.local.set({ [`pin_ks_${publicKey}`]: stored });
  if (oldResult[`keyShare_${publicKey}`]) {
    await chrome.storage.local.remove(`keyShare_${publicKey}`);
  }
  await chrome.storage.session.set({ [`session_ks_${publicKey}`]: keyShare });
}
async function unlockWithPin(publicKey, pin) {
  const result = await chrome.storage.local.get(`pin_ks_${publicKey}`);
  const packed = result[`pin_ks_${publicKey}`];
  if (!packed) throw new Error("No PIN configured for this account");
  const salt = base64ToBytes(packed.salt);
  const iv = base64ToBytes(packed.iv);
  const ciphertext = base64ToBytes(packed.ciphertext);
  const aesKey = await derivePinKey(pin, salt);
  let plaintext;
  try {
    plaintext = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, aesKey, ciphertext);
  } catch {
    throw new Error("Wrong PIN");
  }
  const keyShare = JSON.parse(new TextDecoder().decode(plaintext));
  await chrome.storage.session.set({ [`session_ks_${publicKey}`]: keyShare });
  return keyShare;
}
async function lockVault(publicKey) {
  await chrome.storage.session.remove(`session_ks_${publicKey}`);
}
async function isUnlocked(publicKey) {
  const result = await chrome.storage.session.get(`session_ks_${publicKey}`);
  return !!result[`session_ks_${publicKey}`];
}
async function isPinSet(publicKey) {
  const result = await chrome.storage.local.get(`pin_ks_${publicKey}`);
  return !!result[`pin_ks_${publicKey}`];
}
async function derivePinKey(pin, salt) {
  const pinBytes = new TextEncoder().encode(pin);
  const baseKey = await crypto.subtle.importKey("raw", pinBytes, "PBKDF2", false, ["deriveKey"]);
  return crypto.subtle.deriveKey(
    { name: "PBKDF2", salt, iterations: PBKDF2_ITERATIONS, hash: "SHA-256" },
    baseKey,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
}
function LoginView({ onLogin }) {
  const [loading, setLoading] = reactExports.useState(false);
  const [error, setError] = reactExports.useState();
  async function handleGoogleLogin() {
    setLoading(true);
    setError(void 0);
    try {
      const loginUrl = chrome.runtime.getURL("login.html");
      const tab = await chrome.tabs.create({ url: loginUrl });
      await waitForAuth(tab.id);
      const result = await chrome.storage.local.get("authState");
      const auth = result.authState;
      if (!auth || auth.status !== "authenticated") {
        throw new Error("Login was cancelled or failed");
      }
      onLogin(auth);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login failed");
      setLoading(false);
    }
  }
  function waitForAuth(tabId) {
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        cleanup();
        reject(new Error("Login timed out"));
      }, 5 * 60 * 1e3);
      function onTabRemoved(removedTabId) {
        if (tabId === void 0 || removedTabId === tabId) {
          cleanup();
          resolve();
        }
      }
      function cleanup() {
        clearTimeout(timeout);
        chrome.tabs.onRemoved.removeListener(onTabRemoved);
      }
      chrome.tabs.onRemoved.addListener(onTabRemoved);
    });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col h-screen bg-black", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 flex flex-col items-center justify-center gap-8 px-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(IkaVaultLogo, {}),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl font-semibold text-white mb-2", children: "Decentralized Password Manager" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-gray-500 leading-relaxed", children: "Your credentials, encrypted with Ika 2PC-MPC and stored on Walrus — no central server, no single point of failure." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2 justify-center", children: ["Ika 2PC-MPC", "Walrus Storage", "Solana Native", "Google Login"].map((f) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        "span",
        {
          className: "px-3 py-1 text-xs rounded-full border border-purple-800 text-purple-400 bg-purple-950/30",
          children: f
        },
        f
      )) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          onClick: handleGoogleLogin,
          disabled: loading,
          className: "w-full flex items-center justify-center gap-3 px-4 py-3 rounded-xl\n                     bg-white hover:bg-gray-100 active:bg-gray-200\n                     text-gray-900 font-medium text-sm\n                     transition-colors duration-150\n                     disabled:opacity-50 disabled:cursor-not-allowed",
          children: [
            loading ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-4 h-4 border-2 border-gray-400 border-t-transparent rounded-full animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(GoogleIcon, {}),
            loading ? "Signing in..." : "Continue with Google"
          ]
        }
      ),
      error && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-red-400 text-center", children: error })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pb-4 text-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-700", children: "Powered by Solana · Ika · Walrus" }) })
  ] });
}
function GoogleIcon() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { width: "18", height: "18", viewBox: "0 0 18 18", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        fill: "#4285F4",
        d: "M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844a4.14 4.14 0 01-1.796 2.716v2.259h2.908c1.702-1.567 2.684-3.875 2.684-6.615z"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        fill: "#34A853",
        d: "M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 009 18z"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        fill: "#FBBC05",
        d: "M3.964 10.71A5.41 5.41 0 013.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 000 9c0 1.452.348 2.827.957 4.042l3.007-2.332z"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        fill: "#EA4335",
        d: "M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 00.957 4.958L3.964 7.29C4.672 5.163 6.656 3.58 9 3.58z"
      }
    )
  ] });
}
function PinSetupView({ auth, onDone }) {
  const [pin, setPin] = reactExports.useState("");
  const [confirm, setConfirm] = reactExports.useState("");
  const [showPin, setShowPin] = reactExports.useState(false);
  const [loading, setLoading] = reactExports.useState(false);
  const [error, setError] = reactExports.useState();
  async function handleSubmit(e) {
    e.preventDefault();
    setError(void 0);
    if (pin.length < 4) {
      setError("PIN must be at least 4 characters");
      return;
    }
    if (pin !== confirm) {
      setError("PINs do not match");
      return;
    }
    setLoading(true);
    try {
      await setupPin(auth.publicKey, pin);
      onDone();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to set PIN");
    } finally {
      setLoading(false);
    }
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-col h-screen bg-black", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 flex flex-col items-center justify-center gap-6 px-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(IkaVaultLogo, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-lg font-semibold text-white mb-1", children: "Set a PIN" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-gray-500 leading-relaxed", children: "Your PIN protects the vault even if your Google account is compromised. It encrypts your key share — we never store the PIN itself." })
    ] }),
    auth.profilePicture && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "img",
        {
          src: auth.profilePicture,
          alt: "",
          className: "w-6 h-6 rounded-full"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-gray-400", children: auth.displayName })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleSubmit, className: "w-full flex flex-col gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: showPin ? "text" : "password",
            placeholder: "Choose a PIN (min. 4 characters)",
            value: pin,
            onChange: (e) => setPin(e.target.value),
            className: "w-full bg-gray-900 border border-gray-700 rounded-xl px-4 py-3\n                         text-white placeholder-gray-600 text-sm focus:outline-none\n                         focus:border-purple-500 pr-12",
            autoFocus: true
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setShowPin((v) => !v),
            className: "absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 text-xs",
            children: showPin ? "hide" : "show"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: showPin ? "text" : "password",
          placeholder: "Confirm PIN",
          value: confirm,
          onChange: (e) => setConfirm(e.target.value),
          className: "w-full bg-gray-900 border border-gray-700 rounded-xl px-4 py-3\n                       text-white placeholder-gray-600 text-sm focus:outline-none\n                       focus:border-purple-500"
        }
      ),
      error && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-red-400 text-center", children: error }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "submit",
          disabled: loading || pin.length < 4 || confirm.length < 4,
          className: "w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-500\n                       active:bg-purple-700 text-white font-medium text-sm\n                       transition-colors disabled:opacity-40 disabled:cursor-not-allowed\n                       flex items-center justify-center gap-2",
          children: loading ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" }) : "Set PIN & Open Vault"
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2 bg-purple-950/30 border border-purple-900/50 rounded-xl p-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-purple-400 mt-0.5", children: "ⓘ" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-purple-300/80 leading-relaxed", children: "The PIN encrypts your dWallet key share using PBKDF2 + AES-256-GCM. If you forget it, you will need to re-authenticate and set a new PIN (existing credentials will be re-encrypted)." })
    ] })
  ] }) });
}
function PinUnlockView({ auth, onUnlocked, onSignOut }) {
  var _a;
  const [pin, setPin] = reactExports.useState("");
  const [showPin, setShowPin] = reactExports.useState(false);
  const [loading, setLoading] = reactExports.useState(false);
  const [error, setError] = reactExports.useState();
  const [attempts, setAttempts] = reactExports.useState(0);
  async function handleSubmit(e) {
    e.preventDefault();
    if (!pin) return;
    setError(void 0);
    setLoading(true);
    try {
      await unlockWithPin(auth.publicKey, pin);
      onUnlocked();
    } catch (err) {
      const newAttempts = attempts + 1;
      setAttempts(newAttempts);
      setPin("");
      setError(
        newAttempts >= 5 ? "Too many failed attempts. Sign out and sign in again to reset." : `Wrong PIN (${newAttempts}/5 attempts)`
      );
    } finally {
      setLoading(false);
    }
  }
  const tooManyAttempts = attempts >= 5;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col h-screen bg-black", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 flex flex-col items-center justify-center gap-6 px-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(IkaVaultLogo, {}),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center gap-2", children: [
        auth.profilePicture ? /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: auth.profilePicture,
            alt: "",
            className: "w-12 h-12 rounded-full border-2 border-purple-800"
          }
        ) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-full bg-purple-900 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-white font-semibold text-lg", children: (auth.displayName ?? "?")[0].toUpperCase() }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-gray-400", children: auth.displayName ?? ((_a = auth.publicKey) == null ? void 0 : _a.slice(0, 8)) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-lg font-semibold text-white mb-1", children: "Vault locked" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-gray-500", children: "Enter your PIN to unlock" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleSubmit, className: "w-full flex flex-col gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: showPin ? "text" : "password",
              placeholder: "Enter PIN",
              value: pin,
              onChange: (e) => setPin(e.target.value),
              disabled: tooManyAttempts || loading,
              className: "w-full bg-gray-900 border border-gray-700 rounded-xl px-4 py-3\n                         text-white placeholder-gray-600 text-sm focus:outline-none\n                         focus:border-purple-500 pr-12\n                         disabled:opacity-40 disabled:cursor-not-allowed",
              autoFocus: true
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setShowPin((v) => !v),
              className: "absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 text-xs",
              children: showPin ? "hide" : "show"
            }
          )
        ] }),
        error && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-red-400 text-center", children: error }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "submit",
            disabled: loading || !pin || tooManyAttempts,
            className: "w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-500\n                       active:bg-purple-700 text-white font-medium text-sm\n                       transition-colors disabled:opacity-40 disabled:cursor-not-allowed\n                       flex items-center justify-center gap-2",
            children: loading ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" }) : "Unlock"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pb-5 text-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        onClick: onSignOut,
        className: "text-xs text-gray-600 hover:text-gray-400 transition-colors",
        children: "Sign out"
      }
    ) })
  ] });
}
function VaultView({ auth, entries, onAddNew, onSelect, onLogout }) {
  var _a, _b;
  const [search, setSearch] = reactExports.useState("");
  const filtered = entries.filter(
    (e) => e.label.toLowerCase().includes(search.toLowerCase()) || e.url.toLowerCase().includes(search.toLowerCase()) || e.username.toLowerCase().includes(search.toLowerCase())
  );
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col h-screen bg-black", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between px-4 py-3 border-b border-[#1a1a1a]", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-6 h-6 rounded bg-gradient-to-br from-purple-600 to-purple-900 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-white font-bold text-xs", children: "IV" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-white font-semibold text-sm", children: "IkaVault" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs text-gray-500", children: [
          (_a = auth.publicKey) == null ? void 0 : _a.slice(0, 4),
          "...",
          (_b = auth.publicKey) == null ? void 0 : _b.slice(-4)
        ] }),
        auth.profilePicture && /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: auth.profilePicture,
            alt: "avatar",
            className: "w-6 h-6 rounded-full"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: onLogout,
            title: "Sign out",
            className: "text-gray-600 hover:text-gray-300 transition-colors ml-1",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(LogoutIcon, {})
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-4 py-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 bg-[#111] border border-[#222] rounded-lg px-3 py-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(SearchIcon, {}),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: "text",
          placeholder: "Search credentials...",
          value: search,
          onChange: (e) => setSearch(e.target.value),
          className: "flex-1 bg-transparent text-sm text-white placeholder-gray-600 outline-none"
        }
      )
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex-1 overflow-y-auto px-4 pb-4", children: filtered.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyState, { hasEntries: entries.length > 0, onAddNew }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-col gap-2 mt-2", children: filtered.map((entry) => /* @__PURE__ */ jsxRuntimeExports.jsx(EntryCard, { entry, onClick: () => onSelect(entry) }, entry.index)) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        onClick: onAddNew,
        className: "w-full flex items-center justify-center gap-2 py-3 rounded-xl\n                     bg-purple-600 hover:bg-purple-500 active:bg-purple-700\n                     text-white font-medium text-sm transition-colors",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(PlusIcon, {}),
          "Add Credential"
        ]
      }
    ) })
  ] });
}
function EntryCard({ entry, onClick }) {
  const domain = getDomain$1(entry.url);
  const favicon = `https://www.google.com/s2/favicons?domain=${domain}&sz=32`;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "button",
    {
      onClick,
      className: "w-full flex items-center gap-3 px-3 py-3 rounded-xl\n                 bg-[#0a0a0a] hover:bg-[#111] active:bg-[#1a1a1a]\n                 border border-[#1a1a1a] hover:border-[#333]\n                 transition-colors text-left",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-9 h-9 rounded-lg bg-[#111] border border-[#222] flex items-center justify-center flex-shrink-0 overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: favicon,
            alt: "",
            className: "w-5 h-5",
            onError: (e) => {
              e.target.style.display = "none";
            }
          }
        ) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-white font-medium truncate", children: entry.label }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500 truncate", children: entry.username || domain })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronIcon, {})
      ]
    }
  );
}
function EmptyState({ hasEntries, onAddNew }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center justify-center py-16 gap-4 text-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-16 h-16 rounded-2xl bg-[#0a0a0a] border border-[#1a1a1a] flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LockIcon, {}) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-white font-medium mb-1", children: hasEntries ? "No results" : "No credentials yet" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-600", children: hasEntries ? "Try a different search" : "Add your first credential to get started" })
    ] }),
    !hasEntries && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        onClick: onAddNew,
        className: "text-sm text-purple-400 hover:text-purple-300",
        children: "Add credential →"
      }
    )
  ] });
}
function getDomain$1(url) {
  try {
    return new URL(url.startsWith("http") ? url : `https://${url}`).hostname;
  } catch {
    return url;
  }
}
const LogoutIcon = () => /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { width: "14", height: "14", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", children: [
  /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" }),
  /* @__PURE__ */ jsxRuntimeExports.jsx("polyline", { points: "16 17 21 12 16 7" }),
  /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "21", y1: "12", x2: "9", y2: "12" })
] });
const SearchIcon = () => /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { width: "14", height: "14", viewBox: "0 0 24 24", fill: "none", stroke: "#666", strokeWidth: "2", children: [
  /* @__PURE__ */ jsxRuntimeExports.jsx("circle", { cx: "11", cy: "11", r: "8" }),
  /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "m21 21-4.35-4.35" })
] });
const PlusIcon = () => /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M12 5v14M5 12h14" }) });
const ChevronIcon = () => /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { width: "14", height: "14", viewBox: "0 0 24 24", fill: "none", stroke: "#444", strokeWidth: "2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "m9 18 6-6-6-6" }) });
const LockIcon = () => /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", stroke: "#444", strokeWidth: "1.5", children: [
  /* @__PURE__ */ jsxRuntimeExports.jsx("rect", { x: "3", y: "11", width: "18", height: "11", rx: "2", ry: "2" }),
  /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M7 11V7a5 5 0 0 1 10 0v4" })
] });
function AddEntryView({ auth, onSave, onBack }) {
  const [form, setForm] = reactExports.useState({
    label: "",
    url: "",
    username: "",
    password: "",
    notes: ""
  });
  const [showPassword, setShowPassword] = reactExports.useState(false);
  const [saving, setSaving] = reactExports.useState(false);
  const [error, setError] = reactExports.useState();
  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
    if (field === "url" && !form.label) {
      try {
        const host = new URL(value.startsWith("http") ? value : `https://${value}`).hostname;
        setForm((f) => ({ ...f, url: value, label: host.replace(/^www\./, "") }));
        return;
      } catch {
      }
    }
  }
  async function handleSave() {
    if (!form.label || !form.password) {
      setError("Label and password are required");
      return;
    }
    setSaving(true);
    setError(void 0);
    try {
      const response = await new Promise((resolve) => {
        chrome.runtime.sendMessage(
          {
            type: "SAVE_CREDENTIAL",
            payload: {
              publicKey: auth.publicKey,
              label: form.label,
              url: form.url,
              username: form.username,
              password: form.password,
              notes: form.notes || void 0
            }
          },
          resolve
        );
      });
      if (response.success && response.data) {
        onSave(response.data);
      } else {
        setError(response.error ?? "Failed to save credential");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save credential");
    } finally {
      setSaving(false);
    }
  }
  function generatePassword() {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*";
    const arr = new Uint8Array(20);
    crypto.getRandomValues(arr);
    const pwd = Array.from(arr, (b) => chars[b % chars.length]).join("");
    setForm((f) => ({ ...f, password: pwd }));
    setShowPassword(true);
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col h-screen bg-black", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 px-4 py-3 border-b border-[#1a1a1a]", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: onBack, className: "text-gray-400 hover:text-white transition-colors", children: /* @__PURE__ */ jsxRuntimeExports.jsx(BackIcon$1, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-sm font-semibold text-white", children: "Add Credential" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 overflow-y-auto px-4 py-4 flex flex-col gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Field,
        {
          label: "Label",
          placeholder: "e.g. GitHub Work",
          value: form.label,
          onChange: (v) => update("label", v)
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Field,
        {
          label: "URL",
          placeholder: "https://github.com",
          value: form.url,
          onChange: (v) => update("url", v),
          type: "url"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Field,
        {
          label: "Username / Email",
          placeholder: "you@example.com",
          value: form.username,
          onChange: (v) => update("username", v),
          type: "email"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs text-gray-500 font-medium uppercase tracking-wide", children: "Password" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 bg-[#0a0a0a] border border-[#222] rounded-lg px-3 py-2.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: showPassword ? "text" : "password",
              placeholder: "Enter or generate password",
              value: form.password,
              onChange: (e) => update("password", e.target.value),
              className: "flex-1 bg-transparent text-sm text-white placeholder-gray-600 outline-none font-mono"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: () => setShowPassword((v) => !v),
              className: "text-gray-500 hover:text-gray-300",
              children: showPassword ? /* @__PURE__ */ jsxRuntimeExports.jsx(EyeOffIcon, {}) : /* @__PURE__ */ jsxRuntimeExports.jsx(EyeIcon, {})
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: generatePassword,
            className: "text-xs text-purple-400 hover:text-purple-300 text-left mt-1",
            children: "Generate strong password"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Field,
        {
          label: "Notes (optional)",
          placeholder: "Recovery codes, 2FA backup...",
          value: form.notes,
          onChange: (v) => update("notes", v),
          multiline: true
        }
      ),
      error && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-red-400", children: error })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        onClick: handleSave,
        disabled: saving,
        className: "w-full flex items-center justify-center gap-2 py-3 rounded-xl\n                     bg-purple-600 hover:bg-purple-500 active:bg-purple-700\n                     text-white font-medium text-sm transition-colors\n                     disabled:opacity-50 disabled:cursor-not-allowed",
        children: [
          saving ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(SaveIcon, {}),
          saving ? "Encrypting & saving..." : "Save to Vault"
        ]
      }
    ) })
  ] });
}
function Field({
  label,
  placeholder,
  value,
  onChange,
  type = "text",
  multiline
}) {
  const inputClass = "w-full bg-[#0a0a0a] border border-[#222] rounded-lg px-3 py-2.5 text-sm text-white placeholder-gray-600 outline-none focus:border-purple-700 transition-colors";
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-1", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs text-gray-500 font-medium uppercase tracking-wide", children: label }),
    multiline ? /* @__PURE__ */ jsxRuntimeExports.jsx(
      "textarea",
      {
        placeholder,
        value,
        onChange: (e) => onChange(e.target.value),
        rows: 3,
        className: `${inputClass} resize-none`
      }
    ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
      "input",
      {
        type,
        placeholder,
        value,
        onChange: (e) => onChange(e.target.value),
        className: inputClass
      }
    )
  ] });
}
const BackIcon$1 = () => /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { width: "18", height: "18", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "m15 18-6-6 6-6" }) });
const SaveIcon = () => /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", children: [
  /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" }),
  /* @__PURE__ */ jsxRuntimeExports.jsx("polyline", { points: "17 21 17 13 7 13 7 21" }),
  /* @__PURE__ */ jsxRuntimeExports.jsx("polyline", { points: "7 3 7 8 15 8" })
] });
const EyeIcon = () => /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { width: "14", height: "14", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", children: [
  /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" }),
  /* @__PURE__ */ jsxRuntimeExports.jsx("circle", { cx: "12", cy: "12", r: "3" })
] });
const EyeOffIcon = () => /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { width: "14", height: "14", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", children: [
  /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" }),
  /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "1", y1: "1", x2: "23", y2: "23" })
] });
function EntryDetailView({ entry, auth, onBack, onDelete }) {
  const [password, setPassword] = reactExports.useState();
  const [loadingPassword, setLoadingPassword] = reactExports.useState(false);
  const [copied, setCopied] = reactExports.useState(null);
  const [confirmDelete, setConfirmDelete] = reactExports.useState(false);
  const [deleting, setDeleting] = reactExports.useState(false);
  async function revealPassword() {
    setLoadingPassword(true);
    try {
      const response = await new Promise((resolve) => {
        chrome.runtime.sendMessage(
          {
            type: "DECRYPT_CREDENTIAL",
            payload: {
              publicKey: auth.publicKey,
              encryptedBlobId: entry.encryptedBlobId
            }
          },
          resolve
        );
      });
      if (response.success && response.data) {
        setPassword(response.data.password);
      }
    } finally {
      setLoadingPassword(false);
    }
  }
  async function copyToClipboard(text, field) {
    await navigator.clipboard.writeText(text);
    setCopied(field);
    setTimeout(() => setCopied(null), 2e3);
  }
  async function handleDelete() {
    setDeleting(true);
    try {
      await new Promise((resolve) => {
        chrome.runtime.sendMessage(
          {
            type: "DELETE_CREDENTIAL",
            payload: { publicKey: auth.publicKey, entryIndex: entry.index }
          },
          () => resolve()
        );
      });
      onDelete(entry.index);
    } finally {
      setDeleting(false);
    }
  }
  const domain = getDomain(entry.url);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col h-screen bg-black", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 px-4 py-3 border-b border-[#1a1a1a]", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: onBack, className: "text-gray-400 hover:text-white", children: /* @__PURE__ */ jsxRuntimeExports.jsx(BackIcon, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-sm font-semibold text-white truncate", children: entry.label }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500 truncate", children: domain })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 overflow-y-auto px-4 py-4 flex flex-col gap-3", children: [
      entry.url && /* @__PURE__ */ jsxRuntimeExports.jsx(
        InfoRow,
        {
          label: "URL",
          value: entry.url,
          action: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "a",
            {
              href: entry.url,
              target: "_blank",
              rel: "noreferrer",
              className: "text-purple-400 hover:text-purple-300 text-xs",
              children: "Open →"
            }
          )
        }
      ),
      entry.username && /* @__PURE__ */ jsxRuntimeExports.jsx(
        InfoRow,
        {
          label: "Username",
          value: entry.username,
          action: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: () => copyToClipboard(entry.username, "username"),
              className: "text-xs text-gray-400 hover:text-white",
              children: copied === "username" ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-green-400", children: "Copied!" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(CopyIcon, {})
            }
          )
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-gray-500 font-medium uppercase tracking-wide", children: "Password" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 bg-[#0a0a0a] border border-[#1a1a1a] rounded-lg px-3 py-2.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex-1 text-sm font-mono text-white truncate", children: password ?? "••••••••••••" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2", children: password ? /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: () => copyToClipboard(password, "password"),
              className: "text-gray-400 hover:text-white",
              children: copied === "password" ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-green-400", children: "Copied!" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(CopyIcon, {})
            }
          ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: revealPassword,
              disabled: loadingPassword,
              className: "text-xs text-purple-400 hover:text-purple-300 disabled:opacity-50",
              children: loadingPassword ? "..." : "Reveal"
            }
          ) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 pt-4 border-t border-[#111]", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-gray-700", children: [
          "Added ",
          formatDate(entry.createdAt),
          entry.updatedAt !== entry.createdAt && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            " · Updated ",
            formatDate(entry.updatedAt)
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-gray-700 mt-1 font-mono truncate", children: [
          "Walrus: ",
          entry.encryptedBlobId.slice(0, 16),
          "..."
        ] })
      ] }),
      !confirmDelete ? /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => setConfirmDelete(true),
          className: "mt-4 text-xs text-red-600 hover:text-red-400",
          children: "Delete credential"
        }
      ) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 p-3 rounded-xl border border-red-900/50 bg-red-950/20 flex flex-col gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-red-400", children: "Delete this credential? This cannot be undone." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: () => setConfirmDelete(false),
              className: "flex-1 py-2 rounded-lg bg-[#111] text-xs text-gray-400 hover:text-white",
              children: "Cancel"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: handleDelete,
              disabled: deleting,
              className: "flex-1 py-2 rounded-lg bg-red-900 text-xs text-red-200 hover:bg-red-800 disabled:opacity-50",
              children: deleting ? "Deleting..." : "Delete"
            }
          )
        ] })
      ] })
    ] })
  ] });
}
function InfoRow({ label, value, action }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-1", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-gray-500 font-medium uppercase tracking-wide", children: label }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 bg-[#0a0a0a] border border-[#1a1a1a] rounded-lg px-3 py-2.5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex-1 text-sm text-white truncate", children: value }),
      action
    ] })
  ] });
}
function getDomain(url) {
  try {
    return new URL(url.startsWith("http") ? url : `https://${url}`).hostname;
  } catch {
    return url;
  }
}
function formatDate(unix) {
  return new Date(unix * 1e3).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric"
  });
}
const BackIcon = () => /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { width: "18", height: "18", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "m15 18-6-6 6-6" }) });
const CopyIcon = () => /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { width: "14", height: "14", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", children: [
  /* @__PURE__ */ jsxRuntimeExports.jsx("rect", { x: "9", y: "9", width: "13", height: "13", rx: "2", ry: "2" }),
  /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" })
] });
function reducer(state, action) {
  switch (action.type) {
    case "SET_AUTH":
      return { ...state, auth: action.auth };
    case "SET_VIEW":
      return { ...state, currentView: action.view };
    case "SET_ENTRIES":
      return { ...state, entries: action.entries };
    case "SET_SELECTED":
      return { ...state, selectedEntry: action.entry };
    case "SET_LOADING":
      return { ...state, isLoading: action.loading };
    case "SET_ERROR":
      return { ...state, error: action.error };
    case "ADD_ENTRY":
      return { ...state, entries: [...state.entries, action.entry] };
    case "DELETE_ENTRY":
      return {
        ...state,
        entries: state.entries.map(
          (e) => e.index === action.index ? { ...e, isActive: false } : e
        )
      };
    default:
      return state;
  }
}
const initialState = {
  auth: { status: "unauthenticated" },
  currentView: "login",
  entries: [],
  isLoading: true,
  error: void 0
};
function App() {
  const [state, dispatch] = reactExports.useReducer(reducer, initialState);
  reactExports.useEffect(() => {
    checkAuth();
  }, []);
  async function checkAuth() {
    dispatch({ type: "SET_LOADING", loading: true });
    try {
      const stored = await getStoredAuth();
      if ((stored == null ? void 0 : stored.status) === "authenticated" && stored.publicKey) {
        dispatch({ type: "SET_AUTH", auth: stored });
        const pinConfigured = await isPinSet(stored.publicKey);
        if (!pinConfigured) {
          dispatch({ type: "SET_VIEW", view: "pin_setup" });
        } else if (await isUnlocked(stored.publicKey)) {
          dispatch({ type: "SET_VIEW", view: "vault" });
          await loadEntries(stored.publicKey);
        } else {
          dispatch({ type: "SET_VIEW", view: "pin_unlock" });
        }
      } else {
        dispatch({ type: "SET_VIEW", view: "login" });
      }
    } catch (err) {
      console.error("Auth check failed:", err);
      dispatch({ type: "SET_VIEW", view: "login" });
    } finally {
      dispatch({ type: "SET_LOADING", loading: false });
    }
  }
  async function handleLogin(auth) {
    dispatch({ type: "SET_AUTH", auth });
    dispatch({ type: "SET_LOADING", loading: true });
    await storeAuth(auth);
    try {
      const pinConfigured = await isPinSet(auth.publicKey);
      dispatch({ type: "SET_VIEW", view: pinConfigured ? "pin_unlock" : "pin_setup" });
    } finally {
      dispatch({ type: "SET_LOADING", loading: false });
    }
  }
  async function handlePinDone() {
    dispatch({ type: "SET_VIEW", view: "vault" });
    dispatch({ type: "SET_LOADING", loading: true });
    try {
      await loadEntries(state.auth.publicKey);
    } finally {
      dispatch({ type: "SET_LOADING", loading: false });
    }
  }
  async function loadEntries(publicKey) {
    const response = await sendMessage({
      type: "GET_USER_PROFILE",
      payload: { publicKey }
    });
    if ((response == null ? void 0 : response.success) && response.data) {
      const { entries } = response.data;
      dispatch({ type: "SET_ENTRIES", entries });
    }
  }
  async function handleAddEntry(entry) {
    dispatch({ type: "ADD_ENTRY", entry });
    dispatch({ type: "SET_VIEW", view: "vault" });
  }
  function handleSelectEntry(entry) {
    dispatch({ type: "SET_SELECTED", entry });
    dispatch({ type: "SET_VIEW", view: "detail" });
  }
  function handleDeleteEntry(index) {
    dispatch({ type: "DELETE_ENTRY", index });
    dispatch({ type: "SET_VIEW", view: "vault" });
  }
  async function handleLogout() {
    if (state.auth.publicKey) {
      await lockVault(state.auth.publicKey);
    }
    await sendMessage({ type: "LOGOUT" });
    await storeAuth({ status: "unauthenticated" });
    dispatch({ type: "SET_AUTH", auth: { status: "unauthenticated" } });
    dispatch({ type: "SET_ENTRIES", entries: [] });
    dispatch({ type: "SET_VIEW", view: "login" });
  }
  if (state.isLoading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(LoadingScreen, {});
  }
  switch (state.currentView) {
    case "login":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(LoginView, { onLogin: handleLogin });
    case "pin_setup":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(PinSetupView, { auth: state.auth, onDone: handlePinDone });
    case "pin_unlock":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(
        PinUnlockView,
        {
          auth: state.auth,
          onUnlocked: handlePinDone,
          onSignOut: handleLogout
        }
      );
    case "vault":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(
        VaultView,
        {
          auth: state.auth,
          entries: state.entries.filter((e) => e.isActive),
          onAddNew: () => dispatch({ type: "SET_VIEW", view: "add" }),
          onSelect: handleSelectEntry,
          onLogout: handleLogout
        }
      );
    case "add":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(
        AddEntryView,
        {
          auth: state.auth,
          onSave: handleAddEntry,
          onBack: () => dispatch({ type: "SET_VIEW", view: "vault" })
        }
      );
    case "detail":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(
        EntryDetailView,
        {
          entry: state.selectedEntry,
          auth: state.auth,
          onBack: () => dispatch({ type: "SET_VIEW", view: "vault" }),
          onDelete: handleDeleteEntry
        }
      );
    default:
      return /* @__PURE__ */ jsxRuntimeExports.jsx(LoginView, { onLogin: handleLogin });
  }
}
function LoadingScreen() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center justify-center h-screen bg-black gap-3", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(IkaVaultLogo, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" })
  ] });
}
function IkaVaultLogo() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 rounded-lg bg-gradient-to-br from-purple-600 to-purple-900 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-white font-bold text-sm", children: "IV" }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-white font-semibold text-lg tracking-tight", children: [
      "Ika",
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-purple-400", children: "Vault" })
    ] })
  ] });
}
async function getStoredAuth() {
  return new Promise((resolve) => {
    if (typeof chrome === "undefined" || !chrome.storage) {
      resolve(null);
      return;
    }
    chrome.storage.local.get("authState", (result) => {
      resolve(result.authState ?? null);
    });
  });
}
async function storeAuth(auth) {
  return new Promise((resolve) => {
    if (typeof chrome === "undefined" || !chrome.storage) {
      resolve();
      return;
    }
    chrome.storage.local.set({ authState: auth }, resolve);
  });
}
async function sendMessage(msg) {
  return new Promise((resolve) => {
    if (typeof chrome === "undefined" || !chrome.runtime) {
      resolve(null);
      return;
    }
    chrome.runtime.sendMessage(msg, (response) => {
      resolve(response ?? null);
    });
  });
}
const root = document.getElementById("root");
if (!root) throw new Error("#root element not found");
createRoot(root).render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(React.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(App, {}) })
);
//# sourceMappingURL=popup.js.map
